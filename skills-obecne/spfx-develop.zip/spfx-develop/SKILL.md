---
name: spfx-develop
description: Psaní samotné SPFx aplikace — struktura projektu, více web partů v jednom řešení, sdílený vzhled, property pane, úklid posluchačů, Heft toolchain a lokální ladění. Použij při psaní nebo úpravě kódu SPFx web partu či rozšíření, při "přidej další web part", při řešení scss/stylů a při migraci z gulpu na Heft.
---

# Vývoj SPFx aplikace

Nasazení řeší `spfx-ship`, výkon a vzhled `spfx-performance`. Tenhle skill je o kódu.
Ověřeno na **SPFx 1.24.1 / Heft 1.3.2** (listopad 2026) s Node **22.23.3** (celý řetězec včetně nasazení)
a **26.13.0** (`npm ci` + produkční build web partu). `engines` šablony: `>=22.14.0 <23 || >=24 <25 || >=26 <27`.
Past: starší globální generátor (např. z homebrew) přebije `npm install -g --prefix X`; nastav npm
prefix tak, aby `npm root -g` ukazoval do X, a zkontroluj `Generator@1.24.1` v banneru `yo`.

## Volba frameworku

`--framework none` je výchozí doporučení, dokud nevíš, že potřebuješ React:

- bez frameworku vyjde web part řádově v **jednotkách až desítkách kB**
- s Reactem si přibíráš **vazbu na přesnou verzi** (SPFx 1.24 = React **18.3.1 exact**,
  `--save-exact`; jiná verze = tiché runtime selhání bez chyby při buildu)

## Víc komponent v jednom řešení

Druhý a další web part přidáš do existujícího projektu:

```bash
yo @microsoft/sharepoint --component-type webpart --component-name <Jmeno> --framework none --skip-install
```

Generátor dopíše do `config/config.json` nový bundle a vyrobí manifest s novým GUID.
Jedno `.sppkg` pak nese všechny — jeden deploy, jeden install, víc web partů.

**Sdílený vzhled dej do `src/` nad web party**, ne do každého zvlášť:

```
src/theme.ts                       palety, <style> blok, inline SVG ikony
src/webparts/<a>/<A>WebPart.ts
src/webparts/<b>/<B>WebPart.ts
```

Styl injektuj jako jeden `<style>` blok **scopovaný pod vlastní root třídu**, ať nepřeteče
do SharePointu. Ikony drž jako inline SVG — externí ikonový font je v zamčené síti riziko
a další request (viz `spfx-performance`).

## Povinný úklid

Web part se v SharePointu **může přerenderovat víckrát**. Co zaregistruješ v `render()`,
odregistruj v `onDispose()` — jinak ti běží několik instancí najednou:

```ts
protected onDispose(): void {
  if (this.raf) { cancelAnimationFrame(this.raf); }
  if (this.onKey) { window.removeEventListener('keydown', this.onKey); }
  super.onDispose();
}
```

Platí pro `requestAnimationFrame`, posluchače na `window`/`document`, timery, observery
a websockety.

## Property pane

Scaffold dá funkční kostru; drž se jí. Řetězce ber ze `strings` modulu
(`<Jmeno>WebPartStrings`) — nepsat je natvrdo, jinak padne lokalizace a build hlásí
nepoužitý import.

## Manifest: dvě pole, na kterých záleží

```jsonc
"requiresCustomScript": false,   // nech false — true = komponenta zmizí na NoScript webech
"supportedHosts": ["SharePointWebPart", "TeamsPersonalApp", "TeamsTab", "SharePointFullPage"]
```

`SharePointFullPage` je podmínka pro Single Part App Page. Scaffold 1.23+ obojí generuje
správně — ověřeno, že se mezi 1.23.2 a 1.24.1 defaulty nezměnily.

## Heft (od SPFx 1.22)

| | gulp (≤ 1.21.1) | Heft (1.22+) |
|---|---|---|
| konfigurace | `gulpfile.js` | `heft.json`, `rig.json`, `typescript.json` |
| dev | `gulp serve` | `npm run start` (`heft start --clean`) |
| produkce | `gulp bundle --ship` + `gulp package-solution --ship` | `npm run build` |
| úpravy webpacku | zásah do generované konfigurace | Heft plugin / Webpack Patch plugin, nebo eject |

- **Heft neinstaluješ** — přijde s rigem, verzi drží SPFx.
- `config/config.json` (`bundles`, `externals`, `localizedResources`) **zůstává** i pod Heftem.
- Od **1.24 je gulp nepodporovaný**; `--use-gulp` bylo jen v 1.22/1.23. Migrace = přepsat
  customizace a CI příkazy, ne jen zvednout verze.
- `eject-webpack` je jednosměrka — přebíráš vlastnictví konfigurace.

## Ladění

- `npm run start` → local workbench; hosted workbench na `<tenant>/_layouts/15/workbench.aspx`
  potřebuje, aby se do něj daly načíst assety.
- Pro věci, které se projeví až na ostré stránce (chrome, theming, kontext uživatele),
  je rychlejší **nasadit a otevřít** než ladit ve workbenchi — `spfx-ship` má celý řetězec.
- Konzoli čti i když appka vypadá v pořádku; SharePoint do ní sype vlastní šum,
  ale tvoje chyby se v něm dají najít.

## Související

`spfx-ship` · `spfx-performance` · `sharepoint-tenant-recon` · `m365-cli-safe`
