// @ts-check
// KANONICKÝ ZDROJ: skill ppf-browsermagic (template/auth-refresh.mjs). @sessionstore-version 0.9.0
// (verze pluginu, ve které se šablony naposledy změnily; stejná jako v auth-state.mjs)
//
// Standalone refresher pro node projekty BEZ @playwright/test (jen balíček `playwright`).
// Drží SPO session naživu tak, aby ji konzumující `.mjs` skripty jen reuse-ly:
//   node auth-refresh.mjs           # obvykle reuse / tichý headless refresh, bez MFA
//   node auth-refresh.mjs           # když je state mrtvý → otevře headed prohlížeč (MFA)
//
// Jediný zapisovač do storu (P1→P4): refresh + atomický re-save.
// SITE_URL nastav per repo (env nebo default níž). Kde leží state určuje resolveAuthPaths
// (auth-state.mjs): 1) SPO_AUTH_DIR, 2) existující sdílený ~/.config/spo-auth, 3) <cwd>/.auth.
// State je state-<tenant>.json. Spouštěj z project rootu (kvůli node_modules a .auth/).
//
// Prohlížeč: chrome → msedge → přibalené Chromium Playwrightu (pořadí a důvod viz
// BROWSER_CHANNELS v auth-state.mjs). Přihlášení poznáme podle HOSTNAME cílového webu, ne
// podle cesty, takže funguje i kořenový web a /teams/.
//
// Import je bez vedlejších efektů: modul jen exportuje `main()` a `resolveSiteUrl()`;
// spustí se až když je to hlavní soubor (`node auth-refresh.mjs`).

import * as fs from 'fs';
import * as path from 'path';
import { pathToFileURL } from 'url';
import {
  resolveAuthPaths,
  shouldReuse,
  trySilentRefresh,
  launchBrowser,
  isLoggedInUrl,
  writeStateAtomic,
  assertKmsi,
  fedAuthDaysLeft,
} from './auth-state.mjs';

const DEFAULT_SITE_URL = 'https://contoso.sharepoint.com/sites/Dev'; // ← per-repo default

/**
 * Cílový web: env SITE_URL, jinak per-repo default.
 * @param {NodeJS.ProcessEnv} [env]
 * @returns {string}
 */
export function resolveSiteUrl(env = process.env) {
  return env.SITE_URL || DEFAULT_SITE_URL;
}

/**
 * Celý refresh. Vrací exit kód (0 = session platná), vyhazuje při neřešitelné chybě.
 * @param {{ siteUrl?: string, cwd?: string }} [opts]
 * @returns {Promise<number>}
 */
export async function main(opts = {}) {
  const SITE_URL = opts.siteUrl ?? resolveSiteUrl();
  // path.join, ne ruční lomítko — jinak na Windows vznikne `C:\repo/.auth` (míchané separátory).
  const REPO_AUTH_DIR = path.join(opts.cwd ?? process.cwd(), '.auth');
  const { tenant, authFile: AUTH_FILE } = resolveAuthPaths(SITE_URL, REPO_AUTH_DIR);

  // P1 — reuse podle reálné cookie-expiry.
  const decision = shouldReuse(AUTH_FILE);
  if (decision.reuse) {
    console.log(`[${tenant}] Reuse — ${decision.reason}. (${AUTH_FILE})`);
    return 0;
  }
  console.log(`[${tenant}] Obnova — ${decision.reason}.`);

  // dynamický import: reuse cesta i import modulu nepotřebují nainstalovaný `playwright`
  const { chromium } = await import('playwright');

  // P4 — headless-first: tichý refresh, teprve při selhání headed login.
  if (await trySilentRefresh(chromium, AUTH_FILE, SITE_URL)) {
    console.log(`[${tenant}] Tichý headless refresh OK, headed login není potřeba. Session do ${fedAuthDaysLeft(AUTH_FILE)} d.`);
    return 0;
  }
  console.log(`[${tenant}] Tichý refresh selhal (device auth / prázdný state) — otevírám prohlížeč.`);

  // Headed fallback — viditelný prohlížeč (chrome → msedge → Chromium), uživatel dokončí MFA.
  const { browser, channel } = await launchBrowser(chromium, { headless: false });
  console.log(`[${tenant}] Prohlížeč: ${channel ?? 'přibalené Chromium'}.`);
  try {
    const ctx = await browser.newContext({
      ...(fs.existsSync(AUTH_FILE) ? { storageState: AUTH_FILE } : {}),
      ignoreHTTPSErrors: true,
    });
    const page = await ctx.newPage();
    await page.goto(SITE_URL, { waitUntil: 'domcontentloaded', timeout: 60_000 });

    if (!isLoggedInUrl(page.url(), SITE_URL)) {
      console.log(`\n=== PŘIHLAS SE DO ${tenant.toUpperCase()} V OTEVŘENÉM PROHLÍŽEČI ===\n`);
      // P2 — zpevněný KMSI klik + čekání na návrat na host cílového webu.
      await page.locator('#idSIButton9, button:has-text("Yes")').first()
        .click({ timeout: 15_000 })
        .catch(() => console.warn('[KMSI] dialog „Stay signed in?" nedorazil do 15 s (může být OK).'));
      await page.waitForURL((url) => isLoggedInUrl(url.href, SITE_URL), { timeout: 300_000 });
    }
    await page.waitForLoadState('load');
    await page.waitForTimeout(3000);

    // P3/P5 — atomický zápis + P2 tvrdá kontrola KMSI.
    const state = await ctx.storageState();
    assertKmsi(state);
    writeStateAtomic(AUTH_FILE, state);
    console.log(`[${tenant}] Auth state uložen atomicky do ${AUTH_FILE}. Session do ${fedAuthDaysLeft(AUTH_FILE)} d.`);
    return 0;
  } finally {
    await browser.close();
  }
}

// Spusť jen jako hlavní modul (ne při `import`). realpath kvůli symlinkům v cestě.
const isMain = (() => {
  try {
    return !!process.argv[1] && import.meta.url === pathToFileURL(fs.realpathSync(process.argv[1])).href;
  } catch {
    return false;
  }
})();
if (isMain) {
  main().then(
    (code) => process.exit(code),
    (err) => {
      console.error(err);
      process.exit(1);
    },
  );
}
