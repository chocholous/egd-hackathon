// @ts-check
// KANONICKÝ ZDROJ: skill ppf-browsermagic (template/auth-state.mjs). @sessionstore-version 0.9.0
// (@sessionstore-version = verze pluginu ppf-browsermagic, ve které se obě šablony naposledy
//  změnily; v auth-state.mjs i auth-refresh.mjs je vždy stejná a nikdy vyšší než verze pluginu —
//  hlídá to skills/ppf-browsermagic/dev/test-auth.mjs. Kit podle ní pozná, že má kopii zastaralou.)
//
// Sdílené jádro správy SPO auth-session pro Playwright. Do repa se KOPÍRUJE (žádná runtime
// závislost, žádný SPOF). Needituj lokální kopii — uprav kanonický a překopíruj.
//
// Jeden canon pro OBA světy: `chromium` se injektuje jako parametr, takže modul nemá žádný
// playwright import a jde konzumovat z:
//   • @playwright/test suit (.ts)   → import { chromium } from '@playwright/test'
//   • standalone node (.mjs)        → import { chromium } from 'playwright'
// (empiricky ověřeno: .ts wrapper i node standalone importují týž .mjs canon).
//
// Typová kontrola bez .ts: `// @ts-check` + JSDoc níže (spustí ji editor/tsc --noEmit).
// Empirie za čísly: floormap-demo/research/results/stream-G-spo-session-lifetime.md.

import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';

/** SPO session cookies, jejichž reálná expiry řídí platnost (ne mtime souboru). */
const SPO_COOKIES = ['FedAuth', 'rtFa'];
/** ESTSAUTHPERSISTENT sám o sobě stačí k tichému re-auth (empiricky ověřeno) — fallback. */
const ESTS_PERSISTENT = 'ESTSAUTHPERSISTENT';
/** Rezerva před skutečnou expirací, aby běh nikdy nechytil cookie těsně před vypršením. */
export const SAFETY_MARGIN_MS = 60 * 60 * 1000; // 1 h
/** Strop stáří souboru (safety-net na device-auth freshness). Pod naměřenou 5denní hranicí. */
export const MAX_AGE_MS = 96 * 60 * 60 * 1000; // 4 d

/**
 * @typedef {{ name: string, expires: number }} Cookie
 * @typedef {{ cookies: Cookie[], origins?: unknown[] }} State
 */

/** Centrální sdílený store — OPT-IN pouhou existencí tohoto adresáře. */
export const CENTRAL_AUTH_DIR = path.join(os.homedir(), '.config', 'spo-auth');

/** Je state v souboru ještě použitelný (cookie platná s rezervou)? */
function stateUsable(file) {
  const until = spoSessionValidUntil(file);
  return until !== null && until - Date.now() > SAFETY_MARGIN_MS;
}

/**
 * P5 — kde leží state. Pořadí:
 *   1) `SPO_AUTH_DIR` (explicitní override — vyhrává nad vším),
 *   2) centrální `~/.config/spo-auth/` **pokud adresář existuje** (opt-in). Když je centrální
 *      state neplatný a lokální platný, jednorázově se lokální zmigruje do centrálního
 *      (tím store nasype první projekt a ostatní ho pak reuse-nou bez MFA),
 *   3) lokální `<repo>/.auth/`.
 * Když centrální adresář NEEXISTUJE, chování je bit-za-bit původní lokální — žádná tvrdá
 * závislost, vypnutí storu (přejmenování adresáře) nic nerozbije.
 * @param {string} siteUrl
 * @param {string} repoAuthDir
 * @returns {{ tenant: string, authDir: string, authFile: string, source: 'env'|'central'|'local' }}
 */
export function resolveAuthPaths(siteUrl, repoAuthDir) {
  const tenant = new URL(siteUrl).hostname.split('.')[0];
  const name = `state-${tenant}.json`;

  if (process.env.SPO_AUTH_DIR) {
    const authDir = path.resolve(process.env.SPO_AUTH_DIR);
    return { tenant, authDir, authFile: path.join(authDir, name), source: 'env' };
  }

  const localFile = path.join(repoAuthDir, name);
  if (fs.existsSync(CENTRAL_AUTH_DIR)) {
    const centralFile = path.join(CENTRAL_AUTH_DIR, name);
    // Migrace: centrální nepoužitelný + lokální použitelný → zasej lokální do centrálního.
    if (!stateUsable(centralFile) && stateUsable(localFile)) {
      try {
        writeStateAtomic(centralFile, JSON.parse(fs.readFileSync(localFile, 'utf8')));
        console.log(`[${tenant}] centrální store nasazen z lokálního state → ${centralFile}`);
      } catch {
        /* migrace je best-effort; při selhání se prostě použije centrální/re-auth cesta */
      }
    }
    return { tenant, authDir: CENTRAL_AUTH_DIR, authFile: centralFile, source: 'central' };
  }

  return { tenant, authDir: repoAuthDir, authFile: localFile, source: 'local' };
}

/**
 * Pořadí prohlížečů pro spuštění. Zdůvodnění:
 *   1) 'chrome'  — reálný nainstalovaný Google Chrome: keychain ACL už je udělené (cookies
 *                  šifrované klíčem z keychainu se čtou bez dotazu) a nemění se s verzemi PW.
 *   2) 'msedge'  — také reálný nainstalovaný Chromium prohlížeč (na Windows je vždy; i na
 *                  firemním Macu bývá), stejný engine a stejné SPO/Entra chování jako Chrome.
 *   3) null      — přibalené Chromium Playwrightu (bez `channel`): vyžaduje
 *                  `npx playwright install chromium`; je poslední, protože je to jiný profil/
 *                  keychain identita, takže device-auth (DeviceAuthTls) častěji vynutí MFA.
 * `channel` je v Playwright API řetězec ('chrome', 'msedge', …); vynechání = přibalené Chromium.
 */
export const BROWSER_CHANNELS = Object.freeze(['chrome', 'msedge', null]);

/**
 * Spusť první dostupný prohlížeč z BROWSER_CHANNELS. Když nejde spustit žádný, vyhodí chybu
 * se souhrnem všech pokusů (ať je vidět proč).
 * @param {import('playwright').BrowserType} chromium INJEKTOVANÝ (z '@playwright/test' i 'playwright')
 * @param {{ headless: boolean }} opts
 * @param {readonly (string|null)[]} [channels]
 * @returns {Promise<{ browser: import('playwright').Browser, channel: string | null }>}
 */
export async function launchBrowser(chromium, opts, channels = BROWSER_CHANNELS) {
  const errors = [];
  for (const channel of channels) {
    try {
      const browser = await chromium.launch({ headless: opts.headless, ...(channel ? { channel } : {}) });
      return { browser, channel };
    } catch (e) {
      errors.push(`${channel ?? 'bundled chromium'}: ${String(e && e.message ? e.message : e).split('\n')[0]}`);
    }
  }
  throw new Error(`Nepodařilo se spustit žádný prohlížeč (${errors.join(' | ')}). Nainstaluj Chrome nebo Edge, nebo spusť: npx playwright install chromium`);
}

/**
 * Je stránka na hostu cílového webu (tj. přihlášení dokončeno)? Porovnává HOSTNAME tenantu,
 * ne cestu — funguje i pro kořenový web, /teams/ i /sites/. Přihlašovací stránky
 * (login.microsoftonline.com apod.) mají jiný host, takže neprojdou.
 * @param {string} pageUrl
 * @param {string} siteUrl
 * @returns {boolean}
 */
export function isLoggedInUrl(pageUrl, siteUrl) {
  try {
    return new URL(pageUrl).hostname.toLowerCase() === new URL(siteUrl).hostname.toLowerCase();
  } catch {
    return false;
  }
}

/**
 * P1 — do kdy je SPO session platná podle reálné cookie expiry (ms epoch), nebo null.
 * @param {string} file
 * @returns {number | null}
 */
export function spoSessionValidUntil(file) {
  try {
    /** @type {State} */
    const st = JSON.parse(fs.readFileSync(file, 'utf8'));
    const spo = st.cookies.filter((c) => SPO_COOKIES.includes(c.name) && c.expires > 0).map((c) => c.expires * 1000);
    if (spo.length) return Math.min(...spo);
    const ests = st.cookies.find((c) => c.name === ESTS_PERSISTENT);
    return ests && ests.expires > 0 ? ests.expires * 1000 : null;
  } catch {
    return null;
  }
}

/**
 * P1 — rozhodnutí reuse vs obnova. Dvě nezávislé podmínky, obě musí platit:
 *  1) cookie má dost zbytkové platnosti (msLeft > SAFETY_MARGIN) — primární brána,
 *  2) soubor není starší než MAX_AGE — safety-net na device-auth freshness.
 * mtime tady NENÍ proxy za platnost cookie (to je (1)) — je to jen strop stáří.
 * @param {string} file
 * @returns {{ reuse: boolean, reason: string, validUntil: number | null }}
 */
export function shouldReuse(file) {
  const validUntil = spoSessionValidUntil(file);
  if (!validUntil) return { reuse: false, reason: 'žádný platný state / SPO cookie', validUntil: null };
  const msLeft = validUntil - Date.now();
  if (msLeft <= SAFETY_MARGIN_MS) {
    return { reuse: false, reason: `cookie vyprší za ${(msLeft / 86_400_000).toFixed(2)} d (pod rezervou)`, validUntil };
  }
  let ageMs = 0;
  try {
    ageMs = Date.now() - fs.statSync(file).mtimeMs;
  } catch {
    return { reuse: false, reason: 'state nelze statovat', validUntil };
  }
  if (ageMs > MAX_AGE_MS) {
    return { reuse: false, reason: `state starý ${(ageMs / 86_400_000).toFixed(2)} d (> MAX_AGE) — vynucuji silent refresh`, validUntil };
  }
  return { reuse: true, reason: `platné ${(msLeft / 86_400_000).toFixed(2)} d, stáří ${(ageMs / 86_400_000).toFixed(2)} d`, validUntil };
}

/**
 * P2 — ověř, že KMSI zabralo: ESTSAUTHPERSISTENT musí být perzistentní (expires > 0).
 * @param {State} state
 */
export function assertKmsi(state) {
  const ests = state.cookies.find((c) => c.name === ESTS_PERSISTENT);
  if (!ests || ests.expires <= 0) {
    throw new Error(
      'KMSI nezabralo — session je neperzistentní (ESTSAUTHPERSISTENT chybí nebo je session-cookie). ' +
        'State by vydržel jen do zavření prohlížeče. Zkontroluj klik na „Stay signed in? → Yes".',
    );
  }
}

/**
 * P3/P5 — atomický zápis state (tmp + rename), mode 0600. Bezpečné pro souběžné běhy.
 *
 * PLATFORMNÍ VÝHRADA (Windows): `mode` je no-op — Windows používá ACL, ne POSIX bity,
 * takže záruka 700/600 platí jen na POSIX. Soubor tam zdědí ACL rodičovského adresáře
 * (typicky uživatelský profil). Je to živá session včetně MSAL token cache — kdo chce na
 * Windows tvrdou záruku, musí ACL nastavit sám (icacls) nebo store umístit přes SPO_AUTH_DIR.
 * Atomicita `rename` je POSIX vlastnost; na Windows jde o MoveFileEx a přepis zamčeného
 * cíle (antivir, paralelní běh) může skončit EPERM — neověřeno na reálném Windows stroji.
 * @param {string} file
 * @param {unknown} state
 */
export function writeStateAtomic(file, state) {
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 }); // mode: POSIX only
  const tmp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(state), { mode: 0o600 }); // mode: POSIX only
  fs.renameSync(tmp, file); // atomický na POSIX; Windows = MoveFileEx
}

/**
 * Kolik dní zbývá SPO session — pro čitelný log.
 * @param {string} file
 * @returns {string}
 */
export function fedAuthDaysLeft(file) {
  const until = spoSessionValidUntil(file);
  return until ? ((until - Date.now()) / 86_400_000).toFixed(2) : 'n/a';
}

/**
 * P4 — tichý headless re-auth. `chromium` INJEKTOVANÝ (z '@playwright/test' i 'playwright').
 * Otevře headless kontext ze starého state, jednou naviguje na SPO a ověří, že reálně
 * přistál na hostu cílového webu (isLoggedInUrl). Když ano, přeuloží obnovené cookies atomicky (rolling refresh) a
 * vrátí true. Když skončí na login.microsoftonline (typicky DeviceAuthTls), vrátí false →
 * volající spustí headed interaktivní login.
 * @param {import('playwright').BrowserType} chromium
 * @param {string} authFile
 * @param {string} siteUrl
 * @returns {Promise<boolean>}
 */
export async function trySilentRefresh(chromium, authFile, siteUrl) {
  if (!fs.existsSync(authFile)) return false;
  let browser;
  try {
    // chrome → msedge → přibalené Chromium (pořadí viz BROWSER_CHANNELS)
    ({ browser } = await launchBrowser(chromium, { headless: true }));
  } catch {
    return false; // žádný prohlížeč nejde spustit → nech to na headed fallbacku (ten vyhodí srozumitelnou chybu)
  }
  try {
    const ctx = await browser.newContext({ storageState: authFile, ignoreHTTPSErrors: true });
    const page = await ctx.newPage();
    await page.goto(siteUrl, { waitUntil: 'domcontentloaded', timeout: 45_000 }).catch(() => {});
    await page.waitForTimeout(2000);
    const landed = isLoggedInUrl(page.url(), siteUrl);
    if (landed) writeStateAtomic(authFile, await ctx.storageState()); // rolling refresh: ESTS→+90d, SPO→+5d
    await ctx.close();
    return landed;
  } catch {
    return false;
  } finally {
    await browser.close();
  }
}
