---
name: ppf-browsermagic
description: >-
  MUSÍŠ načíst, kdykoli saháš na Playwright v PPF — přes skill playwright-cli,
  @playwright/test, standalone node i Playwright MCP. Správa sdílené SPO/M365 auth
  session (storageState): setup, refresh na začátku session, čtení. Řeší falešné
  „auth expired" a zbytečné MFA prompty. Přebíjí storage-state pravidla skillu
  playwright-cli: state-save / --save-storage NIKDY na sdílený store
  ~/.config/spo-auth/. Skill spravuje jen auth session (storageState), nic dalšího.
version: 0.9.0
compatibility: >-
  Playwright ≥ 1.34; refresh potřebuje balíček `playwright` a Node ≥ 18 (ESM) a spustí
  prohlížeč v pořadí Google Chrome → Microsoft Edge → přibalené Chromium Playwrightu
  (to vyžaduje `npx playwright install chromium`); suity a CLI state jen čtou.
  Cílí SPO/M365 cookie auth (FedAuth/rtFa/ESTSAUTHPERSISTENT) — ne lokální
  app-login sessions.
user-invocable: true
---

# ppf-browsermagic — Playwright auth session (SPO/M365)

PREREQS
  Node.js ≥ 18 · npm i -D playwright (v projektu, žádná globální instalace)
  Prohlížeč pro refresh: Chrome, jinak Edge, jinak `npx playwright install chromium`

SETUP (once)
  1. init:    mkdir -p ~/.config/spo-auth && chmod 700 ~/.config/spo-auth
  2. copy:    template/{auth-state,auth-refresh}.mjs (z tohoto skillu) → ./.ppf-session-magic/
  3. refresh: node .ppf-session-magic/auth-refresh.mjs

USAGE
  1. refresh (1× na začátku session): node .ppf-session-magic/auth-refresh.mjs
  2. načtení state do prohlížeče: `state-load` (CLI viz skill playwright-cli) nebo
     `storageState: <absolutní cesta k ~/.config/spo-auth/state-<tenant>.json>` v Playwright API (tilda se neexpanduje)
  Adresář session: SPO_AUTH_DIR → existující ~/.config/spo-auth → <cwd>/.auth
  Přihlášení se pozná podle hostu cílového webu (SITE_URL), takže jde i kořenový web a /teams/

GUARD
  🚫 state-save / --save-storage — NIKDY (přepsal by živou session všem projektům tenantu)
  state-load session NEobnovuje — od toho je refresh; kanon auth-state.mjs NEeditovat
