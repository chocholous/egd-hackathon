# Icons

One set, one configuration, no drawn pictograms: **Material Symbols Outlined**. Never mix Outlined with Rounded or Sharp, never hand-roll SVG icons, never use emoji as an icon.

## Axis settings

| Axis | Value | Note |
|---|---|---|
| `FILL` | `0` default, `1` only on the active navigation item | A filled icon is a state, not decoration. Always 0 in tables and toolbars. |
| `wght` | `400` | Matches body text. `300` above 32 px, never `500`. |
| `GRAD` | `0` on light, `25` on navy surfaces | Small optical correction in app bar and dark bar only. |
| `opsz` | same number as `font-size` | 20 for 20 px, 24 for 24 px. Never scale an icon without changing `opsz`. |

```css
font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
```

## Sizes

| Size | Use |
|---|---|
| 18 px | Inside text, badges, inline hints |
| 20 px | Rows, lists, inputs, list leading icons |
| 22 px | App bar, toolbars, dark bar |
| 30 px | Empty states (colour `#B8C4D0`) |

The interactive target is always 40–44 px regardless of glyph size.

## Colour

| Colour | Use |
|---|---|
| `#002C5A` navy | Default for every icon |
| `#4A6480` | Secondary context, inactive tree caret, metadata |
| `#9A5E37` copper | Selected state or the one accented action only |
| `#B8C4D0` | Disabled, empty state, decorative rail |

On navy or dark surfaces reduce opacity to `.85` instead of changing colour.

## Canonical vocabulary

One meaning = one icon across all apps.

**Navigation and structure** — `account_tree` organisational structure · `groups` team, meeting room · `meeting_room` space, floor · `place` desk · `menu` main navigation · `chevron_right` drill in · `expand_more` / `chevron_right` tree open / closed · `my_location` locate on plan

**Content** — `search` search · `tune` scope and search settings · `description` document · `picture_as_pdf` PDF · `table_chart` spreadsheet · `cloud` OneDrive · `edit_note` content editor · `attach_file` attachment · `image` image block · `movie` video block · `format_quote` quote block · `title` subheading block · `notes` paragraph block · `drag_indicator` reorder handle

**Decision and status** — `task_alt` approval queue · `check` approved, done · `close` rejected, dismiss · `hourglass_empty` awaiting decision · `priority_high` needs attention · `lock` restricted access · `gavel` rule, mandate · `shield` compliance · `topic` topic · `person` person · `delete` remove · `more_vert` row menu · `add` primary create action

**Building services (floor plans)** — `elevator` · `stairs` · `wc` · `local_cafe` kitchenette · `settings` technical room

**Communication** — `mail` e-mail · `chat` chat · `notifications` notifications · `notifications_active` announcement · `campaign` news · `article` article · `school` course

**Briefs and chat widgets** — `share` share as an artifact · `open_in_new` open in the source app (Outlook, Teams, Excel) · `reply` prepared reply draft · `event` meeting, calendar · `grid_view` priority matrix · `checklist` action items · `lightbulb` idea · `info` remark, quality note · `alt_route` second-order effect

**Empty and error states** — `inbox` empty queue · `search_off` no results

## Rules

✓ Icon supports text; a standalone icon only for universal actions (`search`, `close`, `more_vert`, `add`) and always with `aria-label`.
✓ Icon button target 40–44 px even when the glyph is 20 px.
✓ In the dark bar and app bar lower opacity rather than change hue.
✓ Add a new icon to this list before using it, so the vocabulary stays single-valued.

✗ Copper never marks a content type — only a selected state or one action.
✗ No icon-only rows in tables: every action needs a label or the bulk bar.
✗ No decorative illustrations built from icons.
✗ No second icon style, no icon fonts other than Material Symbols.
