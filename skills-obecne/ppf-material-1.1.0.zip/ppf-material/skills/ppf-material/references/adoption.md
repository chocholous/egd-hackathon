# Adoption matrix — Material Design 3

Dividing line: **adopt mechanics and specifications, reject the visual signature.**

## Adopt unchanged

Technical specifications that do not collide with the brand. Copy including the numbers.

| Item | Note |
|---|---|
| Motion tokens (duration + easing) | short 100–200 ms, medium 250–400 ms, emphasized decelerate/accelerate — without the overshoot variants |
| 48 dp touch target | 44 px minimum here, 8 px between targets, also for icon buttons with a 20 px glyph |
| List item specification | One-, two- and three-line variants at 56 / 72 / 88 px with leading and trailing slots |
| Component states | enabled, hover, focus, pressed, dragged, disabled (38 % opacity) — no state skipped |
| Focus and keyboard handling | Visible 2 px focus ring with 2 px offset, Tab/Shift-Tab, Esc closes a dialog, Enter confirms the primary action |
| Progress indicators | Linear for known progress, circular only for indeterminate; never both on one screen |
| Snackbar rules | One message, at most one action, 4–10 s, never for errors requiring a decision |
| Contrast minima | Text 4.5:1, large text and icons 3:1 — hence copper text `#9A5E37` |
| Density axis | Comfortable default, compact for dense data screens |

## Adopt with modification

Mechanics yes, shape and colour per PPF. This is where the system's look is decided.

| Item | Modification |
|---|---|
| Top app bar variants | Use small and medium (collapsing). No large, no centre-aligned — a centred title is not editorial |
| Navigation drawer / rail | Rail for 4–7 sections, drawer for portals. Never bottom navigation — we are desktop-first |
| Chip types | Filter and input chips only, in our copper selected logic. Assist and suggestion chips become text buttons |
| Bottom sheet | Becomes a right side sheet. The only thing arriving from the bottom is the bulk action bar |
| Three card types | Elevated / filled / outlined kept — filled is copper wash `#F0E1D7`, outlined is 1 px `#B8C4D0` |
| Segmented button | View switcher (Plan / Structure) inside a pill container with navy text |
| Menu and tooltip | Menu at elevation 3 with navy shadow; plain dark `#121733` tooltip, no rich variant with buttons |
| Search view | Docked in the app bar. Full-screen search on mobile only |
| Badge | Numeric badge as a neutral pill, not a red circle — red is reserved for escalation |
| Dialogs | Basic dialog for confirmation; full-screen dialog only for multi-step forms. Destructive actions require an audit comment |
| Elevation levels | Same 0–5 hierarchy, recomputed from navy instead of black |
| State layers | Same 4/8/12 % opacities, but selected is copper plus a left marker instead of a primary-container fill |

## Do not adopt

Material's visual signature. Each of these would dissolve the PPF identity.

| Item | Why |
|---|---|
| Dynamic color and tonal palettes | Colours are not generated from a seed. The palette is fixed and legally protected |
| Surface tint overlay for elevation | Elevation is carried by a navy shadow, not by tinting the surface with the primary colour |
| Ripple | Replaced by a static 12 % state layer. A wave from the click point is too consumer |
| Shape morph / fully rounded shapes | Full radius only chip, switch, avatar, FAB. Buttons stay at 8 px |
| Roboto / Google Sans | Typography is PPF Display + Neue Haas Unica. Always |
| Baseline colour roles | No primary/secondary/tertiary containers — map to navy, copper, cream and stop |
| FAB menu / expanding action fans | One primary action per screen; a fan of buttons signals unresolved information architecture |
| Bottom app bar | Actions belong in the header or next to the content, not at the window's bottom edge |
| Material illustrations and empty-state art | Empty states are one icon plus one sentence |

## When a pattern is not listed

Ask two questions. Does it specify **behaviour** (timing, states, keyboard, sizes)? Adopt it. Does it specify **appearance** (colour derivation, tint, shape language, imagery)? Rebuild it from `references/tokens.md`. If both, adopt the behaviour and rebuild the appearance — and add the decision to this file.
