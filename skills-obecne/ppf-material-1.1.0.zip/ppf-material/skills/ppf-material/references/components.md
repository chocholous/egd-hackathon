# Components

Every spec below is implemented in `examples/PPF_Material.dc.html`; the app examples show them in product context. Copy from there rather than re-deriving.

## Buttons

Priority order: **filled navy → tonal copper wash → outlined → text**. One filled button per view.

| Variant | Spec |
|---|---|
| Filled | h 44, radius 8, `#002C5A` / `#F6EFE2`, hover `#001A36` + elevation 1 |
| Tonal | h 44, radius 8, `#F0E1D7` / `#9A5E37`, hover `#E6D2C4` |
| Outlined | h 44, radius 8, 1px `#B8C4D0`, hover navy 4 % + border `#002C5A` |
| Text | h 44, padding 0 16, `#9A5E37`, hover copper 8 % |
| Icon button | 44 × 44, radius full, glyph 20–22, hover navy 6 %, `aria-label` required |
| FAB | h 56, radius full (extended: radius 16, padding 0 22), copper `#B06F41` / white, elevation 2 |

FAB is the only full copper surface on a screen. If a screen has no FAB, copper appears only as text button or selected state.

## Text fields

Two variants, one per context — never mixed on the same screen.

- **Filled** — h 48, radius 8 8 0 0, background navy 4 %, bottom border 2px `#B8C4D0` → copper on focus. For dense data screens and search.
- **Outlined** — h 48, radius 8, 1px `#B8C4D0` → `#002C5A` on focus (inset ring, no glow). For forms and detail editing.

Label above the field (12 px `#4A6480`), helper text below (12 px `#808080`). Error state: border `#A33B2B`, helper text `#A33B2B`, never a red fill. Numeric fields use JetBrains Mono.

## Selection controls

- **Switch** — 52 × 32, knob 24, off = transparent with `#B8C4D0` border and grey knob, on = navy fill with cream knob. 160 ms. Tokens: `size.switch_track_width` / `size.switch_track_height` / `size.switch_thumb` / `motion.duration.switch` (CSS `--w-switch`, `--h-switch`, `--thumb-switch`, `--dur-switch`).
- **Checkbox** — 20 × 20, radius 4, 1.5px `#B8C4D0` → navy fill with cream check.
- **Radio** — 16 outer ring, 8 inner dot, copper when selected (used for one-of filters like period).
- **Slider** — `accent-color: #002C5A`, value shown in mono copper above right.

## Chips

Filter and input chips only. h 30–36, radius full, 1px border.
Off: transparent + `#B8C4D0` + navy text. On: `rgba(176,111,65,.12)` + copper border + `#9A5E37` text. `white-space: nowrap` always. Active filters may be echoed above results as removable chips with a "Zrušit vše" text button.

## Cards

- **Elevated** — white, radius 12, elevation 1. Default.
- **Filled** — `#F0E1D7`, radius 12, no shadow, copper text. For one highlighted metric or a tip.
- **Outlined** — transparent, 1px `#B8C4D0`, radius 12. For secondary groupings and side panels.

## Tables

Header: navy `#002C5A`, cream text, 12 px, `.06em`, uppercase, radius 0, `position: sticky; top: 0` inside its own scroll container (never page-level sticky).
Rows: white, separated by `1px #F2F2F2`, hover navy 4 %, selected copper 10 % + 3 px copper inset marker. Numeric columns mono and right-aligned. Status as a pill badge with dot + word.
Row actions: none per row — selection opens the bulk bar. Only a single `more_vert` menu is acceptable.

## Tabs

h 46–48, label 14/500, colour `#4A6480` → `#002C5A` when active, indicator `inset 0 -2px 0 #B06F41` sliding in 200 ms. Optional count as a neutral pill (`rgba(0,44,90,.06)`, copper tint when active). Primary tabs only; no secondary tab row — use filters instead.

## Navigation

- **Rail** for 4–7 sections; **drawer** for portals. No bottom navigation.
- Active item: copper 10 % background, copper text and icon, 3 px copper left marker, `FILL 1` on the icon.
- App bar: h 64 standard, navy, title 18/500, actions right, avatar last. Collapsing variant see `motion.md`.

## Dialogs

Scrim `rgba(0,44,90,.42)`, surface white, radius 12, width 420–460, elevation 4, entry 280 ms (opacity + 12 px rise, scale .98 → 1).
Title PPF Display 22, body 14 `#4A6480`, actions right: text "Zrušit" (copper) + filled navy confirm. Destructive actions require an audit comment field. Esc closes, Enter confirms.

## Snackbar and bulk bar

- **Snackbar** — `#121733`, cream text, radius 8, min-width 320, one action in `#D3A789`, 4–10 s, enters from 12 px below. One message at a time; never for errors that need a decision.
- **Bulk bar** — same surface, h 64, radius 12, anchored 24 px from the content bottom edge: count in mono, sum, secondary actions, primary light action right, close icon last.

## Empty states

Icon 30–40 px `#B8C4D0`, title 16/500, one sentence of guidance ≤ 44ch, optional single text action. Factual tone — an empty queue is finished work, not an error.

## Loading

Skeleton bars matching the content shape (14 px high, radius 4, navy 6→10 % shimmer 1.4 s) for known layouts. Linear 2 px copper progress on the app bar edge for known progress. Circular indicator only when the result shape is unknown. Never two indicators on one screen.
