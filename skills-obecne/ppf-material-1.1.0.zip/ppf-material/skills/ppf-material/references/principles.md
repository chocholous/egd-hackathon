# Ten principles

If all ten hold, the output looks like PPF without a brand review. Full interactive version: `examples/Zasady_-_PPF_x_Material.dc.html`.

**01 Navy is primary, copper is one moment.**
Filled surfaces, headers and the main CTA are navy. Copper keeps meaning only by being rare — selected row, tab indicator, one FAB, one text link.
✓ Copper under 10 % of the screen. ✗ Copper as a panel background or as a second button beside the first.

**02 Background is cream, surfaces are white.**
Page `#F6EFE2`, cards and panels `#FFFFFF`. White is always the nearer layer.
✓ Cream as canvas, white as content. ✗ White page, or a cream card on cream.

**03 Shadow is mixed from navy.**
Elevation 0–3 from `rgba(0,44,90,·)` in two layers; above level 3 only dialogs and menus.
✓ `0 1px 2px rgba(0,44,90,.10), 0 1px 3px 1px rgba(0,44,90,.06)`. ✗ `rgba(0,0,0,·)`, Material baseline shadows, glow.

**04 Radius: 0 / 8 / 12 / full.**
Zero for app bar and table head, 8 for buttons and inputs, 12 for cards and dialogs, full only for chip, switch, avatar, FAB.
✓ Four values in the whole app. ✗ Custom 6, 10, 16 px by feel.

**05 Interaction states from navy, selected state from copper.**
Hover 4 %, focus 8 %, pressed 12 % navy. Selected is copper 10 % plus a 3 px copper marker on the left edge.
✓ `rgba(0,44,90,.04)` on row hover. ✗ Lightening the element or shifting its hue.

**06 PPF Display for headings, NHU for text, mono for numbers.**
No Roboto. Money, phone numbers, IDs, desk codes and dates in JetBrains Mono, right-aligned in tables.
✓ `412,0 M` right-aligned in mono. ✗ Numbers in a proportional font inside a column.

**07 Sentence case and factual language.**
No ALL CAPS except 11–12 px eyebrow labels. No emoji, exclamation marks or superlatives — including empty states and toasts.
✓ "Žádost zamítnuta". ✗ "Hotovo! Skvělá práce!"

**08 Layout is app bar + tabs + three columns.**
Filters or navigation left, content centre, detail right. The detail panel never overlays content; modals are reserved for confirmation and destructive actions.
✓ Sticky action bar at the bottom edge of the detail panel. ✗ A modal for ordinary reading of a detail.

**09 Bulk action lives in one dark bar.**
Checkbox selection opens a `#121733` bar with count, sum and actions. Primary action right, close at the end.
✓ One bar for the whole selection. ✗ A set of buttons on every row.

**10 Status is always a dot and a word.**
Semantic colours are muted (`#48C78E`, `#FF8686`, `#FFE08A`) and never carry meaning alone — text stands beside the dot.
✓ Dot + "Eskalace" in a pill badge. ✗ A red row with no textual explanation.
