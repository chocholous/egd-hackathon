# Motion

Working demo: `examples/Ikony_a_pohyb.dc.html` (scroll inside the framed area).

## Tokens

| Token | Value | Use |
|---|---|---|
| short | `120ms` | State changes, hover, tab colour, header collapse |
| medium | `200ms` | Component entry, FAB collapse, tab indicator slide, bulk bar |
| long | `280ms` | Dialogs, first open of the side panel |
| progress | `80ms linear` | Progress line width |
| easing | `cubic-bezier(.2,0,0,1)` | Everything |

No overshoot, no spring, no decorative transitions. Under `prefers-reduced-motion` drop transforms and keep opacity changes.

## Collapsing header

The header shrinks, it never disappears.

| Property | Expanded | Collapsed |
|---|---|---|
| height | `104px` | `56px` |
| title | `26px` PPF Display | `17px` |
| secondary metadata | opacity 1 | opacity 0 |
| leading icon | opacity .5 | opacity 1 |
| elevation | none | level 2 |

Drive it from the scroll container's `scrollTop`: `t = min(1, scrollTop / 72)`, interpolate height / font-size / opacity, transition `120ms` standard easing. The action row stays reachable the whole time.

## Elevation is the answer to scroll

While content is at zero, neither the header nor the table head casts a shadow. After the first 8 px, level 2 appears — that is the only signal of overlap. Never a permanent shadow, never a border added on scroll.

## Progress on the edge

Reading or loading progress is a 2 px copper line on the bottom edge of the app bar, width 0–100 %, `80ms linear`. No percentage label, no spinner in the middle of the page.

## Sticky table head

`position: sticky; top: 0; z-index: 2` inside its own scroll container — never sticky at page level. Stays navy; gains level 2 shadow once `scrollTop > 8`.

## FAB shrink

Extended FAB (radius 16, padding 0 22, label visible) collapses to a circle (radius full, padding 0 17) when the user scrolls past ~40 px. The icon never changes; only the label's `max-width` goes to 0 with opacity, `200ms`. Keep the button `flex: none` so the expanded label is not clipped by its row.

## Panels and detail

Changing the selected row repaints the detail panel with no layout shift. Only the panel's first appearance animates (opacity 0 → 1, `160ms`). Width is never animated.

## Tab indicator

The copper underline slides between tabs (`transform`, `200ms`) rather than jumping; text colour changes at the same time.

## Bulk bar

Selection opens the dark bar with a 12 px rise and fade, `200ms`. Closing is immediate with no exit animation — the user has already moved on.

## Loading

Skeleton bars matching the content shape (14 px high, radius 4, navy 6 → 10 % shimmer, 1.4 s linear loop) whenever the layout is known. Circular indicator only when the result shape is unknown. Never two indicators on one screen.

## Snackbar

Enters from 12 px below with fade, `200ms`; lives 4–10 s; one action maximum. Never used for errors that require a decision — those are dialogs.
