# Sync with ppf-documentdesign

This skill is standalone: it ships its own `tokens/tokens.json`, `assets/ppf-material.css` and fonts. Only a small set of **brand** values originates elsewhere. `ppf-documentdesign` stays their single source of truth.

## What is imported (never edited here)

| This skill | Comes from `ppf-documentdesign` |
|---|---|
| `color.brand.*` (navy, copper, cream, greys, copper wash, copper medium, dark) | `tokens/tokens.json` → `color.brand`, `color.brand_extended`, `color.web` |
| `color.aa.*` (`copper_text`, `body_navy`, `navy_dark`) | `tokens/tokens.json` → `color.web_aa` |
| `color.status.*` base hexes | `tokens/tokens.json` → semantic colours |
| `color.chart_web` | Web 8-colour sequence |
| `type.font.display`, `type.font.body` | Font definitions |
| `assets/fonts/*` | `assets/fonts/` (PPF Display, Neue Haas Unica W1G) |

## What this skill owns

Shape scale, elevation formulas, state layers, motion tokens, component sizes, type scale, icon axis settings, layout patterns, principles, reference screens. These are Material-derived decisions and have no counterpart in `ppf-documentdesign`.

## Re-sync procedure

1. Pull `ppf-documentdesign` and open `tokens/tokens.json`.
2. Compare every entry in this skill marked `"source": "ppf-documentdesign"` against it. If a hex differs, copy the upstream value — never adjust it locally, and never introduce an "almost navy".
3. Mirror the change into `assets/ppf-material.css` (`:root` block) — the CSS is generated from the JSON, so keep the two in step.
4. If fonts changed, copy the new `woff2`/`woff` files into `assets/fonts/` and check the `@font-face` names still match.
5. Update `$meta.brand_source.synced` with the current date and bump `$meta.version` (patch for value sync, minor for new tokens).
6. Open two examples (`PPF_Material.dc.html`, `App_-_Schvalovaci_fronta.dc.html`) and confirm nothing shifted visually.

## Division of routing

| Output | Skill |
|---|---|
| Web app, internal tool, HTML artifact, prototype, dashboard | **ppf-material** |
| PPTX, DOCX, XLSX, email template | ppf-documentdesign |
| Logo usage, clear space, forbidden treatments, print/Pantone specs | ppf-documentdesign |
| Brand compliance review of a web screen | ppf-material (`references/principles.md`) then ppf-documentdesign for brand values |

## Handover checklist

- [ ] `assets/fonts/` contains real font files (examples fall back to Georgia / Helvetica without them).
- [ ] `tokens/tokens.json` and `assets/ppf-material.css` agree on every value.
- [ ] `$meta.brand_source.synced` is the actual sync date.
- [ ] Examples open in a browser next to `support.js`.
- [ ] Team knows the dividing line: adopt Material mechanics, reject Material's visual signature.
