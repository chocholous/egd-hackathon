# Tokens — the interactive layer

Brand values are canonical in `ppf-documentdesign` → `tokens/tokens.json`. This file only records how they are used in interactive UI, plus the values Material contributes (radius, elevation, state layers, motion).

## Colour roles (Material role → PPF value)

| Material role | PPF value | Use |
|---|---|---|
| primary | `#002C5A` navy | Filled buttons, app bar, table head, tree root |
| on-primary | `#F6EFE2` cream | Text and icons on navy |
| secondary / accent | `#B06F41` copper | Selected state, tab indicator, FAB, one link — under 10 % of area |
| accent text (AA) | `#9A5E37` | Copper as text or small icon on light background |
| surface | `#F6EFE2` cream | Page background (never pure white) |
| surface-container | `#FFFFFF` | Cards, panels, table body |
| surface-container-warm | `#F0E1D7` | Filled card, copper wash callout |
| on-surface | `#002C5A` | Body text |
| on-surface-variant | `#4A6480` | Secondary text, secondary icons |
| outline | `#B8C4D0` | Borders, dividers between regions |
| outline-variant | `#F2F2F2` | Row separators inside a white surface |
| inverse-surface | `#121733` | Snackbar, bulk action bar, tooltip |
| success / danger / caution | `#48C78E` / `#FF8686` / `#FFE08A` | Status dots and badge backgrounds only |
| status text | `#1F7A56` / `#A33B2B` / `#8A6A16` | AA-safe text on those tints |

Status tints in use: `rgba(72,199,142,.16)` positive, `rgba(187,75,58,.10)` negative, `rgba(255,224,138,.35)` caution, `rgba(0,44,90,.06)` neutral.

## Shape

| Token | Value | Applies to |
|---|---|---|
| none | `0` | App bar, table header, full-bleed bands |
| small | `8px` | Buttons, inputs, list rows, small containers |
| medium | `12px` | Cards, dialogs, panels, plan cells |
| full | `999px` | Chip, switch, avatar, FAB, icon button, badge |

Nothing else. No 6, 10 or 16 px "by feel".

## Elevation (navy, never black)

```
level 0  none (on cream: 1px solid #B8C4D0 instead)
level 1  0 1px 2px rgba(0,44,90,.10), 0 1px 3px 1px rgba(0,44,90,.06)
level 2  0 1px 2px rgba(0,44,90,.10), 0 2px 6px 2px rgba(0,44,90,.08)
level 3  0 4px 8px 3px rgba(0,44,90,.09), 0 1px 3px rgba(0,44,90,.12)
level 4  0 8px 12px 6px rgba(0,44,90,.15), 0 4px 4px rgba(0,44,90,.30)   /* dialog, menu only */
```

Cards use level 1. Level 2 appears as an answer to scroll (sticky head, collapsed header). Level 3 for FAB hover and menus.

## State layers

| State | Value |
|---|---|
| hover | `rgba(0,44,90,.04)` |
| focus | `rgba(0,44,90,.08)` |
| pressed | `rgba(0,44,90,.12)` |
| dragged | `rgba(0,44,90,.16)` |
| selected | `rgba(176,111,65,.10)` + `inset 3px 0 0 #B06F41` |
| disabled | element opacity `.38`, no layer |

Never express a state by lightening the element's own colour.

## Motion

| Token | Value | Use |
|---|---|---|
| short | `120ms` | State changes, hover, tab colour |
| medium | `200ms` | Component entry, FAB collapse, tab indicator slide |
| long | `280ms` | Dialogs, side panel first open |
| switch | `160ms` | Switch thumb and track colour (`--dur-switch`) |
| easing | `cubic-bezier(.2,0,0,1)` | Everything |
| linear | `80ms linear` | Progress line width |

No overshoot, no spring, no decorative transitions. Respect `prefers-reduced-motion` by dropping transforms and keeping opacity.

## Spacing and density

8 px base: 4 / 8 / 12 / 16 / 20 / 24 / 28 / 32 / 40 / 56.
Comfortable density = 8 px unit (default); compact = 6 px unit for dense data screens. Row heights: 44 px compact table row, 56 / 72 / 88 px for one-, two-, three-line list items.

## Type scale (web)

| Role | Font | Size / line |
|---|---|---|
| page title | PPF Display 400 | 46–56 / 1.06 |
| section title | PPF Display 400 | 26 / 1.2 |
| card title | NHU 500/600 | 16–17 / 1.35 |
| body | NHU 400 | 14–15 / 1.6 |
| secondary | NHU 400 `#4A6480` | 13 / 1.55 |
| label | NHU 500 | 14 / 1 (buttons) |
| eyebrow | NHU 500, `.08–.16em`, uppercase | 11–12 |
| numeric | JetBrains Mono 400 | 13–15, right-aligned in tables |

Eyebrow labels are the only uppercase text in the system.

## Minimum targets

Interactive target 44 × 44 px (icon glyph may be 20 px inside it), 8 px between adjacent targets. Focus ring 2 px navy with 2 px offset. Text contrast 4.5:1, icons and large text 3:1 — which is why copper text is `#9A5E37`, not `#B06F41`.
