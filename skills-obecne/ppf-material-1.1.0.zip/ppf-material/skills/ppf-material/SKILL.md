---
name: ppf-material
description: "Standalone design system for PPF Group web interfaces — PPF brand identity combined with Material Design 3 mechanics. Use when building or reviewing any web UI, internal tool, prototype or HTML artifact for PPF: buttons, inputs, tables, tabs, dialogs, snackbars, navigation, icons, motion, layout. Self-contained — carries its own tokens, CSS and reference screens. Brand values (colour hexes, fonts, logo) are imported from the ppf-documentdesign repo, which stays their single source of truth; for Office documents (PPTX / DOCX / XLSX) and logo rules use ppf-documentdesign instead."
version: 1.1.0
user-invocable: true
---

# PPF × Material Design 3

**Dividing line: we adopt Material's mechanics and specifications, never its visual signature.**
Material solves interaction behaviour, accessibility and component hierarchy. PPF supplies material — navy on cream, copper as a single accent, editorial type, restraint. Anything that would make output recognisably "Material-looking" (dynamic color, tonal palettes, surface tint elevation, ripple, Roboto, full-round buttons) is rejected.

This skill is **standalone**: everything needed to build a screen is in this folder. It imports nothing at runtime except the fonts.

## What is in this folder

| Path | Content |
|---|---|
| `tokens/tokens.json` | Canonical token snapshot for this system — brand values (imported) + interactive layer (owned here) |
| `assets/ppf-material.css` | Custom properties + `@font-face` + resets. The only file a page must load |
| `assets/fonts/` | PPF Display + Neue Haas Unica W1G (woff2/woff), copied from `ppf-documentdesign` |
| `references/principles.md` | The ten rules. If all ten hold, output passes brand review |
| `references/tokens.md` | Human-readable token reference: colour roles, shape, elevation, state layers, motion, type scale |
| `references/components.md` | Buttons, inputs, chips, cards, tables, tabs, navigation, dialogs, snackbar, bulk bar, empty and loading states |
| `references/icons.md` | Material Symbols axis settings, sizes, canonical icon vocabulary |
| `references/motion.md` | Collapsing header, sticky heads, scroll elevation, FAB shrink, skeletons |
| `references/adoption.md` | Full adopt / adapt / reject matrix against Material Design 3 |
| `references/sync.md` | How brand values are imported from `ppf-documentdesign` and when to re-sync |
| `examples/` | Nine working reference screens |

## Read order

1. `references/principles.md`
2. `references/tokens.md` (or `tokens/tokens.json` if generating code)
3. `references/components.md`
4. `references/icons.md` + `references/motion.md`
5. `references/adoption.md` when a Material pattern is not covered above
6. `examples/` — start from the closest screen; do not invent layout

## Relationship to ppf-documentdesign

`ppf-documentdesign` remains the source of truth for the brand itself: colour hexes and their Pantone provenance, fonts, logo rules, Office document templates and Python styles. This skill **copies** the handful of brand values it needs into `tokens/tokens.json` (marked `"source": "ppf-documentdesign"`) so it can be handed over and used on its own. When brand values change there, re-run the sync described in `references/sync.md`.

Route Office outputs (PPTX / DOCX / XLSX / email) and anything about logo usage to `ppf-documentdesign`. Everything on the web is this skill.

## Non-negotiables (short version)

- Navy `#002C5A` primary, copper `#B06F41` accent under 10 % of visual area, page background cream `#F6EFE2`, surfaces white.
- Shadows mixed from `rgba(0,44,90,·)`. Elevation 0–3; 4–5 only dialogs and menus.
- Radius: 0 (app bar, table head) / 8 (buttons, inputs) / 12 (cards, dialogs) / full (chip, switch, avatar, FAB).
- State layers: navy 4 % hover, 8 % focus, 12 % pressed; **selected** is copper 10 % + 3 px copper left marker.
- Type: PPF Display for headings, Neue Haas Unica for everything, JetBrains Mono for numerics (right-aligned in tables). No Roboto.
- Sentence case. No emoji, no exclamation marks, no superlatives — including empty states and toasts.
- Icons: Material Symbols Outlined only, `FILL 0 / wght 400 / opsz = font-size`. Never hand-drawn SVG, never emoji as icon.
- Layout: app bar + tabs + three columns (filters left, content centre, detail right). Modal is for confirmation and destructive actions only.
- Bulk actions live in one dark `#121733` bar with count, sum and actions.
- Status is always a dot plus a word; muted semantic colours never carry meaning alone.

## Reference screens (`examples/`)

| Id | File | Pattern it owns |
|---|---|---|
| `component-vocabulary` | `PPF_Material.dc.html` | Component vocabulary: tokens, buttons, inputs, cards, dialog, snackbar |
| `orgchart` | `App_-_Orgchart.dc.html` | Hierarchy: searchable tree, multi-level chart, person detail |
| `approval-queue` | `App_-_Schvalovaci_fronta.dc.html` | Queue: tabs with counts, multi-select, bulk bar, confirm dialog with audit comment |
| `company-search-light` | `App_-_Company_search_light.dc.html` | Simple search: people / topics / accountabilities, facets |
| `company-search-hard` | `App_-_Company_search_hard.dc.html` | Federated search: sources incl. OneDrive, subtopics, best answer, restricted access, preview panel |
| `orgchart-floorplan` | `App_-_Orgchart_a_floorplan.dc.html` | Spatial: floor plan (rooms, services, desk clusters) mapped to team structure |
| `content-editor` | `App_-_Content_editor.dc.html` | Authoring: news / article / announcement / course, block editor, pre-publish checks |
| `icons-motion` | `Ikony_a_pohyb.dc.html` | Icons and motion, plus the adopt / adapt / reject matrix |
| `principles` | `Zasady_-_PPF_x_Material.dc.html` | The ten principles as a one-page canon for designers |

The id is the stable handle: `examples/index.json` maps id → file, so a reference by id survives a file rename (update the index, not the references). Never rename an id.

Examples are Design Components (`.dc.html`) — they open directly in a browser next to `support.js`. All styling is inline, so any screen reads as plain HTML and ports to React, SPFx or Fluent without a build step.

## Review

Check output against `references/principles.md` and the reject list in `references/adoption.md`. Most common failures, in order: copper used as a surface, black shadows, invented radius values, Roboto or a system sans instead of NHU, numbers in a proportional font, selected state expressed by tinting the element instead of a copper marker.
