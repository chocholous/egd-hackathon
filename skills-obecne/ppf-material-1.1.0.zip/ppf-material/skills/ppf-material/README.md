# ppf-material

Standalone design system for PPF Group **web** interfaces: PPF brand identity + Material Design 3 mechanics.
Dividing line: adopt Material's mechanics and specifications, reject its visual signature.

## Install as a skill

Copy this folder to `skills/ppf-material/` in your skills repo (e.g. next to `ppf-documentdesign`), commit, and it is invocable by name. Nothing else is required — the skill is self-contained.

```
skills/ppf-material/
  SKILL.md                  entry point, read order, non-negotiables
  tokens/tokens.json        canonical token snapshot
  assets/ppf-material.css   variables + @font-face + resets (the only file a page loads)
  assets/fonts/             PPF Display + Neue Haas Unica W1G  ← copy from ppf-documentdesign
  references/               principles, tokens, components, icons, motion, adoption, sync
  examples/                 nine working reference screens + support.js
```

## Use in a page

```html
<link rel="stylesheet" href="assets/ppf-material.css">
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,400,0,0&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
```

Then build with the variables (`var(--navy)`, `var(--e1)`, `var(--r-md)`, `var(--state-hover)`) and follow `references/components.md`. No component classes are shipped on purpose — components are specified in prose and demonstrated in `examples/`, so the system ports to React, SPFx or Fluent without inheriting anyone's CSS.

## Relationship to ppf-documentdesign

`ppf-documentdesign` stays the source of truth for brand values, fonts, logo rules and Office outputs (PPTX / DOCX / XLSX / email). This skill copies only the brand values it needs (marked `"source": "ppf-documentdesign"` in `tokens/tokens.json`) so it can be handed over on its own. Re-sync per `references/sync.md`.

Route: web → `ppf-material`; documents and logo → `ppf-documentdesign`.

## Before handing over

1. Copy the real font files into `assets/fonts/` (without them the examples fall back to Georgia / Helvetica).
2. Verify `tokens/tokens.json` and `assets/ppf-material.css` agree.
3. Open `examples/Zasady_-_PPF_x_Material.dc.html` — that one page is the briefing for designers.
