> **PPF poznámka** (jediná změna textu). Kopie záznamu ze zdrojového repa `m365-cli-12` (commit 6c3ad32). Skripty, které ho
> vyrobily (`live/`), se do pluginu nekopírují: zapisují do skutečného webu a ke skillu nejsou potřeba.

# Commands run against a tenant

What `npm run verify` cannot tell: what a command does once it reaches Microsoft 365. This is
the record of one pass with CLI for Microsoft 365 **12.0.0**, on 2026-11-11, as a site
collection admin of one test site who is **not** a SharePoint admin, on macOS under bun.
Every object it made carried the prefix `m365cli12` and went to the recycle bin afterwards.

| Group | Commands | verified | ran | reached | denied | not called |
|---|---|---|---|---|---|---|
| `spo` | 375 | 182 | 17 | 22 | 38 | 116 |
| `entra` | 47 | 22 | 0 | 0 | 18 | 7 |
| `tenant` | 13 | 1 | 0 | 0 | 10 | 2 |

`entra` and `tenant` were only read (`get` / `list`); their other commands are not in the table.

- **verified** -- the result was checked: the output of a read against what was there, a write
  by reading it back with another command, a removal by finding the object in the recycle bin.
- **ran** -- exit code 0, result not checked.
- **reached** -- the service answered with the error the test expected (an unknown id, a
  feature the tenant has switched off). The option parsing and the request are proven, the
  effect is not.
- **denied** -- refused for lack of a role, a scope or a site setting. Says nothing about the
  command.
- **not called** -- on purpose; the note says why. Tenant-level writes, writes that change the
  test site as a whole, permanent deletion, and commands that need something the test site
  does not have.

## What the pass found

Defects of the CLI (12.0.0):

- `spo site recyclebinitem move --ids <id>` moves **every** item of the first-stage recycle
  bin to the second stage, not the ones named: it posts the ids to `MoveAllToSecondStage`,
  which ignores them. Seen on the test site; it cannot be undone from the CLI.
- `spo contenttype field set` fails (`' ' is an unexpected token`) for a site column whose
  schema ends ` />` with a space before the slash: the CLI splices its attribute in after the
  slash. A column created with `<Field …></Field>` works. Same on 11.10.0.
- `spo file rename --force` fails when the target name does **not** exist yet (it tries to
  remove it first); without `--force` it works, and with an existing target it replaces it.
- `entra group list --type <t> --properties <p>` builds a broken URL
  (`'true?$select=…' is not a valid count option`); either option alone works.
- `spo list get --withPermissions` fails on anything that is not a document library
  (`VersionPolicies is not supported`). Same on 11.10.0.

Behaviour that is easy to get wrong:

- `spo listitem add --folder` is relative to the **list root** (`F1/deep`), and missing folders
  are created. A web-relative path creates that whole path again inside the list; a
  server-relative URL fails with `Invalid URL value`, and so does a folder made with
  `spo folder add`.
- `spo listitem add|set` with `--query` fails with `Column 'query' does not exist`: the global
  option is sent as a column. Filter the JSON output instead.
- `spo folder list --recursive --filter` applies the filter on every level, so a match under a
  parent that does not match is not found. `spo file list --recursive --filter` does find it.
- `spo navigation node list|add` return the node id as `Key` (children under `Nodes`), not `Id`.
- Permissions come back in different places: `RoleAssignments` for a list, file and list
  item, `ListItemAllFields.RoleAssignments` for a folder.
- `spo listitem get --uniqueId` wants the item's `UniqueId`, not its `GUID` field.
- `spo page control list` also returns a placeholder per empty column (`id: "emptySection"`).
- Options typed as an id refuse anything that is not an RFC 4122 UUID (`Invalid UUID`), an
  all-zero placeholder included.
- Column names that look like a cell reference (`Num1`, `DV1`) are stored encoded
  (`_x0044_V1`); SharePoint does that, not the CLI.
- `spo term … list|get` without `--webUrl` go to the admin site and are refused for a non-admin;
  with `--webUrl` they work.
- `spo page add --publish false` publishes, and a removal without `--force` and without a
  terminal is refused at once (`ExitPromptError`): see the skill.

## spo

| Command | Result | Note |
|---|---|---|
| `spo externaluser list` | denied | {"error":"Request failed with status code 403"}  |
| `spo file add` | verified | --fileName; --overwrite (v2); --overwrite (v3) |
| `spo file checkin` | verified |  |
| `spo file checkout` | verified | --id |
| `spo file copy` | ran | --newName --nameConflictBehavior |
| `spo file get` | verified | reads back attachment set (content replaced); --id --asString; reads back --overwrite; --asFile --path |
| `spo file list` | verified | --recursive --filter --fields; reads back the removes; reads back rename and rename --force |
| `spo file move` | ran |  |
| `spo file retentionlabel ensure` | not called | no retention label is published to this site |
| `spo file roleassignment add` | verified |  |
| `spo file sharinglink add` | verified |  |
| `spo file sharinglink get` | verified |  |
| `spo file sharinglink set` | verified |  |
| `spo file version get` | verified |  |
| `spo folder add` | ran | --ensureParentFolders --color |
| `spo folder copy` | verified | copy B/C into A2; --newName --nameConflictBehavior |
| `spo folder list` | verified | TRAP: with --recursive the --filter is applied on every level, so a match under a non-matching parent (B/moved) is NOT found; reads back folder copy; reads back folder copy --newName and folder move |
| `spo folder move` | verified | move A2/C-copy to B/moved |
| `spo folder retentionlabel ensure` | not called | no retention label is published to this site |
| `spo folder roleassignment add` | verified | inheritance broken beforehand |
| `spo folder set` | verified |  |
| `spo folder sharinglink add` | verified |  |
| `spo folder sharinglink get` | verified |  |
| `spo folder sharinglink set` | verified |  |
| `spo group add` | ran |  |
| `spo group get` | verified | --id; --associatedGroup; reads back group set |
| `spo group member add` | verified |  |
| `spo list add` | ran |  |
| `spo list contenttype add` | verified |  |
| `spo list contenttype default set` | verified |  |
| `spo list get` | verified | --url + --properties; reads back spo list set; reads back break |
| `spo list retentionlabel ensure` | not called | no retention label is published to this site |
| `spo list retentionlabel get` | verified | no label applied |
| `spo list roleassignment add` | verified |  |
| `spo list sensitivitylabel ensure` | not called | needs a sensitivity label; applying one to a library is governed by Purview policy |
| `spo list sitescript get` | verified |  |
| `spo list view field add` | verified |  |
| `spo list view field set` | verified |  |
| `spo list view get` | verified | reads back view set; reads back view field add + set; reads back view field remove |
| `spo list view set` | verified |  |
| `spo list webhook add` | not called | needs a public HTTPS endpoint that answers SharePoint's validation request |
| `spo list webhook get` | reached | unknown id |
| `spo list webhook set` | not called | needs a public HTTPS endpoint that answers SharePoint's validation request |
| `spo page add` | verified |  |
| `spo page clientsidewebpart add` | ran |  |
| `spo page control get` | verified | reads back control set |
| `spo page control list` | verified | one text and one web part control (plus placeholders of empty sections); reads back control remove |
| `spo page control set` | verified |  |
| `spo page copy` | verified | --overwrite |
| `spo page section add` | verified |  |
| `spo page text add` | ran |  |
| `spo roledefinition add` | verified |  |
| `spo roledefinition get` | verified |  |
| `spo site admin add` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo site admin list` | verified |  |
| `spo site appcatalog add` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo site apppermission add` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo site apppermission get` | reached | unknown permission id |
| `spo site apppermission list` | ran |  |
| `spo site apppermission set` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo site chrome set` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo site commsite enable` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo site groupify` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo site hubsite connect` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo site hubsite theme sync` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo site inplacerecordsmanagement set` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo site recyclebinitem list` | verified | reads back listitem remove; removed pages are in the recycle bin; reads back file remove --id |
| `spo site recyclebinitem restore` | verified |  |
| `spo site rename` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo site set` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo eventreceiver list` | verified | --scope site |
| `spo file version list` | verified | reads back version remove; reads back version clear |
| `spo group member list` | verified | reads back member add; reads back member remove |
| `spo list contenttype list` | verified | reads back default set; reads back remove |
| `spo list list` | verified | --filter + --properties; reads back list remove |
| `spo list view list` | verified | reads back view remove |
| `spo list webhook list` | verified |  |
| `spo page list` | verified |  |
| `spo page template list` | verified |  |
| `spo roledefinition list` | verified | reads back roledefinition add; reads back roledefinition remove |
| `spo site membership list` | denied | {"error":"Attempted to perform an unauthorized operation."}  |
| `spo listitem isrecord` | verified | reads back undeclare |
| `spo page set` | verified | --promoteAs NewsPage; --demoteFrom NewsPage |
| `spo get` | verified | the SharePoint URL the CLI has stored; reads back spo set |
| `spo set` | verified | sets the same value back; a local CLI setting |
| `spo agent add` | not called | SITE: creates a Copilot agent on the test site; waits for an explicit yes |
| `spo app add` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo app deploy` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo app get` | reached | asked for something that does not exist |
| `spo app install` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo app instance list` | verified |  |
| `spo app list` | verified | site collection app catalog of the test site |
| `spo app remove` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo app retract` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo app teamspackage download` | reached | asked for something that does not exist |
| `spo app uninstall` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo app upgrade` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo applicationcustomizer add` | not called | registers an SPFx extension on every page/list of the test site; no subsite to isolate it |
| `spo applicationcustomizer get` | reached | unknown title |
| `spo applicationcustomizer list` | verified |  |
| `spo applicationcustomizer remove` | not called | registers an SPFx extension on every page/list of the test site; no subsite to isolate it |
| `spo applicationcustomizer set` | not called | registers an SPFx extension on every page/list of the test site; no subsite to isolate it |
| `spo apppage add` | ran |  |
| `spo apppage set` | ran |  |
| `spo brandcenter colors list` | verified | read |
| `spo brandcenter settings list` | verified | read |
| `spo cdn get` | denied | {"error":"Request failed with status code 403"}  |
| `spo cdn origin add` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo cdn origin list` | denied | {"error":"Request failed with status code 403"}  |
| `spo cdn origin remove` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo cdn policy list` | denied | {"error":"Request failed with status code 403"}  |
| `spo cdn policy set` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo cdn set` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo commandset add` | not called | registers an SPFx extension on every page/list of the test site; no subsite to isolate it |
| `spo commandset get` | reached | unknown title |
| `spo commandset list` | verified |  |
| `spo commandset remove` | not called | registers an SPFx extension on every page/list of the test site; no subsite to isolate it |
| `spo commandset set` | not called | registers an SPFx extension on every page/list of the test site; no subsite to isolate it |
| `spo contenttype add` | ran |  |
| `spo contenttype field list` | verified | reads back field remove; reads back field set; reads back the second set; by --contentTypeName |
| `spo contenttype field remove` | verified |  |
| `spo contenttype field set` | verified | CLI BUG: column whose schema ends " />" -- the CLI splices its attribute after the slash |
| `spo contenttype get` | verified | reads back spo contenttype set; list scope |
| `spo contenttype list` | verified | reads back remove |
| `spo contenttype remove` | verified |  |
| `spo contenttype set` | verified |  |
| `spo contenttype sync` | ran | returns the content type; the content type hub path itself was not exercised |
| `spo contenttypehub get` | verified | read |
| `spo customaction add` | denied | {"error":"Request failed with status code 403"}  |
| `spo customaction clear` | not called | removes EVERY custom action of the test site, not only my own |
| `spo customaction get` | denied | depends on spo customaction add, which this site refuses with 403 (custom scripts are off) |
| `spo customaction list` | verified | reads back remove; --scope All |
| `spo customaction remove` | denied | depends on spo customaction add, which this site refuses with 403 (custom scripts are off) |
| `spo customaction set` | denied | depends on spo customaction add, which this site refuses with 403 (custom scripts are off) |
| `spo eventreceiver get` | reached | unknown name; the CLI has no command that adds one |
| `spo eventreceiver remove` | reached | unknown name; the CLI has no command that adds one |
| `spo feature disable` | not called | would switch a feature on the test site itself; no subsite to isolate it |
| `spo feature enable` | not called | would switch a feature on the test site itself; no subsite to isolate it |
| `spo feature list` | verified | --scope Site |
| `spo field add` | verified | site column; site column, schema not self-closing |
| `spo field get` | verified | reads back spo field set |
| `spo field list` | verified | reads back spo field remove; reads back site column removes; site scope |
| `spo field remove` | verified | site column; --group with no match |
| `spo field set` | verified |  |
| `spo file archive` | reached | Microsoft 365 Archive is not enabled in this tenant |
| `spo file checkout undo` | verified |  |
| `spo file remove` | verified | --id |
| `spo file rename` | verified | CLI BUG: --force fails when the target name does NOT exist yet (it tries to remove it first); --force with an existing target |
| `spo file retentionlabel remove` | not called | no retention label is published to this site |
| `spo file roleassignment remove` | verified |  |
| `spo file roleinheritance break` | verified |  |
| `spo file roleinheritance reset` | verified |  |
| `spo file sharinginfo get` | verified |  |
| `spo file sharinglink clear` | verified |  |
| `spo file sharinglink list` | verified | reads back sharinglink remove and clear |
| `spo file sharinglink remove` | verified |  |
| `spo file unarchive` | reached | file is not archived |
| `spo file version clear` | verified |  |
| `spo file version keep` | verified |  |
| `spo file version remove` | verified |  |
| `spo file version restore` | verified |  |
| `spo folder archive` | reached | Microsoft 365 Archive is not enabled in this tenant |
| `spo folder get` | verified | --id; reads back folder set --name; reads back roleassignment remove |
| `spo folder remove` | verified |  |
| `spo folder retentionlabel remove` | not called | no retention label is published to this site |
| `spo folder roleassignment remove` | verified |  |
| `spo folder roleinheritance break` | verified |  |
| `spo folder roleinheritance reset` | verified |  |
| `spo folder sharinglink clear` | verified |  |
| `spo folder sharinglink list` | verified | --scope; reads back sharinglink remove; reads back sharinglink clear |
| `spo folder sharinglink remove` | verified |  |
| `spo folder unarchive` | reached | Microsoft 365 Archive is not enabled in this tenant |
| `spo group list` | verified | --associatedGroupsOnly; reads back group remove |
| `spo group member remove` | verified |  |
| `spo group remove` | verified |  |
| `spo group set` | verified |  |
| `spo hidedefaultthemes get` | denied | {"error":"Attempted to perform an unauthorized operation."}  |
| `spo hidedefaultthemes set` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo homesite add` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo homesite get` | denied | {"error":"Attempted to perform an unauthorized operation."}  |
| `spo homesite list` | denied | {"error":"Attempted to perform an unauthorized operation."}  |
| `spo homesite remove` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo homesite set` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo hubsite connect` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo hubsite data get` | verified | the test site is not connected to a hub |
| `spo hubsite disconnect` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo hubsite get` | reached | asked for a hub site id that does not exist: ResourceNotFoundException |
| `spo hubsite list` | verified | read |
| `spo hubsite register` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo hubsite rights grant` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo hubsite rights revoke` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo hubsite set` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo hubsite unregister` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo knowledgehub get` | denied | {"error":"Request failed with status code 403"}  |
| `spo knowledgehub remove` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo knowledgehub set` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo list contenttype remove` | verified |  |
| `spo list defaultvalue clear` | verified |  |
| `spo list defaultvalue get` | verified |  |
| `spo list defaultvalue list` | verified | reads back remove; reads back clear |
| `spo list defaultvalue remove` | verified |  |
| `spo list defaultvalue set` | verified |  |
| `spo list remove` | ran | --title; --id |
| `spo list retentionlabel remove` | not called | no retention label is published to this site |
| `spo list roleassignment remove` | verified |  |
| `spo list roleinheritance break` | verified |  |
| `spo list roleinheritance reset` | verified |  |
| `spo list sensitivitylabel remove` | not called | needs a sensitivity label; applying one to a library is governed by Purview policy |
| `spo list set` | verified |  |
| `spo list view add` | verified |  |
| `spo list view field remove` | verified |  |
| `spo list view remove` | verified |  |
| `spo list webhook remove` | not called | needs a public HTTPS endpoint that answers SharePoint's validation request |
| `spo listitem add` | verified | TRAP: --folder as a server-relative URL is refused; --listUrl + --contentType; --folder, web-relative |
| `spo listitem attachment add` | verified | --fileName |
| `spo listitem attachment get` | verified |  |
| `spo listitem attachment list` | verified | reads back attachment remove |
| `spo listitem attachment remove` | verified |  |
| `spo listitem attachment set` | verified |  |
| `spo listitem batch add` | verified | --csvContent |
| `spo listitem batch remove` | verified | --ids; --filePath |
| `spo listitem batch set` | verified |  |
| `spo listitem get` | verified | reads back --systemUpdate; reads back roleassignment remove; no --fields |
| `spo listitem list` | verified | --filter; --camlQuery; --pageSize/--pageNumber |
| `spo listitem record declare` | denied | {"error":"Attempted to perform an unauthorized operation."}  |
| `spo listitem record lock` | reached | item is not a record (declare is denied on this site) |
| `spo listitem record undeclare` | verified | on an item that is not a record |
| `spo listitem record unlock` | reached | item is not a record (declare is denied on this site) |
| `spo listitem remove` | verified | stray item from investigating --folder |
| `spo listitem retentionlabel ensure` | not called | no retention label is published to this site |
| `spo listitem retentionlabel remove` | not called | no retention label is published to this site |
| `spo listitem roleassignment add` | verified |  |
| `spo listitem roleassignment remove` | verified |  |
| `spo listitem roleinheritance break` | verified |  |
| `spo listitem roleinheritance reset` | ran |  |
| `spo listitem set` | verified | --systemUpdate |
| `spo navigation node add` | verified | --parentNodeId |
| `spo navigation node get` | verified | reads back node set |
| `spo navigation node list` | verified | TopNavigationBar; v12 output: the node id is in Key, children in Nodes; reads back add --parentNodeId |
| `spo navigation node remove` | verified | node left by the previous run |
| `spo navigation node set` | verified |  |
| `spo orgassetslibrary add` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo orgassetslibrary list` | denied | {"error":"Request failed with status code 403"}  |
| `spo orgassetslibrary remove` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo orgnewssite list` | denied | {"error":"Request failed with status code 403"}  |
| `spo orgnewssite remove` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo orgnewssite set` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo page column get` | verified |  |
| `spo page column list` | verified |  |
| `spo page control remove` | verified |  |
| `spo page get` | verified | reads back page add; --metadataOnly; --default (home page, read only) |
| `spo page header set` | verified |  |
| `spo page publish` | verified |  |
| `spo page remove` | verified | the app page, to the recycle bin |
| `spo page section get` | verified |  |
| `spo page section list` | verified | reads back section add; reads back section remove |
| `spo page section remove` | verified |  |
| `spo page unpublish` | verified |  |
| `spo propertybag get` | denied | depends on spo propertybag set, which this site refuses (NoScript) |
| `spo propertybag list` | verified | reads back remove |
| `spo propertybag remove` | denied | {"error":"Access is denied. (Exception from HRESULT: 0x80070005 (E_ACCESSDENIED))"}  |
| `spo propertybag set` | denied | Tip: If a site has NoScript enabled, setting the property bag value may result in exceptions. {"error":"Access is denied. (Exception from HRESULT: 0x8 |
| `spo roledefinition remove` | verified |  |
| `spo serviceprincipal grant add` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo serviceprincipal grant list` | verified | read |
| `spo serviceprincipal grant revoke` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo serviceprincipal permissionrequest approve` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo serviceprincipal permissionrequest deny` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo serviceprincipal permissionrequest list` | denied | {"error":"Request failed with status code 403"}  |
| `spo serviceprincipal set` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo site accessrequest setting set` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo site add` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo site admin remove` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo site appcatalog list` | verified | read |
| `spo site appcatalog remove` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo site apppermission remove` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo site archive` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo site ensure` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo site get` | verified |  |
| `spo site hubsite disconnect` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo site list` | denied | {"error":"Attempted to perform an unauthorized operation."}  |
| `spo site recyclebinitem clear` | not called | permanent deletion of the whole recycle bin -- never run |
| `spo site recyclebinitem move` | verified | to the second-stage recycle bin (still recoverable) |
| `spo site recyclebinitem remove` | not called | permanent deletion -- never run |
| `spo site remove` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo site sharingpermission set` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo site unarchive` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo site versionpolicy get` | ran |  |
| `spo sitedesign add` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo sitedesign apply` | not called | SITE: changes the test site as a whole (settings, admins, apps, hub, design); waits for an explicit yes |
| `spo sitedesign get` | reached | asked for something that does not exist |
| `spo sitedesign list` | verified | read |
| `spo sitedesign remove` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo sitedesign rights grant` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo sitedesign rights list` | denied | HTTP 500 for an account that is not a SharePoint admin (a tenant-level command) |
| `spo sitedesign rights revoke` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo sitedesign run list` | verified |  |
| `spo sitedesign run status get` | reached | asked for a run id that does not exist |
| `spo sitedesign set` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo sitedesign task get` | verified | asked for something that does not exist |
| `spo sitedesign task list` | verified |  |
| `spo sitedesign task remove` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo sitescript add` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo sitescript get` | denied | HTTP 500 for an account that is not a SharePoint admin (a tenant-level command) |
| `spo sitescript list` | denied | HTTP 500 for an account that is not a SharePoint admin (a tenant-level command) |
| `spo sitescript remove` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo sitescript set` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo search` | verified |  |
| `spo storageentity get` | verified | asked for something that does not exist |
| `spo storageentity list` | verified | read |
| `spo storageentity remove` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo storageentity set` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo tenant appcatalog add` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo tenant appcatalogurl get` | verified | read |
| `spo tenant applicationcustomizer add` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo tenant applicationcustomizer get` | reached | asked for something that does not exist |
| `spo tenant applicationcustomizer list` | verified | read |
| `spo tenant applicationcustomizer remove` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo tenant applicationcustomizer set` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo tenant commandset add` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo tenant commandset get` | reached | asked for something that does not exist |
| `spo tenant commandset list` | verified | read |
| `spo tenant commandset remove` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo tenant commandset set` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo tenant recyclebinitem list` | denied | {"error":"Attempted to perform an unauthorized operation."}  |
| `spo tenant recyclebinitem remove` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo tenant recyclebinitem restore` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo tenant settings list` | denied | {"error":"Attempted to perform an unauthorized operation."}  |
| `spo tenant settings set` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo tenant site get` | denied | {"error":"Attempted to perform an unauthorized operation."}  |
| `spo term add` | not called | the term store is tenant-wide and the CLI has no command that removes a term, set or group again |
| `spo term get` | verified |  |
| `spo term group add` | not called | the term store is tenant-wide and the CLI has no command that removes a term, set or group again |
| `spo term group get` | verified |  |
| `spo term group list` | verified | with --webUrl (without it the command goes to the admin site and is refused) |
| `spo term list` | verified |  |
| `spo term set add` | not called | the term store is tenant-wide and the CLI has no command that removes a term, set or group again |
| `spo term set get` | verified |  |
| `spo term set list` | verified |  |
| `spo theme apply` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo theme get` | denied | {"error":"Request failed with status code 403"}  |
| `spo theme list` | denied | {"error":"Attempted to perform an unauthorized operation."}  |
| `spo theme remove` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo theme set` | not called | TENANT: a tenant-level write; the account is not a SharePoint admin, and it was not called so that it could not change the tenant |
| `spo user ensure` | ran | my own account (already a site user) |
| `spo user get` | verified | --id; --email |
| `spo user list` | verified |  |
| `spo user remove` | not called | would remove a real person from the test site; the only user I may touch is the one I run as |
| `spo userprofile get` | verified |  |
| `spo userprofile set` | not called | changes my real user profile, outside the test site |
| `spo web add` | reached | subsites are disabled in this tenant |
| `spo web clientsidewebpart list` | verified |  |
| `spo web get` | verified | --withGroups; --withPermissions; reads back roleassignment add |
| `spo web installedlanguage list` | verified |  |
| `spo web list` | verified |  |
| `spo web reindex` | not called | would re-crawl the whole test site; no subsite to isolate it |
| `spo web remove` | not called | no subsite can be created in this tenant, and the test site itself must stay |
| `spo web retentionlabel list` | ran |  |
| `spo web roleassignment add` | verified | a direct Read for my own account on the root web |
| `spo web roleassignment remove` | verified |  |
| `spo web roleinheritance break` | not called | the root web of a site collection has nothing to inherit from; no subsite |
| `spo web roleinheritance reset` | not called | the root web of a site collection has nothing to inherit from; no subsite |
| `spo web rule get` | reached | unknown id; no rule (alert) can be created from the CLI |
| `spo web rule list` | verified |  |
| `spo web rule remove` | reached | unknown id; no rule (alert) can be created from the CLI |
| `spo web set` | not called | would change title/description/header of the test site itself; no subsite to isolate it |
| `spo report activityfilecounts` | denied | {"error":"Authorization is required for this report."}  |
| `spo report activitypages` | denied | {"error":"Authorization is required for this report."}  |
| `spo report activityusercounts` | denied | {"error":"Authorization is required for this report."}  |
| `spo report activityuserdetail` | denied | {"error":"Authorization is required for this report."}  |
| `spo report siteusagedetail` | denied | {"error":"Authorization is required for this report."}  |
| `spo report siteusagefilecounts` | denied | {"error":"Authorization is required for this report."}  |
| `spo report siteusagepages` | denied | {"error":"Authorization is required for this report."}  |
| `spo report siteusagesitecounts` | denied | {"error":"Authorization is required for this report."}  |
| `spo report siteusagestorage` | denied | {"error":"Authorization is required for this report."}  |

## entra (read commands)

| Command | Result | Note |
|---|---|---|
| `entra administrativeunit get` | not called | the tenant has no administrative units (or the listing was refused) |
| `entra app list` | verified |  |
| `entra app role list` | verified |  |
| `entra license list` | denied | {"error":"Insufficient privileges to complete the operation."}  |
| `entra resourcenamespace list` | denied | {"error":"Insufficient privileges to complete the operation."}  |
| `entra roledefinition list` | denied | {"error":"Insufficient privileges to complete the operation."}  |
| `entra rolepermission list` | denied | {"error":"Insufficient privileges to complete the operation."}  |
| `entra administrativeunit list` | denied | {"error":"Insufficient privileges to complete the operation."}  |
| `entra administrativeunit member get` | not called | no administrative unit member to read |
| `entra administrativeunit member list` | not called | no administrative unit |
| `entra agent blueprint list` | verified |  |
| `entra agent blueprintprincipal list` | verified |  |
| `entra agent list` | verified |  |
| `entra approleassignment list` | verified |  |
| `entra enterpriseapp get` | verified |  |
| `entra enterpriseapp list` | verified | --displayName |
| `entra group get` | verified |  |
| `entra group list` | verified | CLI BUG: --type together with --properties builds a broken URL; --type alone |
| `entra group member list` | verified |  |
| `entra groupsetting get` | not called | the tenant has no group setting objects |
| `entra groupsetting list` | denied | {"error":"Insufficient privileges to complete the operation."}  |
| `entra groupsettingtemplate get` | not called | no template listed |
| `entra groupsettingtemplate list` | denied | {"error":"Insufficient privileges to complete the operation."}  |
| `entra m365group conversation list` | denied | {"error":"Access is denied. Check credentials and try again., User '<id>' not authorized to access group '<group>'. Rea |
| `entra m365group conversation post list` | not called | no conversation thread to read (none in the group, or the listing was refused) |
| `entra m365group get` | denied | {"error":"Access denied"}  |
| `entra m365group list` | verified | --displayName |
| `entra m365group recyclebinitem list` | verified |  |
| `entra m365group user list` | verified |  |
| `entra multitenant get` | denied | {"error":"Insufficient privileges to complete the operation."}  |
| `entra oauth2grant list` | denied | {"error":"Insufficient privileges to complete the operation."}  |
| `entra organization list` | verified |  |
| `entra pim role assignment eligibility list` | denied | {"error":"{\"errorCode\":\"PermissionScopeNotGranted\",\"message\":\"Authorization failed due to missing permission scope RoleEligibilitySchedule.Read |
| `entra pim role assignment list` | denied | {"error":"{\"errorCode\":\"PermissionScopeNotGranted\",\"message\":\"Authorization failed due to missing permission scope RoleAssignmentSchedule.Read. |
| `entra pim role request list` | denied | {"error":"{\"errorCode\":\"PermissionScopeNotGranted\",\"message\":\"Authorization failed due to missing permission scope RoleAssignmentSchedule.ReadW |
| `entra policy list` | denied | {"error":"Insufficient privileges to complete the operation."}  |
| `entra siteclassification get` | denied | {"error":"Insufficient privileges to complete the operation."}  |
| `entra user get` | verified | --id --properties --withManager |
| `entra user groupmembership list` | verified |  |
| `entra user license list` | verified |  |
| `entra user list` | verified | filtered by a property (this command accepts any option as a filter) |
| `entra user recyclebinitem list` | verified |  |
| `entra user registrationdetails list` | denied | {"error":"The principal does not have any one of the required Microsoft Graph permissions: AuditLog.Read.All to call this API. For more information ab |
| `entra user signin list` | denied | {"error":"The principal does not have any one of the required Microsoft Graph permissions: AuditLog.Read.All to call this API. For more information ab |
| `entra app get` | verified |  |
| `entra app permission list` | verified |  |
| `entra roledefinition get` | not called | no role definition listed |

## tenant (read commands)

| Command | Result | Note |
|---|---|---|
| `tenant id get` | verified | --domainName |
| `tenant info get` | denied | {"error":"Insufficient privileges to complete the operation."}  |
| `tenant people profilecardproperty get` | denied | {"error":"Authorization failed because of missing requirement(s)."}  |
| `tenant people profilecardproperty list` | denied | {"error":"Authorization failed because of missing requirement(s)."}  |
| `tenant people pronouns get` | denied | {"error":"Authorization failed because of missing requirement(s)."}  |
| `tenant report settings get` | denied | {"error":"{\"error\":{\"code\":\"S2SUnauthorized\",\"message\":\"Invalid permission.\"}}"}  |
| `tenant security alerts list` | denied | {"error":"Auth token does not contain valid permissions or user does not have valid roles."}  |
| `tenant serviceannouncement health get` | denied | Graph answers UnknownError; the token has no ServiceHealth / ServiceMessage scope |
| `tenant serviceannouncement health list` | denied | Graph answers UnknownError; the token has no ServiceHealth / ServiceMessage scope |
| `tenant serviceannouncement healthissue get` | not called | no health issue to read (none listed, or the listing was refused) |
| `tenant serviceannouncement healthissue list` | denied | Graph answers UnknownError; the token has no ServiceHealth / ServiceMessage scope |
| `tenant serviceannouncement message get` | not called | no message to read (none listed, or the listing was refused) |
| `tenant serviceannouncement message list` | denied | Graph answers UnknownError; the token has no ServiceHealth / ServiceMessage scope |
