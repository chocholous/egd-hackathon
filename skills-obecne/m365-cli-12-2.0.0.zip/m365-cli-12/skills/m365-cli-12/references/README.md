> **PPF poznámka** (jediná změna textu). Kopie README ze zdrojového repa `m365-cli-12` (commit 6c3ad32), kde je skill
> v kořeni repa. V pluginu neexistují kořenové symlinky `./m365` a `./lookup`, `npm run …` ani
> `.claude/settings.json`: v celém textu čti `./m365` jako `<m365>` a `./lookup` jako `<lookup>` ze `SKILL.md`,
> skripty leží ve `scripts/`, hook ve `hooks/`. Postup instalace CLI a odchylky: `ATTRIBUTION.md`.

# m365-cli skill

A [Claude Code](https://claude.com/claude-code) skill plus a small toolchain that stops AI
agents from guessing their way through [CLI for Microsoft 365](https://pnp.github.io/cli-microsoft365/).

This is the port to **CLI v12** (pinned 12.0.0) of
[`m365-cli`](https://github.com/chocholous/m365-cli), which stays on v11. The two are meant
to live on one machine: `./m365` here gives v12 a home directory of its own, because run
from the same home v12 deletes v11's token cache — see "A home of its own".

## The problem

`m365` has ~900 commands. An agent that writes `--pageTitle` instead of `--title` gets a
hard rejection — annoying but harmless. The dangerous failures are the quiet ones:

- `{"error":{}}` — an empty object that hides an HTTP **401**. Usually you are hitting a
  SharePoint hostname belonging to a different tenant than the one you signed in to.
- `Attempted to perform an unauthorized operation.` — a missing **role**, not bad syntax.
  Agents burn turns rewriting a command that was correct all along.
- `{"error":{"name":"ExitPromptError"}}` — a destructive command asked for confirmation and
  found no TTY. The operation did *not* run. Adding `--force` to "fix" it silently runs it.
  (Through `./m365` it arrives at once; the bare CLI in an agent's shell waits on a stdin
  that never closes — see [No terminal, no waiting](#no-terminal-no-waiting).)

## The tool

One command answers "how do I call this":

```bash
./lookup spo page add
```

```
m365 spo page add

  Creates modern page

REQUIRED
  -n, --name <string>
  -u, --webUrl <string>

OPTIONAL
  -t, --title <string>
  -l, --layoutType <Article|Home|SingleWebPartAppPage|RepostPage|...>
      --publish   (flag, takes no value)

GLOBAL
      --output <csv|json|md|text|none>
      --query <JMESPath>

More: --examples --remarks --response
```

| | |
|---|---|
| `./lookup <command>` | required vs optional, types, enums, flags |
| `./lookup <group>` | what lives under a path |
| `./lookup -f <text>` | search names, aliases, descriptions |
| `./lookup <command> --examples` | also `--remarks`, `--permissions`, `--response` |

Where a command was seen to behave in a way its options cannot show, the lookup says so
under **WARNING** — `./lookup spo site recyclebinitem move` tells you that `--ids` does not
limit the move and the whole first-stage recycle bin goes. Those texts live, each with its
evidence, in `scripts/verified-exceptions.json`.

Instant and offline. There is nothing else to learn — the awkward parts are handled inside
the tool, and the skill tells the agent to take its output as given.

## Why it is not just `m365 --help`

Two reasons, both measured against 12.0.0 (`npm run verify` repeats the second one).

**Correctness.** `--help` is generated from docs that have drifted from the implementation.
`scripts/verify-commands.mjs` loads every one of the 888 commands in-process and asks the
CLI's own validation what it accepts, without running any command or touching the network:

| | |
|---|---|
| options documented but **rejected** by the CLI | 10 |
| options the CLI accepts but docs omit | 14 |
| requiredness disagreements between docs and CLI | 14 |
| casing typos (`--displayname` for `--displayName`) | 2 |
| short forms (`-x`) shown in the docs that do not work | 15 |
| commands whose `--output` docs claim more formats than they accept | 59 |
| commands that accept **any** option name, typos included | 29 |
| flags where `--flag false` still switches the flag on | 67 |

So the tool reads the package's structured command index for names, requiredness, types
and enums, and the shipped docs only for prose sections and for whether an option takes a
value. Where the index itself disagrees with the CLI, the correction is recorded with its
evidence in `scripts/verified-exceptions.json`, and `npm run verify` fails (rc=1) as soon as
the index plus those corrections stop matching what the CLI accepts — run it after every
version bump. The last two rows are behaviour no help text mentions: the lookup marks the
any-option commands with a NOTE and prints `<true|false>` only on options that really take
a value; the skill lists the rest as traps.

What validation cannot show is what a command does once it reaches the service. That came
from running them: [LIVE-VERIFIED.md](LIVE-VERIFIED.md) records every `spo` command against
a test site, and the defects it turned up (one of them moves a whole recycle bin) are
printed by the lookup as a WARNING on the command concerned.

**Speed.** v12 no longer loads every command module before answering, so `--help` through
the wrapper is down to roughly 170–200 ms here (v11: ~2.4 s). `./lookup` answers in about
60 ms on node and 13–28 ms on bun, by reading the package's data files instead of spawning
the CLI and by reading the help doc of the one command asked about. The gap is now a
convenience, not the argument; correctness is.

## Quick start

```bash
npm install                # installs the pinned CLI for Microsoft 365
cp .env.example .env       # every value documents the command that discovers it
$EDITOR .env
npm run doctor             # runtime, package contract, .env, login, SharePoint reachability
./lookup spo page add      # and you are working
```

Run the CLI itself as `./m365` — the pinned version, rather than whatever `m365` resolves
to on PATH, and kept apart from a v11 install on the same machine (below).

A fresh home means fresh settings: v12 starts with telemetry **on** and with its own
defaults, whatever you set for v11. `npm run doctor` says so; the fix is
`./m365 cli config set --key disableTelemetry --value true`, and likewise for `output`,
`prompt` and the rest (`./m365 cli config list`).

`./lookup` and `./m365` are symlinks to Node scripts. Where symlinks do not survive —
native Windows, where git checks them out as plain text files unless `core.symlinks` is
on — call the scripts directly; they are the same thing:

```powershell
node scripts/m365-lookup.mjs spo page add
node scripts/m365-run.mjs spo web get --url https://contoso.sharepoint.com
npm run doctor
```

Node.js is the only runtime required. [bun](https://bun.sh) is optional: when it is on
`PATH`, `./m365` runs the CLI on it, because it starts faster.

### Values from `.env`

A command that needs `$M365_SITE` has to get it into the shell that expands the command
line — and every agent shell call starts fresh, so it goes on the **same** line:

```bash
source scripts/env.sh && ./m365 spo list list --webUrl "$M365_SPO_ROOT"          # bash, zsh, WSL, Git Bash
```

```powershell
node scripts/env.mjs pwsh | Out-String | Invoke-Expression; node scripts/m365-run.mjs spo list list --webUrl $env:M365_SPO_ROOT
```

`scripts/env.mjs` does the work for both and prints assignments for the shell to evaluate,
plus `M` pointing at the wrapper; `scripts/env.sh` is a shim around it. PowerShell pipes it
into `Invoke-Expression` instead of dot-sourcing a `.ps1`, because that works under the
default `Restricted` execution policy and a script file does not. The wrapper does not read
`.env` itself on purpose: the values are needed by the shell, before the wrapper starts,
and `.env` holds nothing the wrapper uses.

**Which `.env`.** The nearest one from the current directory upward, within these stops:

| stop | applies | effect |
|---|---|---|
| your home directory | always | `~/.env` and anything above home (`/Users/.env`, `/.env`) are never read; from outside home (`/tmp/x`) the search ends below `/` |
| `$CLAUDE_PROJECT_DIR` | when set **and** the current directory is inside it | search up to it, not above — crossing any `.git` on the way, so a submodule at `app/tools/m365-cli` still finds `app/.env` |
| the first directory holding `.git` (repo, worktree, submodule) | otherwise | not above the repository root |

Note that `CLAUDE_PROJECT_DIR` is set for hooks but **not** in the environment of the
agent's Bash tool commands (observed in the desktop app) — there the `.git` and home stops
are the ones that apply, so inside a submodule the parent's `.env` is not found: put one in
the submodule, or `export CLAUDE_PROJECT_DIR=…` on the same command line. A `.env` above the
project belongs to something else (a parent monorepo, `~/.env`), and loading its
`M365_SPO_ROOT` is how a command ends up aimed at the wrong tenant. (Until the Node port,
`env.sh` took the `.env` next to the nearest `package.json`.) A value containing a NUL byte
is refused with the key's name — no shell variable can hold one.

**How it is parsed.** By node's own parser (`util.parseEnv`, the one behind `--env-file`),
not by a shell — so a value is never executed, and also never expanded:

- `$VAR`, `${VAR}`, `$(...)` and backticks stay literal text
- single, double or backtick quotes delimit a value and are removed; inside double quotes
  `\n` becomes a newline
- there are **no backslash escapes**: `L="a \"b\""` ends at the second `"` and gives `a \`
- an unquoted value ends at ` #` (a comment); `export KEY=...` works; CRLF is fine

**Why the output is safe to evaluate.** Every value is emitted as a single-quoted literal,
and a name that is not a plain identifier is skipped with a warning. For PowerShell the
quoting doubles not only `'` but also `‘ ’ ‚ ‛` (U+2018–U+201B), which PowerShell treats as
single quotes too: without that a `.env` value such as `O’Brien` breaks the line, and a
crafted one runs code. `npm test` round-trips hostile values through bash, zsh and — when
installed — `pwsh`.

## Running the CLI: `./m365`

`./m365` (`scripts/m365-run.mjs`) runs the same pinned `dist/index.js`, with the same
arguments and the same output. It changes a few things around it, none of which touches
how a command behaves:

- **a home directory of its own** (`scripts/lib/v12-home.js`), see "A home of its own".
- **connection files written atomically under a lock** (`scripts/lib/atomic-token-cache.js`),
  see "When the sign-in keeps falling out".
- **`CLIMICROSOFT365_NOUPDATE=1`**, which drops update-notifier and the second process it
  spawns per invocation to poll npm.
- **stdout is written synchronously under bun** (`scripts/lib/sync-stdout.js`). This one is
  not an optimisation but a repair: see "Bun truncates piped output" below. It costs ~25 ms
  per call and is not optional on bun.
- **a 120 s cap** on the whole invocation, see "When a command hangs".

**Runtime.** bun when it is on `PATH`, otherwise the node that runs the wrapper.
`M365_RUNTIME=node` or `M365_RUNTIME=bun` forces one (`bun` without bun on `PATH` is an
error, not a silent fallback). On Windows only `bun.exe` counts: an npm-installed bun also
puts `bun.cmd` on `PATH`, and a `.cmd` can only be started through `cmd.exe`, which would
re-parse every CLI argument (quotes, `%`, `^`, `&`) — with only the shim there, the wrapper
uses node. `npm run doctor` prints the runtime the wrapper will pick, from the same code
(`scripts/lib/runtime.mjs`). The wrapper itself is a small node process that starts the
CLI as a child and stays to enforce the cap.

Measured 2026-11-11 on macOS arm64 against 12.0.0, median of 15, signed out, telemetry off:

| | `./m365 version` | `./m365 status` |
|---|---|---|
| node (`M365_RUNTIME=node`) | 284 ms | 285 ms |
| bun (`M365_RUNTIME=bun`) | **161 ms** | **161 ms** |

v12 no longer ships the `applicationinsights` SDK that v11 loaded on every invocation, so
the no-op preload the v11 wrapper carried for it is gone too. A bare `node dist/index.js`
was deliberately not timed for comparison: without the wrapper it runs in the real home.

**Telemetry.** As of 12.0.0 it is a POST to Google Analytics after each command
(`dist/googleAnalytics.js`), and the wrapper does nothing about it. The only opt-out is the
setting: `./m365 cli config set --key disableTelemetry --value true`. It is stored in the
CLI's home, so the opt-out of a v11 install does **not** carry over; `npm run doctor`
checks it.

### A home of its own

v12 moved the MSAL token cache (the refresh token) into the OS credential store. On every
token access `dist/auth/msalCachePlugin.js` then deletes the old file,
`~/.cli-m365-msal.json` — which is the **live** token cache of a v11 install on the same
machine. v12 also writes the same `~/.cli-m365-connection.json`,
`~/.cli-m365-all-connections.json` and configstore file as v11. From one home, v12 signs
v11 out and the two overwrite each other's active connection.

`./m365` therefore preloads `scripts/lib/v12-home.js`, which makes `os.homedir()` answer
`~/.cli-m365-12` (or `$M365_V12_HOME`) inside the CLI process only. Everything the CLI
derives from the home directory follows: the legacy-cache delete, both connection files,
the settings (`<home>/.config/configstore/cli-m365-config.json`).

What that does and does not give you:

- `$HOME` itself is untouched — the macOS keychain is found through it, and child
  processes see the real home.
- **The tokens are not isolated.** They are one credential-store item per OS user
  (service `cli-microsoft365`, account `msal-cache`), shared by every v12 install whatever
  its home. Two v12 homes signed in to different tenants share that item.
- **Never set `M365_V12_HOME` to your real home** next to a v11 install; `npm run doctor`
  fails on it.
- Under bun the redirect reaches `os.homedir()` on the default import (`import os from
  'os'`) but not a named `import { homedir } from 'os'` (bun 1.4.2). The CLI's auth code
  uses the former; `npm run contract` fails if a release changes that.

### Where the CLI package lives: `M365_PKG_DIR`

By default everything reads the copy `npm install` put in this repo's `node_modules`. When
the package is installed elsewhere — a plugin keeping it in its own data directory, say —
point `M365_PKG_DIR` at the package directory (the one holding its `package.json`):

```sh
M365_PKG_DIR=/path/to/node_modules/@pnp/cli-microsoft365 ./m365 version
```

The wrapper, `./lookup`, `npm run contract`, `npm run doctor` and the token-cache test all
resolve it in one place, `scripts/lib/pkg.mjs`. `M365_DIST` (the path to a `dist/index.js`)
still works and still wins, but moves only what `./m365` runs — the lookup keeps reading
`M365_PKG_DIR` or the repo copy. That is what the shim below relies on.

### Outside this repo

The v11 repo documents a shim that shadows the global `m365` with its wrapper. **Do not
point that pattern at this wrapper** unless the global install is v12 as well:
`M365_DIST` changes which `dist/index.js` runs, not where its home is, so a global v11
run through `scripts/m365-run.mjs` here would look for its sign-in in `~/.cli-m365-12`
and find none. A project that wants v12 calls this repo's `./m365` (or
`node /path/to/m365-cli-12/scripts/m365-run.mjs`) by path.

### Bun truncates piped output

Running the CLI on bun costs one thing, and it is worth knowing about because it fails
**silently and with exit code 0**. `dist/cli/cli.js` prints with `console.log` and calls
`process.exit(0)` on the next line (cli.js:221); under bun, whatever is still buffered at
that moment is dropped. `dist/index.js` tries to prevent exactly this with
`process.stdout._handle.setBlocking(true)`, which does nothing under bun — `_handle` is
`undefined` there. Under node it works: for a pipe, `_handle.setBlocking` exists (checked on
node 22.23), which is why the real CLI on node delivers everything.

Measured on `spo page list` over 268 pages, 4.78 MB of JSON:

| | result |
|---|---|
| `node … \| jq length` | 257 pages, 3 runs of 3 |
| `bun … \| jq length` | **truncated, 3 runs of 3** — `Unfinished string at EOF` |
| `bun … \| wc -c` | complete — `wc` drains fast enough to hide it |
| `bun … > file` | complete |
| `bun` + `sync-stdout.js` `\| jq length` | 257 pages, 3 runs of 3 |

The reader's speed decides, which is what makes it dangerous: the quick check passes and
the real pipeline loses data. A batch script reading through `execFile('m365', …)` is
exactly the slow reader. `scripts/lib/sync-stdout.js` routes `console.log`/`console.error`
and both stream `write`s through `fs.writeSync`, so nothing is left buffered to lose.

A synthetic script that writes 4 MB and exits does **not** reproduce it under bun (node
truncates that one instead, at 64 KB, because it skips the CLI's `setBlocking` call). The
real CLI does, offline: `cli completion clink update` prints ~315 KB without touching the
network, and under bun without `sync-stdout.js` a reader that waits 800 ms gets exactly
65536 bytes, rc 0. `npm test` runs that check on both runtimes (`test/wrapper.test.mjs`).
After a bun upgrade, check against a live read too:

```bash
./m365 spo page list --webUrl <a site with many pages> --output json | jq length
```

### When a command hangs

The CLI sets no HTTP timeout — axios is instantiated without one, and `timeout:` appears
nowhere in `dist/` except an unrelated `entra` command — and on **429/503 it retries
forever**: `request.js` recurses into itself with no cap on attempts or total time, and
prints `Request throttled. Waiting N sec` only under `--debug`. Six `spo page remove`
processes were found on this machine still alive after **14 hours** because of it.

So `./m365` caps an invocation at **120 s** and exits **124**. That number is a deadlock
detector, not a latency policy: the longest legitimate command measured against this tenant
was ~56 s (in a live batch at concurrency 35, and that is a lower bound — the sampling
window truncated it), while `spo page list` over 268 pages takes ~17 s on an idle machine.
`M365_TIMEOUT=<seconds>` raises it (`s`/`m`/`h`/`d` suffixes and an exponent work, as
they did with `timeout(1)`: `90`, `1.5m`, `1e3`), `M365_TIMEOUT=0` switches it off, and an
interactive run (stdin is a TTY) is exempt so a device-code or browser sign-in can take as
long as it takes. Anything else is refused with exit **125**, before the CLI starts. A
`SIGINT`/`SIGTERM`/`SIGHUP` sent to the wrapper is passed on to the CLI.

Where this differs from the sh wrapper, deliberately:

| | sh wrapper (`timeout(1)`) | Node wrapper | why |
|---|---|---|---|
| `M365_TIMEOUT=` (empty) | no cap | the default cap | empty is how a variable gets cleared; it must not switch the guard off by accident |
| no `timeout` binary (stock macOS has none) | no cap, silently | cap applies | the cap is a timer in the wrapper, nothing to install |
| what the cap kills | the CLI's whole process group | the CLI process (`SIGTERM`; on Windows: terminated) | the CLI stays in the caller's process group, so Ctrl-C and job control reach it like any child. A subprocess of the CLI could outlive the kill in principle; none is known with update-notifier off |
| invalid value | `timeout: invalid time interval`, 125 | message naming `M365_TIMEOUT`, 125 | same code, clearer text |

**On 124, verify — do not retry blindly.** The command was cut off, so whether the service
carried it out is unknown. Read the target back and decide from what you find: a blind
retry of `spo page add` duplicates a page that may well have been created. And retrying an
invocation the cap interrupted mid-`Retry-After` sends requests into the window the service
explicitly asked you to stay out of, which earns deeper throttling.

### No terminal, no waiting

A command that asks "Are you sure…?" reads the answer from stdin. An agent's shell hands it
a stdin that is neither a terminal nor ever closed, so on 12.0.0 the question sat there
until the cap above cut the CLI off — exit 124 after 120 s, with a message about throttling.
Measured with `spo listitem remove` without `--force`: node with inherited stdin and bun
either way ran into the cap; only node with `</dev/null` gave up at once.

`scripts/lib/no-tty-stdin.js` is preloaded for that case: when stdin is not a terminal, the
CLI gets a stand-in stdin holding one interrupt. The prompt library gives up on it, and the
CLI exits **1** with `{"error":{"name":"ExitPromptError"}}` (text output:
`User force closed the prompt with SIGINT`) straight away, on both runtimes. Nothing is
answered on your behalf — an interrupt is a refusal, the command does not run. The CLI
itself never reads stdin, only its prompt library does; `test/prompt.test.mjs` holds both
claims against the installed package. With a terminal attached nothing changes.

### When the sign-in keeps falling out

As of 12.0.0 the sign-in is kept in two places:

- the **MSAL cache** (the refresh token) in the OS credential store — the macOS keychain,
  DPAPI on Windows, libsecret on Linux — guarded by the CLI's own lockfile;
- two **connection files** in the CLI's home, `.cli-m365-connection.json` (the active
  connection with its access tokens) and `.cli-m365-all-connections.json`, written with a
  plain `fs.writeFile` (`dist/auth/FileTokenStorage.js`): no lock, no temp file, no rename.

Parallel invocations (several sessions, `xargs -P`) tear the connection files, and a reader
in the middle of a write sees half a file. On v11, where the MSAL cache went through the
same code, that meant a browser sign-in every hour until the torn file was found (observed
2026-09-29).

`./m365` therefore preloads `scripts/lib/atomic-token-cache.js` (under node too, via
`--import`), which writes those two files to a temp file and renames it over the target,
under a lock directory `.cli-m365-cache.lock` next to them. A writer waits for the lock at
most `M365_CACHE_LOCK_WAIT_MS` (5000) and then fails the write rather than writing
unlocked; a lock older than `M365_CACHE_LOCK_STALE_MS` (15000) is treated as left by a dead
process.

`npm run test:cache` (node) or `bun scripts/test-token-cache.mjs` runs 30 concurrent
writers × 40 rounds through the CLI's own `FileTokenStorage` in a throwaway home, once
without the preload and once with it, on whichever runtime started it. On 2026-11-11
against 12.0.0: node 866 torn reads without, 0 with; bun 591 without, 0 with.

`npm run doctor` checks it (section *sign-in state*): which home the CLI uses, whether the
MSAL cache item exists (its presence only — the secret is never read), that both connection
files parse, how long each access token has left, a stale lock or leftover temp file, and
that a v11 token cache is out of v12's reach. It prints the exact `./m365 login …` repair
command with the connection's appId and tenant.

Things that do **not** work, in case they look obvious: bundling the CLI with
`bun build` (commands are loaded dynamically and then checked with
`instanceof Command`, so a bundled class fails the check and the CLI silently prints its
general help instead), the same for `bun build --compile`, and `NODE_COMPILE_CACHE`
(9.6 MB of cache, no measurable change — the cost is executing the module graph, not
compiling it).

## Pinned on purpose

The tool reads files inside `@pnp/cli-microsoft365` that are implementation detail, not
public API. The version is therefore pinned exactly, and `npm run contract` asserts every
assumption — the index shape, the docs layout, the markdown renderer. It runs automatically
whenever the installed version differs from the last one seen, and **fails loudly**:

```
@pnp/cli-microsoft365 12.1.0 does not match what this tooling reads.

  - allCommandsFull.json options lost the "required" field

Not falling back to 'm365 --help' on purpose: it would still work, from docs
that disagree with the CLI, and nobody would notice.
```

## The hook

`.claude/settings.json` registers one `PreToolUse` hook on `Bash|PowerShell`,
`.claude/hooks/prefer-lookup.mjs`. It is a Node script with no dependencies, registered in
exec form (`"command": "node"`, `"args": [...]`), so no shell parses it — the same entry
works where Claude Code runs hooks under Git Bash, PowerShell or `sh`. It reads the hook
JSON with `JSON.parse` (anything it cannot parse gets no decision), splits the command line
by the rules of the shell it came from (`tool_name` `Bash` or `PowerShell`: in PowerShell a
backslash is a path separator, `&` calls, quotes include `‘’“”`, `m365` may be
`m365.cmd`/`.ps1`/`.exe`), skips here-document bodies, only ever returns a decision, and
denies exactly two things:

- `m365 <command> --help` / `-h` / `--help=…`, **however m365 is invoked** → points at the
  lookup, which is faster and corrects the places the CLI's help is wrong
- any m365 that is not the pinned wrapper → points at the wrapper. That covers a bare
  `m365` — also after `if`/`then`/`do`/`!`/`{`, behind `VAR=value`, `env`, `command`,
  `exec`, `time`, `nohup`, `nice`, `timeout`, `stdbuf`, `xargs`, `sudo`, `watch`,
  `caffeinate`, `script`, `env -S '…'`, inside `sh -c '…'`, `$'…'`,
  `pwsh -c '…'`, `cmd /c …`, `eval …` and `Invoke-Expression '…'`, inside `$(…)`, after
  leading redirections (`2>/dev/null m365`), inside function bodies, as `m365.CMD` (case is
  ignored), and in PowerShell after an assignment (`$x = m365 …`, `[string]$x +=`,
  `$script:x =`), a dot (`. m365`) or a `<# comment #>`, inside script blocks
  (`ForEach-Object { m365 … }`) and through `Start-Process m365 -ArgumentList …` — as well as
  `bun run m365`, `npx`/`bunx`/`npm exec`/`pnpm dlx` of
  `m365` or `@pnp/cli-microsoft365`, another `m365` by path (`/usr/local/bin/m365`,
  `./node_modules/.bin/m365`, `C:\tools\m365.cmd`), and `node …/cli-microsoft365/dist/index.js`
  — also when the path is built at run time, `node $(npm root -g)/@pnp/cli-microsoft365/dist/index.js`

Not refused: `command -v m365` / `command -V m365`, `which m365`, `type m365` (they only ask
whether it exists), and text — quoted arguments, here-document bodies.

Command lines inside command lines (`sh -c`, `eval`, `cmd /c`, `Invoke-Expression`, `pwsh
-c`) are unpacked up to 8 deep (`MAX_NESTING` in the hook); deeper is **refused**, not let
through unread. So is a command line the reader cannot handle at all (it would otherwise
crash, and a crashed hook counts as no decision).

Allowed: the `--run` invocation, `node`/`bun` running a `m365-run.mjs`, and a path that
resolves (against the tool call's `cwd`, through symlinks) to `m365-run.mjs` — which is what
`./m365` is.

**Out of reach**, since the hook reads a command line and does not run one: anything decided
at run time — `"$M"`, `$(which m365)`, `& (Get-Command m365)`, `source <(echo m365)`,
aliases, `eval "$cmd"`, a script file or an `npm run <script>` that calls m365 — and
wrappers it does not read into (`parallel`, `Start-Job`, Linux `script -c '…'`). The
backstop there is the skill.

The messages name `./lookup`, `./m365` and `source scripts/env.sh` for Bash by default, and
`node scripts/m365-lookup.mjs`, `node scripts/m365-run.mjs` and the `env.mjs |
Invoke-Expression` line for PowerShell (on native Windows the root symlinks are text
files). Where those are not the right invocation, pass them — `--run`/`--lookup` apply to
both shells unless `--ps-run`/`--ps-lookup` say otherwise, `--env` is Bash's and `--ps-env`
PowerShell's:

```json
"command": "node",
"args": ["${CLAUDE_PLUGIN_ROOT}/hooks/prefer-lookup.mjs",
         "--lookup", "node \"${CLAUDE_PLUGIN_ROOT}/scripts/m365-lookup.mjs\"",
         "--run", "node \"${CLAUDE_PLUGIN_ROOT}/scripts/m365-run.mjs\"",
         "--env", "eval \"$(node \"${CLAUDE_PLUGIN_ROOT}/scripts/env.mjs\" sh)\"",
         "--ps-env", "node \"${CLAUDE_PLUGIN_ROOT}/scripts/env.mjs\" pwsh | Out-String | Invoke-Expression"]
```

`npm test` runs the allow/deny table (`test/hook.test.mjs`).

**Needs Claude Code 2.1.139 or newer.** That release added the `args` field (exec form,
per its changelog). The docs do not say what an older version does with a hook object that
has `args`; assume the hook does not run there — nothing refuses anything, silently. On an
older Claude Code, register it in shell form instead:
`"command": "node \"${CLAUDE_PROJECT_DIR}/.claude/hooks/prefer-lookup.mjs\""` (works where
hooks run under `sh` or Git Bash; under PowerShell it depends on Claude Code substituting
the placeholder before the shell sees it, which the docs do not state).

This exists because it was measured: across six agents given read-only tasks in this
repo, three reached for `m365 --help` (19 calls) before reading anything, and two ran live
commands through a different globally-installed version without noticing.

Confirmed firing in headless sessions rooted at this repo (Claude Code 2.1.293, macOS,
2026-10-08). Bash tool: `m365 --version`, `timeout 30 m365 version`,
`./node_modules/.bin/m365 version` and `node scripts/m365-run.mjs spo web get --help` are
refused and the CLI never starts; `node scripts/m365-run.mjs version` runs. PowerShell tool
(`CLAUDE_CODE_USE_POWERSHELL_TOOL=1`, pwsh 7.5.4): `& m365 version` is refused with the
PowerShell wording (`node scripts/m365-run.mjs`, the `env.mjs | Invoke-Expression` line),
`node scripts/m365-run.mjs version` runs. Native Windows is not yet verified.

In practice the skill usually gets there first. Re-run on the task that had failed twice —
"explore what m365 can do with Teams" — an agent loaded the skill, went straight to
`./lookup teams`, and ran every live command through the pinned path: no `--help`, no bare
`m365`, so the hook had nothing to refuse. It is the backstop for agents that never read
the skill, which is exactly how those two failures happened.

Read it before you clone — a hook runs code on your machine, and you should never take
that on trust.

## What is in here

```
.claude/settings.json              registers the hook below
.claude/hooks/prefer-lookup.mjs    PreToolUse guard, Node, no dependencies
.claude/skills/m365-cli/SKILL.md   the skill: two rules, an error→cause table
lookup -> scripts/m365-lookup.mjs  the tool (node shebang, run it directly)
m365 -> scripts/m365-run.mjs       the CLI itself, in a home of its own (see above)
scripts/lib/pkg.mjs                where the CLI package is (M365_PKG_DIR, M365_DIST)
scripts/lib/v12-home.js            the home redirect that keeps v12 off a v11 install
scripts/lib/sync-stdout.js         synchronous output: bun drops buffered writes on exit
scripts/lib/no-tty-stdin.js        no terminal: a confirmation prompt fails at once, not at the timeout
scripts/lib/atomic-token-cache.js  connection files written atomically under a lock
scripts/lib/cache-health.mjs       sign-in state check for doctor
scripts/test-token-cache.mjs       concurrent-write test of the two above
scripts/lib/                       index building, help sections, the contract check
scripts/verified-exceptions.json   corrections to the package index and the lookup's WARNINGs, each with evidence
scripts/verify-commands.mjs        every command's options vs the CLI's validation (npm run verify)
scripts/doctor.mjs                 environment check (npm run doctor)
LIVE-VERIFIED.md                   what each spo command did against a tenant, and the defects found
live/                              the scripts that produced it; they write to a real site (live/README.md)
scripts/env.mjs, scripts/env.sh    .env into the calling shell (sh / PowerShell)
test/                              npm test -- hook table, wrapper, M365_PKG_DIR, .env
```

## Prerequisites

Node.js 22 or newer and npm for installing the pinned CLI, and a signed-in `m365`
(`./m365 login` — a v11 sign-in does not carry over). [bun](https://bun.sh) is optional.
Checked against `@pnp/cli-microsoft365` v12.0.0 on macOS (node 22.23, bun 1.4.2): the
offline suite, the contract, the concurrent-write test, signed-out CLI calls, and every
command's options against the CLI's own validation (`npm run verify`; the entries in
`scripts/verified-exceptions.json` are proven on 12.0.0 that way). Against a tenant, on a
test site: a browser sign-in with the keychain under bun, next to a v11 install that stayed
signed in, and every `spo` command plus the read commands of `entra` and `tenant` --
[LIVE-VERIFIED.md](LIVE-VERIFIED.md) has the result for each one, and the CLI defects the
pass found. About half of `spo` is verified there with its result checked; the rest was
refused for lack of a SharePoint admin role or deliberately not called. **Not verified:**
the other command groups against a tenant, `--permanent`, token renewal after expiry, and
the new commands that write outside a test site (`outlook event add`,
`outlook calendargroup add`, `spe container permission …`). Native Windows
and Linux are written for but not verified. `npm run doctor` checks all of it, `npm test` checks the tooling itself (offline,
no tenant; `test/run.mjs`). Each test — and each test file — gets 5 minutes; on a loaded
machine raise it with `M365_TEST_TIMEOUT_MS=<ms> npm test`.

## License

MIT
