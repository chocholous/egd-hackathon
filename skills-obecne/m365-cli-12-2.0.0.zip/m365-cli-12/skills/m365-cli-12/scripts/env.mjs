#!/usr/bin/env node
// Put the project's .env into the CALLING shell, so the same command line can expand
// $M365_SITE & co. A child process cannot change its parent's environment, so this prints
// assignments for the shell to evaluate:
//
//   bash / zsh   source scripts/env.sh && ./m365 spo web get --url "$M365_SITE"
//                (env.sh is a shim around:  eval "$(node scripts/env.mjs sh)")
//   PowerShell   node scripts/env.mjs pwsh | Out-String | Invoke-Expression; node scripts/m365-run.mjs spo web get --url $env:M365_SITE
//                (piped into Invoke-Expression rather than a dot-sourced .ps1: that works
//                under the default Restricted execution policy, a .ps1 file does not)
//
// Which .env (the stops: project root, home), and how it is parsed: ./lib/envfile.mjs. Also sets M (sh: $M, PowerShell: $M)
// to the wrapper script. On any failure prints nothing to stdout and exits 1, so the shim
// can unset a stale $M instead of reusing one from another project.
//
// What is printed is evaluated as code, so every value goes out as a single-quoted literal
// and names that are not plain identifiers are skipped. In PowerShell the curly quotes
// U+2018-U+201B close a single-quoted string exactly like ' does -- they are doubled too,
// or a value like  O’Brien  breaks the line and a crafted one runs code.
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { findEnvFile, readEnvFile } from './lib/envfile.mjs';
import { distPath, installHint } from './lib/pkg.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const wrapper = path.join(here, 'm365-run.mjs');
const fail = (msg) => { fs.writeSync(2, `env: ${msg}\n`); process.exit(1); };

const NAME = /^[A-Za-z_][A-Za-z0-9_]*$/;
const QUOTE = {
  sh: (v) => `'${v.replace(/'/g, `'\\''`)}'`,
  pwsh: (v) => `'${v.replace(/['\u2018\u2019\u201A\u201B]/g, (q) => q + q)}'`,
};
const ASSIGN = {
  sh: (k, v) => `export ${k}=${QUOTE.sh(v)}`,
  pwsh: (k, v) => `$env:${k} = ${QUOTE.pwsh(v)}`,
};
const SET_M = {
  sh: (v) => `export M=${QUOTE.sh(v)}`,
  pwsh: (v) => `$M = ${QUOTE.pwsh(v)}`,
};

const shell = process.argv[2];
if (!Object.hasOwn(ASSIGN, shell)) { fail('usage: node scripts/env.mjs sh|pwsh'); }

const file = findEnvFile();
if (!file) { fail(`no .env in ${process.cwd()} or above it up to the project root — copy .env.example and fill it in using the commands it documents`); }
if (!fs.existsSync(distPath())) { fail(`no CLI at ${distPath()} — ${installHint()}`); }

const vars = readEnvFile(file);
// No shell can hold a NUL in a value (and node refuses one in a child's environment).
for (const [k, v] of Object.entries(vars)) {
  if (v.includes('\0')) { fail(`${k} in ${file} contains a NUL byte — no shell variable can hold that; fix the .env`); }
}
const lines = [];
for (const [k, v] of Object.entries(vars)) {
  if (!NAME.test(k)) { fs.writeSync(2, `env: skipping ${JSON.stringify(k)} in ${file}: not a variable name\n`); continue; }
  lines.push(ASSIGN[shell](k, v));
}
lines.push(SET_M[shell](wrapper));

// stderr, not stdout: stdout is what the shell evaluates
const v = spawnSync(process.execPath, [wrapper, 'version'], { env: { ...process.env, ...vars }, encoding: 'utf8' });
fs.writeSync(2, `m365 ${(v.stdout || '?').trim().replace(/"/g, '')}  root=${vars.M365_SPO_ROOT || '<unset>'}  env=${file}\n`);

fs.writeSync(1, lines.join('\n') + '\n');
