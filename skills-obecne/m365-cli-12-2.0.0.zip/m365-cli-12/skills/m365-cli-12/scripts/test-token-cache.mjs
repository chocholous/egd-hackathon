// Stress test for scripts/lib/atomic-token-cache.js against the CLI's own FileTokenStorage.
//
//   node scripts/test-token-cache.mjs           # runs both arms, exit 1 if the preload arm tears
//   bun scripts/test-token-cache.mjs            # the same on bun -- workers run on whichever ran this
//
// Each arm gets a throwaway HOME (os.homedir() follows it), then WORKERS processes at once
// each write and read ~/.cli-m365-connection.json ROUNDS times through FileTokenStorage.set/get and
// count reads that fail to parse. Arm A runs without the preload (expected to tear, which
// proves the test can see the fault); arm B runs with it (must tear 0 times, and the final
// file must parse).
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { distPath } from './lib/pkg.mjs';

const WORKERS = Number(process.env.WORKERS ?? 30);
const ROUNDS = Number(process.env.ROUNDS ?? 40);
const here = path.dirname(fileURLToPath(import.meta.url));
const dist = distPath();   // M365_DIST, else M365_PKG_DIR, else the pinned copy
const storage = path.join(path.dirname(dist), 'auth/FileTokenStorage.js');
const preload = path.join(here, 'lib/atomic-token-cache.js');
// bun preloads a path; node imports a specifier, and a Windows path is not one
const isBun = typeof Bun !== 'undefined';
const preloadArgs = isBun ? ['--preload', preload] : ['--import', pathToFileURL(preload).href];

if (process.argv[2] === '--worker') {
  const { FileTokenStorage } = await import(pathToFileURL(storage).href);
  const s = new FileTokenStorage(FileTokenStorage.connectionInfoFilePath());
  const blob = JSON.stringify({ accessTokens: { k: { accessToken: 'x'.repeat(30000 + Math.floor(Math.random() * 5000)) } }, pid: process.pid });
  let torn = 0;
  for (let i = 0; i < ROUNDS; i++) {
    await s.set(blob);
    try { JSON.parse(await s.get()); } catch { torn++; }
  }
  process.stdout.write(String(torn));
  process.exit(0);
}

async function arm(label, withPreload) {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'm365-cache-test-'));
  const args = [...(withPreload ? preloadArgs : []), fileURLToPath(import.meta.url), '--worker'];
  const runs = Array.from({ length: WORKERS }, () => new Promise((resolve) => {
    // USERPROFILE: os.homedir() reads it, not HOME, on Windows
    const p = spawn(process.execPath, args, { env: { ...process.env, HOME: home, USERPROFILE: home } });
    let out = '', err = '';
    p.stdout.on('data', (d) => { out += d; });
    p.stderr.on('data', (d) => { err += d; });
    p.on('close', (code) => resolve({ code, torn: Number(out) || 0, err }));
  }));
  const res = await Promise.all(runs);
  const torn = res.reduce((a, r) => a + r.torn, 0);
  const failed = res.filter((r) => r.code !== 0);
  let finalOk = true;
  try { JSON.parse(fs.readFileSync(path.join(home, '.cli-m365-connection.json'), 'utf8')); } catch { finalOk = false; }
  const leftovers = fs.readdirSync(home).filter((f) => f.endsWith('.tmp') || f === '.cli-m365-cache.lock');
  fs.rmSync(home, { recursive: true, force: true });
  console.log(`${label}: ${WORKERS}×${ROUNDS} writes+reads, torn reads ${torn}, final file ${finalOk ? 'parses' : 'TORN'}, worker failures ${failed.length}, leftovers ${leftovers.length}`);
  for (const f of failed.slice(0, 3)) { console.log(`  worker rc=${f.code}: ${f.err.trim().split('\n')[0]}`); }
  return { torn, finalOk, failed: failed.length, leftovers: leftovers.length };
}

console.log(`runtime: ${isBun ? `bun ${Bun.version}` : `node ${process.version}`}, CLI: ${dist}`);
const a = await arm('A without preload', false);
const b = await arm('B with preload   ', true);
if (a.torn === 0 && a.finalOk) { console.log('note: arm A did not tear this run -- raise WORKERS/ROUNDS to make the check meaningful'); }
process.exit(b.torn === 0 && b.finalOk && b.failed === 0 && b.leftovers === 0 ? 0 : 1);
