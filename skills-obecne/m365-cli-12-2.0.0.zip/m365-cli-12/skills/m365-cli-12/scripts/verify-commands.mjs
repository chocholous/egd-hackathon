#!/usr/bin/env node
// Measure the package's command index and help docs against what the CLI itself accepts,
// for every command, without running any command.
//   npm run verify            summary on stdout, rc=1 when the index disagrees with the CLI
//   npm run verify -- --json report.json    plus the full per-command findings
//
// How: the CLI's own entry point (dist/cli/cli.js execute) is called in this process with
// real argument vectors, so argument parsing, option processing and validation are the
// CLI's own code. The one thing replaced is the step after validation: cli.executeCommand
// is stubbed, so a probe that passes validation is recorded as "would run" and nothing
// runs. Network and child processes are stubbed too and counted -- a non-zero count means a
// validator reached out, and is reported.
//
// What a probe can tell: whether an option NAME is known to the command, which options are
// required, which --output modes are allowed, and whether an option takes a value. It
// cannot tell what a command does once it runs; that needs a signed-in session and a
// tenant, and is out of scope here.
import childProcess from 'node:child_process';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import http from 'node:http';
import https from 'node:https';
import module from 'node:module';
import os from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
// First: the CLI must believe in its own home before any of its modules load.
import { home } from './lib/v12-home.js';
import { installedVersion, paths, pkgDir } from './lib/contract.mjs';
import { loadIndex, withCallShapes } from './lib/index.mjs';

if (os.homedir() !== home) { console.error('verify: os.homedir() is not redirected; refusing to load the CLI'); process.exit(2); }

const jsonAt = process.argv.indexOf('--json');
const only = process.argv.includes('--only') ? process.argv[process.argv.indexOf('--only') + 1] : null;

// ---- nothing leaves this process ---------------------------------------------------
const sideEffects = [];
const block = (what) => (...a) => { sideEffects.push(`${what} ${String(a[0]?.href ?? a[0]?.hostname ?? a[0]).slice(0, 80)} during: ${current}`); throw new Error(`verify: ${what} blocked`); };
http.request = block('http.request'); https.request = block('https.request');
http.get = block('http.get'); https.get = block('https.get');
globalThis.fetch = block('fetch');
for (const fn of ['spawn', 'spawnSync', 'exec', 'execSync', 'execFile', 'execFileSync', 'fork']) { childProcess[fn] = block(`child_process.${fn}`); }
module.syncBuiltinESMExports();
let current = '(startup)';

// ---- the CLI, with the step after validation removed --------------------------------
const { cli } = await import(pathToFileURL(join(pkgDir, 'dist', 'cli', 'cli.js')).href);
const { ZodError } = await import(pathToFileURL(join(pkgDir, 'node_modules', 'zod', 'index.js')).href)
  .catch(() => import('zod'));

class Stop extends Error {
  constructor(kind, detail) { super(kind); this.kind = kind; this.detail = detail; }
}
cli.executeCommand = async () => { throw new Stop('run'); };
cli.closeWithError = async (error) => {
  if (error instanceof Stop) { throw error; }
  if (error && typeof error === 'object' && Array.isArray(error.issues)) {
    throw new Stop('error', {
      issues: error.issues.map((i) => ({ path: i.path.join('.'), code: i.code, keys: i.keys, message: i.message })),
      text: error.issues.map((i) => (i.path.length > 0 ? `${i.path.join('.')}: ${i.message}` : i.message)).join('\n'),
    });
  }
  throw new Stop('error', { text: String(error?.message ?? error).trim() });
};
// The answers must not depend on this machine's CLI settings: with prompt on, a missing
// option becomes a question instead of an error.
const realSetting = cli.getSettingWithDefaultValue.bind(cli);
cli.getSettingWithDefaultValue = (name, def) => (name === 'prompt' ? false : realSetting(name, def));
const refuse = (kind) => async () => { throw new Stop(kind); };
cli.promptForValue = refuse('prompt'); cli.promptForInput = refuse('prompt');
cli.promptForSelection = refuse('prompt'); cli.promptForConfirmation = refuse('prompt');
cli.log = () => {}; cli.error = async () => {};
const realExit = process.exit;
process.exit = (code) => { throw new Stop('exit', { code }); };
void ZodError;

/** One probe. -> { kind: 'run'|'error'|'prompt'|'exit'|'nocommand'|'crash', text, issues, resolved } */
async function probe(words, args = []) {
  current = [...words, ...args].join(' ');
  cli.commandToExecute = undefined;
  cli.optionsFromArgs = undefined;
  cli.currentCommandName = undefined;
  let out;
  try {
    await cli.execute([...words, ...args]);
    out = { kind: cli.commandToExecute ? 'returned' : 'nocommand' };
  }
  catch (e) {
    out = e instanceof Stop ? { kind: e.kind, ...e.detail } : { kind: 'crash', text: String(e?.stack ?? e).split('\n')[0] };
  }
  out.parsed = cli.optionsFromArgs?.options ?? {};
  out.resolved = cli.commandToExecute?.name ?? null;
  out.schema = Boolean(cli.commandToExecute?.command.schema);
  out.anyOption = Boolean(cli.commandToExecute?.command.allowUnknownOptions?.());
  return out;
}

/** Did the CLI say this option name does not exist? */
function unknownOption(r, name) {
  if (r.kind !== 'error') { return false; }
  if (r.issues) { return r.issues.some((i) => i.code === 'unrecognized_keys' && (i.keys ?? []).includes(name)); }
  return r.text.startsWith(`Invalid option: '${name}'`);
}
/** Did the CLI refuse the VALUE given for this option on type grounds? */
function typeRefused(r, name) {
  if (r.kind === 'crash') { return r.text; }
  if (r.kind !== 'error') { return null; }
  if (r.issues) {
    const i = r.issues.find((x) => x.path === name && x.code === 'invalid_type' && x.message !== 'Required option not specified');
    return i ? i.message : null;
  }
  return new RegExp(`for option '--${name}' is not a valid`).test(r.text) ? r.text.split('\n')[0] : null;
}
/** Names the CLI reports as required-but-missing in this result. */
function missingRequired(r, given = new Set()) {
  if (r.kind !== 'error') { return []; }
  // A missing string or number is an invalid_type the CLI rewords; a missing enum is an
  // invalid_value it does not reword. Either way: a complaint about an option not on the line.
  if (r.issues) {
    return r.issues.filter((i) => i.path && !i.path.includes('.') && !given.has(i.path)
      && (i.message === 'Required option not specified' || ['invalid_type', 'invalid_value', 'invalid_union'].includes(i.code))).map((i) => i.path);
  }
  const m = r.text.match(/^Required option (\S+) not specified/);
  return m ? [m[1]] : [];
}

// ---- what the docs say ----------------------------------------------------------------
function docOptions(helpPath) {
  if (!helpPath) { return null; }
  const file = join(paths.docsCmd, helpPath);
  if (!existsSync(file)) { return null; }
  const txt = readFileSync(file, 'utf8');
  const heads = [...txt.matchAll(/^##\s+(.+)$/gm)];
  const i = heads.findIndex((h) => h[1].trim().toLowerCase() === 'options');
  if (i < 0) { return { options: [], global: false }; }
  const sec = txt.slice(heads[i].index, i + 1 < heads.length ? heads[i + 1].index : txt.length);
  const options = [];
  for (const line of sec.split('\n')) {
    const m = line.match(/^\s*`(?:-(\w),\s*)?--([\w-]+)(?:\s*([<\[])[^>\]]*[>\]])?`/);
    if (m) { options.push({ long: m[2], short: m[1] ?? null, takesValue: Boolean(m[3]), required: m[3] === '<' }); }
  }
  return { options, global: /<Global\s*\/>/.test(sec) || /<Global\s*\/>/.test(txt) };
}

// an option name no command declares
const SENTINEL = 'zzNoSuchOption';
const GLOBAL = new Set(['query', 'output', 'debug', 'verbose', 'help']);
const dummy = (o) => (o.autocomplete?.length ? o.autocomplete[0] : o.type === 'number' ? '1' : o.type === 'boolean' ? 'true' : 'x');
const argFor = (o) => (o.takesValue === false ? [`--${o.long}`] : [`--${o.long}`, dummy(o)]);

// ---- the sweep --------------------------------------------------------------------------
const { byName } = loadIndex();
const raw = new Map(JSON.parse(readFileSync(paths.full, 'utf8')).map((c) => [c.name, c]));
const allOutputs = [...new Set([...raw.values()].flatMap((c) => c.options.find((o) => o.long === 'output')?.autocomplete ?? []))].sort();
const names = [...byName.keys()].sort().filter((n) => !only || n.startsWith(only));

const report = { version: installedVersion(), node: process.version, commands: names.length, outputsProbed: allOutputs, perCommand: {}, };
const F = {
  unresolved: [], aliasUnresolved: [], crashes: [], anyOption: [], schema: 0,
  indexRejected: [], docRejected: [], docOnlyAccepted: [], undocumented: [], casing: [],
  shortRejected: [], shortDocMismatch: [],
  requiredIndexVsCli: [], requiredDocVsCli: [],
  outputIndexVsCli: [], outputNarrow: [],
  shapeWrong: [], noDoc: [], docShortRejected: [], flagTakesValue: [], anyOptionUndeclared: [],
  boolBareRefused: [], boolValueRefused: [], falseIsNotFalse: [], numberCoerced: [], numberKept: 0, flags: 0, valueBooleans: 0,
};

for (const name of names) {
  const words = name.split(' ');
  const c = withCallShapes(byName.get(name));
  const doc = docOptions(c.help);
  if (!doc) { F.noDoc.push(name); }
  const docOpts = doc?.options ?? [];
  const idx = new Map(c.options.map((o) => [o.long, o]));
  const docs = new Map(docOpts.map((o) => [o.long, o]));

  // does the name reach a command at all?
  const base = await probe(words, []);
  if (base.resolved !== name) { F.unresolved.push({ name, got: base.resolved, kind: base.kind }); continue; }
  if (base.kind === 'crash') { F.crashes.push({ probe: current, text: base.text }); }
  if (base.schema) { F.schema++; }
  // Measured, not read off the command: allowUnknownOptions() misses the schema commands that
  // pass unknown keys through, and it is the measured answer a caller lives with.
  const sentinel = await probe(words, [`--${SENTINEL}`, 'x']);
  if (!unknownOption(sentinel, SENTINEL)) {
    if (!base.anyOption) { F.anyOptionUndeclared.push(name); }
    base.anyOption = true;
  }
  if (base.anyOption) { F.anyOption.push(name); }
  for (const a of c.aliases) {
    const r = await probe(a.split(' '), []);
    if (r.resolved !== name) { F.aliasUnresolved.push({ alias: a, of: name, got: r.resolved }); }
  }

  // required: keep supplying what the CLI asks for until it stops asking
  const required = new Set();
  let supplied = [];
  for (let round = 0; round <= c.options.length + docOpts.length + 1; round++) {
    const r = await probe(words, supplied);
    const miss = missingRequired(r, required).filter((m) => !required.has(m));
    if (!miss.length) { break; }
    for (const m of miss) {
      required.add(m);
      supplied = supplied.concat(argFor(idx.get(m) ?? { long: m }));
    }
  }
  const idxRequired = new Set(c.options.filter((o) => o.required).map((o) => o.long));
  const docRequired = new Set(docOpts.filter((o) => o.required).map((o) => o.long));
  const sym = (a, b) => [...a].filter((x) => !b.has(x)).map((x) => `+${x}`).concat([...b].filter((x) => !a.has(x)).map((x) => `-${x}`));
  const dIdx = sym(required, idxRequired);
  if (dIdx.length) { F.requiredIndexVsCli.push({ name, cli: [...required], index: [...idxRequired] }); }
  const dDoc = sym(required, docRequired);
  if (dDoc.length && doc) { F.requiredDocVsCli.push({ name, cli: [...required], docs: [...docRequired] }); }

  // option names: everything the index or the docs mention
  const accepted = new Set();
  for (const long of new Set([...idx.keys(), ...docs.keys()])) {
    const o = idx.get(long) ?? docs.get(long);
    const r = await probe(words, argFor(o));
    if (r.kind === 'crash') { F.crashes.push({ probe: current, text: r.text }); }
    const rejected = unknownOption(r, long);
    if (!rejected) { accepted.add(long); }
    if (GLOBAL.has(long)) { continue; }   // the lookup prints these separately, from the index's own data
    if (base.anyOption) {
      // any name is accepted, so a misspelling is not rejected -- it is silently something else
      const twin = !idx.has(long) && [...idx.keys()].find((k) => k.toLowerCase() === long.toLowerCase());
      if (twin) { F.casing.push({ name, option: long, actual: twin, cli: 'accepted as an unrelated option: the command takes any option name' }); }
      continue;
    }
    if (idx.has(long) && rejected) { F.indexRejected.push({ name, option: long, cli: r.text.split('\n')[0] }); }
    if (!idx.has(long) && rejected) {
      const twin = [...idx.keys()].find((k) => k.toLowerCase() === long.toLowerCase());
      (twin ? F.casing : F.docRejected).push({ name, option: long, ...(twin ? { actual: twin } : {}), cli: r.text.split('\n')[0] });
    }
    if (!idx.has(long) && !rejected) { F.docOnlyAccepted.push({ name, option: long, result: r.kind, cli: (r.text ?? '').split('\n')[0] }); }
    if (idx.has(long) && !docs.has(long) && !rejected && doc) { F.undocumented.push({ name, option: long }); }

    // does the call shape the lookup prints survive the CLI's own type check?
    if (idx.has(long) && typeRefused(r, long)) {
      F.shapeWrong.push({ name, option: long, printedAs: argFor(o).join(' '), cli: typeRefused(r, long) });
    }
  }

  // booleans: what do the three ways of writing one actually produce?
  for (const o of c.options.filter((x) => x.type === 'boolean' || x.takesValue === false)) {
    if (base.anyOption && !o.type) { continue; }
    o.takesValue === false ? F.flags++ : F.valueBooleans++;
    const bare = await probe(words, [`--${o.long}`]);
    const yes = await probe(words, [`--${o.long}`, 'true']);
    const no = await probe(words, [`--${o.long}`, 'false']);
    const row = { name, option: o.long, schema: base.schema, lookupShape: o.takesValue === false ? 'flag' : 'value' };
    if (typeRefused(bare, o.long)) { F.boolBareRefused.push({ ...row, cli: typeRefused(bare, o.long) }); }
    // a real flag written bare arrives as true; anything else is a value option printed as a flag
    if (o.takesValue === false && bare.parsed[o.long] !== true) {
      F.flagTakesValue.push({ ...row, bare: bare.kind === 'crash' ? bare.text : bare.parsed[o.long] ?? null });
      continue;
    }
    if (typeRefused(yes, o.long) || typeRefused(no, o.long)) { F.boolValueRefused.push({ ...row, cli: typeRefused(yes, o.long) ?? typeRefused(no, o.long) }); }
    else if (no.parsed[o.long] !== false) { F.falseIsNotFalse.push({ ...row, parsed: no.parsed[o.long] ?? null }); }
  }

  // free-text options: does a value that looks like a number stay text?
  for (const o of c.options.filter((x) => x.takesValue !== false && x.type !== 'boolean' && x.type !== 'number' && !x.autocomplete?.length)) {
    const r = await probe(words, [`--${o.long}`, '007']);
    if (r.kind === 'crash' || typeRefused(r, o.long)) { continue; }   // refused: typed after all, not free text
    if (r.parsed[o.long] === '007') { F.numberKept++; }
    else { F.numberCoerced.push({ name, option: o.long, schema: base.schema, type: o.type ?? null, parsed: r.parsed[o.long] ?? null }); }
  }

  // short names
  for (const o of c.options.filter((x) => x.short)) {
    const args = o.takesValue === false ? [`-${o.short}`] : [`-${o.short}`, dummy(o)];
    const r = await probe(words, args);
    if (!base.anyOption && (unknownOption(r, o.short) || unknownOption(r, o.long))) { F.shortRejected.push({ name, option: o.long, short: o.short, cli: r.text.split('\n')[0] }); }
    const d = docs.get(o.long);
    if (d && d.short !== o.short) { F.shortDocMismatch.push({ name, option: o.long, index: o.short, docs: d.short }); }
  }
  for (const d of docOpts.filter((x) => x.short && idx.has(x.long) && !idx.get(x.long).short)) {
    F.shortDocMismatch.push({ name, option: d.long, index: null, docs: d.short });
  }
  for (const d of docOpts.filter((x) => x.short && idx.has(x.long) && idx.get(x.long).short !== x.short)) {
    const o = idx.get(d.long);
    const r = await probe(words, o.takesValue === false ? [`-${d.short}`] : [`-${d.short}`, dummy(o)]);
    // accepted means the long name arrived; "not rejected" is not enough on a command that takes any option
    if (!(d.long in r.parsed)) { F.docShortRejected.push({ name, option: d.long, docs: d.short, index: o.short ?? null }); }
  }

  // --output
  const okOut = [];
  for (const v of allOutputs) {
    const r = await probe(words, ['--output', v]);
    const bad = r.kind === 'error' && (r.issues ? r.issues.some((i) => i.path === 'output') : /output/i.test(r.text) && !/^Required option/.test(r.text));
    if (!bad) { okOut.push(v); }
  }
  const idxOut = (c.output ?? allOutputs).slice().sort();
  if (idxOut.join() !== okOut.join()) { F.outputIndexVsCli.push({ name, index: idxOut, cli: okOut }); }

  report.perCommand[name] = { schema: base.schema, anyOption: base.anyOption, required: [...required], accepted: [...accepted], outputs: okOut };
}

// ---- summary ------------------------------------------------------------------------------
// "usual" is whatever set of --output modes most commands accept, measured, not assumed
const tally = new Map();
for (const c of Object.values(report.perCommand)) { tally.set(c.outputs.join(), (tally.get(c.outputs.join()) ?? 0) + 1); }
const usual = [...tally].sort((a, b) => b[1] - a[1])[0]?.[0] ?? '';
report.usualOutputs = usual.split(',');
for (const [name, c] of Object.entries(report.perCommand)) { if (c.outputs.join() !== usual) { F.outputNarrow.push({ name, cli: c.outputs }); } }
report.findings = F;
report.sideEffects = sideEffects;
const line = (label, list) => console.log(`${String(Array.isArray(list) ? list.length : list).padStart(5)}  ${label}`);
console.log(`@pnp/cli-microsoft365 ${report.version} on node ${process.version}: ${names.length} commands probed in-process, none run\n`);
line('commands validated by a schema (zod) -- the rest use the legacy validators', F.schema);
line('commands that accept ANY option name (nothing to verify by name)', F.anyOption);
console.log('\n-- the index (what ./lookup prints) against the CLI');
line('command names the CLI does not resolve', F.unresolved);
line('aliases the CLI does not resolve', F.aliasUnresolved);
line('index options the CLI rejects', F.indexRejected);
line('index short names the CLI rejects', F.shortRejected);
line('commands whose required set differs (index vs CLI)', F.requiredIndexVsCli);
line('commands whose --output set differs (index vs CLI)', F.outputIndexVsCli);
line('options whose printed call shape fails the CLI type check', F.shapeWrong);
line('options printed as a flag that the CLI reads as a value', F.flagTakesValue);
console.log('\n-- the help docs against the CLI');
line('options documented but rejected', F.docRejected);
line('options documented in the wrong case', F.casing);
line('options documented, missing from the index, yet accepted', F.docOnlyAccepted);
line('options the CLI accepts that the docs omit', F.undocumented);
line('commands whose required set differs (docs vs CLI)', F.requiredDocVsCli);
line('short names that differ (docs vs index)', F.shortDocMismatch);
line('  of which: short names the docs give that do not reach the option', F.docShortRejected);
line(`commands whose --output modes are not the usual ${usual}`, F.outputNarrow);
line('commands with no help file', F.noDoc);
console.log('\n-- how values are read (traps no listing shows)');
line('flags (no value) in the index', F.flags);
line('booleans the docs write with a value (--x true|false)', F.valueBooleans);
line('  booleans refused when written bare', F.boolBareRefused);
line('  booleans refused when written true / false', F.boolValueRefused);
line('  booleans where "--x false" does NOT turn it off', F.falseIsNotFalse);
line('text options that keep a number-like value ("007") as text', F.numberKept);
line('text options that turn "007" into a number', F.numberCoerced);
console.log('\n-- the probe itself');
line('probes that crashed inside the CLI', F.crashes);
line('network or child-process attempts blocked', sideEffects);

if (jsonAt > 0) { writeFileSync(process.argv[jsonAt + 1], JSON.stringify(report, null, 1)); console.log(`\nfull findings: ${process.argv[jsonAt + 1]}`); }
// the lookup's "accepts any option name" note comes from a list; keep it equal to what was measured
const listed = new Set(JSON.parse(readFileSync(new URL('./verified-exceptions.json', import.meta.url), 'utf8')).acceptsAnyOption?.commands ?? []);
F.anyOptionListWrong = only ? [] : [
  ...F.anyOption.filter((n) => !listed.has(n)).map((n) => ({ name: n, problem: 'accepts any option, not in acceptsAnyOption' })),
  ...[...listed].filter((n) => !F.anyOption.includes(n)).map((n) => ({ name: n, problem: 'in acceptsAnyOption, but rejects an unknown option' })),
];
line('commands where verified-exceptions.json acceptsAnyOption disagrees with the measurement', F.anyOptionListWrong);
const indexWrong = F.anyOptionListWrong.length + F.unresolved.length + F.aliasUnresolved.length + F.indexRejected.length + F.shortRejected.length
  + F.requiredIndexVsCli.length + F.outputIndexVsCli.length + F.docOnlyAccepted.length
  + F.shapeWrong.length + F.flagTakesValue.length;
realExit(indexWrong ? 1 : 0);
