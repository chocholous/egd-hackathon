# Source this, do not execute:   source scripts/env.sh        (bash, zsh; also WSL, Git Bash)
# Loads the nearest .env (from $PWD upward) into this shell, sets $M to the wrapper, and
# returns non-zero -- with M unset -- when something is missing. scripts/env.mjs does the
# work; PowerShell uses it directly:  node scripts/env.mjs pwsh | Out-String | Invoke-Expression
_m365_env=$(node "$(dirname -- "${BASH_SOURCE:-$0}")/env.mjs" sh) || { unset M _m365_env; return 1; }
eval "$_m365_env"
unset _m365_env
