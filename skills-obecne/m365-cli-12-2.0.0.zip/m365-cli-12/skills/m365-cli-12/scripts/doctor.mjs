#!/usr/bin/env node
// Check the environment before drawing the wrong conclusion from an error.
//   npm run doctor      (or: node scripts/doctor.mjs)
// rc=1 if any check fails. Reads only: the CLI calls it makes are `version`,
// `cli config get`, `status` and `spo web get`.
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkContract } from './lib/contract.mjs';
import { findEnvFile, readEnvFile } from './lib/envfile.mjs';
import { distPath, installHint, pkgDir } from './lib/pkg.mjs';
import { onPath, pickRuntime } from './lib/runtime.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const wrapper = path.join(here, 'm365-run.mjs');
let fail = 0;

const ok = (s) => console.log(`  \x1b[32mOK\x1b[0m   ${s}`);
const bad = (s) => { console.log(`  \x1b[31mFAIL\x1b[0m ${s}`); fail = 1; };
const skip = (s) => console.log(`  \x1b[33m--\x1b[0m   ${s}`);
const section = (s) => console.log(`== ${s} ==`);
const done = () => {
  console.log();
  console.log(fail === 0 ? 'Environment looks good.' : 'Something is off — see FAIL above.');
  process.exit(fail);
};

let env = { ...process.env };
const m365 = (...args) => {
  const r = spawnSync(process.execPath, [wrapper, ...args], { env, encoding: 'utf8' });
  return { rc: r.status, out: (r.stdout ?? '').trim(), err: (r.stderr ?? '').trim() };
};
section('runtime');
ok(`node ${process.version}`);
const bun = onPath('bun');
if (bun) { ok(`bun ${(spawnSync(bun, ['--version'], { encoding: 'utf8' }).stdout ?? '').trim()} (optional)`); }
else { skip('bun not on PATH (optional)'); }
// the same decision the wrapper makes, from the same code
const runtime = pickRuntime();
if (runtime.error) { bad(runtime.error); }
else { ok(`the wrapper runs the CLI on ${runtime.name} (${runtime.exe})`); }

section('m365');
const dist = distPath();
if (!fs.existsSync(dist)) {
  bad(`no CLI at ${dist} — ${installHint()}`);
  done();
}
const version = m365('version');
if (version.rc === 0) { ok(`the wrapper runs ${version.out} from ${dist}`); }
else { bad(`the wrapper failed (rc ${version.rc}): ${version.err || version.out}`); done(); }

// As of 12.0.0 telemetry is a POST to Google Analytics after each command (dist/googleAnalytics.js),
// and the wrapper does nothing about it: the setting is the only opt-out. It lives in the
// CLI's own home (scripts/lib/v12-home.js), so a v11 install's opt-out does not carry over.
const telemetry = m365('cli', 'config', 'get', '--key', 'disableTelemetry', '--output', 'text');
if (telemetry.out === 'true') { ok('telemetry disabled'); }
else {
  skip(`telemetry not disabled — every command POSTs to Google Analytics:
       node "${wrapper}" cli config set --key disableTelemetry --value true`);
}

try {
  const broken = await checkContract();
  if (broken.length === 0) { ok(`package contract holds (the lookup can read the index and help docs in ${pkgDir()})`); }
  else { bad(`package contract broken in ${pkgDir()} — run 'npm run contract' for detail`); }
}
catch (e) { bad(`package contract check crashed: ${e.message}`); }

section('.env');
const envFile = findEnvFile();
let vars = {};
if (envFile) {
  vars = readEnvFile(envFile);
  env = { ...env, ...vars };
  ok(`${envFile} loaded`);
  for (const v of ['M365_ACCOUNT', 'M365_TENANT_ID', 'M365_SPO_ROOT']) {
    if (vars[v]) { ok(`${v}=${vars[v]}`); } else { bad(`${v} is not set`); }
  }
  if (vars.M365_SITE) { ok(`M365_SITE=${vars.M365_SITE}`); } else { skip('M365_SITE not filled in'); }
}
else { bad(`no .env in ${process.cwd()} or above it up to the project root — copy .env.example`); }

section('sign-in state');
// A missing refresh token does not show up as "not signed in": the CLI keeps working on the
// last access token and only asks for the browser again when it expires, an hour later.
const health = spawnSync(process.execPath, [path.join(here, 'lib', 'cache-health.mjs')], { env, encoding: 'utf8' });
if (health.status !== 0) {
  bad(`cache check crashed — run 'node scripts/lib/cache-health.mjs': ${(health.stderr ?? '').trim().split('\n')[0]}`);
}
for (const line of (health.stdout ?? '').split('\n').filter(Boolean)) {
  const [kind, ...rest] = line.split('\t');
  const text = rest.join('\t');
  if (kind === 'OK') { ok(text); }
  else if (kind === 'FAIL') { bad(text); }
  else if (kind === 'SKIP') { skip(text); }
  else { console.log(`       ${line.trimStart()}`); }   // continuation line of the previous finding
}

section('signed in as');
const status = m365('status', '--output', 'json');
let who = '';
try { who = JSON.parse(status.out).connectedAs ?? ''; } catch { /* not JSON: not signed in, or an error */ }
if (who) {
  ok(`signed in as ${who}`);
  if (vars.M365_ACCOUNT && who !== vars.M365_ACCOUNT) { bad(`does not match M365_ACCOUNT=${vars.M365_ACCOUNT}`); }
}
else { bad(`not signed in (${status.out || status.err}) — run 'node "${wrapper}" login'`); }

section('SharePoint');
if (vars.M365_SPO_ROOT && who) {
  const r = m365('spo', 'web', 'get', '--url', vars.M365_SPO_ROOT, '--output', 'json', '--query', 'Title');
  const title = r.out || r.err;
  if (!title || title.includes('error')) { bad(`${vars.M365_SPO_ROOT} unreachable: ${title}  (--debug reveals the HTTP status)`); }
  else { ok(`${vars.M365_SPO_ROOT} → ${title}`); }
}
else { skip('skipped (no M365_SPO_ROOT, or not signed in)'); }

done();
