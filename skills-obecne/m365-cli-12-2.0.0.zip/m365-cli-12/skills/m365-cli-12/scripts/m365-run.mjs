#!/usr/bin/env node
// Run CLI for Microsoft 365 v12 next to a v11 install without the two fighting, and without
// paying for what this repo does not use.
// ./m365 is a symlink to this file; elsewhere run it as  node <path>/scripts/m365-run.mjs <command>.
//
// What the wrapper adds, none of which changes what a command does:
//   - a home directory of its own for the CLI (scripts/lib/v12-home.js): without it v12
//     deletes v11's token cache and shares v11's connection files and settings
//   - connection files written atomically under a lock (scripts/lib/atomic-token-cache.js)
//   - no update-notifier, which spawns a second process per invocation to poll npm
//   - a deadlock cap (M365_TIMEOUT)
// Argument parsing, auth and the command itself are untouched, and the CLI being run is the
// same dist/index.js as before. Timings: README "Running the CLI".
//
// Which CLI it runs: $M365_DIST when set, else the package in $M365_PKG_DIR, else the pinned
// copy in this repo's node_modules (scripts/lib/pkg.mjs). A caller that wants a different
// install says so -- see "Outside this repo" in the README.
//
// Which runtime: bun when it is on PATH (faster start), node otherwise -- this process's own
// node, so nothing else has to be installed. M365_RUNTIME=node|bun forces one. Decided in
// ./lib/runtime.mjs, which doctor shares.
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import tty from 'node:tty';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { distPath, installHint } from './lib/pkg.mjs';
import { pickRuntime } from './lib/runtime.mjs';
import { parseTimeout } from './lib/timeout.mjs';

const lib = path.join(path.dirname(fileURLToPath(import.meta.url)), 'lib');
// Must load first: the preloads after it, and the CLI, take their paths from os.homedir().
const v12Home = path.join(lib, 'v12-home.js');
// bun drops buffered output on process.exit -- see the header of that file.
const syncStdout = path.join(lib, 'sync-stdout.js');
// Connection files written atomically under a lock -- see the header of that file for the tear it fixes.
const cacheLock = path.join(lib, 'atomic-token-cache.js');
const noTtyStdin = path.join(lib, 'no-tty-stdin.js');

const say = (msg) => fs.writeSync(2, `m365-run: ${msg}\n`);

const dist = distPath();
if (!fs.existsSync(dist)) {
  say(`no CLI at ${dist} — ${installHint()} (M365_DIST, a dist/index.js, also works for the wrapper alone)`);
  process.exit(1);
}

const runtime = pickRuntime();
if (runtime.error) { say(runtime.error); process.exit(1); }

// bun takes preloads as paths; node's --import takes a specifier, and an absolute Windows
// path (C:\...) is not one -- hence file URLs.
const exe = runtime.exe;
const runtimeArgs = runtime.name === 'bun'
  ? ['--preload', v12Home, '--preload', syncStdout, '--preload', cacheLock, '--preload', noTtyStdin]
  : ['--import', pathToFileURL(v12Home).href, '--import', pathToFileURL(cacheLock).href, '--import', pathToFileURL(noTtyStdin).href];

// Deadlock guard: default and syntax in ./lib/timeout.mjs, with the reasons. Interactive use
// is exempt: a human at a TTY may be reading a device code or completing a browser sign-in,
// which takes as long as it takes.
function capSeconds() {
  const t = parseTimeout(process.env.M365_TIMEOUT);
  if (t.error) {
    say(t.error);
    process.exit(125);   // what timeout(1) answered to an invalid interval, under the sh wrapper
  }
  return t.seconds;
}

const cap = capSeconds();
// tty.isatty(0), not process.stdin.isTTY: touching process.stdin opens fd 0 as a stream in
// this process, which can switch a shared pipe to non-blocking under the CLI's feet.
const capped = cap > 0 && !tty.isatty(0);

const child = spawn(exe, [...runtimeArgs, dist, ...process.argv.slice(2)], {
  stdio: 'inherit',
  // ~80 ms and one spawned child process per invocation, to tell an agent about a new release
  env: { ...process.env, CLIMICROSOFT365_NOUPDATE: '1' },
});

// Whoever stops this process means the CLI: pass it on. (A terminal's Ctrl-C reaches both
// already; a second SIGINT to a dying process is harmless.)
const forwarded = ['SIGINT', 'SIGTERM', 'SIGHUP'];
const forward = (sig) => { child.kill(sig); };
for (const sig of forwarded) { process.on(sig, forward); }

let timedOut = false;
let timer = null;
if (capped) {
  // setTimeout fires at once (with a warning) beyond 2^31-1 ms, ~24.8 days -- a node limit,
  // not a policy. A larger cap is waited out in steps of that size.
  const MAX_TIMER_MS = 2 ** 31 - 1;
  const wait = (ms) => {
    const step = Math.min(ms, MAX_TIMER_MS);
    timer = setTimeout(() => {
      if (ms > step) { wait(ms - step); return; }
      timedOut = true;
      child.kill('SIGTERM');
    }, step);
  };
  wait(cap * 1000);
}

child.on('error', (e) => {
  say(`could not start ${exe}: ${e.message}`);
  process.exit(1);
});

// Exit 124 means the command was cut off, so whether it reached the service is unknown.
// For a read, run it again; for a write, READ THE TARGET BACK before deciding anything --
// a blind retry of `spo page add` duplicates a page that may well have been created.
child.on('exit', (code, signal) => {
  clearTimeout(timer);
  if (timedOut) {
    say(`cut off after ${cap}s (M365_TIMEOUT). The CLI has no timeout of its own and retries 429/503 forever, so it was hung or being throttled. Whether the service ran this is UNKNOWN: verify with a read before retrying, and never blind-retry a write.`);
    process.exit(124);   // timeout(1)'s code, which callers of the sh wrapper already handle
  }
  if (signal) {
    // Die the way the CLI died, so a caller sees the signal and not a made-up exit code.
    for (const sig of forwarded) { process.off(sig, forward); }
    if (process.platform !== 'win32') { process.kill(process.pid, signal); }
    process.exit(128 + (os.constants.signals[signal] ?? 0));
  }
  process.exit(code ?? 1);
});
