# Původ a odchylky od zdroje

Tenhle skill je **kopie** skillu `m365-cli` z repa `m365-cli-12` (správce obou repozitářů je
stejný), vložená do marketplace `ppf-skills` jako plugin `m365-cli-12`. Není s původním repem
nijak propojená: žádný submodul, symlink, sync skript ani odkaz `external:`. Další změny ve
zdroji se sem nedostanou samy, přebalení je ruční (viz Údržba).

| | |
|---|---|
| **Zdroj** | repo `m365-cli-12` (lokálně `~/Projects/m365-cli-12`) |
| **Commit** | `6c3ad32` („Live pass against a tenant: record, lookup WARNINGs, prompt without a terminal“) |
| **Zdrojový skill** | `.claude/skills/m365-cli/SKILL.md`, verze 6.3.0 |
| **CLI** | `@pnp/cli-microsoft365` **12.0.0** je verze, proti které je skill ověřený (`package.json`). Skill CLI neobsahuje ani neinstaluje, bere ho z projektu (odchylka 2) |
| **Licence** | MIT, copyright Pavel Chocholouš (`LICENSE`) |
| **PPF verze** | 2.0.0 (vlastní řada, nezávislá na 6.3.0 ze zdroje; upstream verzi drží pole `upstream:` ve frontmatteru) |

Surová kopie je v git historii jako samostatný commit `m365-cli-12: nezměněná kopie skillu …`;
`git diff` proti němu ukáže všechny odchylky níže.

## Co se nezkopírovalo

- `node_modules/` (254 MB) a od 2.0.0 ani `package-lock.json` a `.npmrc`: skill CLI neinstaluje (odchylka 2)
- `.env` (lokální hodnoty, ani se nečetl) — v pluginu je jen `.env.example`
- `.git/`, `.gitignore`
- `live/` — skripty živého průchodu tenantem: zapisují do skutečného webu a skill je nepotřebuje
  (záznam `LIVE-VERIFIED.md` se zkopíroval, výstupy `live/out/` ve zdroji ani nejsou)
- symlinky `lookup` a `m365` v kořeni (skill volá skripty přes `node`, viz `SKILL.md`)
- `.claude/settings.json` (registrace hooku, viz níže)

## Odchylky od zdroje

1. **`SKILL.md`**: `name: m365-cli-12`, nová `description` (odlišení od CLI 11), `version: 1.0.0`,
   `upstream:`; sekce „Start here“ přepsaná na volání přes `node "${CLAUDE_SKILL_DIR}/scripts/…"`
   (zástupné `<m365>` a `<lookup>`), odstavec „Where the CLI comes from“,
   zmínka o hooku. Zbytek textu (pravidla, tabulka chyb, pasti) je ze zdroje,
   jen `./lookup` → `<lookup>`, `npm run doctor`/`verify` → cesty ke skriptům, `LIVE-VERIFIED.md`
   → `references/LIVE-VERIFIED.md`.
2. **Skill CLI neinstaluje, bere ho z projektu** (od 2.0.0, rozhodnutí vlastníka „čistý skill“).
   `scripts/lib/pkg.mjs` bez `M365_PKG_DIR` hledá nejbližší `node_modules/@pnp/cli-microsoft365` od
   aktuální složky nahoru (instalace projektu), teprve pak ve složce skillu (checkout zdroje). Když
   balíček nenajde, wrapper, lookup, `env.mjs` i `doctor` vypíšou jednu společnou radu
   (`installHint()` tamtéž): přidat CLI do projektu, nebo nastavit `M365_PKG_DIR`. Testy:
   `dev/test/pkg-dir.test.mjs` (poslední dva).
   Verze 1.0.0 instalovala CLI sama (`scripts/ensure-deps.mjs`, `npm install` podle lockfile do
   datového adresáře pluginu). Odstraněno: instalace nikdy neproběhla na čistém stroji, 55 záznamů
   lockfile mířilo na `ms-feed-25.pkgs.visualstudio.com` místo registry.npmjs.org, `npm ci` s ním
   končil `EBADPLATFORM` a projekty, které skill používají, si CLI stejně pinují samy.
   Důsledek: skill mimo projekt s nainstalovaným CLI jen radí (text, tabulka chyb, pasti); lookup
   a wrapper potřebují balíček. Verzi CLI určuje projekt; ověřená je 12.0.0.
3. **Hlášky o chybějícím CLI** (`m365-run.mjs`, `env.mjs`, `doctor.mjs`, `lib/contract.mjs`) a rady
   k přihlášení (`doctor.mjs`, `lib/cache-health.mjs`): místo `npm install` a `./m365 …` jmenují
   skutečné příkazy pluginu (`node …/m365-run.mjs`) a radu z odchylky 2.
4. **`package.json`**: `scripts.test` → `node dev/test/run.mjs`; zůstává jako zápis ověřené verze CLI
   (čte ji `installHint()`) a pro testy. `package-lock.json` a `.npmrc` se od 2.0.0 nedodávají.
5. **Testy** přesunuté do `dev/test/` (`dev/` se do pluginu nebalí): cesty o úroveň výš, hook v
   `hooks/prefer-lookup.mjs`, vypuštěný test „`./m365` v kořeni repa“ (kořenové symlinky nejsou).
6. **`references/README.md`, `references/LIVE-VERIFIED.md`**: původní README a záznam živého průchodu
   s jednou úvodní poznámkou; jinak beze změny.
7. **`hooks/prefer-lookup.mjs`**: beze změny (původně `.claude/hooks/`). **Plugin ho neregistruje**
   (viz Hook).

Jazyk: `SKILL.md`, skripty a reference zůstávají anglicky jako ve zdroji (test
`tools/tests/test_skill_language.py` angličtinu povoluje); česky jsou jen tento soubor a metadata v katalogu.

## Hook `prefer-lookup`

Skript odmítá holé `m365`, `m365 --help` a jiné než pinované CLI. Plugin ho **neregistruje**:
hook v pluginu platí ve všech projektech, kde je plugin zapnutý, a rozbil by práci s CLI 11
(`ppf-sharepoint` volá globální `m365` v11.9.0). Projekt, který pracuje jen s CLI 12, ho registruje sám
v `.claude/settings.json` (exec-form `args` vyžaduje Claude Code 2.1.139+), s cestami na vlastní
vendorovanou kopii nebo na tento plugin:

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash|PowerShell",
        "hooks": [
          {
            "type": "command",
            "command": "node",
            "args": [
              "${CLAUDE_PROJECT_DIR}/.claude/hooks/prefer-lookup.mjs",
              "--lookup", "node \"<cesta k skillu>/scripts/m365-lookup.mjs\"",
              "--run", "node \"<cesta k skillu>/scripts/m365-run.mjs\""
            ],
            "timeout": 10
          }
        ]
      }
    ]
  }
}
```

Hook pozná pinovaný wrapper podle jména souboru `m365-run.mjs` kdekoli na disku, takže volání
z pluginu povolí. Parametry `--lookup`, `--run`, `--env` (a `--ps-*`) jen mění text hlášky.

## Údržba — přebalení na novější zdroj

1. V repu `m365-cli-12` ověř commit a čistý strom (`git rev-parse --short HEAD`, `git status`).
2. Porovnej `git diff 6c3ad32 <nový commit> --stat` a přenes změny do `skills/m365-cli-12/`
   (odchylky 1–7 výše zachovej), do `SKILL.md` zapiš nový `upstream:` a tuhle tabulku.
3. Bump `version:` ve `SKILL.md`, `python tools/build_plugins.py`, testy (viz níže).

Testy (offline, bez přihlášení): v dočasné kopii složky skillu `npm install` (bez lockfile; nebo
zkopírovat `node_modules` z projektu s CLI 12.0.0) a `node dev/test/run.mjs` (`node_modules` do repa nepatří).
