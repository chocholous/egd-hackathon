---
name: m365-cli-12
description: "Use ALWAYS before running any `m365` command of CLI for Microsoft 365 VERSION 12 (verified against 12.0.0: SharePoint, Entra, Teams, OneDrive, Planner, Viva). Look the command up instead of guessing option names, run it through the wrapper with its own sign-in home, confirm destructive commands with the user, and read the error table before concluding a command is wrong. This is the CLI 12 skill; it is NOT the guide for the older CLI 11 that ppf-sharepoint uses through a global `m365` (v11.9.0)."
version: 2.0.0
upstream: "m365-cli-12 repo, commit 6c3ad32 (SKILL.md 6.3.0, @pnp/cli-microsoft365 12.0.0), MIT. Copy, not linked, without its CLI install: see ATTRIBUTION.md"
compatibility: "@pnp/cli-microsoft365 12.0.0 installed in the project (the skill ships and installs no CLI), Node.js 22+ (bun optional), bash/zsh or PowerShell"
user-invocable: true
---

# m365 CLI 12

This is a copy of the `m365-cli-12` skill: a guide, a command lookup and a wrapper. It ships
no CLI and installs none. Differences from the source repo are listed in `ATTRIBUTION.md`
(next to this file).

## Start here

Two placeholders are used below. Write them out exactly like this (the path is filled in when
the skill loads):

- `<m365>` = `node "${CLAUDE_SKILL_DIR}/scripts/m365-run.mjs"`
- `<lookup>` = `node "${CLAUDE_SKILL_DIR}/scripts/m365-lookup.mjs"`

**Where the CLI comes from.** Both read the `@pnp/cli-microsoft365` package your project has
installed: the nearest `node_modules/@pnp/cli-microsoft365` from the current directory upward.
So run them from inside the project. A project without it adds it once:

```bash
npm install --save-dev @pnp/cli-microsoft365@12.0.0
```

A package installed elsewhere is named with `M365_PKG_DIR=<package directory>` in front of the
command. When no package is found, the wrapper and the lookup answer `no CLI at …` with these
two ways out; nothing is downloaded on its own. The lookup and the traps below are verified
against 12.0.0; `<m365> version` prints the one actually in use, so check it when a project
pins another one.

```bash
node "${CLAUDE_SKILL_DIR}/scripts/doctor.mjs"     # when something breaks: binary, .env, login, SPO reachability
```

**Run the CLI as `<m365>`, never as a bare `m365`:**

```bash
<m365> spo web get --url ...
```

A globally installed `m365` is usually a different version than the one this skill is
verified against (on PPF machines it is the v11 that `ppf-sharepoint` uses), so its options
and its `--help` differ. The plugin ships a `PreToolUse` guard (`hooks/prefer-lookup.mjs`)
that refuses bare `m365` and `m365 --help`, but does **not** register it: registered by a
plugin it would apply in every project and break the v11 workflows. A project that works
only with v12 registers it itself (see `ATTRIBUTION.md`). Without it, this rule is on you.

`<m365>` is the project's v12 `dist/index.js` — same CLI, same arguments, same output — run
in a home directory of its own (`~/.cli-m365-12`, or `$M365_V12_HOME`), because from the
real home v12 deletes the token cache of a v11 install and overwrites its connection. So
v12 has its own sign-in and its own settings: being signed in with a v11 `m365` says
nothing about `<m365> status` here. It runs on bun when bun is installed, otherwise on node. It also writes output
synchronously under bun (bun otherwise drops buffered output on exit — a large JSON read
into a pipe comes back truncated, with rc=0) and caps an invocation at 120 s.
`scripts/m365-run.mjs` picks the CLI to run: `$M365_DIST`, else the package in
`$M365_PKG_DIR`, else the nearest project install, else `node_modules` inside the skill
directory (a checkout of the source repo).

Values from `.env` (account, tenant, SharePoint root) must be loaded on the **same command
line**, because every shell call starts fresh. Copy `${CLAUDE_SKILL_DIR}/.env.example` to
`.env` in your project and fill it in, then:

```bash
eval "$(node "${CLAUDE_SKILL_DIR}/scripts/env.mjs" sh)" && <m365> spo list list --webUrl "$M365_SPO_ROOT"
```

```powershell
node "${CLAUDE_SKILL_DIR}/scripts/env.mjs" pwsh | Out-String | Invoke-Expression; node "${CLAUDE_SKILL_DIR}/scripts/m365-run.mjs" spo list list --webUrl $env:M365_SPO_ROOT
```

(`env.mjs` also sets `$M` to the wrapper path, handy as `"$M" spo web get …` after the load.)

`.env.example` names the command that discovers each value. The `.env` used is the nearest
one from the current directory upward, stopping at the repository root (`.git`) — or at
`$CLAUDE_PROJECT_DIR` when set and above you — and never `~/.env` or anything above home. In
an agent shell `CLAUDE_PROJECT_DIR` is usually not set, so inside a submodule keep a `.env`
in the submodule. Values are taken literally: `$VAR` and `$(...)` are not expanded, and
there are no backslash escapes inside quotes.

## Rule: Before running m365 command, look it up, never guess

```bash
<lookup> spo page add
```


That is the whole interface:

| | |
|---|---|
| `<lookup> <command>` | how to call it — required vs optional, types, enums, flags |
| `<lookup> <group>` | what commands live under a path |
| `<lookup> -f <text>` | search names, aliases and descriptions |
| `<lookup> <command> --examples` | real invocations; also `--remarks`, `--permissions`, `--response` |

It is instant and offline, and it already corrects the places where the CLI's own `--help`
is wrong — so **build commands from it, never re-check them against `--help`**.

If a command is not there, it does not exist — check the spelling with `-f`.

## Rule: confirm writes

Irreversible commands are everywhere (`spo site remove`, `spo list remove`,
`entra user remove`, `* set`, `* remove`, `* add`). Before running anything but a read:

1. Verify the target with a read command (`spo web get`, `spo list get`, `entra user get`) —
   that it exists and is genuinely the one you mean.
2. Show the user the exact command and what it will do. **Never run a destructive command
   without confirmation.**

**The m365 `-f, --force` trap:** many destructive commands accept it and it suppresses the
confirmation prompt. Without it the CLI prompts interactively — and since an agent has no
TTY, that fails.

## Errors: what they actually mean

Errors arrive **on stdout as JSON**, so they look like data. Always check whether the
response is `{"error": …}`.

| Output | Cause | What to do |
|---|---|---|
| `Invalid option: 'x'` / `Unrecognized key: "x"` | that option does not exist | `<lookup> <command>` |
| `{"error":{}}` | **a hidden HTTP status**, typically 401 | `--debug 2>&1 \| rg -i '"status"\|www-authenticate'` → usually a SharePoint hostname belonging to a different tenant |
| `Attempted to perform an unauthorized operation.` | a missing role (SharePoint admin) | permissions, **not** syntax — do not rewrite the command |
| `{"error":{"name":"ExitPromptError"}}` (text output: `User force closed the prompt with SIGINT`) | destructive command waiting for confirmation, no TTY | it did not run — **ask the user**, do not add `--force` |
| `Required option not specified` / `Required option x not specified` | a required option is missing | `<lookup> <command>` lists them under REQUIRED |
| `Specify one of the following options: a, b.` (or `…, but not multiple.`) | the command wants exactly one of a set the lookup lists under OPTIONAL | pass exactly one of them |
| `The value 'x' for option '--y' is not a valid boolean` | `--y` wants `true` or `false` | the lookup prints such options as `--y <true\|false>` |
| `Invalid option: expected one of "a"\|"b"` | the value is not one of the allowed ones | they are in the message, and in the lookup |
| `Invalid UUID` | an id option got something that is not an RFC 4122 UUID | read the real id (`… list`, `… get`) and pass that |
| `Command 'x' was not found.` followed by a list of commands | no such command in 12.0.0 (renamed or removed since v11) | `<lookup> -f <word>` |
| rc **124**, `cut off after 120s` | the 120 s cap fired: hung connection, or 429/503 retried in a loop | **the outcome is unknown** — read the target back before doing anything; never blind-retry a write. `M365_TIMEOUT=<s>` raises the cap for a genuinely long command |
| `[]` or empty with rc=0 | genuinely empty, wrong list/site, or not signed in — these look identical | `doctor` (`node "${CLAUDE_SKILL_DIR}/scripts/doctor.mjs"`) first; then confirm the target exists (`spo list get`, `spo web get`) before reporting "nothing there" |

**Graph scopes ≠ SharePoint scopes.** The app may hold `AllSites.FullControl` on the
SharePoint resource and still fail on Graph for want of `Files.Read.All` / `Sites.Read.All`.
What this account actually holds: `<m365> cli doctor` (`roles` and `scopes` per resource).
Check it before building a plan on permissions.

## Traps the lookup cannot show

Seen against a tenant on 12.0.0; `references/LIVE-VERIFIED.md` next to this file has the full record.
Those tied to one command are also printed by `<lookup> <command>` under **WARNING** — read
it before running the command.

- **`--debug` prints the bearer token** (the `Authorization` header of every request) to
  stderr. Never paste, save or commit its raw output; filter it on the way out, as the
  error table does, and prefer `--verbose` when you only need to see what the CLI is doing.

- **`spo site recyclebinitem move --ids <id>` moves the WHOLE first-stage recycle bin** to the
  second stage, not the ids you named, and nothing moves it back. Do not run it to move one
  item. `… remove` and `… clear` delete for good.
- **`spo listitem add --folder` is relative to the list root** (`F1/deep`; missing folders
  are created). A web-relative or server-relative path is wrong: the first silently creates
  that whole path inside the list, the second fails with `Invalid URL value`.
- **`spo file rename --force` fails when the target name is free** (`… does not exist`). Use
  `--force` only to replace an existing file.
- **`spo contenttype field set` fails with `' ' is an unexpected token`** when the site
  column's XML ends ` />`. Create the column as `<Field …></Field>`.
- **`spo folder list --recursive --filter` misses matches under a non-matching parent.** List
  recursively and filter the JSON instead.
- **Ids in output are not always `Id`:** navigation nodes carry `Key`; a folder's permissions
  are under `ListItemAllFields.RoleAssignments`; `spo listitem get --uniqueId` wants the
  `UniqueId` field, not `GUID`.
- **`entra group list --type … --properties …` fails** (`not a valid count option`); pass one
  of the two.
- **`spo list get --withPermissions` fails on anything but a document library**
  (`VersionPolicies is not supported`).
- **`spo term … list|get` without `--webUrl` go to the admin site** and are refused unless you
  are a SharePoint admin; with `--webUrl <a site you can read>` they work.
- **`spo page control list` also returns a placeholder per empty column**
  (`id: "emptySection"`); skip those when counting or picking a control.
- **`Invalid UUID`** — an option typed as an id takes only an RFC 4122 UUID; a made-up or
  all-zero placeholder is refused before any request. Read a real id first.

Measured against the CLI's own validation in 12.0.0 (`scripts/verify-commands.mjs`, 2026-11-11: every
option of every command, nothing run, no tenant). The SharePoint behaviour in the last
trap was observed live on v11 (2026-09-17) and not repeated on v12.

- **A flag is turned off by leaving it out, never by `--flag false`.** Where the lookup
  prints `(flag, takes no value)`, write the bare flag or nothing. On 67 flags of the
  older commands (`entra app remove --force`, `spo group remove --force`,
  `spo site recyclebinitem clear --force`, `todo list|task remove --force`,
  `spo site add --isPublic`, `spo page add --publish`, …) the word `false` is read as a
  non-empty text, so `--force false` **is** `--force`: the confirmation is skipped and the
  delete runs. Only options printed as `<true|false>` take a value.
- **Deleting: v12 turned the switch round.** v11's `--recycle` (and `--skipRecycleBin`) is
  gone; `spo file|folder|list|listitem|page remove`, `spo listitem batch remove`,
  `spe container remove`, `entra m365group remove` and `spo site remove` take
  `--permanent` instead, and without it the item goes to the recycle bin (seen in the
  recycle bin for list item, batch, file, folder, page and list; not tried for the rest). A v11 command line with
  `--recycle` fails (`Invalid option`); do not "fix" it by reaching for `--permanent`.
- **Renamed since v11** — old command lines fail with `Invalid option` / `Unrecognized key`:
  `spo listitem get --properties` → `--fields`; `outlook mail searchfolder add
  --sourceFolderIds` → `--sourceFoldersIds` (sic, and the docs still show the old one);
  `spo navigation node get|set` need `--location` as well; the aliases
  `spo web alert list|remove` are gone (`spo web rule list|remove`).
- **Some commands accept any option name** — the lookup says so in a NOTE. There a typo is
  not an error: the value is sent on as a property, a header or a column, and the option
  you meant stays unset. Copy option names from the lookup letter for letter
  (`--displayName`, not the docs' `--displayname`).
- **Short names: only the ones the lookup prints.** The CLI's help shows a few that do not
  reach their option (`teams message send -t`, `spo site add -f`, `entra app set -p`, …).
  When in doubt use the long name.
- **`spo listitem add` / `spo listitem set` turn every option they do not know into a
  column value** — including `--query`, which the lookup lists under GLOBAL. A typo or a
  global option therefore fails as `Column 'query' does not exist` (or silently writes the
  value, if such a column exists). Only `--output`, `--debug`, `--verbose` and the options
  the lookup lists for the command are safe; pass column values as `--<InternalName>`.
  (Same in the 12.0.0 source: `query` is not on either command's exclusion list.)
- **`spo field add --xml`: SharePoint ignores the `Name` in the XML** and derives the
  internal name from `DisplayName` (`Příchod` → `P_x0159__x00ed_chod`) unless you pass
  `--options AddFieldInternalNameHint` (observed live, 2026-09-17). The lookup shows
  `--options <string>` without its values: they are `DefaultValue`,
  `AddToDefaultContentType`, `AddToNoContentType`, `AddToAllContentTypes`,
  `AddFieldInternalNameHint`, `AddFieldToDefaultView`, `AddFieldCheckDisplayName`,
  comma-separated, **exact casing** — anything else is rejected before any request is made
  (`… is not a valid value for the options argument`, rc 1). Read the internal name back
  (`spo field get`) before relying on it.

## What this skill does NOT cover

Domain knowledge about your own SharePoint (canvas format, SPFx, site structure, deployment
recipes) belongs in a skill layered on top of this one. Read-only search across M365 content
→ an M365 MCP server. Checking pages in a browser → Playwright.
