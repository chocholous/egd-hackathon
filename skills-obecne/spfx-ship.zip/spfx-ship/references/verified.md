# Ověřená čísla a chování

Testovací tenant `pavelchocholousgmail`, účet s rolí Global Admin, 5.–6. 11. 2026.
SPFx 1.24.1, CLI for Microsoft 365 11.x, macOS. Node 22.23.3 (celý řetězec) a 26.13.0 (build web partu). Surový záznam posledního měření: `probes/measure.log`
v repu `chocholous/ppf-arcade`.

## Custom Script (`DenyAddAndCustomizePages`: 1 = povoleno, 2 = blokováno)

| Měření | Deny=1 | Deny=2 |
|---|---|---|
| web part `requiresCustomScript: false` v nabídce webu | ano | **ano** |
| web part `requiresCustomScript: true` v nabídce webu | ano | **ne** |
| web part `requiresCustomScript: true` už vložený na stránce | vykreslí se | **vykreslí se dál** (měřeno pár minut po zablokování), nový vložit nejde |
| nahraný `.aspx` v knihovně | vykreslí se i se skriptem | nahraný až teď: **chyba stránky**; nahraný dřív: vykreslí se i se skriptem |
| nahraný `.html` v knihovně | v rámu SharePointu, skript neběží | totéž |
| `spo customaction add` (ScriptLink, scope Web) | projde | **403** |
| `spo site appcatalog add` (katalog na webu) | neměřeno | **projde** |
| `spo app add/deploy/install`, scope `sitecollection` | neměřeno | **projde**, web part je k dispozici |
| customizer přes feature (`skipFeatureDeployment: false`), instalace z tenant catalogu | neměřeno | **custom action vznikne sama** |
| totéž z katalogu na webu | neměřeno | **custom action vznikne sama** |
| customizer tenant-wide (`ClientSideInstance.xml`, deploy `--skipFeatureDeployment`) | neměřeno | položka v *Tenant Wide Extensions* vznikne, na webu žádná user custom action |

Ani jedna varianta customizeru nepotřebovala `spo customaction add`. V prohlížeči ověřeno
(konzole stránky na obou webech s Deny=2): customizer přes feature i tenant-wide se načte a běží,
web part z katalogu na webu se vykreslí na `SingleWebPartAppPage`.

## Hosté (externí uživatelé) a web part z tenant catalogu

Bez Office 365 CDN (`m365 spo cdn get --type Public` → `false`) se kód web partu načítá z knihovny
`ClientSideAssets` v tenant catalogu. Čte tam jen **Everyone except external users**, která hosty
vynechává. Host proto dostane chybu stránky, i když je ve Visitors webu se stránkou.
Ověřeno 6. 11. 2026 hostovským účtem autora.

| Varianta | Jak | Stav |
|---|---|---|
| 1. Hosté do Visitors katalogu | `m365 spo group member add --webUrl <katalog> --groupId <App catalog Visitors> --userNames <UPN hosta>` | **ověřeno**: host pak stránku vidí. Host ale čte celý web katalogu. |
| 2. Veřejná Office 365 CDN | `m365 spo cdn set --type Public --enabled true` (výchozí origin `*/CLIENTSIDEASSETS`) | **neměřeno**, podle dokumentace bez přihlášení. Kód web partu je pak veřejně čitelný a zapnutí CDN je změna celého tenantu. |

Katalog na webu se stránkou je třetí cesta, protože `ClientSideAssets` webu zdědí jeho Visitors. Neměřili jsme ji.

## Plocha appky (okno 1440×900)

| Prvek | app page | `?env=Embedded` | `?env=WebView` |
|---|---|---|---|
| suite bar | 48 px | 48 px | 0 |
| app bar | 80 px | 0 | 0 |
| hlavička webu | 108 px | 0 | 0 |
| command bar | 49 px | 0 | 0 |
| využití okna | 76 % | 95 % | 100 % |

## Oprávnění

`High 688 / Low 138612833` na webu katalogu odpovídá roli Read. **Domněnka, neměřeno:** `spo app add`
pak skončí Access denied i s delegovaným `AllSites.FullControl` (zápis s rolí Read nikdo nespustil). Access denied může znamenat i aplikaci bez SharePoint
oprávnění (Graph Command Line Tools: `E_ACCESSDENIED` i pod Global Adminem). Nejnižší potřebnou
roli jsme neměřili; dokumentace Microsoftu uvádí pro katalog na webu správce kolekce webů
(site collection administrator).

## Velikosti

`.sppkg`: scaffold web partu 1.24.1 s ukázkovými obrázky = 43 210 B (build na Node 26), web part
bez frameworku a bez obrázků ≈ 19 643 B, tři web party se sdíleným stylem 57 091 B, customizer ≈ 7 kB.
