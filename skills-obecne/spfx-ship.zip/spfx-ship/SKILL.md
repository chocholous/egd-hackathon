---
name: spfx-ship
description: Vyrob, postav a nasaď vlastní aplikaci na SharePoint Online — SPFx web part nebo rozšíření, od scaffoldu po stránku v prohlížeči. Použij při "dej tohle na SharePoint", "nasaď web part", "udělej z toho SPFx appku", při práci s app catalogem, .sppkg, Single Part App Page nebo když nasazená komponenta není vidět.
---

# Od nuly k nasazené appce na SharePointu

Všechno níže je **ověřené měřením** (listopad 2026, SPFx 1.24.1, CLI for Microsoft 365, Global Admin
v testovacím tenantu, macOS).
Čísla a chování v `references/verified.md`.

## Nejdřív: co vlastně stavíš

| Chci | Řešení | Pozor |
|---|---|---|
| obsah na stránce | **web part** | výchozí volba |
| zasáhnout okolní UI SharePointu | **extension** (Application Customizer) | tenant-wide umí jen App Customizer a List View Command Set |
| appka na celé okno | **web part + SingleWebPartAppPage + `?env=WebView`** | `?env=` je nedokumentované |
| něco mimo SharePoint | standalone HTML jinde | uvnitř SharePointu to nejde, viz níže |

Pokud nevíš, jestli do tenantu vůbec smíš zapisovat → **nejdřív `sharepoint-tenant-recon`**.

## Verze: nejnovější ≠ správná

**Node, TypeScript a React si diktuje SPFx, ne npm.** Zjisti je příkazem, nehardcoduj:

```bash
npm view @microsoft/generator-sharepoint version
curl -sS https://nodejs.org/dist/index.json | jq -r '[.[]|select(.lts!=false)][0].version'
```

a porovnej s oficiální maticí SPFx (`learn.microsoft.com/sharepoint/dev/spfx/compatibility`).

Ověřené kombinace: **SPFx 1.24.1 + Node 22.23.3** (celý řetězec: web part, customizer přes feature
i tenant-wide, tenant catalog i katalog na webu, blokovaný Custom Script, kontrola v prohlížeči)
a **Node 26.13.0** (`npm ci` + produkční build web partu, dřív i nasazení do tenant catalogu).
`engines` šablony 1.24.1: `>=22.14.0 <23 || >=24 <25 || >=26 <27`. Dál TypeScript ≤ 5.8 a
React přesně 18.3.1
(`npm install react@18.3.1 react-dom@18.3.1 --save-exact` — Microsoft varuje, že jiná verze
Reactu způsobí **tiché runtime selhání bez chyby při buildu**).

⚠️ Starší globální generátor (např. z homebrew) přebije `npm install -g --prefix X`. Nastav npm
prefix (`NPM_CONFIG_PREFIX` nebo `npm config set prefix X`) tak, aby `npm root -g` ukazoval do X,
a vždy zkontroluj `Generator@1.24.1` v banneru `yo`.

⚠️ Node „Current" bývá alpha. ⚠️ Od SPFx 1.24 je **gulp nepodporovaný**, toolchain je Heft;
`--use-gulp` existovalo jen v 1.22/1.23. Update verzí sám projekt nemigruje.

## Řetězec

```bash
# 1) scaffold — cílové prostředí "SharePoint Online only (latest)"
yo @microsoft/sharepoint --solution-name <n> --component-type webpart --framework none --environment spo

# 2) build (Heft)
npm run build        # → sharepoint/solution/<n>.sppkg

# 3) do katalogu (tenant catalog: --appCatalogScope tenant --appCatalogUrl <kat>;
#    katalog na webu: --appCatalogScope sitecollection, --appCatalogUrl i --siteUrl = URL webu)
m365 spo app add --filePath <.sppkg> --appCatalogScope tenant --appCatalogUrl <kat> --overwrite

# 4) nasadit
m365 spo app deploy --name <soubor.sppkg> --appCatalogScope tenant --appCatalogUrl <kat>

# 5) nainstalovat na web  ← tenhle krok se nejčastěji vynechá
m365 spo app install --id <ID> --siteUrl <web> --appCatalogScope tenant   # u katalogu na webu: sitecollection

# 6) POČKAT (měřeno 20 s až 1 min)

# 7) stránka — pořadí není libovolné
m365 spo page add --webUrl <web> --name x.aspx --layoutType Article
m365 spo page section add --webUrl <web> --pageName x.aspx --sectionTemplate OneColumn --order 1
m365 spo page clientsidewebpart add --webUrl <web> --pageName x.aspx --webPartId <id> --section 1 --column 1
m365 spo page set --webUrl <web> --name x.aspx --layoutType SingleWebPartAppPage --publish
```

**U každého zápisu pinnuj `--appCatalogUrl` / `--webUrl`** — viz `m365-cli-safe`, proč.

## Pasti, které stojí hodiny

1. **`deploy` ≠ dostupné.** Bez `--skipFeatureDeployment` (zaškrtávátko „available to all sites")
   musí přijít `spo app install` na konkrétní web.
2. **Propagace.** Hned po instalaci vrací přidání web partu `There is no available WebPart with Id …`;
   za 20 s až 1 min je k dispozici. **Není to chyba práv** — nezahazuj to jako neúspěch, ověř znovu později.
3. **Stránka nemá sekce.** `spo page add` vyrobí prázdný canvas → `clientsidewebpart add` spadne na
   `Invalid column 'undefined'`, pak `Invalid section '1'`. Nejdřív `page section add`.
   A sekci nepřidáš, dokud je stránka už přepnutá na app page → pořadí **Article → sekce → web part → layout**.
4. **Návratový kód za rourou lže.** `cmd | head` dá `$?` posledního článku; příkaz s `Error: 403`
   tak skončí s `rc=0`. Validuj **tvar výstupu**, ne jen rc.

## Custom script řešit nemusíš

Změřeno kontrolním pokusem (dva web party, jeden web, jedna chvíle):

| custom script | `requiresCustomScript: false` | `requiresCustomScript: true` |
|---|---|---|
| povolený (`Deny=1`) | vidět | vidět |
| **blokovaný (`Deny=2`)** | **vidět a běží** | **zmizel z nabídky** |

Scaffold generuje `false` → stačí nepřepínat. App catalog s blokovaným custom scriptem
nasazení **nebrání**. Povolení se navíc samo vrací na blokováno do 24 h, takže na něm nestav.

**Co custom script opravdu zakáže:** klasický ScriptLink přes `spo customaction add` → **403**
(ověřeno: `Deny=2` → 403, `Deny=1` → projde). `--location ClientSideExtension.ApplicationCustomizer
--clientSideComponentId` projde, ale je zbytečný a navíc customizer spustí podruhé. **Ten příkaz
nepotřebuješ.** Na webu s `Deny=2`
ověřeno (viz `references/verified.md`):

- customizer přes feature (`skipFeatureDeployment: false`): `spo app install` custom action
  založí sám, z tenant catalogu i z katalogu na webu,
- customizer tenant-wide (`ClientSideInstance.xml` + `deploy --skipFeatureDeployment`):
  vznikne položka v *Tenant Wide Extensions*, na webu nic registrovat nemusíš,
- katalog na webu (`spo site appcatalog add`) a `app add/deploy/install --appCatalogScope
  sitecollection` projdou i při blokovaném custom scriptu.

## Appka nemá vypadat jako SharePoint

- `SingleWebPartAppPage` sama **nestačí** — ukrojí 218 px shora a 80 px zleva (76 % okna).
- **`?env=WebView`** = 0 chrome, 100 % okna. `?env=Embedded` nechá jen suite bar.
- **Všechny interní odkazy musí ten parametr nést**, jinak uživatel vypadne zpátky do SharePointu.
- `?env=WebView` schová rámec i na úvodní stránce webu; odkaz bez parametru ukáže celý rámec →
  vstupní odkaz dávej lidem už s parametrem.
- Dál viz `spfx-performance` (co na webu vypnout).

## Co uvnitř SharePointu nefunguje

- **Standalone HTML jako náhrada appky.** Embed web part i Script Editor jsou při blokovaném
  custom scriptu vypnuté, Page Viewer nejde nasměrovat. Hostovat jinde = shánět schválení
  nového hostingu; celostránkovost řeší `?env=WebView`.
- `spo file add` nahrál `.html` i `.aspx` na web s blokovaným Custom Scriptem (jako admin), ale
  **jak se pak servírují, jsme nezjistili** — nespoléhej na to; pro běžného uživatele netestováno.

## Hotovo = přečteno zpátky i viděno

`rc=0` nestačí. `spo app list` → `Deployed=true`, `spo page get` → `layoutType` a web part
v `canvasContentJson`, **a stránka otevřená v prohlížeči**. Co jsi neviděl, není ověřené.

## Související

`sharepoint-tenant-recon` · `m365-cli-safe` · `spfx-develop` · `spfx-performance`
