---
name: m365-cli-safe
description: Bezpečný provoz CLI for Microsoft 365 na stroji, kde běží víc Claude sessions — izolace přihlášení, pinnování cíle u zápisů, rozdíly CLI 11 vs 12, instalace v zamčené síti a tabulka chybových hlášek. Použij při každé práci s příkazem m365, při "Access denied", při podezření, že příkazy míří do jiného tenantu, a při instalaci CLI bez admin práv nebo bez přístupu k npm/PSGallery.
---

# CLI for Microsoft 365 bezpečně

## 🔴 Connection store je globální stav

CLI drží přihlášení jako dotfiles **přímo v `$HOME`**:

```
~/.cli-m365-connection.json        aktivní spojení
~/.cli-m365-all-connections.json   všechna spojení
~/.cli-m365-msal.json              MSAL cache (refresh token)
```

(`~/.config/configstore/cli-m365-config.json` drží jen preference, ne přihlášení.)

**Je to sdílené všemi session na stroji.** `m365 connection use` v jedné session tiše
přesměruje příkazy ve všech ostatních — bez varování, bez chyby. Ověřeno: uprostřed práce
v jednom tenantu přepnula jiná session spojení a `spo tenant appcatalogurl get` začal
vracet úplně jiný katalog.

Navíc CLI zapisuje ty tři soubory `fs.writeFile` **bez zámku** → dvě souběžné instance si
zápisy proloží a cache se roztrhne (pozorováno: `~/.cli-m365-msal.json` useknutý uprostřed
tokenu, „Unfinished JSON term at EOF"). Pak CLI žije na posledním access tokenu a po jeho
vypršení chce znovu prohlížeč.

### Obrana

1. **Vlastní `HOME`.** `XDG_CONFIG_HOME` CLI **ignoruje** (čte `os.homedir()`), `HOME` respektuje:
   ```bash
   export HOME=/cesta/k/izolovanemu/domovu
   m365 setup --scripting --skipApp      # nastaví output json a prompt false bez loginu
   m365 login --appId <id> --tenant <id> --authType deviceCode
   ```
   ⚠️ **`setup --scripting` nevynechávej.** V izolovaném domově není config, takže platí
   default `prompt: true` — a příkaz, kterému chybí povinná volba, se místo chyby **zeptá
   a visí až do timeoutu** (`Provide values for the following parameters: url:`). Vypadá to
   jako pomalý SharePoint, přitom čeká na stisk klávesy, který nikdy nepřijde.
2. **Pinnuj cíl u každého zápisu** — `--webUrl`, `--appCatalogUrl`, `--siteUrl`.
   Při přepnutém spojení pak dostaneš chybu autentizace místo zápisu do cizího tenantu.
3. **Assertuj tenant ve stejném příkazu jako zápis**, ne o příkaz dřív:
   ```bash
   [ "$(m365 status | jq -r .appTenant)" = "<tenantId>" ] || exit 1
   m365 spo app add --appCatalogUrl <kat> ...
   ```
4. **Nepoužívej `m365 connection remove`** na poslední/nahrazené spojení — je to plný logout.

## CLI 11 vs 12

| | v11 | v12 |
|---|---|---|
| tokeny | soubor v `$HOME` | **credential store OS** |
| izolace přes `HOME` | úplná (i tokeny) | jen connection soubory |
| po upgradu | — | **nutný nový login**, maže starý `~/.cli-m365-msal.json` |
| nativní závislosti | žádné install skripty | `keytar`, `@azure/msal-node-extensions` |

**Past: v12 + izolovaný `HOME` = `CachePersistenceError`.** macOS hledá login keychain pod
`$HOME`; když tam není, ověření persistence selže a login vůbec nestartuje. Fallback na soubor
má v kódu **jen Linux** — na macOS CLI vyhodí chybu (změřeno). Řešení:

```bash
mkdir -p <home>/Library && ln -s ~/Library/Keychains <home>/Library/Keychains
```

⚠️ Ani pak **tokeny po `HOME` izolované nejsou** — `serviceName: 'cli-microsoft365'` a
`accountName: 'msal-cache'` jsou v kódu konstanty, takže keychain je jeden na uživatele OS.
Dvě session přihlášené v12 do různých tenantů se o jednu položku přetahují. Pro paralelní
práci je v11 v tomhle lepší.

**Měřeno 6. 11. 2026 (macOS, CLI 12.0.0, lokální instalace):** na Node 22 (npm 10) se `keytar` postaví a projde
celý řetězec včetně katalogu na webu a stránky. npm 11 (Node 26) instalační skript `keytar` blokuje; login s v12
na Node 26 neměřeno.

⚠️ **Windows neměřeno.** Podle kódu by CLI 12 mohlo spadnout na úložišti hesel i tam; je to
neověřené riziko. Když spadne, použij CLI 11 (tokeny v souboru).

## Instalace v zamčeném prostředí

**CLI je npm balíček, ne PowerShell modul** — zablokovaná PSGallery ho neomezuje. Nejčastější omyl.

| Varianta | Jak | Kdy |
|---|---|---|
| globálně | `npm install -g @pnp/cli-microsoft365` | vlastní stroj |
| **lokálně** ⭐ | `npm install @pnp/cli-microsoft365`, volat `node_modules/.bin/m365` | verze pinnutá v lockfile, bez admin práv |
| globálně bez práv | `npm config set prefix "$HOME/.npm-global"` | zamčený stroj |
| offline | nainstalovat jinde, **přenést celou složku** | blokovaný i npm |

K offline přenosu: v11 nemá install skripty a nese si vlastní strom (~300 MB, 352 balíčků),
takže kopie funguje. **v12 má nativní `keytar`** → přenos jen mezi stejnými platformami,
a npm 11 install skripty blokuje: `npm install-scripts approve keytar @azure/msal-node-extensions`.

⚠️ **`npx m365` nepoužívej** — na npmjs existuje cizí balíček toho jména. Správně
`npx -p @pnp/cli-microsoft365 m365 <cmd>`.

## Tabulka chyb

| Hláška | Znamená | Co s tím |
|---|---|---|
| `Access denied` / `403` u `spo app add` | buď role na webu katalogu, nebo aplikace bez SharePoint oprávnění (Graph Command Line Tools dostaly `E_ACCESSDENIED` i pod Global Adminem) | ověř `scp` na SPO resource a roli na webu; nejnižší potřebnou roli jsme neměřili (dokumentace Microsoftu uvádí správce kolekce webů na webu katalogu) |
| `403` u `spo customaction add` | web s blokovaným Custom Scriptem (`Deny=2`) odmítá klasický ScriptLink; `--location ClientSideExtension.ApplicationCustomizer --clientSideComponentId` projde | customaction ručně nepotřebuješ: customizer přes feature (`skipFeatureDeployment: false`, ve feature jen `elements.xml`) se zaregistruje sám při `spo app install` (z tenant i site catalogu); ruční akce navíc customizer spustí dvakrát. Tenant-wide je druhá cesta, chce zápis do tenant catalogu |
| `AADSTS65001` | chybí consent pro appId | vlastní registrace + admin consent |
| `Attempted to perform an unauthorized operation` | tenant admin API bez SharePoint Admin role | nečitelné, přiznej UNVERIFIABLE |
| `There is no available WebPart with Id` | propagace po instalaci | počkej a ověř znovu |
| `CachePersistenceError` (v12) | keychain není pod `$HOME` | symlink `Library/Keychains` |
| token visí do timeoutu | rozbité IPv6 k `login.microsoftonline.com` | `curl -6` vs `curl -4` test |
| příkaz visí, pak timeout | chybí povinná volba + zapnutý `prompt` | `m365 setup --scripting`, zkontroluj volbu v `./lookup` |
| `The property '--x false' does not exist` | zsh nerozdělil nekvótovanou proměnnou na slova | argumenty piš přímo, nebo pole `arr=(...)` + `"${arr[@]}"` |

## Dvě věci, které se nevyplatí hádat

**Názvy voleb si vždycky vyhledej** (`./lookup <cmd>`). Nejsou konzistentní napříč příkazy —
`spo web set` chce `--url`, zatímco většina ostatních `spo` příkazů `--webUrl`. Hádání
podle sousedního příkazu stojí jeden běh do timeoutu.

**Scratchpad session nepřežije restart.** Zdrojáky čehokoli, co jsi nasadil, patří do gitu
nebo jiného trvalého místa — nasazený balíček v katalogu běží dál, ale bez zdrojáků ho
nezměníš ani nepředáš dál.

## Související

`sharepoint-tenant-recon` · `spfx-ship` · `spfx-performance`
