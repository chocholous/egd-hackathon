# Atribuce a odchylky od upstreamu

Tenhle skill je **zapečená (pinnutá) kopie** oficiálního Microsoft skillu pro Playwright Agent CLI.

| | |
|---|---|
| **Upstream** | `@playwright/cli` **0.1.17** — <https://github.com/microsoft/playwright-cli> |
| **Zdroj v balíčku** | `node_modules/playwright-core/lib/tools/cli-client/skill/` |
| **Licence** | Apache License 2.0 (plné znění v `LICENSE`) |
| **Copyright** | Microsoft Corporation |
| **PPF verze** | 1.0.0 |
| **Zapečeno** | 2026-07-23 |

Upstream soubory byly převzaty beze změny s výjimkou úprav níže. Verzování `version:` je
**vlastní PPF řada** (1.0.0, …), nezávislá na upstream verzi — plugin marketplace `ppf-skills`
pozná novou verzi právě podle tohoto pole a upstream skill žádné nemá. Upstream verzi drží pole `upstream:` ve
frontmatteru; při bumpu CLI podle něj poznáš, z čeho přebalovat.

## Změny proti upstreamu (Apache-2.0 §4b)

1. **`SKILL.md` — frontmatter**: doplněno `version: 1.0.0` (nutné, aby marketplace
   poznal novou verzi) a `upstream:`. Do `description` přidána věta, že storage state řídí
   `ppf-browsermagic`.
2. **`SKILL.md` — hlavička**: blockquote „PPF pin" se zákazem `install --skills`.
3. **`SKILL.md` — sekce Storage**: blockquote odkazující správu auth session na
   `ppf-browsermagic` (zákaz `state-save` na sdílený store, `state-load`
   session neobnovuje, cesty ke state).
4. **`SKILL.md` — sekce Installation**: poznámka, že se instaluje jen binárka, ne skills.
5. **`references/storage-state.md`**: blockquote s týmž přebíjením + upozornění, že
   `state-save` neukládá sessionStorage ani IndexedDB.
6. **Přidáno**: `LICENSE` (z balíčku), `ATTRIBUTION.md` (tento soubor).

Ostatních 8 referencí je bit-za-bit upstream.

## Údržba — jak přebalit na novější CLI

```bash
npm install -g @playwright/cli@latest
playwright-cli --version                     # nová upstream verze

# porovnej upstream se zapečenou kopií
diff -ru ~/.claude/skills/playwright-cli \
  /opt/homebrew/lib/node_modules/@playwright/cli/node_modules/playwright-core/lib/tools/cli-client/skill/
```

Diff ukáže jak upstream změny, tak našich 6 úprav. Přenes upstream změny, zachovej úpravy,
zvedni PPF `version:` a `upstream:`, přegeneruj pluginy (`.venv/bin/python tools/build_plugins.py`)
a ověř lokálně přes `claude --plugin-dir plugins/playwright-cli`.

**Nepřebalovat přes `playwright-cli install --skills`** — přepisuje vendored soubory natvrdo,
bez zálohy a bez varování (ověřeno 2026-07-23: marker vložený do `SKILL.md` byl po reinstalaci
pryč, md5 se změnilo; `.claude/settings.local.json` naopak zůstal nedotčený).
