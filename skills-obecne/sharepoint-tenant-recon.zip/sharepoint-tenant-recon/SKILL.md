---
name: sharepoint-tenant-recon
description: Zjisti, co v konkrétním M365/SharePoint tenantu reálně smíš, dřív než začneš cokoli stavět. Použij před prvním nasazením do neznámého tenantu, při "Access denied" u SharePointu, při otázce "jaké appId / oprávnění tu máme" a když je potřeba formulovat žádost pro IT. Jen čtení, nikdy nezapisuje.
---

# Recon tenantu: co tu smím

Pouštěj **před** stavbou, ne až po prvním 403. Výstup nejsou dumpy, ale tři seznamy:
**funguje / blokováno / žádost pro IT**.

## Železné pravidlo

**Oprávnění jsou dvě nezávislé vrstvy a obě musí sedět:**

| Vrstva | Co to je | Jak selže |
|---|---|---|
| **Entra** — co smí aplikace | delegované scopes app registrace (`AllSites.FullControl`) | `AADSTS65001`, chybí scope v tokenu |
| **SharePoint** — co smíš ty na webu | role uživatele na konkrétní site collection | `Access denied`, `403` i s plným scope |

`Access denied` / `403` může znamenat roli na webu, ale i aplikaci bez SharePoint oprávnění
(Graph Command Line Tools dostaly `E_ACCESSDENIED` i pod Global Adminem) — rozliš to podle `scp`
na SPO resource a podle masky na webu katalogu. Nejnižší potřebnou roli jsme neměřili
(neměřeno; dokumentace Microsoftu uvádí pro katalog na webu i pro tenant catalog správce kolekce webů
na webu katalogu, site collection administrator).
Žádost pro IT pojmenuj podle zjištěné vrstvy, ne "obecně chybí oprávnění".

## Postup

### 1. Čím jsem přihlášený a co ten token umí

```bash
m365 status
m365 util accesstoken get --resource https://graph.microsoft.com | cut -d. -f2 | tr '_-' '/+' | sed 's/$/==/' | base64 -d | jq '{appid, app_displayname, tid, upn, scp}'
```

Pro SharePointové operace si vyžádej token na SPO resource (`--resource https://<tenant>.sharepoint.com`)
a podívej se na `scp` tam — Graph scopes o SharePointu nevypovídají.

### 2. Jaké aplikace a oprávnění jsou v tenantu k dispozici

Ne jen „co mám teď", ale „co bych mohl použít":

```bash
# service principaly a jejich delegované granty (chce Application.Read.All / Directory.Read.All)
m365 entra app list
m365 request --url "https://graph.microsoft.com/v1.0/oauth2PermissionGrants" --resource https://graph.microsoft.com
```

Zajímá tě hlavně, jestli někde existuje app s delegovaným **`AllSites.FullControl`** — to je
to, co `spo app add` i `spo app deploy` vyžadují.

Zjisti taky, jestli si registraci **umíš založit sám**: potřebuješ `Application.ReadWrite.All`
a `DelegatedPermissionGrant.ReadWrite.All`. Když je máš, nemusíš nic shánět přes IT.

> **Degraduj nahlas.** Když na enumeraci nemáš práva, napiš to — „nenalezeno ≠ neexistuje".
> Prázdný výsledek bez komentáře je horší než chybová hláška.

### 3. App catalog a práva na něm

```bash
m365 spo tenant appcatalogurl get
m365 spo app list --appCatalogScope tenant --appCatalogUrl <katalog>      # čtení funguje?
m365 spo list get --webUrl <katalog> --title "Apps for SharePoint" --properties "Title,EffectiveBasePermissions"
```

Masku **dekóduj na jména práv**, jinak nikomu nic neřekne. Je to 64bit: `Low` jsou bity 0–31,
`High` bity 32+. Pro zápis balíčku potřebuješ `addListItems` a `editListItems`.

Příklad reálného výsledku: `High 688 / Low 138612833` = role **Read** — chybí `addListItems`,
`editListItems`, `addAndCustomizePages`, `manageLists`. Čtení katalogu přitom funguje, takže
bez dekódování masky to vypadá, že je všechno v pořádku.

Mají appku používat hosté? Zkontroluj CDN a kdo čte `ClientSideAssets` v katalogu:

```bash
m365 spo cdn get --type Public
m365 spo list get --webUrl <katalog> --url <cesta katalogu>/ClientSideAssets --withPermissions
```

Bez CDN, a když tam čte jen „Everyone except external users“, host web part nenačte (ověřeno 6. 11. 2026).
Řešení je v `spfx-ship/references/verified.md`, sekce Hosté.

Zkontroluj i list **Tenant Wide Extensions** v katalogu (`spo list get`) — jeho existence
a `ItemCount` ti řeknou, jestli už někdo v tenantu nasazoval rozšíření tenant-wide.

### 4. Sestav verdikt

Tři seznamy, každý s konkrétním příkazem nebo chybou jako důkazem:

- **Funguje** — co jsi ověřil voláním, ne co predpokládáš
- **Blokováno** — co a na které vrstvě
- **Žádost pro IT** — jedna věta, konkrétně pojmenovaná

## Co sem nepatří

- **Custom script neřeš.** Pro SPFx je irelevantní (viz `spfx-ship`), čtení jeho stavu navíc
  vyžaduje SharePoint Admin a typicky skončí `Attempted to perform an unauthorized operation`.
  Patří do diagnostiky 403 u `customaction add` (klasický ScriptLink), ne do reconu.
- Nic nezapisuj. Recon je read-only; i „neškodný" testovací upload patří až za rozhodnutí.

## Související

`spfx-ship` (stavba a nasazení) · `m365-cli-safe` (bezpečný provoz CLI) · `spfx-performance`
