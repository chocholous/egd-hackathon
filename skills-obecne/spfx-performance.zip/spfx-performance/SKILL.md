---
name: spfx-performance
description: Zrychli a odchroumuj SPFx aplikaci na SharePointu — schovat rámec SharePointu, vypnout co appku zdržuje, zmenšit bundle a změřit skutečný dopad. Použij při "appka je pomalá", "nemá to vypadat jako SharePoint", "schovej navigaci", při ladění velikosti .sppkg a při nastavování webu pro aplikační použití.
---

# Výkon a čistý vzhled SPFx appky

Cíl: aby **bez devtools a bez pohledu na URL** nebylo poznat, že to běží na SharePointu —
a aby se kolem appky nenačítalo nic, co k ní nepatří.

## 1. Schovat rámec

Naměřeno `getBoundingClientRect()` při okně 1440×900, komunikační web s navigací:

| Prvek | app page | `?env=Embedded` | `?env=WebView` |
|---|---|---|---|
| Suite bar | 48 px | 48 px | — |
| SharePoint app bar (vlevo) | 80 px | — | — |
| Hlavička webu | 108 px | — | — |
| Command bar | 49 px | — | — |
| **Obsah začíná** | **218 / 80 px** | 48 px | **0, 0** |
| **Využití okna** | **76 %** | 95 % | **100 %** |

- `SingleWebPartAppPage` sama schová jen **page header** (titulní banner stránky) a zúží command bar.
  Site header s navigací, suite bar ani app bar nezmizí. App bar navíc Microsoft od 31. 3. 2023 skrýt nedovoluje.
- **`?env=WebView` je jediná varianta se 100 %.**
- ⚠️ `?env=` není dokumentované. Pro interní appku ano, pro provozně kritickou věc si to ohlídej.

**Konzistence je součást dojmu:** když jedna stránka parametr má a odkaz na druhou ne, uživatel
vypadne zpátky do SharePointu. **Všechny interní odkazy musí `?env=WebView` nést.**
`?env=WebView` schová rámec i na úvodní stránce webu; odkaz bez parametru ukáže celý rámec →
vstupní odkaz distribuuj lidem rovnou s parametrem.

## 2. Co na webu vypnout

Ověřeno — po těchto čtyřech příkazech `_api/web` vrací `QuickLaunchEnabled=false`,
`MegaMenuEnabled=false`, `FooterEnabled=false`, `HeaderLayout=2`:

```bash
m365 spo web set --url <web> --quickLaunchEnabled false   # levá navigace
m365 spo web set --url <web> --megaMenuEnabled false      # rozbalovací menu
m365 spo web set --url <web> --footerEnabled false        # patička
m365 spo web set --url <web> --headerLayout compact       # nižší hlavička
m365 spo page set --webUrl <web> --name <page> --commentsEnabled false   # komentáře
```

⚠️ **`spo web set` chce `--url`, ne `--webUrl`** — na rozdíl od většiny `spo` příkazů.
Tohle si vždycky ověř (`./lookup spo web set`), nehádej podle ostatních příkazů.

Komentáře na aplikační stránce nikdo nečte, takže je vypnout dává smysl kvůli vzhledu; vliv na
rychlost jsme neměřili.

⚠️ Když `spo web set` **visí až do timeoutu**, nebývá to pomalý server, ale **interaktivní
dotaz na chybějící povinnou volbu** (`Provide values for the following parameters: url:`).
V izolovaném `HOME` chybí config, takže je `prompt` zapnutý — viz `m365-cli-safe`.

> **Měř, než to vydáš za zrychlení.** Jistá je jen změna vzhledu; vliv vypnutých prvků na rychlost
> jsme neměřili.
> Čísla si vezmi z `read_network_requests` a z časů v prohlížeči se stejnou stránkou
> s parametrem a bez něj — ne z dojmu.

## 3. Bundle

- **`includeClientSideAssets: true`** (default) servíruje JS z app catalogu → **žádná CDN**,
  o jeden požadavek na IT míň a bez cizího původu.
- Referenční velikost `.sppkg`: **web part bez frameworku a bez obrázků ≈ 19,6 kB**, scaffold
  1.24.1 s ukázkovými obrázky 43,2 kB, tři web party se sdíleným stylem a inline SVG ikonami 57,1 kB. React stack je řádově výš — pokud appka React nepotřebuje,
  scaffolduj `--framework none`.
- **Ikony a fonty inline**, ne z CDN: externí font je další DNS + TLS + request a v zamčené
  síti se nemusí stáhnout vůbec.
- `npm run build` (Heft) dělá produkční bundle; `debug/` vedle `.sppkg` do nasazení nepatří.

## 4. Runtime appky samotné

- Jeden `requestAnimationFrame` smyčka, žádné `setInterval` na kreslení.
- `canvas` velikost násob `devicePixelRatio` a `setTransform`, jinak to na retina displeji rozmaže.
- Posluchače na `window` registruj v `render()` a **odregistruj v `onDispose()`** — web part se
  v SharePointu může přerenderovat víckrát a bez úklidu ti běží několik smyček najednou.
- `touch-action: none` na herní ploše, jinak mobil scrolluje místo hraní.

## 5. Jak to měřit

1. Otevři stejnou stránku s `?env=WebView` a bez něj.
2. `read_network_requests` → počet requestů a objem.
3. Konzole → chyby, které appku zpomalují tiše.
4. Rozdíl zapiš i s datem a verzí SPFx; za půl roku to bude jinak.

## Související

`spfx-ship` (nasazení) · `spfx-develop` (kód appky) · `m365-cli-safe`
