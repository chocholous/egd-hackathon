# ppf-citizen-ai-devkit — plugin pro citizen AI developery

Stavíš SharePoint aplikaci (SPFx web part) v PPF tenantu s Claude Code. Plugin dá agentovi skill
s celým postupem a šablonu projektu, ve které jsou všechny nástroje lokálně (`npm run …`).

## Instalace

1. Přidej marketplace ppf-skills (interní, mimo PPF nedostupný; v tomhle repu místo něj ZIPy) a nainstaluj z něj plugin
   `ppf-citizen-ai-devkit`. Tři pluginy, na kterých kit závisí, se nainstalují a zapnou samy:
   `ppf-material` (vzhled), `ppf-browsermagic` (přihlášení sondy stránek) a `m365-cli-12` (volby a pasti CLI for Microsoft 365).
2. Žádný z těch tří nevypínej: s vypnutou závislostí se kit nenačte.
3. Měj Node 22.14+, 24 nebo 26 (doporučeno 26 LTS) a git. Nic dalšího globálně instalovat nemusíš.
4. Otevři v Claude Code prázdnou složku, napiš **`/ppf-citizen-ai-devkit`** (jediný zaručený vstup: v prázdné složce se
   kit z pouhé věty načíst nemusí) a pak agentovi řekni: **„založ mi novou SharePoint appku <název>“**.
   Agent spustí `devkit init` (skript `skills/ppf-citizen-ai-devkit/scripts/devkit.mjs` v pluginu), nainstaluje
   závislosti a řekne, co musíš udělat ty:
   - říct mu adresu svého DEV webu (potřebuješ na něm vlastníka a site app catalog; když nevíš, zeptej se správce webu),
   - jednou se přihlásit do m365 (přesný příkaz ti vypíše `npm run prereq`, otevře prohlížeč),
   - jednou se přihlásit pro sondu stránek (plugin `ppf-browsermagic`; přesný příkaz vypíše sonda).
5. Pak popiš, co má appka dělat: „udělej formulář pro hlášení incidentů, uživatel vidí jen svoje, editor všechno“.

## Jak to běží

Appka se vyvíjí lokálně nad mocky (`npm run dev`), listy, práva a stránky jsou v `sp/app.manifest.json`
a na DEV/TEST je dá jediný příkaz `npm run deploy` (nejdřív plán, pak zápis potvrzený hashem).
Po nasazení agent stránku ověří v prohlížeči. Testeři na DEV/TEST píšou připomínky přímo do appky a agent
si je přečte. Produkční nasazení je mimo tento kit: review a deployment kit je plánovaný a jeho vlastníka určí správce kitu; předává se tag v gitu.

## Co plugin obsahuje

| Část | K čemu |
|---|---|
| skill `ppf-citizen-ai-devkit` | postup pro agenta: workflow, příkazy, pravidla, řešení potíží |
| `skills/ppf-citizen-ai-devkit/templates/project` | šablona projektu: `prereq`, `dev`, `gen`, `build`, `deploy`, `sp`, `probe`, `feedback`, `m365`, `test`, `cert` |
| `skills/ppf-citizen-ai-devkit/scripts/devkit.mjs` | `init` (nový projekt) a `theme` (PPF vzhled pro MUI) |
| hook | holé `m365` odmítne a pošle na `npm run m365 -- …` |

Kit závisí na třech pluginech z marketplace ppf-skills: `ppf-material` (PPF vzhled, tokeny, fonty, komponenty;
kit z něj theme generuje), `ppf-browsermagic` (uložená session prohlížeče pro sondu) a `m365-cli-12` (návod
a lookup voleb CLI for Microsoft 365 verze 12). Odkazuje na ně jménem, takže se bere vždy nainstalovaná verze.
Samotné CLI plugin `m365-cli-12` neobsahuje: je závislostí projektu s pinem v `package.json` a volá se
`npm run m365 -- …`. Zdroj kitu je repo ppf-spfx-devkit; do katalogu se kopíruje (`tools/sync-to-skills.mjs`).
Původ vendorovaných částí: `SOURCES.json`.

Projekty kitu v0.1 (`.env`, `devkit setup`, VIP) tahle verze nepodporuje: zůstaň na pluginu 0.2,
nebo projekt převeď (`devkit init` a přenes kód do `spfx/src/app`).

## Platformy

macOS ověřeno proti DEV web. Windows neměřeno: `skills/ppf-citizen-ai-devkit/references/windows.md`.

## Pravidla, na která se můžeš spolehnout

- Nasazuje se jen přes `npm run deploy` a jen do prostředí pojmenovaných `dev` a `test`; jiné jméno prostředí kit odmítne.
  Že na produkční web nezapíšeš, zaručují práva tvého účtu, ne kit. Ruční `npm run m365` je průchozí: zápis jím jen po tvém ano.
- Nic se nemaže, ani na SharePointu, ani v souborech.
- Po každém nasazení agent stránku zkontroluje v prohlížeči; úspěšný build sám nestačí.
