---
name: ppf-citizen-ai-devkit
description: "Vývoj SharePoint aplikací (SPFx web partů) v PPF tenantu: nový projekt ze šablony, lokální vývoj nad mocky, listy, práva a stránky v manifestu, nasazení na DEV a TEST jedním příkazem s plánem, sonda stránky v prohlížeči, připomínky testerů v appce, předání na produkci. Použij vždy, když se v repu pracuje se SharePointem, SPFx, složkou spfx/, project_config.json, m365 příkazem, listem, stránkou nebo nasazením — i když uživatel řekne jen „udělej mi formulář na SharePoint“, „nasaď to“, „proč se webpart nevykreslí“ nebo „přidej sloupec“. Repo jen s .env a bez project_config.json je starý projekt v0.1, který tahle verze nepodporuje (plugin 0.2, nebo převod přes devkit init)."
version: 0.8.0
compatibility: "Node 22/24/26, doporučeno 26 LTS (SPFx 1.24.1, React 18.3.1, heft, m365 CLI 12.0.0, Playwright 1.65), git; pluginy ppf-material (1.1.0 nebo novější), ppf-browsermagic a m365-cli-12 z marketplace ppf-skills (závislosti pluginu, instalují se s ním; samotné CLI je v projektu). Nic globálně: nástroje jsou v package.json projektu. macOS ověřeno na DEV web, Windows neměřeno (references/windows.md)."
user-invocable: true
---

# ppf-citizen-ai-devkit

Tenhle skill je plugin `ppf-citizen-ai-devkit` (dřív `ppf-spfx-devkit`); lokální složka
`~/Projects/citizen-ai-dev-kit` je vzorová aplikace, ne kit, a nástroje ani pravidla se z ní neberou.

**Prázdná složka (projekt ještě není):** napiš `/ppf-citizen-ai-devkit`. To je jediný zaručený vstup; z věty
jako „udělej mi appku na SharePoint“ se skill v prázdné složce načíst nemusí. V projektu ho načítá `CLAUDE.md`.

Projekt = repo s `project_config.json`, založené ze šablony tohoto skillu. Všechno se v něm dělá příkazy
`npm run …`; CLI pluginu (`devkit`) a `doctor` se spouštějí z kitu:

```bash
node "${CLAUDE_SKILL_DIR}/scripts/devkit.mjs" init <složka> --name "<Název appky>" --prefix <PREFIX> --install
node "${CLAUDE_SKILL_DIR}/scripts/doctor.mjs" --project <složka> [--pred-nasazenim]
```

`${CLAUDE_SKILL_DIR}` je složka tohoto skillu. V shellu bývá prázdná (ověř `echo "${CLAUDE_SKILL_DIR}"`); pak za ni dosaď
složku, ze které je tenhle SKILL.md načtený (u pluginu z marketplace
`~/.claude/plugins/cache/<marketplace>/ppf-citizen-ai-devkit/<verze>/skills/ppf-citizen-ai-devkit`; instalované pluginy
vypíše `claude plugin list`; v GitHub Copilot CLI
`~/.copilot/installed-plugins/<marketplace>/ppf-citizen-ai-devkit/skills/ppf-citizen-ai-devkit`, vypíše
`copilot plugin list`). Cestu neodhaduj: ověř, že v ní je `scripts/devkit.mjs`. Čerstvě nainstalovaný plugin
nemusí být v běžící session hned vidět; když skill chybí, začni novou session.

**Nástroje `prereq`, `gen`, `build` a `probe` končí dalším krokem a řádkem `STAV:`, `deploy` a `sp` řádkem
`STAV:`.** Řiď se jimi; návod popisuje hlavně to, co nástroj neřekne.
Hodnoty `STAV` plánu nasazení a návratové kódy jsou v §Návratové kódy a v [sp-sync.md](references/sp-sync.md)
§Výsledek.

## Postup

| # | Krok | Příkaz | Kdo |
|---|---|---|---|
| 1 | **Průvodce (povinně první, jednou na projekt)** | nový projekt i převzetí staršího podle [onboarding.md](references/onboarding.md): `devkit init` nebo cesta Migrace, pak `doctor --project .` a kroky průvodce | agent vede, člověk potvrzuje své kroky |
| 2 | Weby a role | **prerekvizita:** sada tří webů SharePointu (DEV, TEST, PROD), kterou nováček dostane předem; adresy DEV a TEST do `environments.<env>.site`, role → skupiny ([manifest.md](references/manifest.md) §Práva). PROD do souboru nepatří | člověk řekne, agent zapíše |
| 3 | Přihlášení do m365 (jednou za čas) | `npm run m365 -- login …` (přesný příkaz vypíše `prereq`); jen v terminálu projektu, přihlášení z jiné složky nebo holým `m365` projekt nevidí | člověk, prohlížeč |
| 4 | Začátek každé práce | `npm run prereq` (bez skriptu `prereq` zpět na krok 1). FAIL u webu nebo přihlášení blokuje jen práci na SharePointu (deploy, probe, feedback, `dev --sp`); jiný FAIL (Node, závislosti) oprav nejdřív. Je-li `cockpit.url`, **přečti cockpit** ([cockpit.md](references/cockpit.md) §Co agent udělá po přečtení) | agent |
| 5 | Zadání a návrh | zadání (chat nebo cockpit) → návrh po částech ke schválení v cockpitu podle [app-design.md](references/app-design.md), u každé obrazovky vzorová obrazovka ppf-material; po schválení `sp/app.manifest.json` a `sp/data/`, `npm run gen` | agent navrhne, člověk schválí |
| 6 | Kód appky | `spfx/src/app/` podle [kod.md](references/kod.md): jen `DataSource` a `can()`, obrazovky ze stavebních bloků, formulář z MUI ([app-design.md](references/app-design.md) §2) | agent |
| 7 | Vyzkoušet lokálně | `npm run dev -- --port <port>` (`?user=<jméno>` role, `?now=<ISO čas>` hodiny); průběžně `npm run design-check -- --rychle`, před nasazením úplná `npm run design-check` a **projdi screenshoty**; před commitem `npm run check-all` | agent i člověk |
| 8 | Nasadit na DEV | zvednout `solution.version`, `npm run build`, commit a push, `npm run deploy -- --env dev` (plán), ukázat člověku, `--confirm <hash>` | agent, člověk schválí plán |
| 9 | Ověřit | kontrolní plán na konci nasazení, `npm run probe -- --env dev`; práva role bez druhého účtu `npm run sp -- prava --env dev --user <upn>` | agent |
| 10 | Připomínky testerů | testeři píšou do appky; `npm run cockpit` je přenese do cockpitu, dál tok Připomínka → úkol ([cockpit.md](references/cockpit.md)); jednu přečte i `npm run feedback -- --env dev` | testeři, člověk, agent |
| 11 | TEST | totéž s `--env test` | agent, člověk schválí plán |
| 12 | Předání na produkci | tag `v<verze>` na commitu nasazeném na TEST a push (§Produkce) | člověk |

**Hotovo** znamená prázdný kontrolní plán (nebo jen nálezy `navíc`, které člověk zná), sondu bez chyby a záznam
o nasazení na webu. Build sám nic nedokazuje.

Krok 1 blokuje ve dvou stupních. Lokální vývoj (kroky 5–7) smí začít, jakmile `doctor --project .` nehlásí
`CHYBA`; před prvním nasazením musí projít `doctor --project . --pred-nasazenim` (vzdálený repozitář, web
a přihlášení, role, cockpit, výjimky). Podmínky zjistitelné bez webu čte doctor ze stejného místa jako plán
nasazení (`tools/lib/podminky.mjs`): co pustí jeden, pustí druhý.

## Pojistky

Platí vždy, ne „většinou“.

1. **Zapisuje jen `npm run deploy` a jen do prostředí pojmenovaných `dev` a `test`.** Jiné jméno skripty kitu
   odmítnou. Který web je produkční, kit neví: že za jmény `dev` a `test` není produkce, zaručují práva účtu a ten,
   kdo weby do `project_config.json` zapsal.
2. **Plán ukaž člověku; nasazení potvrzuje člověk.** Zápis jde jen s `--confirm <hash>` téhož plánu. Shodu hashe
   kontroluje skript, souhlas člověka ne: to je pravidlo pro agenta, ne zámek. Jediná výjimka: převzetí úkolu
   v cockpitu je souhlas s plánem, který obsahuje jen balíček a stránky ([cockpit.md](references/cockpit.md)
   §Připomínka, krok 4); jiný plán se ukazuje.
3. **Nasazuje se jen commitnutý a pushnutý stav.** Necommitnuté změny (i nové soubory), commit mimo vzdálenou
   větev a repo bez remote plán ukáže jako nález `git` a `--confirm` zápis odmítne, na DEV i TEST. Obejití není.
4. **Kit nemaže listy, knihovny, sloupce, stránky, skupiny, členy skupin ani úrovně oprávnění.** Co je na webu navíc,
   plán jen vyjmenuje (`navíc`, `odchylka`), odebírá člověk ručně. Odebírá jen to, co git výslovně říká: položku
   konfiguračního listu nebo asset odebraný z gitu pošle do koše. **Nevratné:** na listech s vlastními právy odebere
   přiřazení práv, která git nezná, a u listu s `access: "inherit"` obnoví dědičnost, čímž vlastní práva listu
   zahodí. Výpis plánu slovo „nevratné“ nepíše, proto to **agent řekne člověku při ukázání plánu**.
5. **Git je zdroj pravdy.** Struktura, práva, konfigurace a stránky jsou v `sp/`, web je cíl. Odchylka (změna jen na
   webu) a konflikt se nikdy nezapíšou samy: odchylka → `npm run sp -- pull --env <env> --write` a commit, konflikt
   rozhodne člověk ([manifest.md](references/manifest.md) §Git je zdroj pravdy).
6. **m365 jen přes `npm run m365 -- …`** (pinnutá verze a vlastní přihlášení projektu; holé `m365` a `npx` hook
   pluginu odmítne). **Tenant z `project_config.json` ověřují jen `deploy`, `sp` a `feedback`; ruční
   `npm run m365` je průchozí, tenant neověřuje** a pustí každý zápis, na který má účet práva.
7. **Zápis ručním `npm run m365` jen po ano člověka s přesným příkazem ukázaným předem.** Co jde přes manifest,
   patří do manifestu. Pasti ručního m365: [sp-sync.md](references/sp-sync.md) §Ruční m365.
8. **Přihlášení a MFA, tag pro produkci a schválení výjimky dělá člověk.** Agent vypíše příkaz a počká; výjimku
   jen navrhne.
9. **Nástroje projektu kontroluje `doctor` z kódu kitu** proti šabloně (krok `p-nastroje`, i soubor
   `DEVKIT-VYJIMKY.md`). Plán běží v projektu a šablonu kitu nezná, takže upravený nástroj projektu odhalí jen doctor.

## Další pravidla

- **Cockpit je povinný pro každé nasazení, i na DEV.** Prázdné `cockpit.url` plán hlásí jako blokující nález
  `cockpit` a `--confirm` zápis odmítne ([cockpit.md](references/cockpit.md)).
- **`solution.version` zvedni před každým nasazením nového kódu.** Plán pozná kód podle otisku obsahu; balíček
  z jiného kódu a stejnou verzi z jiného kódu, než je na webu, zablokuje.
- **Appka mluví jen přes `DataSource`** a na práva se ptá `can()`; žádný `fetch` na `_api`, žádná jména skupin v kódu.
- **Před commitem `npm run check-all`** (testy, typy a lint, bez buildu balíčku). `npm test` zůstává rychlý a sám.
- **Záznam o nasazení je jen na webu** (`_deploy/<env>.json` v konfigurační knihovně appky); do gitu po nasazení nic
  nepřibývá a necommituje se.
- **Pravidlo kitu se neporuší bez položky v `DEVKIT-VYJIMKY.md`**, kterou schválí člověk; odchylku, která je mezerou
  kitu, nahlas do kitu ([manifest.md](references/manifest.md) §Výjimky).
- **Git: stage jen explicitní cesty** (`git add -- <cesta> …`), nikdy `git add -A` ani `git add .`. Necommituj
  `.m365-home/`, `.env` ani `.devkit/`.
- **Nové části UI označ `data-cadk-id`**, řádky seznamů `data-cadk-key={item.Id}` (kotvy připomínek a kontroly vzhledu).
- **Vzhled řídí skill `ppf-material`** (1.1.0 nebo novější): před prací na UI ho načti. Barvy, rozměry, písmo a pohyb
  jen z theme (`PPF.*`), nikdy číslem nebo hexem; theme, fonty a `ppfDesign.json` needituj ručně, přegeneruj je
  `devkit theme`. Nález kontroly vzhledu je chyba appky, ne pravidla ([app-design.md](references/app-design.md) §2).

## Návratové kódy

Příkazy kitu (`npm run deploy`, `sp`, `cockpit`, `devkit diff`, `devkit update`) končí jedním z kódů
(`tools/lib/kody.mjs`):

| Kód | Význam | Co dál |
|---|---|---|
| 0 | hotovo, nic nezbylo | pokračuj |
| 1 | chyba: příkaz nedoběhl nebo zápis selhal | přečti hlášku, oprav příčinu; výsledek nemáš |
| 2 | špatné použití (neznámá volba, chybí `--env`) | oprav příkaz |
| 10 | plán má akce nebo nálezy a **nic se nezapsalo** | není chyba: ukaž plán člověku, případně `--confirm <hash>` / `--zapsat` |
| 11 | **zapsáno**, ale s upozorněním (kontrolní plán není prázdný, zbyl konflikt; u `npm run cockpit`: web některého prostředí nešel přečíst) | přečti upozornění; zápis už proběhl, neopakuj ho naslepo |

Plán proto neřetěz přes `&&`. `STAV: blokováno` = plán má blokující nález (první oddíl výpisu) a potvrzení nenabízí:
odstraň příčinu a spusť plán znovu.

## Příkazy

`devkit` = `node "${CLAUDE_SKILL_DIR}/scripts/devkit.mjs"`, `doctor` = `node "${CLAUDE_SKILL_DIR}/scripts/doctor.mjs"`.

| Úkol | Příkaz | Detail |
|---|---|---|
| nový projekt (výchozí plná ukázka; `--prazdny` bez ukázkové domény) | `devkit init <složka> --name … --prefix … [--prazdny] --install` | [onboarding.md](references/onboarding.md) |
| kontrola prerekvizit z kitu (jen čte) | `doctor --project . [--env <env>] [--pred-nasazenim] [--write]` | [onboarding.md](references/onboarding.md) |
| prerekvizity v projektu (jen čte; řádek FAIL nese opravu) | `npm run prereq [-- --env <env>] [--pred-nasazenim]` | [manifest.md](references/manifest.md) §prereq |
| návrh dat, stránky, rolí a práv | `sp/app.manifest.json`, pak `npm run gen` | [app-design.md](references/app-design.md), [manifest.md](references/manifest.md) |
| appka nad mocky / na DEV stránce z localhostu | `npm run dev -- --port <port>` / `npm run dev -- --sp [--page <klíč>]` | [kod.md](references/kod.md) |
| testy nástrojů a logiky appky | `npm test` | [kod.md](references/kod.md) §Testy |
| před commitem: testy + typy + lint | `npm run check-all` (jednotlivě `npm run typecheck`, `npm run lint`) | [kod.md](references/kod.md) §Testy |
| kontrola vzhledu | `npm run design-check -- --rychle [--sekce <id>]`, úplná `npm run design-check` | [app-design.md](references/app-design.md) §Co kontrola projde |
| balíček `.sppkg` | `npm run build` | [kod.md](references/kod.md) §Build |
| plán nasazení / nasazení | `npm run deploy -- --env dev` / `… --confirm <hash>` | [sp-sync.md](references/sp-sync.md) |
| plán bez balíčku, i pro jiná prostředí (jen čte, `--json`) | `npm run sp -- plan --env <env>` | [sp-sync.md](references/sp-sync.md) |
| odchylka na webu → do gitu | `npm run sp -- pull --env dev --write`, pak commit | [manifest.md](references/manifest.md) §Git je zdroj pravdy |
| práva uživatele proti manifestu bez jeho účtu (jen čte) | `npm run sp -- prava --env dev --user <upn> [--role <role>]` | [manifest.md](references/manifest.md) §Práva |
| sonda stránek appky | `npm run probe -- --env dev [--page <klíč>]` | [sp-sync.md](references/sp-sync.md) §Sonda |
| připomínky testerů | `npm run feedback -- --env dev [--all]` | [sp-sync.md](references/sp-sync.md) §Připomínky |
| cockpit (export stavu, deník rozhodnutí) | `npm run cockpit [-- --log <soubor>]`, nástroje `Artifact` a `ArtifactData`; bez nich (GitHub Copilot CLI) místní cockpit: `npm run cockpit -- --serve` | [cockpit.md](references/cockpit.md) |
| jednorázový m365 dotaz | `npm run m365 -- <příkaz> --help`, pak `npm run m365 -- <příkaz>` | [sp-sync.md](references/sp-sync.md) §Ruční m365 |
| PPF vzhled do staršího projektu | načti `ppf-material`, pak `devkit theme spfx/src/app/ppf --material <složka skillu ppf-material>` | [kod.md](references/kod.md) §UI |
| rozdíl projektu proti šabloně kitu (jen čte) | `devkit diff <složka projektu>` | [manifest.md](references/manifest.md) §Verze kitu |
| převzít novou verzi kitu | `devkit update <složka projektu> [--zapsat]` | [manifest.md](references/manifest.md) §Aktualizace projektu |
| https ladění | `"https": true` v `spfx/config/serve.json` a jednou `npm run cert` | [kod.md](references/kod.md) §Ladění na DEV |
| souběžná práce ve worktree | — | [kod.md](references/kod.md) §Souběžná práce |

## Produkce

Produkční nasazení je mimo tento kit (review a deployment kit je plánovaný, jeho vlastníka určí správce kitu).
**Předáváš commit, ne soubory:** commit, ze kterého proběhlo nasazení na TEST s prázdným kontrolním plánem a sondou
bez chyby (dokládá ho záznam o nasazení na webu TEST se stejným `commit` a `version`, `dirty: false`; přečte ho
doctor a `npm run cockpit`), označený `git tag v<solution.version> <commit>` a pushnutý do remote z
`project_config.json` → `git.remote` (`git push <remote> v<verze>`). Tag dělá člověk.
Při předání vypiš, co produkce potřebuje vědět z gitu: jména `@env:` ve vlastnostech web partů
(`rg -o '@env:[A-Za-z0-9]+' sp/app.manifest.json`; appka musí fungovat i bez nich,
[app-design.md](references/app-design.md) §Co se liší mezi prostředími) a listy `class: initial`, jejichž výchozí
sada se má na produkci vložit jednou.

## Když něco nejde

Ostatní stavy nástroj vypíše i s opravou; tyhle tři ne:

| Příznak | Příčina a oprava |
|---|---|
| sonda hned po nasazení ukazuje starou verzi | propagace 15–30 s, zopakuj |
| tester na TEST neotevře stránku | skupina role nemá na webu Read → [manifest.md](references/manifest.md) §Práva |
| `{"error":{}}` z ručního m365 (i s exit 0) | skrytý 401, většinou jiný tenant nebo hostname; `npm run prereq` ([sp-sync.md](references/sp-sync.md) §Ruční m365) |

## Reference

[onboarding.md](references/onboarding.md) průvodce: nový projekt nebo migrace až po cockpit ·
[cockpit.md](references/cockpit.md) zadání, připomínky, úkoly, rozhodování ·
[app-design.md](references/app-design.md) data, stránka, oprávnění ·
[manifest.md](references/manifest.md) manifest, `project_config.json`, práva, výchozí sada, prereq, verze kitu ·
[kod.md](references/kod.md) kód appky, mocky, harness, SPFx, UI, testy, build ·
[sp-sync.md](references/sp-sync.md) nasazení, plán, sonda, připomínky, ruční m365 ·
[windows.md](references/windows.md) Windows.
Vnitřek nástrojů pro správce kitu (propagace balíčku, otisk, záznam o nasazení, verze cockpitu, selektory sondy)
je v repu kitu v `docs/vnitrek-nastroju.md`; agent ho k práci nepotřebuje.
