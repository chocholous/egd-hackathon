# Průvodce: nový projekt nebo migrace, až po cockpit

Cíl: projekt, ve kterém už všechno další běží přes cockpit ([cockpit.md](cockpit.md)). Dvě cesty:
**A) nový projekt** ze šablony, **B) migrace** projektu, který už existuje (starší šablona kitu nebo
vlastní úpravy nástrojů). Liší se jen částí 2; stroj, tenant, cockpit a nasazení jsou společné.

Kroky mají stálé identifikátory (`s-node`, `p-git`, …). Stejné používá stránka průvodce
(`templates/onboarding.html`) a skript `scripts/doctor.mjs`, takže stav jde číst i zapisovat strojově.
Windows: [windows.md](windows.md).

## Jak průvodce používat

V prázdné složce (projekt ještě není) začni příkazem `/ppf-citizen-ai-devkit`: je to jediný zaručený vstup do kitu.

1. **Doctor** (jen čte, nic nemění; síť jen přes `npm run prereq` projektu):
   ```bash
   node "${CLAUDE_SKILL_DIR}/scripts/doctor.mjs" --project <složka projektu> [--env dev] [--pred-nasazenim] [--write]
   ```
   Vypíše ke každému kroku `OK | CHYBA | POZOR | ?` a větu, co našel. Exit 0 = žádná `CHYBA`, 1 = aspoň
   jedna, 2 = špatné použití. Podmínky nasazení zjistitelné bez webu (git, cockpit, balíček, vzhled) čte ze stejného
   kódu jako plán nasazení: co pustí doctor, pustí i nasazení. Bez volby se ptá „jde lokálně vyvíjet?“ (`CHYBA` jen
   Node, git, projekt a jeho nástroje, závislosti, prefix a manifest; co je potřeba až k nasazení, hlásí jako
   `POZOR`); s `--pred-nasazenim` jsou i tyto kroky `CHYBA`. `--write` uloží výsledek do `.devkit/onboarding.json`
   (jen když je `.devkit/` v `.gitignore`). Běží z kitu, ne z projektu: migrovaný projekt nové nástroje ještě nemá.
2. **Stránka průvodce** (volitelná, doporučená): založení v §Artefakt průvodce. Agent do ní zapíše
   výsledek doctoru, člověk odklikává kroky, které stroj nepozná.
3. Kroky jdou shora dolů (stránka slučuje části 2 a 3 do jedné části „Projekt“). `CHYBA` z běhu bez volby blokuje lokální vývoj, `CHYBA` z běhu s `--pred-nasazenim` blokuje první nasazení; `POZOR` si přečti a rozhodni.

Co doctor **neumí** a ověřuje se ručně: `s-claude`, `m-vzhled`, `p-worktree`, `t-sonda`, `l-gen`, `l-dev`,
`l-test`, `c-publikace`, `c-data`, `d-plan`, `d-confirm`, `d-kontrola`, `d-sonda`, `x-test`.

## 1. Stroj (jednou na počítač)

| Krok | Co má platit | Ověření → očekávaný výstup | Když neplatí |
|---|---|---|---|
| `s-node` | Node v rozsahu `engines` šablony | `node -v` → verze uvnitř rozsahu z `jq -r .engines.node package.json` (v projektu), jinak z `templates/project/package.json` | Nainstaluj Node LTS z rozsahu bez práv správce (nvm, fnm, `brew install node@<major>`). Po změně Node znovu `npm ci` a `npm --prefix spfx ci`. |
| `s-git` | git a identita autora | `git --version`; `git config user.name && git config user.email` → dva neprázdné řádky | `git config --global user.name "…"`, `git config --global user.email "…"`. Bez identity `devkit init` neudělá první commit. |
| `s-claude` | Claude Code přihlášený účtem claude.ai (nástroje `Artifact` a `ArtifactData` pro cockpit) | `claude auth status` → `"loggedIn": true`, `"authMethod": "claude.ai"` | `claude auth login` (člověk). Bez účtu claude.ai jde vyvíjet i nasazovat, jen bez cockpitu: schválení se píšou do chatu. |
| `s-kit` | Plugin `ppf-citizen-ai-devkit` nainstalovaný | `claude plugin list --json \| jq -r '.[] \| select(.id \| startswith("ppf-citizen-ai-devkit")) \| "\(.id) \(.version)"'` → jeden řádek | Nainstaluj z marketplace ppf-skills: `claude plugin install ppf-citizen-ai-devkit@ppf-skills` (tři závislosti se nainstalují s ním). `POZOR` = kit běží ze složky a plugin chybí (hook na holé `m365` pak v projektu neplatí), nebo se verze spuštěného kitu a pluginu liší (projekt zakládáš jinou verzí, než jakou má Claude načtenou jako skill). „NEVYDANÝ kit“ = pracovní kopie kitu bez tagu verze nebo s necommitnutými změnami ([manifest.md](manifest.md) §Verze kitu). Plugin pod starým jménem `ppf-spfx-devkit` (do 0.4.2) přeinstaluj pod novým jménem. |
| `s-material` | Skill `ppf-material` (zdroj vzhledu; `devkit init` a `theme` bez něj skončí chybou) | `claude plugin list --json \| jq -r '.[] \| select(.id \| startswith("ppf-material")) \| "\(.id) \(.version) \(.installPath)"'` → řádek; v `<installPath>/skills/ppf-material/tokens/tokens.json` existuje soubor | Nainstaluj plugin `ppf-material` z marketplace `ppf-skills`. Jinou složku skillu jde předat `--material <složka>`. |
| `s-auth` | Sdílená session prohlížeče pro sondu | `ls ~/.config/spo-auth/` → `state-<tenant>.json` | Není chyba: soubor vznikne krokem `t-sonda`. Adresář je společný pro všechny projekty a session na stroji (kanon pluginu `ppf-browsermagic`); zapisuje do něj jen skill `ppf-browsermagic`, kit a sonda jen čtou. |

Nic se neinstaluje globálně. **m365 CLI 12, Playwright, yo a generátor SPFx jsou závislosti projektu**
s pinem v `package.json` (krok `p-prereq`); plugin `m365-cli-12` z marketplace `ppf-skills` (závislost kitu, instaluje se s ním) je nápověda k příkazům CLI,
CLI samotné neobsahuje ([sp-sync.md](sp-sync.md) §Ruční m365).

## 2A. Nový projekt

| Krok | Co má platit | Ověření → očekávaný výstup | Když neplatí |
|---|---|---|---|
| `p-projekt` | Projekt založený ze šablony | `node "${CLAUDE_SKILL_DIR}/scripts/devkit.mjs" init <složka> --name "<Název>" --prefix <PREFIX> --install`, pak `git -C <složka> log --oneline` → jeden commit „Nový projekt …“ a `test -f <složka>/project_config.json` | `init` nepřepisuje: cílová složka musí být prázdná. `--prazdny` založí projekt bez ukázkové domény (prázdná appka v AppShell); zvol ho, když ukázku nechceš mazat. „nenalezen skill ppf-material“ → `s-material`. „první commit se nepovedl“ → `s-git`, pak commit ručně. Prefix: 2 až 16 znaků, písmena a číslice. |
| `p-kit` | V `project_config.json` je, ze které verze kitu projekt vznikl | `jq '.kit \| {verze, commit, varianta}' project_config.json` → verze a commit kitu (`varianta: "prazdny"` u projektu z `--prazdny`) | Zapisuje ho `devkit init`. `null` = projekt je starší než kit 0.4 → cesta Migrace. `npm run prereq` hlásí rozdíl proti nainstalovanému pluginu jako WARN `kit.verze`. |

**`init --install` spadl na `npm ci`** (časté: plný disk, závislosti jednoho projektu zaberou přes 1,5 GB, změřeno 2026-11-15;
síť): projekt je založený, ale bez úplných závislostí a **bez prvního commitu**. `init` znovu
nepouštěj, do neprázdné složky nezapisuje. Odstraň příčinu a navaž ve složce projektu: `npm ci && npm --prefix spfx ci`,
pak `git add . && git commit -m "Nový projekt <Název> ze šablony ppf-citizen-ai-devkit"`. Stejné kroky vypíše hláška.

Pokračuj částí 3.

## 2B. Migrace stávajícího projektu

Vzory: **PPF Tracker** (šablona 0.3 s vlastními úpravami nástrojů) a **Gate Insider** (šablona z
commitu `26b50d7`, tedy před 0.3; chybí mu `design-check`, vzhled má v `spfx/src/app/theme/`).
Migrace je ruční převzetí po souborech; automatické slučování kit nemá.

| Krok | Co má platit | Ověření → očekávaný výstup | Když neplatí |
|---|---|---|---|
| `p-projekt` | Repo má `project_config.json` | `test -f project_config.json && jq -r '.app.name, .app.prefix' project_config.json` → název a prefix | Repo jen s `.env` je projekt v0.1: založ vedle nový projekt (`devkit init`, **stejný prefix**, aby seděly názvy SP objektů) a přenes `spfx/src/app`, `sp/` a GUID z `spfx/config/package-solution.json` a manifestu web partu. Jiná GUID = v katalogu vznikne druhá appka. |
| `p-kit` | Známá výchozí verze šablony | `jq .kit project_config.json`; když `null`: `git log --diff-filter=A --format='%h %ad %s' --date=short -- project_config.json` → commit založení, podle data dohledej commit kitu | Zapiš `kit {verze, commit}` ručně (verzi a commit kitu, ze kterého šablona pochází). Bez klíče je projekt pro `devkit diff` i doctor „neznámá verze“: nic neblokuje, ale nejde říct, co je úprava projektu a co starší šablona. |
| `p-nastroje` | Nástroje, datová vrstva, harness a vzhled odpovídají šabloně kitu | `node "${CLAUDE_SKILL_DIR}/scripts/devkit.mjs" diff .; echo "rc=$?"` → řádky `zmeneno\|chybi\|navic<TAB>cesta`, `rc=0` bez rozdílů, `rc=10` s rozdíly (jen čte) | Převzetí nové verze kitu dělá `node "${CLAUDE_SKILL_DIR}/scripts/devkit.mjs" update .` (plán; se `--zapsat` nad čistým git stromem zapíše): co projekt neměnil, převezme, vlastní úpravy nechá a konflikty vypíše k ručnímu sloučení ([manifest.md](manifest.md) §Aktualizace projektu). `zmeneno`, které po něm zbude, **nepřepisuj naslepo**: je to vědomá odchylka (`m-vyjimky`), nebo konflikt ke sloučení. `navic` jsou vlastní soubory projektu, nechávají se. Po převzetí `npm ci`, `npm run check-all`. |
| `m-vzhled` | Theme, fonty a stavební bloky jsou generované z nainstalovaného ppf-material | `node "${CLAUDE_SKILL_DIR}/scripts/devkit.mjs" theme spfx/src/app/ppf --material <složka skillu ppf-material> --check` → exit 0 a řádky `OK: … odpovídá …` | Bez `--check` soubory vygeneruje. Projekt s vlastní složkou vzhledu (Gate Insider: `theme/`) přesune importy na `spfx/src/app/ppf`. Kontrola porovnává hodnoty, ne hlavičku, takže povýšení ppf-material beze změny hodnot drift nehlásí. |
| `m-vyjimky` | Každá vědomá odchylka od kitu je zapsaná a schválená člověkem | `cat DEVKIT-VYJIMKY.md` → u každé výjimky pravidlo, rozsah, důvod, kdo schválil, kdy se zruší, nahlášeno do kitu; počet řádků odpovídá řádkům `zmeneno` z `devkit diff` | Soubor je v šabloně (`templates/project/DEVKIT-VYJIMKY.md`); starší projekt si ho zkopíruje. Sepiš výjimky z `devkit diff`. Schvaluje člověk, ne agent; doctor proto tento krok nikdy neoznačí jako splněný sám. |

## 3. Projekt: závislosti, konfigurace, manifest, git

| Krok | Co má platit | Ověření → očekávaný výstup | Když neplatí |
|---|---|---|---|
| `p-zavislosti` | Závislosti kořene i `spfx/` | `test -d node_modules && test -d spfx/node_modules && echo ok` → `ok` | `npm ci && npm --prefix spfx ci`. `EBADPLATFORM` u `npm ci` → `npm run lockfix`. `EBADENGINE` → Node je mimo rozsah `engines` (`s-node`). |
| `p-prereq` | Ladicí server a prohlížeč pro sondu | `npm run prereq` → všechny řádky oblasti `nástroje` jsou `OK` (ladicí server, prohlížeč pro sondu). Verze nástrojů prereq nekontroluje: dává je `npm ci` z lockfile (`p-zavislosti`); `npm run -s m365 -- version` → verze shodná s pinem v `package.json` | Jiná verze než pin → `npm ci`. `prohlížeč pro sondu` WARN → `npx playwright install chromium`. |
| `p-config` | `project_config.json` vyplněný | `jq '{app, m365: (.m365 \| {tenantId, appId}), dev: .environments.dev.site, test: .environments.test.site, remote: .git.remote}' project_config.json` → neprázdné `app.name`, `app.prefix`, `tenantId`, `appId`, `dev` | **Prerekvizita:** každý nováček dostane předem sadu tří webů SharePointu, DEV, TEST a PROD. Adresy DEV a TEST řekne člověk a agent je zapíše do `environments.dev.site` a `environments.test.site`; adresa PROD do souboru nepatří, na produkci kit nezapisuje. DEV web musí mít katalog aplikací (site collection app catalog) a přidat ho smí jen správce SharePointu (`t-katalog`). `test` může zůstat prázdný (prostředí se přeskočí). Hodnoty `m365` jsou pro PPF tenant předvyplněné; jiný tenant = od jeho správce. Tajné hodnoty do souboru nepatří. |
| `p-manifest` | Platný manifest appky | `npm run gen` → exit 0 a řádek „spfx/src/app/generated: změněno …“ nebo „… beze změny“; `jq '.roles \| keys' sp/app.manifest.json` → role | `gen` vypíše, co v manifestu nesedí. Návrh dat, stránek a práv: [app-design.md](app-design.md); u nového projektu se manifest schvaluje po částech v cockpitu (část 5), šablona má ukázkovou doménu. |
| `l-mock` | Lokální uživatelé pro přepínání rolí v mocku | `jq '.environments.local.users' project_config.json` → aspoň jeden uživatel na každou roli z manifestu | Doplň `environments.local.users` (`jméno → [role]`). |
| `p-git` | Repo má `origin`, `git.remote` míří na totéž repo, strom je čistý a větev pushnutá | `git remote get-url origin` a `jq -r .git.remote project_config.json` míří na totéž repo (jiný zápis téže adresy nevadí); `git status --porcelain` → prázdné; `git rev-list --count @{u}..HEAD` → `0` | Repo zakládá člověk (PPF: interní GitHub Enterprise; člen organizace tam smí založit jen repo s viditelností `internal`, `private` skončí chybou oprávnění — změřeno 2026-11-14). `git remote add origin <url>`, `git push -u origin <větev>`, URL do `git.remote`. „no upstream configured“ = větev nemá protějšek. **Nasazení z necommitnutého nebo nepushnutého stavu kit odmítne** (DEV i TEST, bez obejití); projekt bez vzdáleného repozitáře nenasadí vůbec. |
| `p-worktree` | Souběžná práce jen ve vlastním worktree; přihlášení m365 je společné pro worktree téhož repa | `git worktree list` → hlavní checkout a worktrees; v každém `npm run prereq` → `m365 přihlášení OK` | Worktree zakládej nástrojem, který tým používá; pravidla v [kod.md](kod.md) §Souběžná práce. Jen když nástroj nekopíruje `node_modules` (`.worktreeinclude`): `npm ci`, `npm --prefix spfx ci`. `t-login` znovu jen když ještě nikdo přihlášený není. `.m365-home/` a `.devkit/` se necommitují. |

## 4. Tenant a SharePoint

Vše ověřuje `npm run prereq` (jen čte). Přihlášení a MFA dělá člověk; agent vypíše příkaz a počká.

| Krok | Co má platit | Ověření → očekávaný výstup | Když neplatí |
|---|---|---|---|
| `t-login` | m365 CLI projektu přihlášené do tenantu z configu | `npm run prereq` → `OK m365 přihlášení <účet>` a `OK m365 tenant <tenantId>` | `npm run m365 -- login --authType browser --appId <m365.appId> --tenant <m365.tenantId>` (přesný příkaz vypíše prereq). `tenant … ≠ config` = přihlášeno jinam: `npm run m365 -- logout` a znovu. Holé `m365` nepoužívej. |
| `t-web` | Web prostředí existuje a je dostupný | `npm run prereq -- --env dev` → `OK dev web <titul> — <url>` | 404 nebo 401 → špatná URL v `environments.dev.site`, nebo účet na web nesmí. Web zakládá správce; kit weby nezakládá. |
| `t-vlastnik` | Účet je správce kolekce webů nebo člen Owners | prereq → `OK dev vlastník webu …` | `WARN` = člen jen přes Entra skupinu (nepozná se), nebo opravdu chybí právo. Požádej vlastníka webu o přidání do Owners. Bez toho selže zápis struktury a práv. |
| `t-katalog` | Web má site collection app catalog | prereq → `OK dev site app catalog Apps for SharePoint` | Katalog smí přidat jen správce SharePointu: `m365 spo site appcatalog add --siteUrl <web>` (běžnému účtu skončí 403, i na webu, který sám založil). Bez něj nejde nasadit: plán skončí `STAV: blokováno` s nálezem `katalog`. Na takovém webu plán vypíše i `nejdřív deploy` a `## balíček — beze změny`: neznamená to, že je balíček v pořádku, akce balíčku jsou vynechané, protože není kam nahrát; rozhoduje oddíl `BLOKUJE ZÁPIS`. Požádej správce, nebo vyber web, který katalog má; nehledej obchvat přes tenant katalog. |
| `t-role` | Každá role z manifestu (kromě `owner`) má v prostředí skupinu | `jq '.environments.dev.roles' project_config.json` → záznam pro každou roli; `npm run sp -- plan --env dev` → žádná chyba „role …“ před plánem | Tvary: `{"bindTo": "@members"}` (přidružená skupina webu), `{"members": {"emails": […]}}` (kit založí skupinu `<PREFIX> – <role>`), `{"group": "<název>"}` (existující skupina) — [manifest.md](manifest.md) §Práva. **Kdo je v které roli, řekne člověk**; agent kolegy do rolí sám nepřidává. Na TEST musí mít každý uživatel appky na webu aspoň Read. |
| `t-sonda` | Uložená session prohlížeče pro sondu | `SITE_URL=<adresa webu> node .ppf-session-magic/auth-refresh.mjs` (člověk, prohlížeč a MFA; poprvé SETUP ve skillu `ppf-browsermagic`), pak `ls ~/.config/spo-auth/state-*.json` | Sonda končící na přihlašovací stránce = prošlá session, stejný příkaz. Vydrží dny. |

## 5. Lokální běh a balíček

| Krok | Co má platit | Ověření → očekávaný výstup | Když neplatí |
|---|---|---|---|
| `l-gen` | Typy a mock data z manifestu | `npm run gen` → exit 0 | viz `p-manifest` |
| `l-dev` | Appka běží v harnessu nad mocky | `npm run dev -- --port <port>` → adresa `http://localhost:<port>`; `?user=<jméno>` přepne roli | [kod.md](kod.md). Appka čte jen přes `DataSource`; `fetch` na `_api` v kódu je chyba návrhu. |
| `l-test` | Testy nástrojů a appky, typy, lint | `npm run check-all; echo "rc=$?"` → `rc=0` (v testech řádek `fail 0`) | Selhání po převzetí nástrojů ze šablony = nedokončená migrace (`p-nastroje`). Starší projekt skript `check-all` nebo `typecheck` nemá → `p-nastroje`. |
| `l-design` | Kontrola vzhledu podle ppf-material: rychlá při vývoji, úplná před nasazením | průběžně `npm run design-check -- --rychle [--sekce <id>]`; před nasazením `npm run design-check` → bez chyb, `.devkit/design/report.json` má `uplna: true` a `source` = otisk dnešního kódu; screenshoty v `.devkit/design/` **projdi** | **TEST bez úplné kontroly dnešního kódu nasazení odmítne, DEV jen upozorní**. Kontrola platí, dokud se nezmění kód ve `spfx/` (commit ji nezneplatní). Rychlá nasazení neodemyká. Starší projekt skript nemá → `p-nastroje`. Pozor: `npm run design-check -- --help` a `npm run gen -- --help` nápovědu nemají a rovnou se spustí. |
| `l-build` | Balíček `.sppkg` | `npm run build; echo "rc=$?"` → `rc=0`; `ls spfx/sharepoint/solution/*.sppkg` | [kod.md](kod.md) §Build. |

## 6. Cockpit

Podrobně [cockpit.md](cockpit.md) §Založení; tady jen pořadí a ověření. Cockpit je artefakt na claude.ai
se sdílenou databází, zakládá se jednou na projekt a jeho vlastníkem je ten, kdo projekt vede.

| Krok | Co má platit | Ověření → očekávaný výstup | Když neplatí |
|---|---|---|---|
| `c-publikace` | Cockpit publikovaný z aktuální šablony s pravidly databáze | `Artifact` publish `.devkit/cockpit.html` (kopie `templates/cockpit.html`) s `capabilities` z [cockpit.md](cockpit.md); pak `ArtifactData list` kolekce `meta` s `as_level: "view"` čte, zápis s `as_level: "interact"` je odmítnut | Publikuj z vlastního prostoru, ne z kanálu nebo projektu. Sdílej nejvýš jako Viewer. Migrace: cockpit už existuje → nový nezakládej; porovnej `<meta name="cockpit-template">` publikované stránky se šablonou kitu a při nižším čísle republish na stejnou URL ([cockpit.md](cockpit.md) §Verze šablony). |
| `c-data` | Databáze cockpitu má projekt, obsah a prostředí | `npm run cockpit` → soubory `.devkit/cockpit/projekt.json`, `obsah.json`, `<env>.json`; `ArtifactData get meta/projekt` → `{schema, nazev, prefix, web: null, prace}`; `get meta/obsah` → role, data, stránky; `get prostredi/<env>` pro každé prostředí → `stav` (`nezalozeno` u prostředí bez webu), `nasazeni`, `pripominky` | Zápis: `set meta/projekt` (název a prefix nese export), `set meta/obsah`, `set prostredi/<env>` pro každý vypsaný soubor, vždy s `file_path` na export a u existujícího dokumentu s `if_version`. `schema` vyšší, než zná publikovaná stránka, ji přepne jen ke čtení → republish (`c-publikace`). Kolekce `zadani`, `otazky`, `ukoly` plní agent a stránka až prací; `rozhodnuti` zapisuje **jen stránka** (člověk). |
| `c-url` | Projekt o cockpitu ví | `jq -r .cockpit.url project_config.json` → URL; `npm run prereq` → `OK config cockpit.url …` | Zapiš URL do `project_config.json` → `cockpit.url` a commitni. Další session cockpit najde tam. |

Migrace navíc: co je dnes rozhodnuto jen v chatu nebo v dokumentech projektu (role, otevřené otázky,
rozpracované úkoly), zapiš do cockpitu jako `zadani/*` s `faze: hotovo` (už postavené) a `otazky/*`
(čeká na člověka). Rozhodnutí za člověka nevyplňuj.

## 7. První nasazení na DEV, sonda, TEST a předání

Zapisuje jen `npm run deploy`, jen na `dev` a `test`, vždy plán → schválení člověkem → `--confirm`.

| Krok | Co má platit | Ověření → očekávaný výstup | Když neplatí |
|---|---|---|---|
| `d-plan` | Plán nasazení je čitelný a bez blokací | commit a push, pak `npm run deploy -- --env dev` → seznam akcí, `hash`, řádek potvrzení a poslední řádek `STAV: akce`; žádný oddíl `BLOKUJE ZÁPIS`, žádná `odchylka`, `konflikt` | `STAV: blokováno` = plán začíná oddílem `BLOKUJE ZÁPIS` a potvrzení nenabízí; odstraň, co oddíl jmenuje (`git` → `p-git`, `cockpit` → `c-url`, `katalog` → `t-katalog`, `nástroje` → `p-prereq`), a spusť plán znovu. `block` zastaralý balíček → zvednout verzi a `npm run build`. `odchylka` → `npm run sp -- pull --env dev --write` a commit. `konflikt` → rozhodne člověk (v cockpitu `otazky/*`). Plán s akcemi nebo nálezy vrací kód 10 (nic se nezapsalo); neřetěz ho přes `&&`. |
| `d-confirm` | Člověk plán schválil a zápis proběhl | `npm run deploy -- --env dev --confirm <hash>` → výpis provedených akcí | Hash je otisk plánu: po jakékoli změně nový plán a nové schválení. Pád uprostřed → znovu plán (je idempotentní). |
| `d-kontrola` | Kontrolní plán po zápisu je prázdný | `npm run deploy -- --env dev; echo "rc=$?"` → `STAV: prázdný`, `rc=0`; zbyly-li jen nálezy `navíc`, je to `STAV: nálezy` a `rc=10` (po `--confirm` `rc=11`: zapsáno, něco zbylo) | `STAV: akce` → zopakuj plán a potvrzení. `STAV: chyba` → přečti výpis; „výsledek neznámý“ po vypršení limitu volání m365 znamená nový plán, ne opakování. Nálezy `navíc` kit nemaže; rozhodne člověk. Práva role bez druhého účtu: `npm run sp -- prava --env dev --user <upn>`. |
| `d-sonda` | Stránka appky se v prohlížeči vykreslí | `npm run probe -- --env dev` → `OK n/n`; otevři PNG i text v `.devkit/` | Stará verze hned po nasazení → počkej 15 až 30 s a zopakuj. Přihlašovací stránka → `t-sonda`. [sp-sync.md](sp-sync.md) §Sonda |
| `d-zaznam` | Záznam o nasazení je na webu | nasazení na konci vypíše `záznam o nasazení: na webu zapsán`; `doctor --pred-nasazenim` → `OK d-zaznam dev: <verze> z <commit> (… záznam na webu)`, verze = `solution.version` | Záznam (`_deploy/dev.json` a řádek historie v konfigurační knihovně appky) zapisuje nasazení samo; do gitu se nic necommituje. `ZÁZNAM O NASAZENÍ SELHAL` → oprav příčinu z hlášky a nasaď znovu. `dirty: true` = nasazeno z necommitnutého stromu (dnes to nasazení odmítne). Pak `npm run cockpit` a zapiš `prostredi/dev` do cockpitu. Projekt z doby před 0.6: první nasazení převezme historii z `releases/dev.jsonl` na web. |
| `x-test` | TEST: totéž s `--env test` | části 4 a 7 pro `test`: `npm run prereq -- --env test`, plán, `--confirm`, kontrolní plán, sonda; `doctor --env test --pred-nasazenim` → `OK d-zaznam test: …` | Potřebuje `environments.test.site` a role na TEST (Entra skupiny). Volitelné při zakládání; povinné před předáním. |
| `x-tag` | Commit nasazený na TEST nese tag `v<verze>` a tag je v remote | `git rev-list -n 1 v<verze>` = `commit` ze záznamu o nasazení na webu TEST (vypíše ho `d-zaznam` s `--env test`; `dirty: false`); `git ls-remote --tags origin v<verze>` → řádek | `git tag v<solution.version> <commit>` a `git push origin v<verze>` dělá **člověk**. PROD je mimo kit: přebírá ho Citizen AI review & deployment kit podle tagu (SKILL.md §Produkce). |

**Hotovo** = `doctor --pred-nasazenim` bez `CHYBA`, `c-url` vyplněné, `d-zaznam OK`. Od té chvíle se pracuje z cockpitu:
zadání a rozhodnutí tam, agent čte cockpit na začátku každé práce ([cockpit.md](cockpit.md)).

## Artefakt průvodce

Samostatná šablona `templates/onboarding.html`, ne součást cockpitu. Důvody: cockpit při zakládání ještě
neexistuje (jeho publikace je krok průvodce), průvodce je potřeba jednou a cockpit denně, a datový model
cockpitu má jiného zapisovatele (`rozhodnuti` jen stránka). Stránka průvodce na konci na cockpit odkáže.

Založení (jednou na projekt, agent):

1. Zkopíruj `${CLAUDE_SKILL_DIR}/templates/onboarding.html` do `.devkit/onboarding.html` (gitignored).
2. Publikuj nástrojem `Artifact` (`icon: "checklist"`) s capabilities:
   ```json
   { "db": { "rules": [
       { "path": "", "read": "view", "write": "owner" },
       { "path": "meta", "read": "view", "write": "owner" },
       { "path": "kroky", "read": "view", "write": "owner" } ] },
     "user": {} }
   ```
3. `ArtifactData set` `meta/pruvodce` = `{ "cesta": "novy" | "migrace", "projekt": "<app.name>", "cockpit": "<URL nebo null>" }`.
4. `node "${CLAUDE_SKILL_DIR}/scripts/doctor.mjs" --project . --write`, pak `ArtifactData set` `meta/doctor`
   s `file_path: .devkit/onboarding.json` (existující dokument s `if_version`). Opakuj po každém kroku.

Datový model:

| Dokument | Zapisuje | Obsah |
|---|---|---|
| `meta/pruvodce` | stránka (`cesta`) a agent | `{cesta: novy\|migrace, projekt, cockpit}`; `cockpit` zapni, jakmile je `c-url` splněný — stránka pak ukáže přechod do cockpitu |
| `meta/doctor` | agent | výstup doctoru: `{kdy, prostredi, projekt{nazev, prefix, cesta, cockpit}, kit{verze}, kroky{<id>: {stav: ok\|chyba\|pozor\|neznamo, detail}}}` |
| `kroky/<id>` | stránka (člověk) nebo agent | ruční stav kroku: `{stav: splneno\|nesplneno\|null, poznamka, kdo: clovek\|agent, kdy}`; `null` = platí výsledek doctoru |

Stav kroku na stránce: ruční `kroky/<id>`, když existuje; jinak doctor (`ok` → splněno, `chyba` →
nesplněno, `pozor` a `neznamo` → ke kontrole). Když ruční stav říká splněno a novější doctor hlásí
chybu, stránka ukáže obojí. Agent čte `kroky` a `meta` (`ArtifactData list`) na začátku práce a naváže
na první nesplněný krok; za člověka neodklikává kroky, které má udělat člověk (`t-login`, `t-sonda`,
`d-confirm`, `x-tag`).
