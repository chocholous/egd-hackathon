# Návrh appky: kde jsou data, jak vypadá stránka, jak fungují oprávnění

sources: ppf-material 1.1.0 (z této verze vycházejí principy a vzorové obrazovky, na které se odkazuje; platnost odkazů hlídá dev/ppf-material-links.test.mjs)

Čti před prvním návrhem `sp/app.manifest.json` a vždy, když appka rozlišuje uživatele (kdo co vidí a smí).
Mechanika manifestu je v [manifest.md](manifest.md) (§Listy a sloupce, §Práva), tady je, jak ji použít.
Celý příklad (changelog: IT zadává, security schvaluje, admin spravuje číselník) je na konci a ověřený.

## 1. Kde má appka jaká data

| Data | Kam | Kdo je mění | Proč |
|---|---|---|---|
| Nastavení, které mění vývojář (texty, kategorie, pravidla) | list `class: config` + `sp/data/config/<List>.json` | vývojář v gitu, `npm run deploy` | git je zdroj pravdy; na webu jen čtení |
| Číselník nebo texty, které spravuje byznys, ale appka bez výchozí sady nefunguje (druhy, týmy, lokality, nápověda) | list `class: initial`, klíčový sloupec `Kod` (`required`, `unique`) + `sp/data/initial/<List>.json` | vývojář dodá výchozí sadu, potom role s `edit` v appce | první nasazení vloží výchozí řádky; existující řádek deploy nikdy neupraví ani nesmaže |
| Číselník, který byznys plní celý sám a appka funguje i s prázdným | list `class: operational`, klíčový sloupec `Kod` (`unique`) | role s `edit` v appce | deploy na obsah provozních listů nesahá |
| Záznamy uživatelů (požadavky, hlášení) | list `class: operational` | role podle `access` a `itemScope` | |
| Rozhodnutí, schválení, audit | **samostatný** list `class: operational`, úroveň `add` | jen ten, kdo rozhoduje | nikdo ho neupraví ani nesmaže; viz §3 |
| Soubory k záznamu | **přílohy položky** listu (`"attachments": true`, `addAttachment` / `listAttachments`) | podle `access` listu | knihovnu dokumentů `DataSource` neumí (nahrát ani vypsat); knihovna `Prilohy` v ukázce se v appce nepoužívá, jen ukazuje zápis knihovny v manifestu |
| Logo, obrázky, texty appky | knihovna `Assets` (`class: config`, `source: sp/assets/config`) | vývojář v gitu | |
| Připomínky testerů | list `<PREFIX>-Pripominky` | zakládá kit sám (`"feedback": true`) | do manifestu ho nepiš |

Pravidla:
- **Odkaz mezi listy je textový klíč** (`Druh: "FW"` → `Druhy.Kod`), ne SP Lookup: ID položek se mezi DEV a TEST liší.
  Manifest typ `lookup` umí ([manifest.md](manifest.md) §Listy a sloupce); použij ho jen s důvodem a zapiš proč.
- **Údaj, o kterém rozhoduje někdo jiný než autor záznamu, nepatří do autorova záznamu.** Kdo smí upravit
  položku, smí přes REST přepsat každé její pole, i když ho UI nezobrazuje. Stav „Schváleno“ uložený
  v požadavku si autor schválí sám. Patří do listu, kam smí psát jen schvalovatel.
- **Třídu listu urči dvěma otázkami: funguje appka po čistém nasazení bez těch dat, a kdo je potom mění?**
  - Kód, stránky nebo workflow se odkazují na konkrétní klíče (stavy, typy, pravidla) → `config`. Mění je
    jen vývojář v gitu.
  - Byznys řádky volně přidává a ubírá, ale appka bez výchozí sady nefunguje → `initial`. Vývojář dodá
    výchozí sadu, potom list patří byznysu.
  - Data vznikají používáním appky (žádosti, rozhodnutí, přílohy) → `operational`.
  - Popisky, název a logo jsou `config`. Redakční texty, které po spuštění přepisuje byznys (nápověda,
    oznámení), jsou `initial`.
- **Volby sloupce typu Choice jsou struktura:** nese je manifest a mění je jen vývojář. Když má hodnoty
  přidávat byznys, patří do samostatného listu, ne do Choice sloupce. Když se na hodnoty odkazuje kód
  (stavy), patří do Choice sloupce nebo do konfiguračního listu.
- **`initial` = výchozí sada, kterou deploy vloží jednou.** `sp/data/initial/<List>.json` jde do mocku i na
  web. Deploy vloží jen klíče, které na webu nejsou a které ještě nikdy nevložil. Řádek, který na webu je,
  neupraví ani nesmaže; řádek, který byznys smazal, nevrátí. **Změna existujícího řádku v gitu se proto na
  web nepropíše: řekni člověku, že se mění v appce.** Mechanika: [manifest.md](manifest.md) §Výchozí sada.
- **Seed je jen pro lokální mock** a stroj neopustí. Na DEV/TEST deploy obsah provozních listů nezakládá:
  list `operational` je po prvním nasazení prázdný. Když appka bez jeho řádků nemá z čeho nabídnout výběr,
  je to `initial`, ne `operational`.
- Každý nový provozní list v manifestu = nový soubor `sp/data/seed/<List>.json` (ukázková data pro mock, `_author` =
  jméno lokálního uživatele); do mocku ho po `npm run gen` dostane `generated/mockData.ts`, harness se needituje.
  List `config` a `initial` bere mock ze svého souboru v `sp/data/config` a `sp/data/initial`.

### Co se liší mezi prostředími

Co se mezi prostředími liší (štítek prostředí, logo, adresa nápovědy), je **vlastnost web partu** s hodnotou
`@env:<jméno>` ([manifest.md](manifest.md) §Stránky a web party). Hodnoty pro `local`, `dev` a `test` jsou
v `project_config.json` → `environments.<env>.values`. Soubory (například `logo.svg` i `logo-test.svg`) jsou
v `sp/assets/config` a nasadí se všude; vlastnost jen říká, který se použije.

```json
"properties": { "prostredi": "@env:prostredi", "logo": "@env:logo" }

"dev":  { "values": { "prostredi": "DEV",  "logo": "logo-test.svg" } }
"test": { "values": { "prostredi": "TEST", "logo": "logo-test.svg" } }
```

**Appka musí fungovat i bez té vlastnosti.** Chybějící nebo prázdná hodnota znamená produkční chování: žádný
pruh prostředí, výchozí logo. Produkci nasazuje jiný kit a žádná hodnota pro ni nesmí být povinná. Stejně se
chová vrstva připomínek: kde vlastnost `pripominky` chybí, vůbec se nenačte.

Hodnoty v řádcích konfiguračních listů (`sp/data/config`) podle prostředí kit neumí: `@env:` se dosazuje jen
ve vlastnostech web partů. Když se má lišit hodnota v nastavení, udělej z ní vlastnost web partu.

## 2. Jak vypadá stránka

- Appka = **jedna stránka** `<PREFIX>-App.aspx` s jedním web partem `AppWebPart` (manifest → `pages`).
  Kit ji publikuje jako **aplikační stránku** (`SingleWebPartAppPage`, bez komentářů; manifest `layout` /
  `comments` to přebije) a odkazy na ni dává s `?env=WebView`, který schová rámec SharePointu. Změřeno 2026-11-13
  na DEV web (stránka Trackeru, okno 1440×900, jen čtení): bez parametru je vidět lišta Microsoft 365 (48 px),
  hlavička webu (40 px), příkazová lišta stránky (49 px) a levý app bar; web part začíná na 190 px shora, 81 px
  zleva a je široký 1346 px. S `?env=WebView` žádný z těch prvků vidět není a web part zabírá celé okno (0, 0, 1440 px). Víc stránek jen tehdy, když je opravdu otevírají
  různí lidé z různých míst. Navigace uvnitř appky = záložky, ne další stránky.
- Web part je tenký host (`spfx/src/webparts/app`): předá `DataSource` a vlastnosti, logika je v `spfx/src/app`.
- Co uživatel nesmí, **nevidí jako tlačítko**, ale vidí věcné vysvětlení (`Notice`: „Požadavky zadává IT.“).
  Neschovávej data, která smí číst: skrývání v UI není zabezpečení (§3).
- Klíčové prvky mají `data-cadk-id`, opakované řádky `data-cadk-key` (Id položky) — kotvy připomínek
  (`DataTable` dává `data-cadk-key` sám).

### Rozvržení obrazovky (ppf-material — závazné)

Vzhled je PPF × Material (skill `ppf-material`, [kod.md](kod.md) §UI). Barvy a písmo vynutí theme;
**rozvržení vynutí jen tyhle stavební bloky** z `spfx/src/app/ppf/blocks.tsx` (generuje `devkit theme`,
v projektu se neupravují). Nevymýšlej rozvržení — začni od nejbližší vzorové obrazovky ppf-material
(`examples/`): fronta (`App - Schvalovaci fronta`), vyhledávání (`Company search`), strom (`Orgchart`), editor (`Content editor`).

| Potřeba | Blok | Pravidlo ppf-material |
|---|---|---|
| kostra appky | `AppShell` (lišta 64 px, záložky s počty, filtry, sloupce rail · obsah · detail) | 08 lišta + záložky + tři sloupce |
| seznam | `DataTable` — klik na řádek otevře detail; vedlejší sloupce `secondary: true` se při otevřeném panelu schovají | 09 žádné akce ani pole v řádku |
| detail, úprava, nový záznam | `DetailPanel` + `Section` + `Fields`, akce v liště dole | 08 detail vedle seznamu, nikdy v okně |
| potvrzení, zrušení, smazání | `ConfirmDialog` (s `comment.required` u nevratných akcí). **Vykresli ho uvnitř `AppShell`**: theme nese jen `AppShell`, okno vedle něj je bez PPF vzhledu a kontrola vzhledu to nezachytí (okna neotevírá) | 08 okno jen pro potvrzení |
| stav | `StatusBadge` (tečka + slovo, tón `positive/negative/caution/neutral/accent`) | 10 |
| sdělení, chyba, „nesmíte“ | `Notice` (ne barevný `Alert`) | 10, 07 |
| filtry | `FilterGroup` + `FilterChip` v railu, `SearchField`; pár čipů může být v liště záložek (`toolbar`) | žádná druhá řada záložek |
| hromadné akce | výběr v `DataTable` (`checked`/`onCheck`) + `BulkBar` | 09 jedna tmavá lišta |
| tlačítka | `Primary` (jedno plné na pohled), `Secondary`, `Quiet`; v liště appky `BarButton` | 01 |
| formulář a jeho pole | **blok není**: komponenty MUI přímo (§Formulář níže) | `references/components.md` §Text fields |
| čísla, data, ID | sloupec `mono`, `Mono`, `Fields` s `mono` | 06 |
| prázdno | `EmptyState` (věcně, prázdná fronta je hotová práce) | 07 |

Další pravidla, která bloky samy nevynutí:

- **Jedno plné tlačítko na pohled.** Když se otevře panel s vlastní akcí, plné tlačítko seznamu zmizí.
- **Úpravy v panelu:** detail se čte; „Upravit“ přepne panel do formuláře, „Uložit“ / „Zrušit“ v liště panelu.
  Nový záznam = panel ve stavu „nový“. Okno (`ConfirmDialog`) jen potvrzuje: zrušení, zamítnutí, smazání, převzetí.
- **Tlačítko „Připomínky“ má místo v liště appky** (DEV a TEST): `AppShell` ho drží vpravo před uživatelem a vrstva
  připomínek ho tam vloží sama. Do lišty proto nedávej víc akcí, než se vejde vedle něj; appka bez `AppShell` to místo
  nemá a tlačítko pak plave vpravo nahoře přes obsah.
- **Číselníky jen ke čtení v tabulce;** úprava položky číselníku v panelu, ne pole v každé buňce.
- **Věcný jazyk, žádné vysvětlující odstavce.** Jedna věta pod nadpisem je strop; pravidla patří do nápovědy.
- **Data a časy:** sloupec `date` dostane appka z `DataSource` vždy jako `'YYYY-MM-DD'` (místní kalendářní den;
  SpSource převádí z UTC a zpět, `data/dates.ts`), `datetime` a `Created` jako ISO s `Z`. Zobrazení jen přes
  `formatDate` / `formatDateTime` z `data/dates.ts` a `mono`; nikdy `slice(0, 10)` z ISO řetězce (SharePoint
  vrací UTC, půlnoc v Praze je předchozí den 23:00Z — termíny by byly o den dřív a uložení by je posunulo).

### Formulář (bez vlastního bloku)

Stavební bloky formulářová pole ani rozvržení formuláře nemají a mít nemusí: formulář se skládá **přímo z komponent
MUI** (`TextField`, `Select` / `Autocomplete`, `Switch`, `Checkbox`, `RadioGroup`) uvnitř bloku, kam patří
(`DetailPanel` ve stavu „upravit“ nebo „nový“, `ConfirmDialog` s komentářem). Sáhnout na MUI tady není odchylka
a do `DEVKIT-VYJIMKY.md` nepatří. Vzhled polí dává vygenerované theme, ne kód appky:

- **Pole:** obrysová varianta (`variant="outlined"`, výchozí v theme), popisek plovoucí v obrysu, jak ho dává MUI
  s theme kitu (nepřepisuj ho na popisek nad polem), pomocný text pod ním,
  chyba jen barvou obrysu a pomocného textu (ppf-material `references/components.md` §Text fields). Výšku, zaoblení
  a barvy neurčuj `sx` ani SCSS; čísla, data a ID v poli neproporcionálním písmem (`FONT.mono` z theme).
- **Datum:** `TextField type="date"` s `slotProps={{ inputLabel: { shrink: true }, htmlInput: { style: { fontFamily: FONT.mono } } }}`
  (bez `shrink` popisek překryje masku data); hodnota pole je `RRRR-MM-DD`, do `DataSource` ji převádí pravidlo
  o místní půlnoci výše. Vlastní kalendář nepiš a další knihovnu kvůli datu nepřidávej.
- **Rozvržení:** pole pod sebou v `Stack` z MUI s `spacing` (jednotka theme), širší formulář ve dvou sloupcích přes
  `Stack direction="row"` nebo `Grid`. Rozestupy ber ze vzorové obrazovky ppf-material `App - Content editor`:
  panel s poli má mezeru 20 px mezi poli a 20 px odsazení, tedy `spacing={2.5}` a `p: 2.5` (jednotka theme je 8 px);
  popisek skupiny a její pole dělí 6 až 8 px (`spacing={1}`). Ne od oka a ne v px ve vlastním SCSS.
- **Akce:** „Uložit“ (`Primary`) a „Zrušit“ (`Quiet`) v liště panelu, ne pod posledním polem. Povinná pole a chyby
  ukaž u pole (`required`, `error`, `helperText`), souhrnnou chybu uložení v `Notice`.
- **Kotvy:** formulář a jeho části označ `data-cadk-id` jako každou jinou část UI.
- **Mazání položky `DataSource` nemá.** Záznam, který má „zmizet“, se uzavírá stavem (sloupec `choice`), ne smazáním.
- **Formulář kontrola vzhledu nezměří** (§Co kontrola projde): po úpravě ho otevři v `npm run dev` a posuď ručně proti
  ppf-material, tedy zaoblení, barvy a písmo polí, rozestupy a stav chyby.
- **Rozměry v ukázce:** `App.tsx` šablony má v `style` několik čísel v pixelech (`gap: 16`, `fontSize: 12`). Není to
  vzor: v novém kódu ber rozestupy z theme (`Stack spacing`, `sx` s jednotkou theme) a písmo z `Typography`.
- Úzké okno (< 960 px šířky kostry): rail se skryje, panel detailu nahradí seznam — to dělá `AppShell`.

### Co kontrola projde

Kontrola vzhledu má dva režimy:

- **rychlá** `npm run design-check -- --rychle [--sekce <id>] [--user <jméno>]` v průběhu vývoje, po každé změně
  obrazovky — jedna sekce (výchozí ta, na které appka otevře), jeden uživatel (výchozí první), otevřená záložka
  a detail prvního řádku. Pouštěj ji proti běžícímu `npm run dev` (`--url <adresa harnessu>`), většinu času jinak
  zabere start harnessu a prohlížeče. Ukládá `.devkit/design/rychla.json`, report úplné nepřepisuje a nasazení
  neodemyká;
- **úplná** `npm run design-check` před nasazením do dalšího prostředí — všichni lokální uživatelé × sekce ×
  záložky × detail prvního řádku. Zapíše `.devkit/design/report.json` s otiskem kódu (`source`) a `uplna: true`,
  když nebyla zúžená `--user`. Platí, dokud se nezmění soubor ve `spfx/` (commit, `gen`, `dev` ani `typecheck` ji
  nezneplatní). Bez `ppfDesign.json` skončí s návodem (exit 2).

**Co kontrola neprojde.** Obě jdou pevnou cestou: sekce, záložky a detail prvního řádku. Nic dalšího neotevřou.
Formulář (nový i upravit), potvrzovací okno, krok průvodce, nabídka a jakákoli obrazovka za tlačítkem se **nezměří**
a report je nezná; výpis kontroly to na konci připomene. „Úplná“ tedy znamená všichni uživatelé a všechny pohledy
pevné cesty, ne všechny obrazovky appky. Tyto obrazovky posuď ručně v `npm run dev` za každou roli, která je má,
a řekni to člověku, když mu výsledek kontroly předáváš.

Obě změří pravidla výše (plná tlačítka, ovládací prvky v řádcích, okna, zaoblení, stíny, písma, čísla v mono,
verzálky, stavy, plochu copper, AppShell) a uloží screenshoty do `.devkit/design/`. Barvy, písma, zaoblení
a velikost verzálek, proti kterým měří, berou obě z `spfx/src/app/ppf/ppfDesign.json`; ten generuje
`devkit theme` z tokenů ppf-material spolu s theme, takže kontrola a appka vycházejí ze stejné verze.
**Sekce** v liště appky označ `data-cadk-id="sekce-<id>"` a aktivní `aria-current="page"`; úplná kontrola je
pak projde všechny, záložky v každé hledá podle popisku. `AppShell` pro sekce vlastní místo nemá a `BarButton` tyto
atributy nebere: dej tlačítka sekcí do `actions` a každé obal prvkem, který atributy nese,
`<span data-cadk-id="sekce-ukoly" aria-current={aktivni ? 'page' : undefined} style={{ display: 'contents' }}><BarButton …/></span>`.
Popisek sekce ve výpisu kontroly obsahuje i název ikony tlačítka (například „settingsNastavení“). Pravidlo 09 (žádné ovládací prvky v řádku) neplatí
pro řádky uvnitř `role="grid"` (buňka sama je ovládací prvek: heatmapa, kalendář) a pro prvky
v `data-ppf="inline-edit"` (výslovně schválená úprava v řádku).
Plán nasazení hlásí nález `vzhled`, dokud úplná kontrola neproběhla nad dnešním kódem bez chyb. Report nese otisk
kódu (`.devkit/design/report.json`):
nasazení na **TEST bez úplné kontroly dnešního kódu odmítne, na DEV jen upozorní**.
**Výjimka z pravidla vzhledu.** Pravidlo, které appka se schválenou výjimkou neplní, se vypíná v
`project_config.json`, ne úpravou nástroje:

```json
"vzhled": { "vypnutaPravidla": [ { "pravidlo": "06 čísla", "vyjimka": "V09" } ] }
```

`pravidlo` je jméno, pod kterým ho kontrola vypisuje (`01 plné tlačítko`, `01 copper`, `03 stín`, `04 radius`,
`06 písmo`, `06 čísla`, `07 verzálky`, `08 okno`, `08 kostra`, `09 akce v řádku`, `10 stav`); `vyjimka` je ID
položky v `DEVKIT-VYJIMKY.md`, kterou schválil člověk. Bez ID, s neznámým pravidlem nebo s ID, které v souboru
není, kontrola skončí chybou (exit 2) a nic nevypne. Vypnuté pravidlo se dál měří: jeho nálezy se vypisují jako
`[vypnuto, výjimka V09]`, jen se nepočítají mezi chyby. Seznam vypnutých pravidel s ID vypíše každý běh kontroly
(rychlé i úplné) a plán nasazení ho uvádí v upozorněních. Změna seznamu zneplatní poslední úplnou kontrolu.
Agent pravidlo nevypíná sám: navrhne položku výjimky, člověk ji schválí, teprve pak se zapíše do konfigurace.

Co změřit nejde (přehlednost, hierarchie, množství textu), posuď na screenshotech; u nové obrazovky je
dej do cockpitu ke schválení spolu s návrhem.

## 3. Oprávnění

Tři vrstvy, každá jinde:

| Vrstva | Kde | Co říká |
|---|---|---|
| Role | `sp/app.manifest.json` → `roles` | jaké role appka zná (stejné ve všech prostředích) |
| Kdo roli je | `project_config.json` → `environments.<env>.roles` | skupiny a lidé (liší se DEV / TEST) |
| Co role smí | `lists.<List>.access` + `itemScope` + `levels` | úroveň na každém listu; tohle **vynucuje SharePoint** |

Appka role ani skupiny nezná. Ptá se `source.can(list, akce)` (`read`, `add`, `edit`, `edit-all`), na SP
z `EffectiveBasePermissions`, lokálně ze stejného manifestu. Podle toho ukazuje tlačítka. Vyšší úroveň zahrnuje
nižší (`edit-all` projde i na `can(list, 'add')`): kdo má vidět jinou obrazovku, toho rozliš dotazem na nejvyšší akci.
**Autor položky:** `getItems` vrací u každé položky `_author` (na SharePointu zobrazované jméno autora, v mocku jméno
lokálního uživatele); „moje“ položky poznáš porovnáním s `(await source.currentUser()).name`. `currentUser()` vrací jen
`name`, e-mail ani přihlašovací jméno appka nedostane, takže shoda jmen dvou lidí se takto nerozliší. Zabezpečení je jen
to, co nastaví SharePoint: kdo má na listu úroveň, ten ji má i z REST mimo appku.

Vzory (úrovně jsou klíče z `levels`; jejich jména `read`/`add`/`edit`/`edit-all` jsou zároveň akce `can()`,
definici můžeš změnit, jméno ne):

| Potřeba | Nastavení |
|---|---|
| všichni čtou, nikdo z appky nemění | `"access": { "<role>": "read" }` |
| přidat, ale nic neupravit ani nesmazat (rozhodnutí, audit) | `add` (vlastní úroveň bez `EditListItems`) |
| vidí vše, upraví jen své | `"itemScope": "own-write"` + `edit` |
| vidí a upraví jen své | `"itemScope": "own"` + `edit`; kdo vidí vše, má `edit-all` (`CancelCheckout`) |
| upravit bez mazání | vlastní `edit` bez `DeleteListItems` (příklad níž) |
| spravuje číselník | `edit` na číselníku, ostatní `read` |
| soubory k záznamu, které vidí jen jeho autor a řešitelé | přílohy položek listu s `"itemScope": "own"` a `"attachments": true` (vzor níž); knihovna „jen své“ neumí |
| historie změn záznamu (kdo, kdy, co z čeho na co) | `versioning` na listu + `getVersions` ([kod.md](kod.md) §DataSource); čtenář potřebuje `ViewVersions` |
| komunikace k záznamu, kterou vidí jen autor a řešitelé | stejný vzor jako soubory: jedna položka („vlákno“) na záznam, zakládá autor, ostatní připisují (`edit-all`) |
| role na list nesmí vůbec | `none` (nebo ji v `access` neuváděj) |

**Soubory „jen pro autora záznamu a řešitele“:** knihovna dokumentů neumí „vidí jen své“ a práva složky appka
nenastaví (běží s právy přihlášeného člověka). Použij vlastní list (např. `Soubory`, `itemScope: own`,
`attachments: true`, číselný sloupec s Id záznamu): autor záznamu v něm při založení záznamu založí jednu
položku („sadu“) a všichni přikládají do ní — řešitel přes `edit-all`. Appka počítá jen sady, jejichž autor je
autorem záznamu; ostatní se stejným Id ukáže řešiteli odděleně. Meze: autor sady může své přílohy mimo appku
smazat nebo vyměnit, i ty od řešitele; kdo soubor přiložil, se nedozvíš. **Neověřeno na tenantu** (stav
2026-11-11): že „jen své“ chrání přílohu i přes přímou adresu souboru a že `edit-all` přiloží k cizí položce —
ověř druhým účtem na DEV, než na tom postavíš důvěrnost.

**Úroveň „vidí vše, jen přidává“ kit nemá:** jména úrovní jsou pevná (`read`/`add`/`edit`/`edit-all`) a cizí
položky u `itemScope own` vidí jen `edit-all`, která zároveň dovolí úpravy. Kdo má vidět vše, dostane
`edit-all` a zákaz úprav drží jen appka, ne SharePoint — řekni to v návrhu.

**Schvalování, které autor neobejde:**
1. Požadavky: autor `edit` s `own-write`. Stav se do požadavku **neukládá**.
2. Rozhodnutí: samostatný list, schvalovatel `add`, ostatní `read`. Položka = id požadavku, výsledek,
   komentář a **otisk obsahu** požadavku (SHA-256 rozhodných polí v okamžiku rozhodnutí).
   **Pozor:** `read` pro ostatní znamená, že každý žadatel přečte přes REST rozhodnutí a komentáře i k cizím
   požadavkům. Má-li žadatel vidět jen své, řekni to v návrhu: tento vzor to na úrovni dat nezajistí.
3. Stav se odvozuje: platí poslední rozhodnutí, jehož otisk sedí s aktuálním obsahem. Když autor požadavek
   změní, otisk nesedí → „Změněno po rozhodnutí“ a čeká se na nové. Autor nové rozhodnutí vyrobit nemůže
   (nemá na listu zápis), takže to neobejde ani přes REST. Historie rozhodnutí zůstává (nikdo nemaže).
4. Co SharePoint neumí: zakázat schvalovateli rozhodnout o vlastním požadavku, když je zároveň autorem.
   Appka takové rozhodnutí nepočítá a ukáže varování; kdo to potřebuje vynutit, dá role různým lidem.

Proč otisk a ne číslo verze položky: otisk nezávisí na nastavení verzí listu ani na tom, jakou cestou
kdo položku upravil, a stav z něj spočítá kdokoli, kdo listy čte. Proč ne práva na položce (`itemPermissions: runtime`): appka by je musela
nastavovat za běhu s vyššími právy, než má uživatel; vzory výše vystačí s právy listů.

Ověření práv jiného uživatele bez jeho účtu: `npm run sp -- prava --env <env> --user <upn>` ([manifest.md](manifest.md)
§Práva). Lokálně: `npm run dev`, `?user=<jméno>` přepíná role; data mocku přežijí přepnutí uživatele
(sessionStorage záložky), „obnovit data z gitu“ (`?reset`) je vrátí na seed.

## 4. Příklad: changelog (ověřeno 2026-11-11 lokálně, build + tok rolí Playwrightem)

Role: `it` zadává a upravuje své požadavky, `security` schvaluje a zamítá, `admin` spravuje druhy.

```json
"roles": { "owner": {…}, "it": {…}, "security": {…}, "admin": {…} },
"lists": {
  "Druhy": { "class": "operational", "fields": [
      { "name": "Kod", "type": "text", "required": true, "indexed": true, "unique": true },
      { "name": "Typ", "type": "choice", "choices": ["Žádost", "Oznámení"] },
      { "name": "Aktivni", "type": "boolean", "default": "1" } ],
    "access": { "it": "read", "security": "read", "admin": "edit" } },
  "Pozadavky": { "class": "operational", "itemScope": "own-write", "versioning": { "majorVersionLimit": 50 }, "fields": [
      { "name": "Druh", "type": "text", "required": true, "indexed": true },
      { "name": "Popis", "type": "note", "required": true },
      { "name": "Dopad", "type": "choice", "choices": ["Nízký", "Střední", "Vysoký"] },
      { "name": "Termin", "type": "date" } ],
    "access": { "it": "edit", "security": "read", "admin": "read" } },
  "Rozhodnuti": { "class": "operational", "fields": [
      { "name": "Pozadavek", "type": "number", "required": true, "indexed": true },
      { "name": "Otisk", "type": "text", "required": true },
      { "name": "Vysledek", "type": "choice", "choices": ["Schváleno", "Zamítnuto"], "required": true },
      { "name": "Komentar", "type": "note" } ],
    "access": { "it": "read", "security": "add", "admin": "read" } }
},
"levels": {
  "read": { "builtin": "Read" },
  "add":  { "custom": "Přidávání", "rights": ["ViewListItems", "AddListItems", "ViewFormPages", "Open", "ViewPages", "BrowseUserInfo", "UseRemoteAPIs", "UseClientIntegration"] },
  "edit": { "custom": "Úpravy bez mazání", "rights": ["ViewListItems", "AddListItems", "EditListItems", "ViewVersions", "ViewFormPages", "Open", "ViewPages", "BrowseUserInfo", "UseRemoteAPIs", "UseClientIntegration"] },
  "edit-all": { "custom": "Upravovat vše", "rights": ["ViewListItems", "AddListItems", "EditListItems", "DeleteListItems", "CancelCheckout", "ViewVersions", "ViewFormPages", "Open", "ViewPages", "BrowseUserInfo", "UseRemoteAPIs", "UseClientIntegration"] }
}
```

`edit-all` je definice ze šablony (`CancelCheckout` = vidí i cizí položky u `itemScope own`); projekt z `init --prazdny`
ji v manifestu nemá a musí si ji takto doplnit. Nemá-li smět mazat, vynech `DeleteListItems`.

`project_config.json`: DEV `"it": { "bindTo": "@members" }`, `security` a `admin` přes `members.emails`
(lidé musí být zároveň členy nebo návštěvníky webu — jinak stránku neotevřou).

Logika stavu (`spfx/src/app/stav.ts`), jádro:

```ts
export const POLE_OTISKU = ['Title', 'Druh', 'Popis', 'Dopad', 'Termin'] as const;   // změna = nové posouzení
export async function otisk(p: Item): Promise<string> {
  const text = POLE_OTISKU.map((k) => `${k}=${p[k] == null ? '' : String(p[k]).trim()}`).join('\n');
  const h = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return Array.from(new Uint8Array(h)).map((b) => (b < 16 ? '0' : '') + b.toString(16)).join('');
}
// stav: Oznámení (druh nepotřebuje schválení) | Čeká | Schváleno/Zamítnuto (poslední rozhodnutí se shodným
// otiskem, ne od autora) | Změněno po rozhodnutí (existuje rozhodnutí, ale otisk nesedí)
```

UI: záložky Požadavky a Druhy. IT vidí „Nový požadavek“ a „Upravit“ jen u svých; security „Schválit /
Zamítnout“ u cizích žádostí s dialogem na komentář; admin přidává a vypíná druhy (vypnutý druh se
v novém požadavku nenabízí). Úprava požadavku ukáže upozornění, že zneplatní rozhodnutí.

Ověřený tok v harnessu (16 kontrol): IT zadá → security schválí → IT upraví → „Změněno po rozhodnutí“ →
security zamítne → „Zamítnuto“; igor neupraví ivanin požadavek; security nezadává; admin přidá a vypne druh.
Na SharePointu (vynucení práv, `getusereffectivepermissions` pro každou roli) ověř po nasazení na DEV.

## Kontrola návrhu před `npm run gen`

- [ ] Každý údaj leží v listu, kam smí psát jen ten, kdo o něm rozhoduje.
- [ ] Odkazy mezi listy textovým klíčem (lookup jen se zapsaným důvodem); klíčové sloupce `unique` + `indexed`.
- [ ] Každá role v `access` je v `project_config.json` namapovaná pro každé prostředí, kam se nasazuje.
- [ ] Každý uživatel appky má na webu aspoň Read (role pro všechny = `@members` / `@visitors`).
- [ ] UI se ptá `can()`, nikdy na jméno skupiny nebo role.
- [ ] Seed pro každý list a harness ho importuje; tok mezi rolemi vyzkoušený přes `?user=`.
