# Kód appky: DataSource, mocky, harness, SPFx, UI, testy, build

`devkit …` = `node "${CLAUDE_SKILL_DIR}/scripts/devkit.mjs" …`. Jak appka vypadá a co kde má: [app-design.md](app-design.md).

## Jedna appka, tři hostitelé

Lokální workbench SPFx neexistuje, proto je appka napsaná **nezávisle na SPFx** a lokálně běží v harnessu nad mocky.
Na SharePoint jde stejný kód; web part (`spfx/src/webparts/app`) je jen tenký host.

| režim | příkaz | data | vlastnosti web partu |
|---|---|---|---|
| lokálně | `npm run dev -- --port <port>` | `MockSource` (data z gitu) | `generated/localProps.ts` (`environments.local.values`) |
| DEV, ladění | `npm run dev -- --sp [--env dev] [--page <klíč>]` | `SpSource` (živý web) | instance na stránce |
| nasazený balíček | `npm run build`, `npm run deploy …` | `SpSource` | instance na stránce |

Appka (`spfx/src/app/App.tsx`) dostane ve všech třech `source` (`DataSource`) a `props` (vlastnosti web partu).

`npm run dev` bez `--port` (a bez `PORT`) vybere volný port a vypíše ho. `http://127.0.0.1:<port>/?user=<jméno>`
přepne uživatele a jeho role z `environments.local.users`, `?now=<ISO čas>` posune hodiny, `?reset` vrátí data
z gitu. esbuild hlídá změny, stačí obnovit stránku.

## DataSource

Appka mluví **jen přes `DataSource`** (`spfx/src/app/data/types.ts`): `getItems(list, { where })`, `addItem`,
`updateItem`, `getVersions`, `addAttachment`, `listAttachments`, `searchPeople`, `can(list, action)`, `assetUrl`,
`getAssetJson`, `currentUser`. Nikdy nevolá `fetch` na `_api`, nepoužívá vlastní MSAL ani Graph klienta a nezná
jména skupin. Nové čtení nebo zápis = nová metoda v `DataSource` a v obou implementacích (`SpSource.ts`,
`MockSource.ts`); PnPjs ani `SPHttpClient` nezaváděj. Nový list = manifest + data, ne kód zdroje.

- `can()`: `MockSource` počítá práva ze **stejného manifestu**, ze kterého se staví práva na webu, a zakázaný zápis
  vyhodí `AccessDenied` (403) jako SharePoint; `SpSource` čte `EffectiveBasePermissions` listu. read = ViewListItems,
  add = AddListItems, edit = EditListItems, edit-all = EditListItems + CancelCheckout; práva rolí se sčítají.
- `getItems(list, { where: { Pole: hodnota } })` filtruje na serveru; pole měj indexované. Vrácené položky jsou
  kopie: změna jen přes `updateItem`, pak čti znovu. Položky nesou `_author` (zobrazované jméno; v mocku jméno
  lokálního uživatele); `currentUser()` vrací jen `{ name }`.
- **Mazání `DataSource` nemá**; záznam se uzavírá stavem.
- `addAttachment` / `listAttachments` = přílohy položek (`"attachments": true`), jediná cesta pro soubory k záznamu
  (knihovnu dokumentů `DataSource` neumí). Viditelnost i právo přikládat se řídí položkou (včetně `itemScope`);
  SharePoint neeviduje, kdo přílohu přiložil, a soubor stejného jména nepřepíše.
- `getVersions(list, id)` = historie verzí od nejstarší `{ verze, kdy, kdo, pole }`. Podmínky: list má `versioning`,
  čtenář vidí položku a jeho úroveň má **`ViewVersions`** (vestavěné Read/Contribute a kitová `edit-all` ano, kitová
  `add` ne; doplň ho do `rights` a úrovni dej nové `custom` jméno, existující úroveň se změnou rights nepřepíše).
  Že zadavatel s `ViewVersions` dostane verze své položky u `itemScope own`, **neověřeno** druhým účtem.
- `searchPeople(q)` hledá jen mezi lidmi, které web zná (`siteusers`), nejvýš `PEOPLE_LIMIT` výsledků.
- **Datum:** sloupec `date` je v appce vždy `'YYYY-MM-DD'`, `datetime` a `Created` ISO se `Z`; pravidla zobrazení
  v [app-design.md](app-design.md) §2.
- `Attempted to perform an unauthorized operation` z REST = chybějící role na webu, ne syntaxe.
- Microsoft Graph jen přes `this.context.msGraphClientFactory.getClient('3')`; oprávnění v `package-solution.json`
  → `webApiPermissionRequests` schvaluje správce, bez schválení 403.

## Mock a data

| soubor | kdy |
|---|---|
| `sp/data/config/<List>.json` | konfigurační list — **kanón**, mock čte totéž, co se nasadí |
| `sp/data/initial/<List>.json` | list `class: initial` — výchozí sada, mock čte totéž, co první nasazení vloží |
| `sp/data/seed/<List>.json` | provozní list — jen ukázková data pro mock, na web nikdy nejdou; `_author` = jméno lokálního uživatele |

Mock bere data a práva z manifestu přes `npm run gen` (`generated/mockData.ts`, `appManifest.ts`); harness se
needituje. List bez souboru začíná prázdný. Data mocku drží sessionStorage záložky, takže přežijí přepnutí uživatele
(tok mezi rolemi jde vyzkoušet v jedné záložce); nová záložka a `?reset` začínají ze `sp/data`.

- `itemScope: own`: uživatel bez `edit-all` vidí jen své položky; `own` i `own-write` dovolí `updateItem` jen
  u vlastních (jinak 403). Cizí položky vidí vlastník a úroveň s CancelCheckout: převzato z Trackeru, **neověřeno
  druhým účtem** na tenantu — než na tom postavíš roli, ověř to čtením na DEV.
- `unique: true`: `addItem` a `updateItem` odmítnou hodnotu, kterou už jiná položka má; přesnou odpověď SharePointu
  kit změřenou nemá, appka se nemá spoléhat na znění chyby.
- Hodiny mocku `now` určují `Created` nových položek a razítka verzí.
- **Připomínky lokálně:** s `"feedback": true` ukáže harness stejnou vrstvu jako DEV, list připomínek je jen v paměti
  stránky. Slouží k ověření kotev: „+ Připomínka“, pak klik na prvek; přijme jen prvek s `data-cadk-id` nebo řádek
  s `data-cadk-key` ([sp-sync.md](sp-sync.md) §Připomínky).
- **Assety:** `sp/assets/config/` se lokálně servíruje na `/assets/*`, na SharePointu je to knihovna
  `<PREFIX>-Assets`. Appka odkazuje vždy přes `source.assetUrl(name)` / `getAssetJson(name)`; REST
  `…/Files('x')/$value` pro `<img>` nepoužívat (vrací `application/octet-stream`, SVG se nevykreslí).

## UI: ppf-material + MUI

Vzhled je PPF × Material 3 (skill `ppf-material`) a MUI 9 s **generovaným** theme. Rozvržení a bloky:
[app-design.md](app-design.md) §2. Co bloky ani theme neumí, navrhni podle `ppf-material` (`references/components.md`,
`examples/`), ne od oka.

- Theme, fonty, `ppfDesign.json` a stavební bloky `blocks.tsx` generuje `devkit theme spfx/src/app/ppf --material
  <složka skillu ppf-material>` (u pluginu `~/.claude/plugins/cache/<marketplace>/ppf-material/<verze>/skills/ppf-material`,
  vypíše `claude plugin list`). Nový projekt je má z `init`, starší je dostane stejným příkazem. `--check` vrací
  rc 1 při driftu; ruční editace je chyba (změň tokeny, generátor nebo blok v kitu).
- `AppShell` nese `ThemeProvider` a načte fonty ikon a mono; appka ho jen obalí. `PPF` export theme nese hodnoty,
  které theme nevynutí (status barvy, selected marker, sekvence grafů).
- Fonty: `@use './ppf/ppf-fonts';` na začátku `.module.scss`, který kořenová komponenta importuje (jinak se do bundle
  nedostane; ne `@import`).
- Ikony: `<Icon name="search" />` z `blocks.tsx` (Material Symbols Outlined); nikdy ruční SVG ani emoji.
- **Nepoužívej `CssBaseline`** (reset zasáhne stránku SharePointu kolem web partu); reset jen `ScopedCssBaseline`
  uvnitř kořene web partu.
- Fluent (`@fluentui/react`, v9) se nepoužívá; v `node_modules` zůstává jen jako závislost balíčků SPFx.
- **MUI 9:** `Stack` nemá system props (`alignItems` apod. patří do `sx`), totéž `Typography display`;
  `TextField inputProps` neexistuje → `slotProps={{ htmlInput: { … } }}`.
- Dva MUI web party na jedné stránce **neověřeno**: první takové nasazení ověř sondou a screenshotem.

## Pasti kódu

- **TS cíl `es5` a `lib` ze `spfx/tsconfig.json`.** Šablona přidává `es2016.array.include` a `es2017.object`
  (`includes`, `Object.entries`, `Object.values`); `?.` a `??` TypeScript převede. Nefunguje, co v `lib` není:
  `arr.flat()` (náhrada `[].concat(...arr)`), `str.replaceAll` (`str.split(a).join(b)`), `str.padStart`.
- **Roluje kontejner, ne okno.** Na stránce SharePointu roluje div kanvasu pod lištou webu; `window.scrollY` je
  pořád 0 a `scroll` na `window` nepřijde. Harness to napodobuje (`data-testid="harness-scroll"`). Proto:
  - posun: nejbližší rolovací předek kořene appky (hledat při každém použití), nebo `el.scrollIntoView({ block:
    'nearest' })`, ne `window.scrollTo`;
  - měření: `getBoundingClientRect()` stačí sám, nepřičítej `window.scrollY`; výšku závislou na poloze počítej
    z polohy nezávislé na odrolování (jinak smyčka layout efektu, Gate Insider: React #185 a pád appky);
  - posluchače: `scroll` nebublá — na předkovi, nebo na `document` s `capture: true`; `resize` na `window` funguje;
  - `position: sticky` se lepí k rolovacímu předkovi (předek s `overflow: hidden` ho vypne);
  - `100vh` je výška okna; výška do spodku okna = `window.innerHeight - el.getBoundingClientRect().top`.
- **CSS moduly:** `*.module.scss` jsou moduly, ostatní `.scss` globální; prázdná třída `.foo {}` se neexportuje
  (TS2551), dej aspoň `display: block;`. SCSS proměnné musí být v importovaném souboru; barvy ber z `PPF`, ne z SCSS.
- **Osobní e-maily a adresy webů nepatří do TSX**, ale do vlastností web partu.
- **`preconfiguredEntries` platí jen při vložení web partu na stránku**: nový default se do existující instance
  nedostane a za běhu ho z `this.manifest` nepřečteš. Kód musí počítat s chybějící hodnotou (hláška místo pádu);
  hodnoty instancí nastavuje manifest (`pages`).

## Testy

- `npm test` = testy nástrojů (`tools/test/`) a logiky appky `spfx/src/app/**/test/*.test.mjs`; je rychlý a nepotřebuje
  build. `tools/test/spsource.test.mjs` pouští `SpSource` s podvrženým `fetch` (mění-li se `SpSource`, mění se i test);
  potřebuje `npm --prefix spfx install`.
- `npm run typecheck` = `npm run gen` + `tsc --noEmit` nad `spfx/` (holé `npx tsc` je nespolehlivé, typy `.scss`
  vznikají až buildem). `npm run lint` = eslint s konfigurací projektu nad `spfx/src` (chyba = exit 1).
- **Před commitem `npm run check-all`** = `npm test`, `typecheck` a `lint` za sebou.
- Logiku appky piš v `.ts` bez importů Reactu a v testu ji přelož esbuildem ze `spfx/node_modules` jako
  `tools/test/spsource.test.mjs` (funkce `load()`); přímý `import '../logika.ts'` z `.mjs` selže na Node 22.14.

**Vlastní test toku nad harnessem** (podání → schválení → co kdo vidí) si projekt píše sám. Start harnessu a načtení
appky jsou v `tools/lib/harness.mjs`, nepiš je znovu:

```js
// tools/e2e.mjs v projektu; do package.json "e2e": "node tools/e2e.mjs"
import { loadChromium, startHarness, openApp } from './lib/harness.mjs';

const chromium = await loadChromium();                  // chybí playwright → výjimka s návodem
const h = await startHarness({ url: process.argv[2] }); // bez adresy spustí harness na volném portu
const browser = await chromium.launch();
let fails = 0;
const ok = (c, m) => { if (!c) fails++; console.log(`${c ? 'OK  ' : 'FAIL'} ${m}`); };
try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 }, reducedMotion: 'reduce' });
  page.on('pageerror', (e) => ok(false, `chyba stránky: ${e.message}`));
  await openApp(page, h.url, { reset: true, user: 'anna', now: '2026-11-11' }); // data z gitu, role, hodiny
  await page.getByRole('tab', { name: /Moje/ }).click();
  ok(await page.locator('[data-ppf=row]').count() > 0, 'anna vidí své záznamy');
  await openApp(page, h.url, { user: 'petr' });          // bez reset: data mocku zůstanou (sessionStorage)
  // …
} finally {
  await browser.close();
  h.stop();                                             // převzatý harness (--url) nechá běžet
}
process.exitCode = fails ? 1 : 0;
```

- `?now=2026-11-11` = poledne místního času (nebo `2026-11-11T08:30`); posune `new Date()`, `Date.now()` i razítka
  mocku, lhůty jsou při každém běhu stejné.
- Posun v testu `scrollIntoViewIfNeeded()` nebo přes kontejner harnessu, ne `window.scrollTo`.
- Na přechody MUI čekej jen kvůli screenshotům; kroky toku čekej na obsah (`getByText(…).waitFor()`).

## Build

`npm run build` = gen + `heft test --production` + `package-solution` → `spfx/sharepoint/solution/<name>.sppkg`
a záznam buildu `.devkit/balicek.json` (plán podle něj pozná balíček z dnešního kódu). Před každým nasazením nového
kódu zvedni `solution.version` v `spfx/config/package-solution.json` (`x.y.z.n`).

- Výstup buildu neposílej přes `grep` a build s deployem neřetěz v jednom `&&`: `grep` vrací 0, když najde „error“.
- Čistý log: `NO_COLOR=1 npm run build 2>&1 | sed 's/\x1b\[[0-9;]*m//g'`. Varování `punycode` z Node 22 ignoruj.
- Toolchain je Heft (`useGulp: false`): `npx gulp` nefunguje.

## Další web part a smazání komponenty

Většinou stačí další stránka nebo instance `AppWebPart` s jinými vlastnostmi (`pages` v manifestu). Opravdu nový web
part (ve `spfx/`, generátor ve verzi projektu):

```bash
V=$(node -p "require('./.yo-rc.json')['@microsoft/generator-sharepoint'].version")
npx -y -p yo@7.0.1 -p @microsoft/generator-sharepoint@$V -- yo @microsoft/sharepoint \
  --component-type webpart --component-name "<Name>" --component-description "<popis>" \
  --framework react --skip-install --skip-cache
git checkout -- config/serve.json eslint.config.js .yo-rc.json   # https:false, ignorovaný harness/, původní componentName
npm pkg delete dependencies.@fluentui/react                     # šablona Fluent nepoužívá
/usr/bin/trash teams                                             # ikony pro Teams; kit do Teams nenasazuje
```

Vygenerovanou ukázku přepiš na stejně tenký host jako `AppWebPart` (`spfx/src/webparts/app/AppWebPart.ts`:
`DataSource`, `pripominky`, žádná logika), pak `npm run build` a ověř bundle v `.sppkg` (`unzip -l`). `--use-gulp`
a `--plusbeta` nepoužívat.

Smazání komponenty: `/usr/bin/trash src/webparts/<name>/` (nikdy `rm -rf`) → odebrat z `config/config.json`
(`bundles.*`, `localizedResources.*`) → zvednout `solution.version` → build → deploy; `metadata.longDescription`
v `package-solution.json` drž v souladu s počtem web partů.

## Upgrade SPFx

1. Čistý git stav; zjisti aktuální verzi (`.yo-rc.json`, `@microsoft/sp-*`) a napiš cílovou.
2. `npm run m365 -- spfx doctor` — kompatibilita Node a TS cílové verze.
3. Ve `spfx/`: `node ../tools/m365.mjs spfx project upgrade [--toVersion <v>] --output md` (jen čte a vypíše report);
   aplikuj **všechny** kroky v pořadí.
4. `npm install` → `npm run build` → `npm start` smoke test → review diffu.

Piny (Node, React, SPFx) jsou v projektu (`spfx/package.json`, `spfx/.yo-rc.json`), ne v tomto souboru. Pro nové API
ověř dokumentaci (Context7 `/sharepoint/sp-dev-docs`, `/mui/material-ui`).

## Ladění na DEV

`npm run dev -- --sp` vygeneruje `generated/*`, spustí ladicí server heft na `http://localhost:4321` **bez
certifikátu** a vypíše adresu stránky appky (`--page <klíč>`, jinak první) s `?loadSPFX=true&debugManifestsFile=…`.
Otevři ji a potvrď „Load debug scripts“; Chrome a Edge se jednou zeptají na přístup k místní síti — povolit. Stránka
musí na webu existovat **s web partem** (jednou `npm run deploy`); ladicí režim jen nahradí kód instance.

Https na přání vývojáře: `"https": true` v `spfx/config/serve.json` a jednou `npm run cert` — na macOS vypíše příkaz
pro správce, spouští ho člověk.

## Souběžná práce

Víc session na jednom projektu jen s **vlastním worktree na vlastní větev**; dva procesy nad jedním stromem si
přepisují `generated/`, `.devkit/` a `node_modules`. Nasazuje **jedna** session z commitu na hlavní větvi, ne každá
ze své. Ladicí server `--sp` má pevný port ze `spfx/config/serve.json`, dvě `--sp` ladění najednou se nevejdou.
Dokud se do nového worktree kopírují `node_modules`, hlásí `prereq` chybějící nástroje a přihlášení „nejde ověřit“:
znovu se nepřihlašuj a `npm ci` nespouštěj. Přihlášení m365 sdílí worktree s hlavním checkoutem.
