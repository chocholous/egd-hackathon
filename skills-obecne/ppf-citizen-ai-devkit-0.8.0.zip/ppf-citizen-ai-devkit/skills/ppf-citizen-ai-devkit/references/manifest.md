# Manifest, project_config.json, práva, výchozí sada, prereq a verze kitu

Co appka na SharePointu má (listy, sloupce, práva, stránky), je v `sp/app.manifest.json`; kdo jsou role a kam se
nasazuje, v `project_config.json`. Jak data a práva navrhnout: [app-design.md](app-design.md). Jak se to nasazuje:
[sp-sync.md](sp-sync.md).

## sp/app.manifest.json

```json
{
  "roles": { "owner": {…}, "editor": {…}, "user": {…} },
  "lists": {
    "Kategorie": { "class": "config", "key": "Kod", "fields": [ … ], "access": { "user": "read", "editor": "edit" } },
    "Hlaseni":   { "class": "operational", "itemScope": "own", "fields": [ … ], "access": { "user": "add", "editor": "edit-all" } }
  },
  "libraries": {
    "Assets":  { "class": "config", "source": "sp/assets/config", "access": { "user": "read", "editor": "read" } },
    "Prilohy": { "class": "operational", "access": { "user": "add", "editor": "edit-all" } }
  },
  "levels": { "read": { "builtin": "Read" }, "edit": { "builtin": "Contribute" },
              "add": { "custom": "Přidávání", "rights": [ … ] }, "edit-all": { "custom": "Upravovat vše", "rights": [ … ] } }
}
```

`npm run gen` (spouští ho i `dev` a `build`) manifest zkontroluje a vygeneruje `spfx/src/app/generated/` (typy,
`appManifest.ts`, data mocku).

### Třídy listů

- `class: config` — obsah je v gitu (`sp/data/config/<List>.json`, `sp/assets/config/`) a synchronizuje se. Musí mít
  `key` (sloupec `required` + `unique`): párování mezi gitem a webem jde přes klíč, nikdy přes SP ID.
- `class: initial` — jen list. Výchozí sada řádků je v gitu (`sp/data/initial/<List>.json`), deploy ji vloží jednou,
  potom list spravuje byznys v appce (§Výchozí sada). Musí mít `key` jako konfigurační list.
- `class: operational` — synchronizuje se jen struktura a práva, na obsah se nesahá.
- Kdy kterou zvolit: [app-design.md](app-design.md) §1.

### Listy a sloupce

- **Identita listu je URL, ne titul.** Klíč `"Hlaseni"` + prefix `CADK` → list se založí s titulem `CADK-Hlaseni`
  (SP z něj udělá `Lists/CADKHlaseni`) a pak dostane `"title"` (smí mít diakritiku). Přejmenování = změna `title`,
  URL zůstává. Převzatý list s jinou URL: `"url": "Lists/<Název>"`. Appka adresuje listy stejnou URL.
- **Titul listu je na webu unikátní**: vlastní `title` vol s ohledem na ostatní appky na webu.
- Sloupec: `name` = interní jméno (bez diakritiky, nejde přejmenovat), `display` = popisek. Další atributy:
  `required`, `indexed`, `unique`, `default`, `maxLength`, `numLines`, `choices`, `multi` (user/lookup).
- Typy sloupců: `text`, `note`, `number`, `boolean`, `datetime`, `date`, `choice`, `user`, `lookup`.
  **`user` a `lookup` manifest založí, ale datová vrstva appky je neumí:** `SpSource` žádá sloupce holým jménem bez
  `$expand` a zapisuje hodnotu, jak ji dostane (SharePoint chce čtení přes `$expand` a zápis do `<Sloupec>Id`). Plyne
  to z kódu, na SharePointu to zkoušeno nebylo. V listu, který appka čte, ulož osobu jako text (jméno) a odkaz jako
  textový klíč; lookup jen s důvodem ([app-design.md](app-design.md) §1).
- **Lookup** `{ "type": "lookup", "list": "@list:Kategorie" }`: jen na list téhož manifestu. `deleteBehavior:
  restrict|cascade` vyžaduje `indexed: true` a ne `multi`; lookup nemůže být `unique`. Nad 12 sloupců lookup/osoba
  v listu = varování (limit spojení v dotazu).
- **Lookup v datech** konfigurace a výchozí sady píšeš `"@key:Kategorie/IT"`; plán zapisuje v pořadí odkazů a Id
  dosadí až zápis. Odkaz na neexistující klíč nebo cyklus = chyba před čímkoli dalším. **Osoba** v datech = UPN;
  zápis ji založí na webu přes `ensureuser`.
- List: `itemScope` `own` (vidí a upraví jen své) / `own-write` (vidí vše, upraví své); `own` nastaví
  `ReadSecurity/WriteSecurity = 2` pro celý list: cizí položky vidí jen úroveň s `CancelCheckout` (Override List
  Behaviors) a vlastníci, a nejde kombinovat s unikátním sloupcem. Dále `versioning: { "majorVersionLimit": N }`,
  `attachments: true|false`; nevyplněné kit neřeší.
- List i knihovna: `noCrawl: true` = obsah nejde do vyhledávání SharePointu (připomínky, interní data).
- Role `owner` = vlastníci webu, Full Control, vždy.

Co plán udělá se změnou struktury:

| změna | výsledek |
|---|---|
| nový list, knihovna, sloupec | zápis (nejdřív všechny listy, pak sloupce — lookup na list z téhož běhu projde) |
| titul listu, popisek sloupce, povinnost, délka, počet řádků, výchozí hodnota, přidaná volba | zápis |
| nový povinný sloupec na neprázdném listu | zápis s upozorněním: povinnost hlídají jen formuláře, staré položky zůstanou prázdné |
| odebraná volba Choice | zápis, jen když ji žádná položka nepoužívá; jinak nález |
| index (přidat/odebrat) | zápis do 20 000 položek v listu; nad to nález (limit SP) |
| typ, unikátnost, cíl lookupu, deleteBehavior | nález `migrace` — ručně |
| list s prefixem appky nebo sloupec, které manifest nezná | nález `navíc` — nic se nemaže |
| sloupec, který založil SharePoint sám (vestavěný, jen ke čtení, skupina `_Hidden`) | nic, není nález |

### Stránky a web party

```json
"pages": { "App": { "title": "Hlášení", "webparts": [
  { "id": "app", "webpart": "AppWebPart", "properties": { "seznam": "@list:Hlaseni", "napoveda": "@env:napovedaUrl" } } ] } }
```

- Stránka `<PREFIX>-<Klíč>.aspx`, jedna sekce, při publikování `layout` z manifestu (výchozí
  `SingleWebPartAppPage`, bez komentářů; `comments: true` je nechá). Single Part App Page nese **právě jeden web
  part**; víc web partů = `"layout": "Article"`. Kit spravuje **jen stránky appky a web party z vlastního balíčku**
  (`webpart` = alias z `spfx/src/webparts/*/*.manifest.json`).
- `id` instance je stabilní klíč (instanceId = UUID v5 z id solution a `<Klíč>/<id>`), stejné v každém prostředí.
- `@list:<klíč>` = klíč listu z manifestu. `@env:<jméno>` = `project_config.json` → `environments.<env>.values.<jméno>`;
  chybějící hodnota zastaví plán i `npm run gen` (lokální hodnoty jdou do `generated/localProps.ts`, jen pro harness).
- **Git vyhrává jen nad klíči z manifestu.** Vlastní klíče SharePointu ve vlastnostech se neporovnávají; zápis je
  mělké sloučení, klíč tak nejde smazat, jen přepsat.
- Nálezy: `nejdřív deploy` (web part na webu ještě není dostupný: nasaď balíček a zopakuj plán), `navíc` (instance
  z balíčku, kterou manifest nezná — odebírá se ručně), `migrace` (pod instanceId je jiný web part), `koncept`
  (nepublikovaný koncept, plán nic nemění).

## Výchozí sada (`class: initial`)

List, který po spuštění spravuje byznys, ale appka bez výchozích řádků nefunguje. Řádky v
`sp/data/initial/<List>.json` mají stejný tvar jako konfigurace a jdou do mocku i na web. Deploy řádky jen vkládá;
záznam o nasazení si pamatuje klíče, které kit vložil nebo na webu našel:

| v gitu | na webu | v záznamu | výsledek |
|---|---|---|---|
| je | není | není | **vložit** |
| je | je, i s jiným obsahem | cokoli | nic; existující řádek se nikdy neupraví ani nesmaže |
| je | není | je | nic; řádek smazal byznys a kit ho nevrátí |
| není | je | cokoli | nic; řádek přidal byznys, nebo je odebraný z gitu |

- **Změna existujícího řádku v gitu se na web nepropíše** a plán ji neukáže. Mění se v appce; do gitu má smysl psát
  jen nové klíče.
- **List už má řádky a záznam o něm neví** (převod z `operational`, ztracený záznam): kit nevloží nic, chybějící
  klíče vypíše v upozornění a do plánu dá akci „převzít list s výchozí sadou bez vkládání“, která na web nezapíše
  nic; po potvrzení se zapíše záznam a klíče přidané do gitu potom se už vkládají.
- **Převod `operational` → `initial`:** změň třídu, přidej `key` a soubor `sp/data/initial/<List>.json`.
- `npm run sp -- pull` listy `initial` nečte. Appka bez konfigurační knihovny (`class: config`) list `initial` mít
  nesmí (záznam o nasazení se nemá kam zapsat); kontrola manifestu to odmítne.
- Na produkci kit nezapisuje; výchozí sada je v gitu, takže ji s tagem dostane ten, kdo produkci nasazuje.

## Git je zdroj pravdy

Na webu leží záznam o posledním nasazení `<PREFIX>-Assets/_deploy/<env>.json` (commit, `dirty`, hash každé položky
a assetu). Pro každý klíč konfigurace:

| git | web | výsledek |
|---|---|---|
| změněn | jako při nasazení | **zápis** |
| jako při nasazení | změněn | **odchylka** — nezapíše se; `npm run sp -- pull --env dev --write` → `git diff` → commit |
| změněn | změněn jinak | **konflikt** — nezapíše se; rozhodne člověk (`--prefer-git` přepíše web verzí z gitu; v cockpitu otázka s možnostmi, [cockpit.md](cockpit.md) §Konflikty) |
| odebrán | jako při nasazení | do koše |
| — | jen na webu | odchylka (nabídne pull) |

Z webu na web se konfigurace nikdy nepřenáší: DEV → TEST = DEV → git → TEST. `sp pull --write` jen přepíše soubor
konfigurace v projektu; zkontroluj `git diff`.

## Práva

Výchozí je dědění z webu; vlastní práva má jen list nebo knihovna, která je v manifestu výslovně chce. Práva položek
nastavuje jen appka za běhu, kit je nikdy nečte ani nemění.

**Manifest** — u každého listu a knihovny povinně `access`:

- `"access": "inherit"` — dědí z webu. Má-li list na webu vlastní práva, plán navrhne **obnovit dědičnost** (vlastní
  práva listu se zahodí, nevratně; SKILL.md §Pojistky 4).
- `"access": { "user": "add", "editor": "edit-all" }` — vlastní práva: zápis přeruší dědičnost s kopií práv webu
  (práva položek zůstanou) a srovná přiřazení s gitem. Úroveň `none` = role tu nemá nic. Role `owner` se nepíše.
- Konfigurační knihovna (assety appky) musí mít `access` s aspoň `read` pro každou roli.
- `"itemPermissions": "runtime"` u listu — appka smí za běhu dávat položkám vlastní práva. Kit podle toho nic nemění;
  je to deklarace pro kód appky (jde i do `generated/appManifest.ts`). Kde stačí „vidí/upraví jen své“, použij
  `itemScope`.
- Složky s vlastními právy kit nespravuje: místo složky s jinými právy udělej knihovnu.
- Úrovně: `{ "builtin": "Read" | "Contribute" | "Edit" | "Design" | "Full Control" }` nebo
  `{ "custom": "<název>", "rights": [ ...SPBasePermissions ] }`. Vestavěné se hledají podle typu, fungují i na
  webu s lokalizovanými názvy.
- **Vlastní úrovně** se zakládají jako `<PREFIX> – <název>` a platí pro **celou kolekci webů**. Zakládá se jen
  úroveň, na kterou odkazuje `access` některého listu. Kit je nikdy nemaže ani neupravuje: liší-li se na webu od
  `rights`, plán ukáže nález — uprav úroveň ručně, nebo založ novou s jiným názvem.

**Prostředí** — `project_config.json` → `environments.<env>.roles.<role>` říká, kdo roli je:

- `{ "bindTo": "@members" }` nebo `"@visitors"` — role se váže přímo na přidruženou skupinu webu (DEV: testeři);
- `{ "members": { "emails": [...], "entraGroups": [...] } }` — zápis založí skupinu `<PREFIX> – <role>` a doplní
  členy. Člen navíc = nález (odebírá se ručně). Členové se párují podle `Email`, pak `UserPrincipalName`, pak
  přihlašovacího jména;
- `{ "group": "<název>" }` — existující skupina s jiným názvem (převzatá appka); bez `members` se členství nespravuje.
- SP skupina nemůže obsahovat jinou SP skupinu — proto dva tvary.
- **Kdo je v které roli, řekne člověk**; agent kolegy do rolí sám nepřidává.

Kontrola před plánem (chyba = nic se neplánuje): role musí být v manifestu, `owner` se nemapuje, `bindTo: "@owners"`
nejde, dvě role nesmí mířit na tutéž skupinu a každá role použitá v `access` musí být v cílovém prostředí mapovaná.

**Srovnání přiřazení** (jen na listech a knihovnách appky s vlastními právy):

| na webu | výsledek |
|---|---|
| principál s úrovní, kterou git nezná | **odebrat** tu vazbu (nevratné, SKILL.md §Pojistky 4) |
| role s jinou úrovní než v gitu | nejdřív přidat úroveň z gitu, pak odebrat starou |
| role z gitu chybí | přidat |
| vlastníci webu (přidružená skupina) | nikdy se neodebírají; jen se doplní Full Control, když chybí |
| nasazující účet | jeho přímé přiřazení se nikdy neodebírá ani nehlásí |
| Limited Access | nechává se |

Všechna přidání jdou před odebráním, takže při selhání uprostřed nikdo nepřijde o přístup, který má mít.

**Každý uživatel appky musí mít na webu aspoň Read.** Skupina role `<PREFIX> – <role>` má na webu jen Limited Access
a stránku appky neotevře (změřeno na DEV web). Roli, kterou mají všichni uživatelé (typicky `user`), mapuj na
přidruženou skupinu webu (`@visitors` / `@members`); lidé ve vlastních skupinách rolí musí být zároveň návštěvníky
nebo členy webu. Tester, který stránku neotevře, není ve skupině s Read na webu.

**Ověření práv role bez druhého účtu:** `npm run sp -- prava --env <env> --user <upn> [--role <role>[,<role>]]`
(jen čte; `--json`). Pro každý list porovná skutečná oprávnění uživatele (čte, přidá, upraví, maže, cizí položky)
s tím, co mu dávají role podle manifestu. Role odvodí z přímého členství ve skupinách webu; člen přes Entra skupinu
se nepozná → `--role`. Kód 0 = vše odpovídá, 10 = odchylka.

## project_config.json

| klíč | povinné | význam |
|---|---|---|
| `app.name`, `app.prefix` | ano | prefix se dává před všechny SP objekty appky (sdílený web) |
| `m365.tenantId`, `m365.appId` | ano | tenant a registrace pro přihlášení; tenant ověřují `deploy`, `sp` a `feedback`. Pro PPF předvyplněné (nejsou tajné); jiný tenant = hodnoty od správce |
| `m365.timeoutS` | ne | nejdelší doba jednoho volání m365 v nástrojích kitu (šablona 120); po vypršení se nic neopakuje ([sp-sync.md](sp-sync.md) §Časový limit). Chybí / `null` = bez limitu |
| `m365.timeoutBalicekS` | ne | totéž pro nahrání `.sppkg`; v šabloně `null` |
| `git.remote` | ne (WARN) | URL vzdáleného repa; prereq ověří, že míří na totéž repo jako `origin` (jiný zápis téže adresy nevadí: `.git`, ssh proti https) |
| `cockpit.url` | před nasazením | adresa cockpitu ([cockpit.md](cockpit.md)) |
| `environments.local.users` | doporučeno | jméno → role pro přepínání v mocku |
| `environments.<env>.site` | aspoň jedno | URL webu; prázdné = prostředí se přeskočí |
| `environments.<env>.roles` | ne | mapování rolí na principály (§Práva) |
| `environments.<env>.values` | ne | hodnoty `@env:` pro web party ([app-design.md](app-design.md) §Co se liší mezi prostředími) |
| `vzhled.vypnutaPravidla` | ne | pravidla kontroly vzhledu vypnutá se schválenou výjimkou ([app-design.md](app-design.md) §Co kontrola projde) |
| `kit.verze`, `kit.commit`, `kit.varianta` | ne | zapisuje `devkit init` (§Verze kitu) |

Tajné hodnoty sem nepatří (soubor je v gitu). Klíče `_pozn` nesou zdůvodnění hodnoty.

## npm run prereq

Jen čte; exit 0 = vše OK, 1 = nějaký FAIL. Kontroluje ladicí server (plán totéž hlásí jako nález `nástroje`),
úplnost `project_config.json`, že `git.remote` míří na totéž repo jako `origin`, `cockpit.url`, přihlášení
lokálního m365 a shodu tenantu, pro každé prostředí se `site` dostupnost webu, vlastníka webu (člen přes Entra
skupinu se nepozná → WARN) a site collection app catalog (chybí = FAIL; plán: nález `katalog`), a prohlížeč pro
sondu (chybí → WARN). Prázdné `cockpit.url` a nevyplněný `site` jsou WARN; s `--pred-nasazenim` FAIL.

**Verze Node a nástrojů prereq nekontroluje, zajisti je sám:** po klonu, po přepnutí větve a po `devkit update` spusť
`npm ci && npm --prefix spfx ci`. Nástroje (m365 CLI, Playwright, heft) pak mají verze z lockfile. Node mimo rozsah
`engines` instalace odmítne (`EBADENGINE`; `.npmrc` má `engine-strict`): přepni Node a instaluj znovu. `EBADPLATFORM`
u `npm ci` → `npm run lockfix`. Chyba „Cannot find module“ z nástroje kitu = chybí závislosti, spusť `npm ci`.

Přihlášení (otevře prohlížeč, dělá člověk):

```bash
npm run m365 -- login --authType browser --appId <m365.appId> --tenant <m365.tenantId>
```

Přihlášení platí pro projekt (`.m365-home`, gitignored) a worktree téhož repa ho sdílejí; hláška „nepřihlášeno“ řekne,
kde přihlášení žije, i s příkazem. Neovlivní globální m365 ani jiné projekty.

## Verze kitu

`init` zapíše do `project_config.json` klíč `kit`: `verze`, `commit` a u `--prazdny` `varianta: "prazdny"`. Starší
projekt klíč nemá („neznámá verze“, ne chyba). `npm run prereq` varuje, když se `kit.verze` liší od nainstalovaného
pluginu.
„NEVYDANÝ kit“ (hlásí doctor, `devkit init`, `diff` a `update`) = kit běží z pracovní kopie, jejíž commit nemá tag
verze nebo má necommitnuté změny: číslo verze pak neznamená obsah vydané verze.

```bash
node "${CLAUDE_SKILL_DIR}/scripts/devkit.mjs" diff <složka projektu>
```

Jen čte. Porovná projekt se **šablonou nainstalovaného pluginu**: `tools/**`, `spfx/src/app/data/**`,
`spfx/harness/**`, v `package.json` `scripts` a `devDependencies`, a generovaný vzhled. Rozdíl jen v dosazených
tokenech nebo hlavičce generovaného souboru se nehlásí. Výstup `zmeneno|chybi|navic<TAB>cesta`; kód 0 = bez rozdílů,
10 = rozdíly, 2 = chyba použití. Nic nepřepisuje.

**Prázdná varianta** (`init --prazdny`): tatáž šablona bez ukázkové domény (listy `Kategorie` a `Hlaseni`, knihovna
`Prilohy`, jejich data, `texty.json`, ukázkový `App.tsx`). Zůstanou role `owner` a `user`, vestavěné úrovně práv,
stránka `App` a knihovna `Assets` s `logo.svg`; role `editor`, její mapování, lokální uživatel `petr` a vlastní
úrovně (`add`, `edit-all`) odpadnou. Appka je prázdná v `AppShell`; `npm test`, `gen`, `build` a `typecheck`
procházejí. `kit.varianta: "prazdny"` říká `devkit diff`, že vynechané soubory se s šablonou neporovnávají.

## Aktualizace projektu

```bash
node "${CLAUDE_SKILL_DIR}/scripts/devkit.mjs" update <složka projektu>            # plán, jen čte
node "${CLAUDE_SKILL_DIR}/scripts/devkit.mjs" update <složka projektu> --zapsat   # zápis, jen nad čistým git stromem
```

Třícestné porovnání: **základ** (šablona verze `kit.verze`, známá z otisků `templates/otisky.json`), **nová** šablona
nainstalovaného pluginu a **soubor v projektu**. Plán má řádek `druh<TAB>cesta[<TAB>důvod]`:

| druh | kdy | `--zapsat` |
|---|---|---|
| `prevzit` | šablona soubor změnila, projekt ho neměnil | přepíše verzí z kitu |
| `pridat` | nový soubor šablony | přidá |
| `vlastni` | projekt soubor změnil, šablona ne | nechá být (patří do `DEVKIT-VYJIMKY.md`) |
| `konflikt` | změnil ho projekt i šablona, nebo základ není známý | nezapíše; **sluč ručně hned** |
| `zruseno` | šablona soubor zrušila, v projektu zůstal | nemaže; odstraň ručně, až ho nic nepotřebuje |
| `vzhled` | generovaný vzhled se liší od dnešního `ppf-material` | přegeneruje |

Rozsah: nástroje a datová vrstva šablony (`tools/**`, `spfx/` mimo appku), `spfx/src/app/ppf/blocks.tsx`, v
`package.json` klíče `scripts` a `devDependencies`. Obsah projektu (`sp/**`, `project_config.json`, `CLAUDE.md`,
`DEVKIT-VYJIMKY.md`, `App.tsx`, `App.module.scss`) se nikdy nepřebírá. Zápis nic nemaže ani necommituje; projdi
`git diff`, pak `npm ci`, `npm run check-all` a commit. Kódy: 0, 10, 11 (zapsáno, zbyl konflikt nebo `zruseno`),
1 (strom není čistý, projekt není git repo), 2.

**Konflikt sluč hned po `--zapsat`:** zápis posune `kit.verze` a příští `update` tentýž konflikt neohlásí, dokud
šablona soubor nezmění znovu; ukazuje ho dál jen `devkit diff` jako `zmeneno`. Projekt bez známého základu (starší
než 0.5.0 nebo bez `kit`) má všechno, co se liší, jako `konflikt` a převzetí je ruční. Co aktualizace nepřevezme,
říkají poznámky k vydání kitu.

## Výjimky

`DEVKIT-VYJIMKY.md` v kořeni projektu je jediné místo, kde se projekt smí od pravidel kitu odchýlit (tabulka: ID,
pravidlo, rozsah, důvod, schválil, kdy se zruší, nahlášeno do kitu). Agent položku jen **navrhne**; schvaluje ji
člověk (doplní „schválil“ a commitne). Výjimka, která je mezerou kitu, se vrací do kitu jako požadavek.
