# Cockpit: místo, kde vývojář řídí agenta

Cockpit je stránka (artefakt na claude.ai) jednoho projektu. Vývojář v ní vidí, co čeká na něj, co dělá agent
a v jakém stavu je appka na DEV a TEST; rozhoduje kliknutím. Agent do ní zapisuje nástroji `Artifact`
a `ArtifactData`, **nikdy nerozhoduje za člověka**: do kolekce `rozhodnuti` zapisuje jen stránka. Je to pravidlo pro
agenta, ne zámek (pravidla databáze dovolují zápis vlastníkovi a agent píše jeho jménem), proto ho agent dodržuje vždy.
Testerům se cockpit neukazuje; ti píšou připomínky v appce.

Potřebuje Claude Code přihlášený účtem claude.ai; agent bez artefaktů claude.ai (GitHub Copilot CLI) používá místní
cockpit nad JSON soubory v projektu (§Místní cockpit na konci). Cockpit je **podmínka každého nasazení, i na DEV**: prázdné
`project_config.json` → `cockpit.url` hlásí `npm run prereq` (WARN, s `--pred-nasazenim` FAIL), `doctor --pred-nasazenim`
(`CHYBA c-url`) i plán nasazení (nález `cockpit`, `--confirm` zápis odmítne). Lokální vývoj nad mocky jde i bez něj.

**Stránka agenta neprobudí.** Agent cockpit čte (a) na začátku každé práce s projektem (`npm run prereq` mu URL
připomene) a (b) kdykoli člověk v chatu řekne „cockpit“ / „přečti cockpit“. Čtení je idempotentní: nevyřízené věci se
poznají ze stavu dokumentů, ne z vlajek (§Co agent udělá po přečtení).

## Založení (jednou na projekt)

1. Zkopíruj `${CLAUDE_SKILL_DIR}/templates/cockpit.html` do `.devkit/cockpit.html` (gitignored).
2. Publikuj nástrojem `Artifact` (`file_path` = `.devkit/cockpit.html`, `icon: "checklist"`, `contract` vynechaný)
   s capabilities (změna pravidel = republish s **celou** sadou; kořenové pravidlo zavře i kolekce, které tu nejsou):
   ```json
   { "db": { "rules": [
       { "path": "", "read": "view", "write": "owner" },
       { "path": "meta", "read": "view", "write": "owner" },
       { "path": "prostredi", "read": "view", "write": "owner" },
       { "path": "zadani", "read": "view", "write": "owner" },
       { "path": "otazky", "read": "view", "write": "owner" },
       { "path": "ukoly", "read": "view", "write": "owner" },
       { "path": "rozhodnuti", "read": "view", "write": "owner" } ] },
     "user": {}, "assets": {} }
   ```
   `owner` = jen vlastník artefaktu (ten, kdo projekt vede). Přizvaný editor data nezapíše, **ale smí publikovat novou
   verzi stránky s volnějšími pravidly**; proto cockpit sdílej nejvýš jako Viewer a zakládej ho ve vlastním prostoru,
   ne v kanálu nebo projektu (tam je `owner` každý, kdo tam smí psát).
3. `npm run cockpit` a `ArtifactData set` `meta/projekt` s `file_path: .devkit/cockpit/projekt.json` (existující dokument
   také `set` s `if_version`, **ne `update`**: ten slučuje do hloubky a nechal by v dokumentu pole, která export už
   nenese). Do `meta/projekt` nepatří nic jiného než export. Stránka ukáže pod hlavičkou složku, remote, větev a commit
   a upozorní na dočasnou složku, repozitář bez remote a necommitnuté změny. Opakuj na začátku každé session a po
   změně větve.
4. URL cockpitu do `project_config.json` → `"cockpit": { "url": "https://claude.ai/artifact/…" }` a commit.
   Další session ho najde tam; nový cockpit nezakládej.

## Datový model (db)

Všechno čte každý, zapisuje jen vlastník. Agent zapisuje přes `ArtifactData` (existující dokument vždy s `if_version`
z posledního čtení), stránka zapisuje jen `rozhodnuti/*` a nové `zadani/*`.

| Dokument | Zapisuje | Obsah |
|---|---|---|
| `meta/projekt` | agent z `npm run cockpit` | `{schema, nazev, prefix, web, prace}`; `nazev` a `prefix` z `project_config.json`, `web` vždy `null` (adresa webu je u prostředí), `schema` = verze schématu dat, `prace` = `{slozka, docasna, repo{remote, vetev, commit, dirty}, kdy}` (jen jméno složky, ne cesta ani stroj) |
| `meta/obsah` | agent | co v appce je, pro záložku **Appka** (role, matice „kdo co smí“, objekty po kategoriích s popisem, strukturou a ukázkou dat): `{role[], data[], stranky[], kdy}`. Vyrábí ho `npm run cockpit` z manifestu v gitu do `.devkit/cockpit/obsah.json`; zapiš `set` s `file_path` po každé změně manifestu. Popis objektu bere z `popis` (jinak `pozn`) v manifestu — piš ho pro člověka: k čemu objekt slouží. Ukázka dat = první řádky ze `sp/data/config`, jinak ze `sp/data/seed`. Je to obraz gitu, ne stav webu |
| `meta/agent` | agent | `{text, kdy}` — poslední zpráva agenta („Implementuji #3 ve větvi…“). Stránka ukáže jen „naposledy kdy“ |
| `prostredi/<env>` | agent z `npm run cockpit` | `{env, site, stav, stranky[], nasazeni{verze,kdy,commit,dirty}, pripominky{synchronizovano, souhrn, vlakna[]}, exportovano}` — jeden dokument na **každé** prostředí z `project_config.json` (kromě `local`), i vyřešená vlákna. `stav`: `nezalozeno` (prostředí nemá `site`; `nasazeni` a `pripominky` jsou `null`), `necteno` (web nešel přečíst, příkaz skončí kódem 11), `nenasazeno` (web je, záznam o nasazení ne), `nasazeno` |
| `zadani/<id>` | stránka (`faze: nove`, jen `verbatim`) nebo agent | `{nazev, faze: nove\|navrh\|schvaleno\|hotovo, verbatim, zdroj{jak: chat\|cockpit}, vytvoreno, casti[{id, nazev, kolo, text, body[], obrazky[{url,popis}]}]}`; v `text` jsou po sobě jdoucí řádky `\| a \| b \|` tabulka (první řádek záhlaví) |
| `otazky/<id>` | agent | fronta **Rozhodnutí** (první sekce stránky): `{nazev, text, moznosti[{id,text}], doporuceni, kolo, vytvoreno, vazba{ukol, zadani[{id, cast}]}, uzavreno}`. Bez `moznosti` = člověk odpoví textem (`rozhodnuti/otazka:<id>` má pak `moznost: null` a odpověď v `komentar`). `vazba.zadani` vyplň vždy: stránka u rozhodnutí vypíše dotčená zadání a části a u části ukáže, že na rozhodnutí čeká. Volitelné `poradi` (číslo, menší = výš). **Všechno, co potřebuješ od člověka rozhodnout nebo dodat, patří sem, ne jen do chatu** (členové rolí, export dat, volba mezi cestami) |
| `ukoly/<id>` | agent | viz §Připomínka; id `p-<env>-<Id připomínky>` (starší `p<Id>` zůstávají) |
| `rozhodnuti/<klíč>` | **jen stránka** (agent nikdy; databáze to nevynucuje) | úkol `rozhodnuti/<ukolId>` `{navrh{vysledek,komentar,kolo,kdy}, prevzeti{…}}`; část zadání `rozhodnuti/zadani:<id>:<cast>` `{vysledek: schvaleno\|vraceno, komentar, kolo, kdy}`; připomínka `rozhodnuti/pripominka:<env>-<Id>` `{vysledek: prijato\|odlozeno, komentar, kdy}`; otázka `rozhodnuti/otazka:<id>` `{vysledek: zvoleno\|vraceno, moznost, komentar, kolo, kdy}` |

**Kolo.** Rozhodnutí platí jen pro shodné `kolo`. Každé nové předložení téže věci = `kolo + 1`: u úkolu `kolo`
(návrh) a `implementace.kolo` (převzetí), u části zadání `casti[].kolo`, u otázky `kolo`. Změna textu bez zvýšení
kola nechá staré rozhodnutí platit; proto po každé úpravě kolo zvedni. Vrácené rozhodnutí z minulého kola stránka
ukáže jako komentář.

## Verze šablony

Stránka nese v záhlaví `<meta name="cockpit-template" content="N">` a `<meta name="cockpit-schema" content="N">`.
Na začátku práce s projektem přečti publikovanou stránku nástrojem `Artifact` (`action: "read"`, `url`
z `project_config.json`) a porovnej její `cockpit-template` s `${CLAUDE_SKILL_DIR}/templates/cockpit.html`. Je-li
v kitu vyšší (nebo `meta/projekt.schema` vyšší než `cockpit-schema` publikované stránky), zkopíruj šablonu do
`.devkit/cockpit.html` a republikuj (`Artifact` s `url`, stejné capabilities se `rules`, `contract` vynechaný; viz
§Založení), pak `npm run cockpit` a `set` `meta/projekt` a `prostredi/<env>`. Data zůstávají. Stránka, která dostane
data s vyšším `schema`, než zná, je ukáže jen ke čtení. Kdy se čísla zvedají a přechody starších stránek:
`docs/vnitrek-nastroju.md` §Cockpit v repu kitu.

## Deník rozhodnutí v gitu

Rozhodnutí člověka žijí v databázi artefaktu; do gitu se z ní přenáší jednosměrně (db → git), aby byla dohledatelná
i po zániku artefaktu. **Kdy:** po přečtení cockpitu (po každém `ArtifactData list`), než commituješ změny kódu; soubory
v `docs/cockpit/` se commitují spolu s nimi (`git add -- docs/cockpit`).

1. Z výpisů `ArtifactData list` sestav JSON soubor (třeba `.devkit/cockpit/db.json`):
   `{ "rozhodnuti": [...], "zadani": [...], "otazky": [...], "ukoly": [...] }`. Každá kolekce je pole položek
   `{ "id": "<id dokumentu>", "data": { …pole dokumentu… } }` (stačí i plochý tvar `{ "id", …pole }`, nebo mapa
   `id → data`). Chybějící kolekce se bere jako prázdná. Tvar výpisu nástroje `ArtifactData` tu není ověřený;
   pokud se liší, převeď ho na tento tvar.
2. `npm run cockpit -- --log .devkit/cockpit/db.json` (bez sítě). Přidá nové řádky do `docs/cockpit/rozhodnuti.jsonl`
   (jen přidává, LF, klíče JSON abecedně, jedno rozhodnutí = jeden řádek
   `{"klic","typ","vysledek","kolo","kdy"[,"moznost"]}`) a přepíše snapshoty `zadani.json`, `otazky.json`, `ukoly.json`.
   Opakovaný běh nad týmž exportem nepřidá nic; totožnost záznamu je klíč + kolo + výsledek + čas.
3. Klíč: `<ukol>.navrh`, `<ukol>.prevzeti`, `zadani:<id>:<cast>`, `pripominka:<env>-<Id>`, `otazka:<id>`.

**Bez osobních údajů.** Z databáze se kopírují jen pole z bílého seznamu: doslovná zadání a připomínky (`verbatim`),
komentáře, odpovědi textem, autoři, obrázky se do gitu nikdy nedostanou; úkoly jsou jen odkaz (id, číslo, název, fáze,
kolo). Texty částí zadání a otázek píše agent a v gitu jsou: nepiš do nich jména, e-maily ani jiné identifikátory lidí
(takové věci patří do odpovědi textem, která se nepřenáší).

## Co agent udělá po přečtení cockpitu

`ArtifactData list` nad `zadani`, `otazky`, `ukoly`, `prostredi`, `rozhodnuti`, pak podle stavu:

| Nález | Krok |
|---|---|
| `zadani` s `faze: nove` | projdi zadání podle [app-design.md](app-design.md), `update` na `faze: navrh` s `casti` (§Zadání) |
| část zadání: rozhodnutí pro aktuální kolo `vraceno` | uprav část podle komentáře, `kolo + 1` |
| všechny části schváleny a `faze: navrh` | `faze: schvaleno`, pak stav (manifest, `gen`, kód, harness); hotovo → `faze: hotovo` |
| `rozhodnuti/pripominka:<env>-<Id>` `prijato` a žádný úkol se `zdroj.pripominka` = `<env>-<Id>` | založ úkol (§Připomínka) |
| `rozhodnuti/<ukol>.navrh` `schvaleno` pro aktuální kolo a `faze: navrh` | větev, implementace, obrázky po, `faze: implementovano` |
| `…navrh` `vraceno` | uprav výklad/kritéria, `kolo + 1`, zůstává `navrh` |
| `…prevzeti` `prijato` pro `implementace.kolo` a `faze: implementovano` **a úkol má `vetev`** | merge, verze, build, deploy DEV, `faze: nasazeno` + `nasazeni` |
| `…prevzeti` `vraceno` | oprav ve větvi, nové obrázky po, `implementace.kolo + 1` |
| `rozhodnuti/otazka:<id>` `zvoleno` pro aktuální kolo a otázka bez `uzavreno` | jednej podle `moznost`, pak `uzavreno: true` |

Úkol bez `vetev` je ze staršího toku (nasazeno před převzetím): převzetí je konečné, nic nenasazuj.
Po každém větším kroku `set` `meta/agent` `{ text, kdy }` (co jsi udělal a co děláš dál).

## Zadání → návrh po částech

Zadání přijde v chatu (agent ho zapíše rovnou jako `faze: navrh`) nebo z formuláře v cockpitu (`faze: nove`).
`verbatim` je text člověka beze změn. Agent podle [app-design.md](app-design.md) sepíše `casti`, každou
schvaluje člověk zvlášť:

1. **Role a kdo co smí** — role, kdo je kdo na DEV/TEST, tabulka list × role × úroveň.
2. **Data** — listy, `class`, klíčové sloupce, co se kam ukládá a proč (rozhodnutí v samostatném listu).
3. **Stránka a obrazovky** — záložky, karty, akce; obrázek = náčrt z harnessu (Playwright screenshot nahraný
   jako asset) nebo textový popis, když ještě nic neběží.
4. **Nasazení** — prostředí, kdo testuje, co je „hotovo“.

Nejasnosti nepiš jako domněnky: založ `otazky/<id>` s možnostmi a `vazba.zadani`. Staví se až po schválení
všech částí; co člověk vrátil, přepiš a zvedni `kolo` jen u té části.

## Připomínka → úkol → větev → převzetí → nasazení

1. **Synchronizace:** `npm run cockpit` (všechna prostředí se `site`, nebo `-- --env dev`) zapíše
   `.devkit/cockpit/<env>.json`. Pak `ArtifactData get prostredi/<env>` (verze) → `set` s `file_path`
   a `if_version` (nový dokument bez něj). Stránka ukáže pás prostředí a připomínky s **Přijmout / Odložit**;
   DEV a TEST se liší prefixem (`dev-1` ≠ `test-1`).
2. **Úkol** po přijetí (`rozhodnuti/pripominka:<env>-<Id>` = `prijato`): obrázek před
   (`npm run probe -- --env <env> --page <klíč> --shot .devkit/pred-<id>.png`, u jiné role harness), nahraj
   (`Artifact` s `url` cockpitu, `asset: true`, `file_paths`), `ArtifactData set` `ukoly/p-<env>-<Id>`:
   ```json
   { "cislo": 2, "nazev": "krátký název", "kolo": 1, "faze": "navrh", "vytvoreno": "<ISO>",
     "zdroj": { "autor": "…", "kdy": "…", "prostredi": "dev", "verze": "1.0.0.2", "kotva": "formular", "pripominka": "dev-5" },
     "verbatim": "<připomínka přesně, včetně odpovědí>", "vyklad": "<co udělám, co neudělám, otázky>",
     "kriteria": ["ověřitelná věta"], "pred": [{ "url": "/_blob/…", "popis": "DEV, role it" }] }
   ```
   `verbatim` se nezkracuje. **Bez schválení nic neimplementuj.**
3. **Schváleno** (`navrh.schvaleno`): `git switch -c ukol/<id>`, implementace, `npm run check-all`, `npm run build`,
   obrázky po ze **stejného záběru** z harnessu (`npm run dev`, Playwright `?user=<role>`), nahraj,
   `update` úkolu: `faze: implementovano`, `vetev`, `po`, `implementace: { kolo: 1, commit, poznamka, kdy }`.
   Na DEV se zatím nic nenasazuje.
4. **Převzato** (`prevzeti.prijato`): merge do `main`, zvedni `solution.version`, `npm run build`,
   `npm run deploy -- --env dev`. Plán jen balíček + stránky = převzetí je souhlas (jediná výjimka z pojistky 2
   „plán ukaž člověku“ ve SKILL.md §Pojistky); jiný plán → `otazky/*` s možnostmi nebo ano v chatu. Pak `--confirm`,
   sonda (záznam o nasazení zapíše nasazení samo na web, do gitu nic), `update` úkolu: `faze: nasazeno`,
   `nasazeni: { env, verze, commit, kdy }`; `npm run cockpit` znovu.
   **Vráceno:** oprav ve větvi, nové obrázky po, `implementace.kolo + 1`.
5. Testerovi odpovídá a vlákno v appce uzavírá člověk; po dalším `npm run cockpit` je vlákno „Vyřešeno v appce“.

## Konflikty a volby

Když plán hlásí `konflikt` (git × web), nebo je víc rozumných cest, nerozhoduj: `ArtifactData set` `otazky/<id>`
`{ nazev, text, moznosti: [{id:"git", text:"Přepsat web verzí z gitu (--prefer-git)"}, {id:"web", text:"Převzít web do gitu (pull --write)"}], doporuceni, kolo: 1, vytvoreno, vazba: { ukol } }`.
Člověk vybere, agent při dalším čtení jedná a nastaví `uzavreno: true`. Vrácení otázky (s komentářem) = přeformuluj, `kolo + 1`.

## Stavy v cockpitu (odvozené)

| Položka | Stav | Ukáže |
|---|---|---|
| zadání | `nove` / části bez rozhodnutí / vše schváleno, `navrh` / `schvaleno` / `hotovo` | Čeká na agenta / Čeká na tebe: N částí / Vše schváleno, agent začne stavět / Schváleno, agent staví / Postaveno |
| otázka | bez volby / `zvoleno` / `uzavreno` | Čeká na tvou volbu / Rozhodnuto: … / Vyřízeno |
| připomínka | bez rozhodnutí / `prijato` bez úkolu / úkol existuje / `odlozeno` / vlákno Vyřešeno | Nová, rozhodni / Přijato, agent založí úkol / Úkol #n · stav / Odloženo / Vyřešeno v appce |
| úkol | `navrh` bez rozhodnutí / vráceno / schváleno / `implementovano` bez převzetí / převzato s větví / `nasazeno` / `zruseno` | Čeká na tvé schválení / Vráceno agentovi / Schváleno, agent pracuje ve větvi / Hotovo ve větvi, zkontroluj náhled po a převezmi / Převzato, agent slučuje a nasazuje / Nasazeno na DEV x.y / Zrušeno |

Filtr „Čeká na mě“ = jen položky s tlačítkem. Vrácení (část, úkol, otázka) vyžaduje komentář; odložení ne.

## Místní cockpit (agent bez artefaktů claude.ai)

Pro agenta, který nástroje `Artifact` a `ArtifactData` nemá (GitHub Copilot CLI). Je to **tatáž stránka a tatáž data**,
jen místo databáze artefaktu jsou JSON soubory v projektu a stránku vydává malý server kitu na tomto stroji. Všechno
výše (datový model, kolo, co agent udělá po přečtení, zadání, připomínky, konflikty, stavy) platí beze změny; liší se
jen to, čím se čte a zapisuje. Projekt má cockpit buď na claude.ai, nebo místní, ne oba.

**Založení (jednou na projekt)**

1. Do `project_config.json` zapiš `"cockpit": { "url": "local" }` a commitni. Kontroly před nasazením tím projdou.
2. Zkopíruj `templates/cockpit.html` ze složky skillu do `.devkit/cockpit.html` (gitignored). Stejně při vyšší verzi
   šablony v kitu (§Verze šablony); republish odpadá, server čte soubor při každém dotazu.
3. `npm run cockpit` zapíše `meta/projekt`, `meta/obsah` a `prostredi/<env>` rovnou do místní databáze. Opakuj na
   začátku každé session, po změně větve a po změně manifestu.
4. Server spouští **člověk**, nebo agent po jeho ano: `npm run cockpit -- --serve`. Běží do ukončení, poslouchá jen
   na `127.0.0.1`, port vybere systém; adresu vypíše a zapíše do `.devkit/cockpit/adresa.txt`. Tu adresu dej člověku.

**Data:** `.devkit/cockpit/db/<kolekce>/<id>.json`, jeden dokument = jeden soubor, kolekce a tvary podle §Datový model.

| Místo nástroje | Udělej |
|---|---|
| `ArtifactData list <kolekce>` | přečti soubory ve složce `.devkit/cockpit/db/<kolekce>/` |
| `ArtifactData get` / `set` / `update` | přečti / zapiš / uprav soubor `<id>.json` (celý platný JSON; `if_version` tu není) |
| nahrání obrázku (`asset: true`) | ulož ho do `.devkit/cockpit/soubory/<jméno>.png` a do dokumentu dej `url: "soubory/<jméno>.png"` |
| deník rozhodnutí z výpisů | `npm run cockpit -- --log` (bez souboru; čte místní databázi) |

- **Do `rozhodnuti/` nikdy nezapisuj**, stejně jako u artefaktu. Zapisuje tam jen stránka přes server; ten jí nic
  jiného než rozhodnutí a nové zadání zapsat nedovolí. Tvoje soubory server nehlídá: pravidlo dodržuješ ty.
- Jméno souboru rozhodnutí má dvojtečku zapsanou jako `%3A`: klíč `otazka:o1` je soubor `otazka%3Ao1.json`,
  `zadani:z1:data` je `zadani%3Az1%3Adata.json`. Id dokumentů, které zakládáš ty, piš jen z písmen, číslic, `-` a `_`.
- Stránka si změny v souborech načte sama do několika vteřin; rozhodnutí člověka najdeš v souboru hned po kliknutí.
- Server neběží = stránka se neotevře, data zůstávají v souborech. Cockpit je jen na tomto stroji a nikomu dalšímu se
  odkazem neukáže. `.devkit/` není v gitu: dohledatelnost rozhodnutí drží deník v `docs/cockpit/`.
