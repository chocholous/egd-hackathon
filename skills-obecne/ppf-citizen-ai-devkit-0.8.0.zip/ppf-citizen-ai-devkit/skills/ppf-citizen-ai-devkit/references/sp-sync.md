# Nasazení: plán, zápis, ověření, sonda, připomínky, ruční m365

Pojistky nasazení jsou v SKILL.md §Pojistky a tady se neopakují. Co se nasazuje (manifest, práva, výchozí sada,
tříbodové porovnání): [manifest.md](manifest.md). Vnitřek nástrojů (propagace balíčku, otisk, tvar záznamu) je
pro správce kitu v `docs/vnitrek-nastroju.md` repa kitu.

## Postup

```bash
npm run sp -- plan --env dev                      # jen čte: struktura, práva, konfigurace, stránky + nálezy
npm run build                                     # po zvednutí solution.version (nový kód appky)
npm run deploy -- --env dev                       # plán nasazení = balíček + totéž co sp plan; hash
npm run deploy -- --env dev --confirm <hash>      # zápis přesně toho plánu; na konci kontrolní plán
npm run probe -- --env dev                        # sonda stránek appky (příkaz vypíše i nasazení)
```

Plán nasazení má akce v pořadí balíček → struktura → práva → konfigurace → stránky:

| oblast | zdroj | akce |
|---|---|---|
| struktura | manifest | založit list/knihovnu a sloupce, titul, Read/WriteSecurity, verze, přílohy, bezpečné změny sloupců; rizikové = nález |
| práva | manifest + `environments.<env>.roles` | úrovně oprávnění, skupiny rolí, členové, dědičnost, přiřazení ([manifest.md](manifest.md) §Práva) |
| konfigurace | `sp/data/config`, `sp/assets/config` | přidat/upravit/do koše položku podle klíče, nahrát asset |
| výchozí sada | `sp/data/initial` | vložit chybějící klíč ([manifest.md](manifest.md) §Výchozí sada) |
| stránky | manifest `pages` + `environments.<env>.values` | založit stránku appky, vložit web part, nastavit vlastnosti, publikovat |

Provozní obsah se nečte ani nemění. Co kit odebírá (vždy jen podle gitu a vždy viditelně v plánu):

| co | vratné |
|---|---|
| položka konfiguračního listu odebraná z gitu (na webu beze změny od nasazení) | ano, z koše |
| asset konfigurační knihovny odebraný z gitu | ano, z koše |
| přiřazení práv na listu s vlastními právy, které git nezná | **ne** — znovu přidat |
| vlastní práva listu s `access: "inherit"` (obnovení dědičnosti) | **ne** |

Při ukázání plánu s těmito dvěma akcemi práv řekni člověku, že jsou nevratné (SKILL.md §Pojistky 4).

**Balíček.** Stejná `solution.version`, jaká už je v katalogu, se nenahrává (nový kód = zvednout verzi, nebo vědomě
`--same-version`). Plán se ptá na otisk kódu (`spfx/src`, `spfx/config`, `spfx/harness`; čas souborů ani commit
nerozhodují, takže `gen`, `dev`, `typecheck`, `design-check` ani commit nic nezneplatní):

| kontrola | nález | co dál |
|---|---|---|
| balíček vznikl z dnešního kódu přes `npm run build` | `block` „neodpovídá kódu“ | `npm run build` (balíček postavený jinak plán odmítne) |
| stejná verze = stejný kód jako na webu | `block` „verze už na webu je, ale z jiného kódu“ | zvednout `solution.version`, nebo vědomě `--same-version` |
| úplná kontrola vzhledu dnešního kódu | `vzhled` (mimo DEV `block`) | `npm run design-check` |

Web nasazený před 0.5.1 otisk v záznamu nemá: plán to u stejné verze vypíše jen jako upozornění.

**Katalog.** Web musí mít site collection app catalog; přidat ho smí jen správce SharePointu. Bez něj plán skončí
`STAV: blokováno` s nálezem `katalog` (vypíše i `nejdřív deploy` a „balíček — beze změny“, protože akce balíčku
vynechal). Vyber jiný web nebo požádej správce; nehledej obchvat přes tenant katalog.

**Poprvé** se web part na stránku dostane, až je balíček na webu nainstalovaný; když se po instalaci ještě
nepropagoval, zápis skončí hláškou a stačí plán a nasazení zopakovat.

## Výsledek

Poslední řádek plánu, nasazení i `npm run sp -- plan` je právě jeden z:

| řádek | význam |
|---|---|
| `STAV: prázdný` | web odpovídá gitu, nic k zápisu ani k rozhodnutí |
| `STAV: akce` | plán má akce (u kontrolního plánu: po zápisu ještě něco chybí) |
| `STAV: nálezy` | žádné akce, ale nálezy čekají na člověka (u kontrolního plánu i zbylé `navíc`) |
| `STAV: blokováno` | plán má blokující nález (`git`, `cockpit`, `katalog`, `nástroje`, nález balíčku, mimo DEV i vzhled); výpis je má v prvním oddílu `## BLOKUJE ZÁPIS`, řádek potvrzení s `--confirm` chybí, kód 10. Odstraň příčinu a spusť plán znovu |
| `STAV: chyba` | nic nebo jen část se nezapsala: selhání uprostřed, odmítnutí (`git`, hash, nález balíčku), chyba manifestu nebo m365 |

Kódy: 0 = plán prázdný, nebo zápis proběhl a kontrolní plán je prázdný; 1 = zápis selhal nebo byl odmítnut, nezapsal
se záznam, chyba manifestu nebo m365; 2 = špatné použití; 10 = jen plán, **nic se nezapsalo**; 11 = po `--confirm`
**zapsáno**, ale kontrolní plán není prázdný (zbylé `navíc`, odchylka, konflikt, migrace nebo akce).
S `sp plan --json` je `STAV` na stderr a v JSON pole `stav` a `blokuje`.

Hash plánu stav gitu neobsahuje: po commitu a pushi platí stejný hash, pokud se akce nezměnily. Po jakékoli změně
akcí je to nový plán a nové schválení.

**Po zápisu** kontrolní plán musí vyjít prázdný (kód 0; zbylé `navíc` ukaž člověku, kód 11) a druhé nasazení hned
po prvním také. Pak sonda.

**Nasazení spadlo uprostřed:** vypíše, co proběhlo; spusť znovu plán (je idempotentní).

**Záznam o nasazení.** Po akcích zapíše nasazení do konfigurační knihovny appky `_deploy/<env>.json` (poslední stav,
čte ho každý plán) a řádek `_deploy/<env>.historie.jsonl`. Do gitu se nic nezapisuje. Projekt založený před 0.6 má
historii v `releases/<env>.jsonl`: první nasazení ji převezme a soubor nechá být. `ZÁZNAM O NASAZENÍ SELHAL`
(kód 1) = akce proběhly, chybí záznam: oprav příčinu z hlášky a nasaď znovu.

## Časový limit

Jedno volání m365 v nástrojích kitu smí trvat nejvýš `m365.timeoutS` (nahrání balíčku `m365.timeoutBalicekS`).
Po vypršení se volání **neopakuje** (zápis mohl na serveru doběhnout a zápisy položek a sekcí stránky nejsou
idempotentní): nasazení se zastaví s hláškou „výsledek neznámý“ a záznam se nezapíše. **Neopakuj akci ani hned
nepotvrzuj znovu**: počkej pár minut a spusť nový plán, ten ukáže skutečný stav. Průchozí `npm run m365` limit nemá.

## Sonda

```bash
npm run probe -- --env dev                  # všechny stránky appky z manifestu
npm run probe -- --env dev --page App       # jedna stránka; --url <adresa> libovolná stránka webu
```

Sonda otevře stránku pod uloženou session s `?env=WebView` (jak appku uvidí uživatel), vypíše HTTP stav, chyby web
partu, chyby konzole appky a selhané požadavky a uloží screenshot do `.devkit/`. Exit ≠ 0 = něco selhalo. **Otevři
PNG i text**, než prohlásíš, že stránka funguje. Hned po nasazení může ukázat starý bundle (propagace 15–30 s):
počkej a zopakuj. Nenačtený font ikon je varování.

**Přihlášení sondy kit nedělá.** Sdílenou session `~/.config/spo-auth/state-<tenant>.json` zapisuje jen skill
`ppf-browsermagic`: jednou SETUP podle skillu, pak `SITE_URL=<adresa webu> node .ppf-session-magic/auth-refresh.mjs`
(PowerShell: `$env:SITE_URL="<adresa webu>"; node .ppf-session-magic/auth-refresh.mjs`). Dělá ho člověk (prohlížeč,
MFA), vydrží dny. Sonda končící na přihlašovací stránce = prošlá session, stejný příkaz.

Sonda běží na Chromiu Playwrightu z projektu (chybí → `npx playwright install chromium`); když nejde spustit, zkusí
Microsoft Edge.

## Připomínky

S `"feedback": true` (výchozí) přidá nasazení na DEV/TEST list `<PREFIX>-Pripominky` a úroveň `pripominky`
(schéma je v kódu kitu; do manifestu je nepiš, vlastní list nebo úroveň s tím jménem je chyba) a appka dostane vrstvu,
ve které testeři píšou připomínky k jejím prvkům. Tlačítko „Připomínky“ má místo v liště `AppShell`. Kde vlastnost
`pripominky` chybí (produkce), se vrstva vůbec nenačte.

- Kód appky jen označí části `data-cadk-id="<jméno>"` (stabilní, čitelné) a řádky seznamů `data-cadk-key={item.Id}`.
  Prvek bez kotvy připomínku nepřijme. Kotvy přejmenovávej jen vědomě: staré připomínky ztratí špendlík.
- `npm run feedback -- --env dev` vypíše otevřená vlákna jako markdown (stránka, verze, kotva, text, autor,
  odpovědi), `--all` i vyřešená, `--json` strojově. Kotvu najdeš `rg 'data-cadk-id="<kotva>"' spfx/src`, opravíš
  a nasadíš. Odpovídá a vlákno uzavírá člověk v appce (zápis do listu připomínek z příkazové řádky kit nemá).
- Přenos do cockpitu a tok úkolů: [cockpit.md](cockpit.md) §Připomínka.

## Ruční m365

Nasazení dělá `npm run deploy`; ruční m365 je na dotazy a diagnostiku. Spouštěj ho vždy z kořene projektu:

```bash
npm run m365 -- <příkaz> --help          # nápověda pro pinnutou verzi projektu
npm run m365 -- <příkaz> --output json   # běh
npm run -s m365 -- <příkaz> --output json | jq …   # strojové čtení: -s vynechá hlavičku npm před JSON
```

**Wrapper je průchozí: tenant neověřuje a nic nefiltruje** (SKILL.md §Pojistky 6 a 7). Zápis jen po ano člověka
s přesným příkazem ukázaným předem; co jde přes manifest, patří do manifestu. Holé `m365` ani `npx` nepoužívej,
ani wrapper skillu `m365-cli-12` (jiné přihlášení, bez ověření tenantu). Volby příkazů a pasti CLI 12 má skill
`m365-cli-12` (závislost kitu); ověřuj je `npm run m365 -- <příkaz> --help`.

Chybí-li přihlášení, hláška „m365 není přihlášené“ (`prereq`, `deploy`, `sp`) uvede, kde přihlášení žije, a přesný
příkaz `npm run m365 -- login …`, který spouští člověk. Worktree téhož repa přihlášení sdílejí.

| Výstup | Příčina | Co dělat |
|---|---|---|
| `Invalid option` / `Unrecognized key` | volba neexistuje | `--help` k příkazu |
| `{"error":{}}` s exit 0 | skrytý HTTP stav, typicky 401 | `--debug 2>&1 \| rg -i '"status"\|www-authenticate'`; nejčastěji jiný tenant nebo hostname → `npm run prereq` |
| `Attempted to perform an unauthorized operation.` | chybí role na webu | oprávnění, ne syntaxe — příkaz nepřepisuj |
| `{"error":{"name":"ExitPromptError"}}` | destruktivní příkaz čeká na potvrzení | neproběhl; zeptej se člověka, `--force` nepřidávej |
| `… nedoběhlo do N s … výsledek neznámý` | vypršel `m365.timeoutS` | nic neopakuj; počkej, pak nový plán |
| `[]` nebo prázdno s exit 0 | opravdu prázdné, špatný web/list, nebo nepřihlášený — vypadá stejně | `npm run prereq`, pak ověř, že cíl existuje (`spo web get`, `spo list get`) |

Výsledek parsuj ze stdout, exit kódu nevěř.

**Pasti, které hrozí smazáním nebo přepisem cíle** (změřeno na DEV web, CLI 12.0.0):

- `spo list remove --title` hledá **titul**, ne URL (titul `CADK-Hlaseni` ≠ URL `Lists/CADKHlaseni`).
- `spo app remove` nepoužívat (neověřeno, zda jde do koše). Úklid balíčku z katalogu: `spo app uninstall --force`,
  `spo app retract --force`, pak soubor `<web>/AppCatalog/<name>.sppkg` do koše
  (`GetFileByServerRelativeUrl(…)/recycle()`).
- `spo listitem add/set` udělá z každé neznámé volby hodnotu sloupce (i z `--query`). Hodnoty dávej jako
  `--<InterníNázev>`, jiné volby než z `--help` nepřidávej.
- `spo app add --overwrite` se **starší** verzí = tichý downgrade; porovnej `solution.version` s `AppCatalogVersion`.
- `spo file add` nepřepíše existující soubor bez `--overwrite`.
- List s lookupem `deleteBehavior: restrict` nejde dát do koše (`recycle()` vrátí 500, ani list, na který odkazuje):
  nejdřív u sloupce přepni `RelationshipDeleteBehavior` na `None` (`spo field set --SchemaXml …`).
- `spo field add --xml`: SharePoint ignoruje `Name` a odvodí interní název z `DisplayName`, pokud nedáš
  `--options AddFieldInternalNameHint`. Sloupce zakládá kit z manifestu; ruční sloupec je nález v plánu.
- `m365 request` předá neznámé volby jako hlavičky: MERGE = `--x-http-method MERGE --if-match *`.
- Ručně s balíčkem: `--appCatalogScope sitecollection` je povinný (výchozí `tenant` → ResourceNotFoundException);
  `--appCatalogUrl` pro add/deploy/retract/remove/list, `--siteUrl` pro install/uninstall/upgrade; `upgrade` bez
  instalace a `install` bez `deploy` jsou tiché no-op.
