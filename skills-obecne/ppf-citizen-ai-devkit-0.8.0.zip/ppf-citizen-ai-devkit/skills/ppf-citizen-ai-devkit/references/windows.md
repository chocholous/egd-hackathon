# Windows

Stav: **neměřeno na Windows stroji.** Obsah je z MS dokumentace, dokumentace Claude Code
a pastí ze 17 konverzací OpRisk (citizen developer na Windows, 2026-10). Až se změří, přepiš.

## Co vyřeší lokální instalace přes npm — a co ne

Vyřeší: dostupnost a verze nástrojů (lockfile), žádný `npm install -g`, žádný admin, žádný PATH.

**Nevyřeší chyby shellu.** PowerShell 5.1 maže vnořené uvozovky v argumentech nativních programů.
PowerShell 7.3+ to opravil (`$PSNativeCommandArgumentPassing = 'Windows'`), ale **jen pro `.exe`**;
`.cmd`/`.bat` zůstávají ve starém režimu — a `npm`, `npx` i `node_modules/.bin/*.cmd` jsou `.cmd`.

Proto v projektu:
- nástroje projektu (`tools/*.mjs`) spouštějí m365 jako `node <cli>/dist/index.js` s **polem argumentů**
  (žádný shell, žádný `.cmd` shim);
- složité vstupy (JSON, XML sloupce, CAML) patří do souboru nebo do manifestu, ne do příkazové řádky;
- agent volá `npm run <skript> -- <jednoduché argumenty>`, ne ručně skládané `m365 … --xml '<…>'`.

## Doporučené prostředí

1. **Git for Windows** (obsahuje Git Bash) a v Claude Code bash místo PowerShellu: nastav uživatelskou
   proměnnou Windows `CLAUDE_CODE_USE_POWERSHELL_TOOL=0` (Desktop může ignorovat `env` v settings.json,
   proto proměnná prostředí, ne settings). Cesta k bash: `CLAUDE_CODE_GIT_BASH_PATH` → `bash.exe`
   (MinGit bash nemá).
2. Když musí zůstat PowerShell: **pwsh 7** (portable zip, bez admina) místo 5.1. Claude Code ho najde sám.
3. Node 22, 24 nebo 26 (doporučeno 26 LTS) z MSI nebo portable zipu; `npm run prereq` ověří verzi.

## Pasti PowerShellu 5.1 (z transkriptů)

| past | obrana |
|---|---|
| `Out-File`/`Set-Content` píší BOM / UTF-16 | soubory zapisuj Node skriptem nebo `[IO.File]::WriteAllText(p, s, [Text.UTF8Encoding]::new($false))` |
| čeština jako mojibake (cp1250) | `chcp 65001`; čti/zapisuj přes Node |
| `$` v `"…"` se rozvine (`$top`, `$filter`) | OData v jednoduchých uvozovkách, nebo v souboru |
| `2>&1` z nativního programu = `NativeCommandError` | nepřesměrovávej stderr, čti exit kód |
| `| Select -First N` zabije proces (exit 255) | výstup do souboru, pak čti |
| české „“ ukončí řetězec | v příkazech jen ASCII uvozovky |
| `ConvertFrom-Json` padá na `Id` a `ID` v jednom objektu | JSON zpracovávej v Node |

## m365 CLI 12 na Windows

CLI 12 drží tokeny v Credential Manageru přes nativní `keytar`. Na Windows to není změřené.
Pin verze se kvůli tomu nemění (`prereq` přijme jen verzi z `package.json` a zbytek kitu s CLI 12 počítá):
kdyby `npm ci` nebo login padal, zapiš přesnou chybu a nahlas ji do kitu.

## Sonda (Playwright)

`npm run prereq` při každém běhu zkusí spustit headless Chromium Playwrightu (kontrola prohlížeče pro sondu).
Na Windows neměřeno; když selže, je to jen WARN a lokální vývoj nebrzdí. Prohlížeč: `npx playwright install chromium`; když to síť blokuje, sonda (`npm run probe`) sama zkusí nainstalovaný Microsoft Edge (`channel: 'msedge'`). Záloha Edge zatím nebyla na Windows změřena a `prereq` ji nezkouší, takže tam WARN může zůstat, i když sonda poběží.
