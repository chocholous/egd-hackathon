import * as React from 'react';
import Link from '@mui/material/Link';
import { DataSource } from './data/types';
import { AppShell, EmptyState } from './ppf/blocks';
import styles from './App.module.scss';

/** Vlastnosti web partu: na SharePointu z instance na stránce (plán je zapíše z manifestu stránek),
 *  lokálně z generated/localProps.ts. Obojí vzniká z téhož sp/app.manifest.json → pages.
 *  pripominky: zapne vrstvu připomínek (jen DEV/TEST, dosadí nasazení kitu; čte ji hostitel, ne App). */
export interface AppProps { napoveda?: string; pripominky?: { list: string; env: string; verze: string } }

// Prázdná appka (devkit init --prazdny): jen rám AppShell. Obrazovky se skládají ze stavebních bloků
// ./ppf/blocks (ppf-material, references/app-design.md §2), data přes DataSource; nové části UI označ data-cadk-id.
export function App({ source, props = {} }: { source: DataSource; props?: AppProps }): React.ReactElement {
  const [ja, setJa] = React.useState('');
  React.useEffect(() => { source.currentUser().then((u) => setJa(u.name)).catch(() => undefined); }, [source]);

  return (
    <div className={styles.root} data-testid="app-app">
      <AppShell title="__APP_NAME__" icon="apps" user={ja}
        actions={props.napoveda ? <Link href={props.napoveda} data-testid="app-napoveda" color="inherit" variant="body2">Nápověda</Link> : undefined}>
        <div data-cadk-id="uvod">
          <EmptyState title="Appka je zatím prázdná" text="Seznamy a stránky doplň v sp/app.manifest.json, obrazovky v spfx/src/app/App.tsx." />
        </div>
      </AppShell>
    </div>
  );
}
