// Data a časy mezi SharePointem a appkou.
// SharePoint vrací sloupce date i datetime v UTC: půlnoc 13. 11. v Praze je "2026-11-12T23:00:00Z".
// `String(v).slice(0, 10)` proto ukáže předchozí den a uložení formuláře termín posune (Tracker 2026-11-11).
// Smlouva DataSource: sloupec typu `date` je v appce vždy 'YYYY-MM-DD' (kalendářní den v místním čase
// prohlížeče = pásmo webu u PPF), `datetime` a Created zůstávají ISO s 'Z' a zobrazují se přes formatDateTime.
const pad = (n: number): string => (n < 10 ? '0' : '') + n;

/** ISO z SharePointu → 'YYYY-MM-DD' v místním čase; 'YYYY-MM-DD' projde beze změny; prázdné → null (jako SP). */
// eslint-disable-next-line @rushstack/no-new-null
export function localDate(v: unknown): string | null {
  if (v === null || v === undefined || v === '') return null;
  const s = String(v);
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  const d = new Date(s);
  if (isNaN(d.getTime())) return s;
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/** 'YYYY-MM-DD' → ISO místní půlnoci (stejně jako formulář SharePointu); jiný tvar projde beze změny. */
export function toSpDate(v: unknown): unknown {
  if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v)) return v;
  const [y, m, d] = v.split('-').map(Number);
  return new Date(y, m - 1, d).toISOString();
}

/** 'd. M. yyyy' (místní kalendářní den) z 'YYYY-MM-DD' i z ISO; prázdné → ''. */
export function formatDate(v: unknown): string {
  const d = localDate(v);
  if (!d) return '';
  const [y, m, dd] = d.split('-').map(Number);
  return `${dd}. ${m}. ${y}`;
}

/** 'd. M. yyyy H:mm' v místním čase z ISO; prázdné → ''. */
export function formatDateTime(v: unknown): string {
  if (v === null || v === undefined || v === '') return '';
  const d = new Date(String(v));
  if (isNaN(d.getTime())) return String(v);
  return `${d.getDate()}. ${d.getMonth() + 1}. ${d.getFullYear()} ${d.getHours()}:${pad(d.getMinutes())}`;
}
