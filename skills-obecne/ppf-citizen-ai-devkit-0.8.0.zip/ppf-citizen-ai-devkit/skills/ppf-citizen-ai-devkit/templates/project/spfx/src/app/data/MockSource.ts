// Lokální zdroj dat: fixtures z gitu (sp/data) + manifest práv + simulovaný uživatel.
// Práva počítá ze STEJNÉHO manifestu, ze kterého deploy staví ACL na SharePointu,
// a zakázaný zápis odmítne jako SP (AccessDenied, status 403).
// Zápis (addItem, updateItem) navíc kontroluje hodnoty proti sloupcům z manifestu: povinná pole (required),
// volby (choice + choices) a typy text, note, number, boolean, date a datetime. Co mock NEKONTROLUJE:
// hodnoty sloupců user a lookup (tvar ani existenci osoby či cílové položky), maxLength, sloupce, které manifest
// nezná (SP je odmítne), data načtená ze seedu a fixtures (ta hlídá validateManifest) a přesné znění chyb SP.
// List bez `fields` v manifestu se nekontroluje vůbec. Výchozí hodnotu (default) mock doplní jen u text, note a choice.
import { AppManifest } from '../manifest';
import { AccessDenied, Action, Attachment, DataSource, GetOptions, Item, Person, PEOPLE_LIMIT, Version } from './types';

/** Příloha položky v mocku: drží se v položce v poli _attachments (jako SP AttachmentFiles; getItems ji appce nevrací). */
interface MockAttachment { name: string; url: string }
async function toDataUrl(data: Blob): Promise<string> {
  const bytes = new Uint8Array(await data.arrayBuffer());
  let bin = '';
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return `data:${data.type || 'application/octet-stream'};base64,${btoa(bin)}`;
}

/** Práva čtyř základních úrovní pro manifest, který úrovně nenese (starší generated/appManifest.ts, testy). */
const ZAKLAD: Record<string, string[]> = {
  read: ['ViewListItems'], add: ['ViewListItems', 'AddListItems'], edit: ['ViewListItems', 'AddListItems', 'EditListItems'],
  'edit-all': ['ViewListItems', 'AddListItems', 'EditListItems', 'CancelCheckout'],
};

/** Verze se v mocku drží v položce v poli _versions (jako přílohy v _attachments); getItems je appce nevrací. */
type Verzovana = Item & { _versions?: Version[] };
/** hodnoty položky bez Id, Created a vnitřních polí mocku (_author, _attachments, _versions) */
const snimek = (i: Item): Record<string, unknown> => {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(i)) if (!k.startsWith('_') && k !== 'Id' && k !== 'Created') out[k] = v;
  return out;
};
/** výchozí verze položky ze seedu, která historii verzí nemá: aktuální stav, autor, Created */
const prvni = (i: Item): Version => ({ verze: '1.0', kdy: String(i.Created ?? ''), kdo: String(i._author ?? ''), pole: snimek(i) });

export interface MockOptions {
  manifest: AppManifest;
  users: Record<string, string[]>; // jméno → role
  user: string;
  data: Record<string, Item[]>; // list → položky (config fixtures + seed)
  assetBase: string; // URL, kde lokální server servíruje sp/assets/config
  /** Data přežijí přepnutí uživatele (?user=…): bez toho by tok mezi rolemi (zadá IT, schválí security)
   *  v harnessu nešel vyzkoušet. Harness dává sessionStorage, takže nová záložka začíná z fixtures. */
  persist?: { storage: Storage; key: string };
  /** hodiny mocku (Created nových položek); harness je posouvá parametrem ?now= kvůli lhůtám */
  now?: () => Date;
}

export class MockSource implements DataSource {
  public readonly label: string;
  private readonly store: Record<string, Item[]>;

  constructor(private readonly o: MockOptions) {
    this.label = `mock · ${o.user} (${(o.users[o.user] || []).join(', ')})`;
    this.store = this.load() ?? {};
    if (!Object.keys(this.store).length) {
      for (const [list, items] of Object.entries(o.data)) {
        this.store[list] = items.map((it, i) => ({ ...it, Id: it.Id ?? i + 1, _author: it._author ?? o.user }));
      }
    }
  }

  private load(): Record<string, Item[]> | undefined {
    try {
      const raw = this.o.persist?.storage.getItem(this.o.persist.key);
      return raw ? (JSON.parse(raw) as Record<string, Item[]>) : undefined;
    } catch {
      return undefined; // úložiště zakázané nebo poškozené → fixtures
    }
  }

  private save(): void {
    try {
      this.o.persist?.storage.setItem(this.o.persist.key, JSON.stringify(this.store));
    } catch {
      /* bez úložiště data platí jen do přepnutí uživatele */
    }
  }

  public async currentUser(): Promise<{ name: string }> {
    return { name: this.o.user };
  }

  /** Práva uživatele na listu: sjednocení práv úrovní všech jeho rolí (SP sčítá oprávnění skupin). Úroveň se bere
   *  z manifest.levels (gen.mjs ji rozepíše z sp/app.manifest.json), jinak ze čtyř základních; neznámá úroveň = žádná práva. */
  private rights(list: string): Set<string> | 'owner' {
    const roles = this.o.users[this.o.user] || [];
    if (roles.includes('owner')) return 'owner';
    const def = this.o.manifest.lists[list] || this.o.manifest.libraries[list];
    if (!def) throw new Error(`neznámý list ${list}`);
    const out = new Set<string>();
    for (const r of roles) {
      const lvl = def.access[r];
      if (!lvl || lvl === 'none') continue;
      for (const p of this.o.manifest.levels?.[lvl]?.rights || ZAKLAD[lvl] || []) out.add(p);
    }
    return out;
  }

  /** Stejné rozhodování jako SpSource.can() nad EffectiveBasePermissions: read = ViewListItems, add = AddListItems,
   *  edit = EditListItems, edit-all = EditListItems + CancelCheckout (Override List Behaviors). */
  public async can(list: string, action: Action): Promise<boolean> {
    const r = this.rights(list);
    if (r === 'owner') return true;
    switch (action) {
      case 'read': return r.has('ViewListItems');
      case 'add': return r.has('AddListItems');
      case 'edit': return r.has('EditListItems');
      case 'edit-all': return r.has('EditListItems') && r.has('CancelCheckout');
    }
  }

  /** CancelCheckout (Override List Behaviors) na SP ruší „jen své položky“ i bez práva úprav (úroveň typu „čtení všeho“).
   *  V kitu neověřeno druhým účtem; převzato z projektu Tracker (viz references/kod.md). */
  private vidiCizi(list: string): boolean {
    const r = this.rights(list);
    return r === 'owner' || r.has('CancelCheckout');
  }

  /** Sloupec s unique: SP odmítne druhou položku se stejnou hodnotou (i položku, kterou uživatel nevidí).
   *  Porovnání bez ohledu na velikost písmen a tvar chyby jsou předpoklad, na tenantu neověřeno (references/kod.md). */
  private checkUnique(list: string, values: Record<string, unknown>, selfId?: number): void {
    for (const f of this.o.manifest.lists[list]?.fields || []) {
      if (!f.unique || values[f.name] === undefined || values[f.name] === null || values[f.name] === '') continue;
      const v = String(values[f.name]).toLowerCase();
      if ((this.store[list] || []).some((i) => i.Id !== selfId && String(i[f.name] ?? '').toLowerCase() === v)) {
        throw new Error(`${list}: hodnota „${String(values[f.name])}“ ve sloupci ${f.name} už existuje (sloupec vyžaduje jedinečné hodnoty)`);
      }
    }
  }

  /** Hodnoty zápisu proti sloupcům z manifestu: povinná pole, volby, typy. `add` hlídá i chybějící povinná pole,
   *  `update` jen ta, která změna nastavuje. Prázdná hodnota (undefined, null, '') typ neporušuje. Meze: hlavička souboru. */
  private checkValues(list: string, values: Record<string, unknown>, mode: 'add' | 'update'): void {
    const prazdne = (v: unknown): boolean => v === undefined || v === null || v === '';
    for (const f of this.o.manifest.lists[list]?.fields || []) {
      const v = values[f.name];
      if (prazdne(v)) {
        const chybi = mode === 'add' ? !f.default : f.name in values;
        if (f.required && chybi) throw new Error(`${list}: sloupec ${f.name} je povinný`);
        continue;
      }
      const spatne = (cekam: string): never => { throw new Error(`${list}: sloupec ${f.name} (${f.type}) čeká ${cekam}, dostal ${JSON.stringify(v)}`); };
      switch (f.type) {
        case 'text': case 'note': if (typeof v !== 'string') spatne('text'); break;
        case 'number': if (typeof v !== 'number' || !Number.isFinite(v)) spatne('číslo'); break;
        case 'boolean': if (typeof v !== 'boolean') spatne('true nebo false'); break;
        case 'date': if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v) || Number.isNaN(Date.parse(v))) spatne('datum RRRR-MM-DD'); break;
        case 'datetime': if (typeof v !== 'string' || Number.isNaN(Date.parse(v))) spatne('datum a čas ISO 8601'); break;
        case 'choice':
          if (typeof v !== 'string') spatne('text');
          if (f.choices && !f.choices.includes(v as string)) throw new Error(`${list}: sloupec ${f.name} nemá volbu „${String(v)}“ (má: ${f.choices.join(', ')})`);
          break;
        default: break; // user, lookup: mock nekontroluje
      }
    }
  }

  /** Výchozí hodnoty sloupců (jako SP při založení položky): jen text, note a choice, kde je default text. */
  private sDefaulty(list: string, item: Item): Item {
    const out: Item = { ...item };
    for (const f of this.o.manifest.lists[list]?.fields || []) {
      if (f.default !== undefined && ['text', 'note', 'choice'].includes(f.type) && (out[f.name] === undefined || out[f.name] === null)) out[f.name] = f.default;
    }
    return out;
  }

  public async getItems(list: string, options?: GetOptions): Promise<Item[]> {
    if (!(await this.can(list, 'read'))) throw new AccessDenied(list, 'read');
    const where = Object.entries(options?.where || {});
    const items = (this.store[list] || []).filter((i) => where.every(([k, v]) => i[k] === v));
    const own = this.o.manifest.lists[list]?.itemScope === 'own';
    // itemScope own = SP ReadSecurity 2: cizí položky vidí jen úroveň s CancelCheckout a vlastníci
    const visible = own && !this.vidiCizi(list) ? items.filter((i) => i._author === this.o.user) : items;
    // kopie bez příloh: appka nesmí držet živý objekt úložiště (po updateItem by neviděla změnu a mohla by úložiště přepsat mimo práva)
    return visible.map((i) => { const c = { ...i } as Verzovana & { _attachments?: unknown }; delete c._attachments; delete c._versions; return c; });
  }

  public async addItem(list: string, item: Item): Promise<Item> {
    if (!(await this.can(list, 'add'))) throw new AccessDenied(list, 'add');
    this.checkValues(list, item, 'add');
    this.checkUnique(list, item);
    const items = (this.store[list] = this.store[list] || []);
    const created: Verzovana = { ...this.sDefaulty(list, item), Id: items.reduce((m, i) => Math.max(m, i.Id || 0), 0) + 1, Created: (this.o.now?.() ?? new Date()).toISOString(), _author: this.o.user };
    if (this.limitVerzi(list)) created._versions = [prvni(created)];
    items.push(created);
    this.save();
    const vratit = { ...created };
    delete vratit._versions;
    return vratit;
  }

  public async updateItem(list: string, id: number, changes: Record<string, unknown>): Promise<void> {
    if (!(await this.can(list, 'edit'))) throw new AccessDenied(list, 'edit');
    const item = (this.store[list] || []).find((i) => i.Id === id);
    if (!item) throw new Error(`${list}: položka ${id} neexistuje`);
    // itemScope own/own-write = SP WriteSecurity 2: cizí položku upraví jen edit-all a vlastníci
    const scope = this.o.manifest.lists[list]?.itemScope;
    if (scope && item._author !== this.o.user && !(await this.can(list, 'edit-all'))) throw new AccessDenied(list, 'edit');
    this.checkValues(list, changes, 'update');
    this.checkUnique(list, changes, id);
    const limit = this.limitVerzi(list);
    // položka ze seedu historii nemá: její stav PŘED úpravou je verze 1.0
    if (limit && !(item as Verzovana)._versions) (item as Verzovana)._versions = [prvni(item)];
    for (const [k, v] of Object.entries(changes)) if (!k.startsWith('_') && k !== 'Id') item[k] = v;
    if (limit) this.pridejVerzi(item as Verzovana, limit);
    this.save();
  }

  /** versioning.majorVersionLimit listu z manifestu; bez něj mock verze nevede (getVersions vrátí jen aktuální stav) */
  private limitVerzi(list: string): number | undefined {
    return this.o.manifest.lists[list]?.versioning?.majorVersionLimit;
  }

  /** Jako SP s verzemi: každá úprava = nová hlavní verze (kdo = editor, kdy = hodiny mocku); nad limit se nejstarší zahodí. */
  private pridejVerzi(item: Verzovana, limit: number): void {
    const v = (item._versions ??= []);
    const posledni = Number(String(v[v.length - 1].verze).split('.')[0]) || v.length;
    v.push({ verze: `${posledni + 1}.0`, kdy: (this.o.now?.() ?? new Date()).toISOString(), kdo: this.o.user, pole: snimek(item) });
    while (v.length > limit) v.shift();
  }

  public async getVersions(list: string, id: number): Promise<Version[]> {
    // stejná viditelnost jako getItems (itemScope own); ViewVersions mock nemodeluje — mají ho Read, Contribute i úrovně
    // projektu s "ViewVersions" v rights; vlastní úroveň bez něj na SP verze nevrátí (viz references/kod.md)
    if (!(await this.getItems(list)).some((i) => i.Id === id)) throw new Error(`${list}: položka ${id} neexistuje nebo ji nevidíte`);
    const item = (this.store[list] || []).find((i) => i.Id === id) as Verzovana;
    return (item._versions && item._versions.length ? item._versions : [prvni(item)]).map((v) => ({ ...v, pole: { ...v.pole } }));
  }

  public async addAttachment(list: string, itemId: number, name: string, data: Blob): Promise<Attachment> {
    // příloha = úprava položky: SP chce EditListItems a u itemScope own/own-write jen vlastní položku (WriteSecurity 2),
    // cizí jen edit-all. Autor položky (_author) se nemění — jako na SP (Author zůstává, mění se jen Editor).
    if (!(await this.can(list, 'edit'))) throw new AccessDenied(list, 'edit');
    const item = (this.store[list] || []).find((i) => i.Id === itemId);
    if (!item) throw new Error(`${list}: položka ${itemId} neexistuje`);
    if (this.o.manifest.lists[list]?.itemScope && item._author !== this.o.user && !(await this.can(list, 'edit-all'))) throw new AccessDenied(list, 'edit');
    const att = ((item as { _attachments?: MockAttachment[] })._attachments ??= []);
    if (att.some((a) => a.name.toLowerCase() === name.toLowerCase())) throw new Error(`${list}(${itemId}): příloha ${name} už existuje`);
    const a: MockAttachment = { name, url: await toDataUrl(data) };
    att.push(a);
    this.save();
    return { name, url: a.url, itemId, itemAuthor: String(item._author) };
  }

  public async listAttachments(list: string, options?: GetOptions): Promise<Attachment[]> {
    const out: Attachment[] = [];
    for (const v of await this.getItems(list, options)) {
      const i = (this.store[list] || []).find((s) => s.Id === v.Id) as Item;
      for (const a of ((i as { _attachments?: MockAttachment[] })._attachments || [])) out.push({ name: a.name, url: a.url, itemId: i.Id as number, itemAuthor: String(i._author) });
    }
    return out;
  }

  public async searchPeople(query: string): Promise<Person[]> {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    return Object.keys(this.o.users).filter((u) => u.toLowerCase().includes(q)).slice(0, PEOPLE_LIMIT).map((u) => ({ name: u, email: `${u}@example.test` }));
  }

  public assetUrl(name: string): string {
    return `${this.o.assetBase}/${name}`;
  }

  public async getAssetJson<T>(name: string): Promise<T> {
    const r = await fetch(this.assetUrl(name));
    if (!r.ok) throw new Error(`asset ${name}: HTTP ${r.status}`);
    return (await r.json()) as T;
  }
}
