// Lokální harness: stejná appka jako na SharePointu, ale nad MockSource.
// Uživatel se přepíná parametrem ?user=<jméno z project_config.json environments.local.users>.
// Vlastnosti web partu jsou ze stránek manifestu vyhodnocené pro local (tools/gen.mjs → generated/localProps.ts).
// ?now=<ISO čas> posune hodiny stránky (clock.ts). Appka běží v rolovacím kontejneru jako na Single Part App Page
// SharePointu: roluje div pod lištou harnessu, okno nikdy (references/kod.md §Pasti kódu, rolování).
import { nowParam, ted } from './clock'; // první import: hodiny se posunou dřív, než se vyhodnotí moduly appky
import * as React from 'react';
import { createRoot } from 'react-dom/client';
import { App } from '../src/app/App';
import { MockSource } from '../src/app/data/MockSource';
import { appManifest } from '../src/app/generated/appManifest';
import { localProps } from '../src/app/generated/localProps';
import { mockData } from '../src/app/generated/mockData';
import config from '../../project_config.json';

const users = (config as { environments: { local: { users: Record<string, string[]> } } }).environments.local.users;
const params = new URLSearchParams(location.search);
// data mocku drží sessionStorage záložky (přežijí přepnutí uživatele); ?reset vrátí fixtures z gitu
const persistKey = `devkit-mock:${appManifest.prefix}`;
if (params.has('reset')) { try { sessionStorage.removeItem(persistKey); } catch { /* bez úložiště */ } }
const user = params.get('user') && users[params.get('user') as string] ? (params.get('user') as string) : Object.keys(users)[0];
// odkazy harnessu drží posunuté hodiny i po přepnutí uživatele
const keep = (u: string): string => `?user=${encodeURIComponent(u)}${nowParam ? `&now=${encodeURIComponent(nowParam)}` : ''}`;

const source = new MockSource({
  manifest: appManifest,
  users,
  user,
  now: ted,
  data: mockData, // sp/data/config, sp/data/initial nebo sp/data/seed každého listu z manifestu (generuje tools/gen.mjs)
  assetBase: '/assets',
  persist: { storage: sessionStorage, key: persistKey },
});

// připomínky lokálně: stejná vrstva jako na SP, nad MockSource (list Pripominky v paměti prohlížeče).
// Připojuje se až po vykreslení Shell (useEffect): #app-host musí existovat; requestAnimationFrame
// po createRoot().render nestačí, React 18 vykresluje asynchronně (změřeno 2026-11-11, souběh u většího bundlu).
const fb = (localProps.AppWebPart as { pripominky?: { list: string; env: string; verze: string } } | undefined)?.pripominky;

function Shell(): React.ReactElement {
  React.useEffect(() => {
    if (!fb) return undefined;
    let off: (() => void) | undefined;
    let live = true;
    import('../src/feedback')
      .then((m) => { if (live) off = m.mountFeedback(document.getElementById('app-host') as HTMLElement, document.getElementById('app-el') as HTMLElement, source, { ...fb, page: 'local' }); })
      .catch((e) => console.error('připomínky se nenačetly', e));
    return () => { live = false; off?.(); };
  }, []);
  // okno se nerolí (jako na SP); co spoléhá na window.scrollY / scrollTo / posluchač scrollu okna, tady selže stejně
  React.useEffect(() => { document.documentElement.style.overflow = 'hidden'; }, []);
  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
      <div style={{ flex: 'none', background: '#F6EFE2', color: '#4A6480', borderBottom: '1px solid #B8C4D0', padding: '6px 12px', fontFamily: "'Neue Haas Unica W1G', Helvetica, Arial, sans-serif", fontSize: 12 }} data-testid="harness-bar">
        Lokální mock · jsem:{' '}
        {Object.entries(users).map(([u, r]) => (
          <a key={u} href={keep(u)} style={{ marginRight: 10, fontWeight: u === user ? 700 : 400 }}>{u} ({r.join(', ')})</a>
        ))}
        <a href={`${keep(user)}&reset`} style={{ marginLeft: 12 }} data-testid="harness-reset">obnovit data z gitu</a>
        {nowParam && <span style={{ marginLeft: 12 }} data-testid="harness-now">hodiny: {nowParam}</span>}
      </div>
      <div data-testid="harness-scroll" style={{ flex: 1, minHeight: 0, overflowY: 'auto' }}>
        <div id="app-host"><div id="app-el"><App source={source} props={localProps.AppWebPart || {}} /></div></div>
      </div>
    </div>
  );
}

createRoot(document.getElementById('root') as HTMLElement).render(<Shell />);
