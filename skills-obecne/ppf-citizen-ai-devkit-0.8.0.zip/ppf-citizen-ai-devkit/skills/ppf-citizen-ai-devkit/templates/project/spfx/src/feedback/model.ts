// Připomínky bez DOM a bez SharePointu — čisté funkce, testované v tools/test/feedback.test.mjs.
//   pick(kandidáti, kotva)  kam patří špendlík: přesná shoda id+klíč → jen id (kontejner, řádek zmizel) → nikam
//   threads(položky)        vlákna z položek listu: kořen + odpovědi (NadrazenaId), stav = poslední Stav ve vlákně
// Kotva: data-cadk-id prvku + data-cadk-key řádku (u opakovaných prvků, typicky Id položky). Úryvek textu
// se ukládá jen pro člověka a agenta (P8), k hledání se nepoužívá: obsahuje data, která se mění.
import { Item } from '../app/data/types';

export interface Anchor { id: string; key?: string; text?: string }
export interface Candidate { id: string; key?: string }
export type Status = 'Otevřeno' | 'Vyřešeno';
export interface Thread { root: Item; replies: Item[]; status: Status }

/** Index kandidáta pro kotvu a jestli sedí přesně; undefined = připomínka je nepřipnutá (postranní seznam). */
export function pick(cands: Candidate[], a: Pick<Anchor, 'id' | 'key'>): { index: number; exact: boolean } | undefined {
  if (!a.id) return undefined;
  if (a.key) {
    const i = cands.findIndex((c) => c.id === a.id && c.key === a.key);
    if (i >= 0) return { index: i, exact: true };
  }
  const i = cands.findIndex((c) => c.id === a.id && !c.key);
  if (i >= 0) return { index: i, exact: !a.key };
  return undefined;
}

export function threads(items: Item[]): Thread[] {
  const roots = items.filter((i) => !i.NadrazenaId).sort((a, b) => (a.Id || 0) - (b.Id || 0));
  return roots.map((root) => {
    const replies = items.filter((i) => Number(i.NadrazenaId) === root.Id).sort((a, b) => (a.Id || 0) - (b.Id || 0));
    const last = [root, ...replies].filter((i) => i.Stav).pop();
    return { root, replies, status: (last?.Stav as Status) || 'Otevřeno' };
  });
}

/** Titul položky (povinný sloupec SP listu) = začátek textu. */
export const titleOf = (text: string): string => (text.length > 60 ? `${text.slice(0, 57)}…` : text) || '(bez textu)';
