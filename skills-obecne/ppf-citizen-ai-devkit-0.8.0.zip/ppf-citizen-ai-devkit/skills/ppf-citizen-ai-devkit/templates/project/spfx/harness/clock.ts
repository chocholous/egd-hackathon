// Hodiny harnessu: ?now=<ISO čas> (2026-11-11, 2026-11-11T08:30, 2026-11-11T08:30:00Z) posune čas CELÉ stránky
// harnessu — Date.now() a new Date() bez argumentů začnou na zadaném čase a dál běží. Samotné datum = poledne
// místního času (jako Tracker; den se neposune v žádném pásmu).
// Proč globálně: appka počítá „dnes“ a lhůty přes new Date() a MockSource razítkuje Created/verze stejnými hodinami;
// lhůty jdou zkoušet bez čekání a screenshoty design-checku jsou při každém běhu stejné. Jen harness, do balíčku
// se nedostane. Musí se importovat PRVNÍ (main.tsx), aby čas posunul dřív, než se vyhodnotí moduly appky.
// Chyba: neplatná hodnota ?now = hláška v konzoli a skutečný čas (harness nespadne).
const raw = new URLSearchParams(location.search).get('now');
const parsed = raw ? new Date(/^\d{4}-\d{2}-\d{2}$/.test(raw) ? `${raw}T12:00:00` : raw) : undefined;
if (raw && (!parsed || isNaN(parsed.getTime()))) console.error(`harness: ?now=${raw} není čas (RRRR-MM-DD nebo ISO 8601) — běží skutečné hodiny`);

/** Hodnota ?now, když je platná (harness ji drží v odkazech na přepnutí uživatele); jinak null. */
export const nowParam: string | null = parsed && !isNaN(parsed.getTime()) ? raw : null;

if (nowParam && parsed) {
  const RealDate = Date;
  const offset = parsed.getTime() - RealDate.now();
  // podtřída místo náhrady: instanceof Date, Date.UTC, Date.parse a new Date(x) s argumenty dál platí beze změny
  class HarnessDate extends RealDate {
    constructor(...a: unknown[]) {
      if (a.length === 0) super(RealDate.now() + offset);
      else super(...(a as [string]));
    }
    static now(): number { return RealDate.now() + offset; }
  }
  (globalThis as unknown as { Date: DateConstructor }).Date = HarnessDate as unknown as DateConstructor;
}

/** Hodiny pro MockSource.now (shodné s posunutým Date). */
export const ted = (): Date => new Date();
