// Zdroj dat nad SharePointem (běží na stránce SP, cookies téže domény).
// Práva čte z EffectiveBasePermissions listu → appka nezná jména skupin a funguje
// v každém prostředí stejně. Bezpečnost drží SP; tohle jen zobrazuje, co smíš.
import { AppManifest, spPath } from '../manifest';
import { AccessDenied, Action, Attachment, DataSource, GetOptions, Item, Person, PEOPLE_LIMIT, Version } from './types';
import { localDate, toSpDate } from './dates';

const odata = (v: string | number): string => (typeof v === 'number' ? String(v) : `'${encodeURIComponent(v.replace(/'/g, "''"))}'`);

// SP.PermissionKind: viewListItems=1, addListItems=2, editListItems=3, cancelCheckout=9
const KIND: Record<string, number> = { view: 1, add: 2, edit: 3, override: 9 };
const has = (low: number, kind: number): boolean => ((low >>> (kind - 1)) & 1) === 1;
/** Odpovědi čtení práv, které znamenají „nemáš / nevidíš“ (výsledek false smí zůstat zapamatovaný do znovunačtení
 *  stránky): 403 přístup odepřen, 404 list neexistuje nebo ho uživatel nevidí. Síť, 5xx a jiné chyby se
 *  nepamatují a jdou volajícímu — přechodný výpadek nesmí natrvalo schovat tlačítka (Gate Insider 6446cb9). */
const PERM_DENIED_STATUS: readonly number[] = [403, 404];
/** Chyba HTTP se stavem (zpráva zůstává '403' kvůli dosavadním kontrolám v getItems a spol.). */
const httpError = (message: string, status: number): Error & { status: number } => Object.assign(new Error(message), { status });

export class SpSource implements DataSource {
  public readonly label: string;
  private perms: Record<string, number> = {};
  private digest?: { value: string; until: number };

  constructor(private readonly webUrl: string, private readonly manifest: AppManifest, private readonly userName: string) {
    this.label = `SharePoint · ${webUrl.replace(/^https:\/\/[^/]+/, '')}`;
  }

  private api(list: string): string {
    // list adresuje URL z manifestu (generuje tools/gen.mjs), ne titul — titul jde přejmenovat
    return `${this.webUrl}/_api/web/GetList('${encodeURIComponent(spPath(this.manifest, this.webUrl, list).replace(/'/g, "''"))}')`;
  }

  private async get<T>(url: string): Promise<T> {
    const r = await fetch(url, { credentials: 'same-origin', headers: { Accept: 'application/json;odata=nometadata' } });
    if (r.status === 403) throw httpError('403', 403);
    if (!r.ok) throw httpError(`${url}: HTTP ${r.status}`, r.status);
    return (await r.json()) as T;
  }

  private async requestDigest(): Promise<string> {
    if (this.digest && this.digest.until > Date.now()) return this.digest.value;
    const r = await fetch(`${this.webUrl}/_api/contextinfo`, { method: 'POST', credentials: 'same-origin', headers: { Accept: 'application/json;odata=nometadata' } });
    const j = (await r.json()) as { FormDigestValue: string; FormDigestTimeoutSeconds: number };
    this.digest = { value: j.FormDigestValue, until: Date.now() + (j.FormDigestTimeoutSeconds - 60) * 1000 };
    return j.FormDigestValue;
  }

  public async currentUser(): Promise<{ name: string }> {
    return { name: this.userName };
  }

  public async can(list: string, action: Action): Promise<boolean> {
    if (this.perms[list] === undefined) {
      try {
        const p = await this.get<{ Low: string }>(`${this.api(list)}/EffectiveBasePermissions`);
        this.perms[list] = Number(p.Low);
      } catch (e) {
        // jen „nemáš / nevidíš“ je odpověď; síť, 5xx a jiné chyby se nepamatují (příští volání zkusí znovu)
        if (PERM_DENIED_STATUS.indexOf((e as { status?: number }).status ?? 0) >= 0) this.perms[list] = 0;
        else throw e;
      }
    }
    const low = this.perms[list];
    switch (action) {
      case 'read': return has(low, KIND.view);
      case 'add': return has(low, KIND.add);
      case 'edit': return has(low, KIND.edit);
      case 'edit-all': return has(low, KIND.edit) && has(low, KIND.override);
    }
  }

  // sloupce typu date: na SP UTC půlnoc místního dne, v appce 'YYYY-MM-DD' (data/dates.ts)
  private isDate(list: string, field: string): boolean {
    return (this.manifest.lists[list]?.fields || []).some((f) => f.name === field && f.type === 'date');
  }
  private fromSp(list: string, i: Item): Item {
    const out: Item = { ...i };
    for (const f of this.manifest.lists[list]?.fields || []) if (f.type === 'date' && f.name in out) out[f.name] = localDate(out[f.name]);
    return out;
  }
  private toSpValue(list: string, field: string, v: unknown): unknown {
    return this.isDate(list, field) ? toSpDate(v) : v;
  }

  public async getItems(list: string, options?: GetOptions): Promise<Item[]> {
    const def = this.manifest.lists[list];
    const fields = ['Id', 'Title', 'Created', 'Modified', ...(def?.fields || []).map((f) => f.name), 'Author/Title'];
    const where = Object.entries(options?.where || {}).map(([k, v]) => `${k} eq ${odata(v)}`).join(' and ');
    try {
      // stránkuje přes odata.nextLink až do konce — žádný vlastní strop počtu položek
      const out: Item[] = [];
      let url: string | undefined = `${this.api(list)}/items?$select=${fields.join(',')}&$expand=Author${where ? `&$filter=${where}` : ''}`;
      while (url) {
        const j: { value: (Item & { Author?: { Title: string } })[]; 'odata.nextLink'?: string } = await this.get(url);
        for (const i of j.value) out.push(this.fromSp(list, { ...i, _author: i.Author?.Title }));
        url = j['odata.nextLink'];
      }
      return out;
    } catch (e) {
      if ((e as Error).message === '403') throw new AccessDenied(list, 'read');
      throw e;
    }
  }

  public async addItem(list: string, item: Item): Promise<Item> {
    const body: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(item)) if (!k.startsWith('_') && k !== 'Id') body[k] = this.toSpValue(list, k, v);
    const r = await fetch(`${this.api(list)}/items`, {
      method: 'POST', credentials: 'same-origin',
      headers: { Accept: 'application/json;odata=nometadata', 'Content-Type': 'application/json;odata=nometadata', 'X-RequestDigest': await this.requestDigest() },
      body: JSON.stringify(body),
    });
    if (r.status === 403) throw new AccessDenied(list, 'add');
    if (!r.ok) throw new Error(`zápis do ${list}: HTTP ${r.status} ${await r.text()}`);
    return this.fromSp(list, (await r.json()) as Item);
  }

  public async updateItem(list: string, id: number, changes: Record<string, unknown>): Promise<void> {
    const body: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(changes)) if (!k.startsWith('_') && k !== 'Id') body[k] = this.toSpValue(list, k, v);
    const r = await fetch(`${this.api(list)}/items(${id})`, {
      method: 'POST', credentials: 'same-origin',
      headers: { Accept: 'application/json;odata=nometadata', 'Content-Type': 'application/json;odata=nometadata', 'X-RequestDigest': await this.requestDigest(), 'X-HTTP-Method': 'MERGE', 'IF-MATCH': '*' },
      body: JSON.stringify(body),
    });
    if (r.status === 403) throw new AccessDenied(list, 'edit');
    if (!r.ok) throw new Error(`úprava ${list}(${id}): HTTP ${r.status} ${await r.text()}`);
  }

  // Verze položky: GET items(id)/versions. Tvar ověřen čtením na tenantu PPF 2026-11-11 (účet vlastníka webu; Microsoft
  // Learn popisuje jen typ SP.ListItemVersion): pole VersionId (512 na hlavní verzi), VersionLabel "2.0", IsCurrentVersion,
  // hodnoty sloupců pod interními jmény, Editor {LookupId, LookupValue, Email}, Modified s "Z" (Created verze je tentýž
  // čas BEZ "Z", proto se bere Modified); pořadí od nejnovější. Potřebuje ViewVersions a viditelnou položku.
  public async getVersions(list: string, id: number): Promise<Version[]> {
    const pole = ['Title', ...(this.manifest.lists[list]?.fields || []).map((f) => f.name)];
    type SpVerze = Record<string, unknown> & { VersionId?: number; VersionLabel?: string; Modified?: string; Created?: string; Editor?: { LookupValue?: string; Title?: string } };
    try {
      const raw: SpVerze[] = [];
      let url: string | undefined = `${this.api(list)}/items(${id})/versions`;
      while (url) {
        const j: { value: SpVerze[]; 'odata.nextLink'?: string } = await this.get(url);
        raw.push(...j.value);
        url = j['odata.nextLink'];
      }
      const poradi = (v: SpVerze): number => (typeof v.VersionId === 'number' ? v.VersionId : parseFloat(String(v.VersionLabel)) * 512);
      return raw.sort((a, b) => poradi(a) - poradi(b)).map((v) => {
        const hodnoty: Record<string, unknown> = {};
        for (const k of pole) hodnoty[k] = v[k] === undefined ? null : this.isDate(list, k) ? localDate(v[k]) : v[k];
        return { verze: String(v.VersionLabel ?? ''), kdy: String(v.Modified ?? v.Created ?? ''), kdo: String(v.Editor?.LookupValue ?? v.Editor?.Title ?? ''), pole: hodnoty };
      });
    } catch (e) {
      if ((e as Error).message === '403') throw new AccessDenied(list, 'read');
      throw e;
    }
  }

  /** absolutní URL přílohy z ServerRelativeUrl, zakódovaná po částech (mezery, diakritika) */
  private absUrl(serverRelativeUrl: string): string {
    return `${new URL(this.webUrl).origin}${serverRelativeUrl.split('/').map(encodeURIComponent).join('/')}`;
  }

  // REST podle Microsoft Learn „Working with folders and files with REST“ (§ files attached to list items), ověřeno 2026-11-11
  public async addAttachment(list: string, itemId: number, name: string, data: Blob): Promise<Attachment> {
    const r = await fetch(`${this.api(list)}/items(${itemId})/AttachmentFiles/add(FileName=${odata(name)})`, {
      method: 'POST', credentials: 'same-origin',
      headers: { Accept: 'application/json;odata=nometadata', 'X-RequestDigest': await this.requestDigest() },
      body: data,
    });
    if (r.status === 403) throw new AccessDenied(list, 'edit');
    if (!r.ok) throw new Error(`příloha ${name} k ${list}(${itemId}): HTTP ${r.status} ${await r.text()}`);
    const j = (await r.json()) as { FileName: string; ServerRelativeUrl: string };
    return { name: j.FileName, url: this.absUrl(j.ServerRelativeUrl), itemId }; // autora položky odpověď nenese
  }

  public async listAttachments(list: string, options?: GetOptions): Promise<Attachment[]> {
    const where = Object.entries(options?.where || {}).map(([k, v]) => `${k} eq ${odata(v)}`).join(' and ');
    try {
      const out: Attachment[] = [];
      let url: string | undefined = `${this.api(list)}/items?$select=Id,Author/Title,AttachmentFiles&$expand=Author,AttachmentFiles${where ? `&$filter=${where}` : ''}`;
      while (url) {
        const j: { value: { Id: number; Author?: { Title: string }; AttachmentFiles?: { FileName: string; ServerRelativeUrl: string }[] }[]; 'odata.nextLink'?: string } = await this.get(url);
        for (const i of j.value) for (const a of i.AttachmentFiles || []) out.push({ name: a.FileName, url: this.absUrl(a.ServerRelativeUrl), itemId: i.Id, itemAuthor: i.Author?.Title });
        url = j['odata.nextLink'];
      }
      return out;
    } catch (e) {
      if ((e as Error).message === '403') throw new AccessDenied(list, 'read');
      throw e;
    }
  }

  public async searchPeople(query: string): Promise<Person[]> {
    const q = query.trim();
    if (!q) return [];
    // jen lidé (PrincipalType 1), které web už zná (siteusers); adresář celého tenantu by chtěl Graph a schválení správce
    const j = await this.get<{ value: { Title: string; Email: string }[] }>(`${this.webUrl}/_api/web/siteusers?$select=Title,Email&$filter=PrincipalType eq 1 and (substringof(${odata(q)},Title) or substringof(${odata(q)},Email))&$top=${PEOPLE_LIMIT}`);
    return j.value.map((u) => ({ name: u.Title, email: u.Email || undefined }));
  }

  private assetRoot = '';

  /** Přímá URL knihovny assetů (z manifestu). REST $value by šel taky, ale vrací
   *  application/octet-stream a <img> pak SVG nevykreslí. */
  public async init(): Promise<void> {
    this.assetRoot = `${new URL(this.webUrl).origin}${spPath(this.manifest, this.webUrl, 'Assets')}`;
  }

  public assetUrl(name: string): string {
    return `${this.assetRoot}/${encodeURIComponent(name)}`;
  }

  public async getAssetJson<T>(name: string): Promise<T> {
    return this.get<T>(this.assetUrl(name));
  }
}
