import * as React from 'react';
import { createRoot, type Root } from 'react-dom/client';
import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import { App, AppProps } from '../../app/App';
import { SpSource } from '../../app/data/SpSource';
import { appManifest } from '../../app/generated/appManifest';

// Tenký host: SPFx dodá URL webu, jméno uživatele a vlastnosti instance (zapisuje je npm run deploy z manifestu
// stránek); appka je stejná jako v lokálním harnessu. Vlastnost "pripominky" (jen DEV/TEST) líně načte
// vrstvu připomínek (src/feedback) — bez ní se ten kód nestáhne.
export default class AppWebPart extends BaseClientSideWebPart<AppProps> {
  private source!: SpSource;
  private root?: Root;
  private appEl?: HTMLDivElement;
  private feedbackOff?: () => void;

  protected async onInit(): Promise<void> {
    this.source = new SpSource(this.context.pageContext.web.absoluteUrl, appManifest, this.context.pageContext.user.displayName);
    await this.source.init();
  }

  public render(): void {
    if (!this.appEl) {
      this.appEl = document.createElement('div');
      this.domElement.appendChild(this.appEl);
      this.root = createRoot(this.appEl); // React 18: jeden root na web part
      const fb = this.properties.pripominky;
      if (fb) {
        const page = decodeURIComponent(location.pathname.split('/').pop() || '');
        import(/* webpackChunkName: 'pripominky' */ '../../feedback')
          .then((m) => { this.feedbackOff = m.mountFeedback(this.domElement, this.appEl as HTMLDivElement, this.source, { ...fb, page }); })
          .catch((e) => console.error('připomínky se nenačetly', e));
      }
    }
    this.root?.render(React.createElement(App, { source: this.source, props: this.properties }));
  }

  protected onDispose(): void {
    this.feedbackOff?.();
    this.root?.unmount();
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }
}
