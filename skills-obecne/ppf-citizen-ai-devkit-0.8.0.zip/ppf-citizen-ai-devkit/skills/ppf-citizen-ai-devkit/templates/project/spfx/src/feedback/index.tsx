// Vrstva připomínek nad appkou (P6). Načítá se líně (dynamický import) jen tehdy, když web part dostane
// vlastnost "pripominky" — tu zapíše nasazení kitu jen na DEV a TEST (tools/lib/feedback.mjs), lokálně gen.mjs.
// Na PROD vlastnost není, takže se tenhle kód ani nestáhne.
//
//   mountFeedback(host, appEl, source, opts) → odpojit()
//     host   prvek web partu (position: relative); vrstva do něj přidá vlastní div se špendlíky a panelem
// Tlačítko „Připomínky“ má pevné místo v liště appky: AppShell (ppf/blocks.tsx) tam drží prázdný prvek
// data-ppf="pripominky" a vrstva do něj tlačítko vloží (portál). Je tak uvnitř kořene appky: nic nepřekrývá
// a kontrola vzhledu ho vidí mezi tlačítky. Appka bez AppShellu (nebo se starším blocks.tsx) to místo nemá;
// tlačítko pak plave vpravo nahoře jako dřív.
// Výběr prvku pro novou připomínku: prvek pod kurzorem, ke kterému by se připomínka připnula, se zvýrazní
// (obrys + podbarvení); klik ho vybere, Esc nebo klik na tlačítko Připomínky výběr zruší.
//     appEl  kořen appky — tady se hledají prvky s data-cadk-id
// Data jdou přes DataSource appky (MockSource lokálně, SpSource na SP) do listu opts.list.
import * as React from 'react';
import { createPortal } from 'react-dom';
import { createRoot } from 'react-dom/client';
import { DataSource, Item } from '../app/data/types';
import { Anchor, Thread, pick, threads, titleOf } from './model';

export interface FeedbackOpts { list: string; env: string; verze: string; page: string }

// Vzhled podle ppf-material (tokeny opsané, aby vrstva nezávisela na MUI a theme appky): navy, copper jen
// u špendlíku a zvýraznění vybíraného prvku, stíny z navy, radius 8 / 12 / plný, písmo Neue Haas Unica.
const C = { navy: '#002C5A', copper: '#B06F41', copperText: '#9A5E37', line: '#B8C4D0', divider: '#F2F2F2', muted: '#4A6480', bg: '#FFFFFF', cream: '#F6EFE2', error: '#A33B2B' };
const FONT = "'Neue Haas Unica W1G', 'Helvetica Neue', Helvetica, Arial, sans-serif";
const SHADOW = '0 8px 12px 6px rgba(0,44,90,.15), 0 4px 4px rgba(0,44,90,.30)';
const S: Record<string, React.CSSProperties> = {
  // v liště appky (navy): světlé obrysové jako BarButton z ppf/blocks.tsx; plné tlačítko patří do obsahu
  bar: { flex: 'none', background: 'transparent', color: C.cream, border: '1px solid rgba(246,239,226,.35)', borderRadius: 999, height: 36, padding: '0 16px', cursor: 'pointer', font: `500 14px ${FONT}`, whiteSpace: 'nowrap' },
  // záloha pro appku bez místa v liště: plave vpravo nahoře pod lištou (64 px + 6 px)
  fab: { position: 'absolute', right: 16, top: 70, zIndex: 20, background: C.navy, color: C.cream, border: 0, borderRadius: 999, height: 36, padding: '0 16px', cursor: 'pointer', font: `500 13px ${FONT}`, boxShadow: '0 1px 2px rgba(0,44,90,.10), 0 1px 3px 1px rgba(0,44,90,.06)' },
  panel: { position: 'absolute', right: 12, top: 112, zIndex: 21, width: 340, maxHeight: 480, overflow: 'auto', background: C.bg, border: `1px solid ${C.line}`, borderRadius: 12, boxShadow: SHADOW, padding: 16, font: `14px/1.5 ${FONT}`, color: C.navy },
  // prvek pod kurzorem při výběru: copper obrys a 10% podbarvení (výběr podle ppf-material), kliky propouští
  hover: { position: 'absolute', zIndex: 18, pointerEvents: 'none', outline: `2px solid ${C.copper}`, outlineOffset: 2, background: 'rgba(176,111,65,.10)', borderRadius: 8 },
  hint: { position: 'absolute', zIndex: 22, left: '50%', transform: 'translateX(-50%)', background: C.navy, color: C.cream, borderRadius: 999, padding: '6px 16px', font: `500 13px ${FONT}`, boxShadow: SHADOW, whiteSpace: 'nowrap', pointerEvents: 'none' },
  pin: { position: 'absolute', zIndex: 19, width: 22, height: 22, borderRadius: 999, background: C.copper, color: '#FFFFFF', border: '2px solid #FFFFFF', font: `500 11px ${FONT}`, cursor: 'pointer', padding: 0, transform: 'translate(-50%,-50%)' },
  item: { borderTop: `1px solid ${C.divider}`, padding: '8px 0' },
  meta: { color: C.muted, fontSize: 12 },
  btn: { font: `500 13px ${FONT}`, height: 32, padding: '0 12px', marginRight: 6, cursor: 'pointer', border: `1px solid ${C.line}`, borderRadius: 8, background: 'transparent', color: C.navy },
  ta: { width: '100%', boxSizing: 'border-box', minHeight: 64, font: `14px ${FONT}`, color: C.navy, border: `1px solid ${C.line}`, borderRadius: 8, padding: '8px 10px', margin: '6px 0' },
};

interface Cand { el: Element; id: string; key?: string }
function candidates(appEl: Element): Cand[] {
  return Array.from(appEl.querySelectorAll('[data-cadk-id], [data-cadk-key]')).map((el) => {
    const keyEl = el.closest('[data-cadk-key]');
    const idEl = el.hasAttribute('data-cadk-id') ? el : el.closest('[data-cadk-id]');
    return { el, id: idEl?.getAttribute('data-cadk-id') || '', key: el.hasAttribute('data-cadk-key') ? keyEl?.getAttribute('data-cadk-key') || undefined : undefined };
  }).filter((c) => c.id && (c.key || c.el.hasAttribute('data-cadk-id')));
}
/** Prvek, ke kterému se připomínka připne: nejbližší řádek s data-cadk-key, jinak nejbližší data-cadk-id. */
function anchorEl(target: Element): Element | undefined {
  const keyEl = target.closest('[data-cadk-key]');
  const idEl = (keyEl || target).closest('[data-cadk-id]');
  return idEl ? keyEl || idEl : undefined;
}
/** Čitelný text prvku: texty potomků oddělené mezerou (textContent by buňky řádku slepil dohromady). */
function textOf(el: Element): string {
  const out: string[] = [];
  const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
  for (let n = w.nextNode(); n; n = w.nextNode()) { const t = (n.textContent || '').trim(); if (t) out.push(t); }
  return out.join(' ').replace(/\s+/g, ' ');
}
/** Kotva prvku, na který se kliklo: nejbližší řádek s data-cadk-key (+ jeho data-cadk-id), jinak nejbližší data-cadk-id. */
function anchorOf(target: Element): Anchor | undefined {
  const keyEl = target.closest('[data-cadk-key]');
  const idEl = (keyEl || target).closest('[data-cadk-id]');
  if (!idEl) return undefined;
  const el = keyEl || idEl;
  return { id: idEl.getAttribute('data-cadk-id') as string, key: keyEl?.getAttribute('data-cadk-key') || undefined, text: textOf(el).slice(0, 250) };
}

function Layer({ host, appEl, source, o }: { host: HTMLElement; appEl: HTMLElement; source: DataSource; o: FeedbackOpts }): React.ReactElement {
  const [items, setItems] = React.useState<Item[]>([]);
  const [open, setOpen] = React.useState(false);
  const [picking, setPicking] = React.useState(false);
  const [draft, setDraft] = React.useState<Anchor | null>(null);
  const [sel, setSel] = React.useState<number | null>(null);
  const [text, setText] = React.useState('');
  const [showDone, setShowDone] = React.useState(false);
  const [err, setErr] = React.useState('');
  const [hover, setHover] = React.useState<Element | undefined>(undefined); // prvek pod kurzorem při výběru
  const [, setTick] = React.useState(0); // změna = nové vykreslení = přepočet poloh špendlíků

  const load = React.useCallback(async () => {
    try { setItems((await source.getItems(o.list)).filter((i) => i.Stranka === o.page)); setErr(''); }
    catch (e) { setErr((e as Error).message); }
  }, [source, o.list, o.page]);
  React.useEffect(() => { load().catch(() => undefined); }, [load]);

  // appka renderuje asynchronně → polohy přepočítat po každé změně DOM a velikosti
  React.useEffect(() => {
    let raf = 0;
    const bump = (): void => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => setTick((t) => t + 1)); };
    const mo = new MutationObserver(bump); mo.observe(appEl, { subtree: true, childList: true, characterData: true });
    const ro = new ResizeObserver(bump); ro.observe(appEl);
    return () => { mo.disconnect(); ro.disconnect(); cancelAnimationFrame(raf); };
  }, [appEl]);

  // režim výběru prvku: klik v appce (zachycený dřív, než ho dostane appka) = kotva nové připomínky
  React.useEffect(() => {
    if (!picking) return undefined;
    const vTlacitku = (t: EventTarget | null): boolean => !!(t as Element | null)?.closest?.('[data-ppf="pripominky"]');
    const onMove = (ev: MouseEvent): void => { setHover(vTlacitku(ev.target) ? undefined : anchorEl(ev.target as Element)); };
    const onLeave = (): void => setHover(undefined);
    const onKey = (ev: KeyboardEvent): void => { if (ev.key === 'Escape') setPicking(false); };
    const onClick = (ev: MouseEvent): void => {
      if (vTlacitku(ev.target)) return; // klik na tlačítko Připomínky výběr ruší (řeší ho tlačítko samo)
      ev.preventDefault(); ev.stopPropagation();
      const a = anchorOf(ev.target as Element);
      setPicking(false);
      if (!a) { setErr('Tenhle prvek nemá kotvu (data-cadk-id) — klikni na jinou část appky.'); return; }
      setDraft(a); setOpen(true); setSel(null); setText('');
    };
    appEl.style.cursor = 'crosshair';
    appEl.addEventListener('click', onClick, true);
    appEl.addEventListener('mousemove', onMove, true);
    appEl.addEventListener('mouseleave', onLeave);
    document.addEventListener('keydown', onKey);
    return () => {
      appEl.style.cursor = ''; setHover(undefined);
      appEl.removeEventListener('click', onClick, true); appEl.removeEventListener('mousemove', onMove, true);
      appEl.removeEventListener('mouseleave', onLeave); document.removeEventListener('keydown', onKey);
    };
  }, [picking, appEl]);

  const all = threads(items);
  const cands = candidates(appEl);
  const hostBox = host.getBoundingClientRect();
  const placed = all.map((t) => {
    const hit = pick(cands, { id: String(t.root.Kotva || ''), key: (t.root.KotvaKlic as string) || undefined });
    if (!hit) return { t, pos: null as null | { x: number; y: number }, exact: false };
    const r = cands[hit.index].el.getBoundingClientRect();
    return { t, pos: { x: r.right - hostBox.left - 4, y: r.top - hostBox.top + 4 }, exact: hit.exact };
  });
  const visible = placed.filter((p) => showDone || p.t.status === 'Otevřeno');
  const num = (t: Thread): number => all.indexOf(t) + 1;
  // místo pro tlačítko v liště appky (AppShell); hledá se při každém vykreslení, appka ho může vykreslit později
  const slot = appEl.querySelector<HTMLElement>('[data-ppf="pripominky"]');
  const pod = slot?.closest('[data-ppf="appbar"]')?.getBoundingClientRect();
  const podListou = pod ? { top: pod.bottom - hostBox.top + 8 } : {}; // panel a nápověda výběru hned pod lištou
  const hoverBox = picking && hover?.isConnected ? hover.getBoundingClientRect() : undefined;
  const tlacitko = (
    <button type="button" style={slot ? S.bar : S.fab} data-testid="fb-toggle" aria-pressed={open || picking}
      onClick={() => { if (picking) setPicking(false); else setOpen(!open); }}>
      {picking ? 'Zrušit výběr' : `Připomínky (${all.filter((t) => t.status === 'Otevřeno').length})`}
    </button>
  );

  const add = async (item: Item): Promise<void> => {
    try { await source.addItem(o.list, { Stranka: o.page, Prostredi: o.env, Verze: o.verze, Zdroj: 'člověk', ...item }); await load(); }
    catch (e) { setErr((e as Error).message); }
  };
  const saveDraft = async (): Promise<void> => {
    if (!draft || !text.trim()) return;
    await add({ Title: titleOf(text.trim()), Text: text.trim(), Kotva: draft.id, KotvaKlic: draft.key || null, KotvaText: draft.text, Stav: 'Otevřeno' });
    setDraft(null); setText('');
  };
  const reply = async (t: Thread, stav?: 'Otevřeno' | 'Vyřešeno'): Promise<void> => {
    const body = text.trim() || (stav === 'Vyřešeno' ? 'Vyřešeno.' : stav ? 'Znovu otevřeno.' : '');
    if (!body) return;
    await add({ Title: titleOf(body), Text: body, NadrazenaId: t.root.Id, ...(stav ? { Stav: stav } : {}) });
    setText('');
  };
  const cur = sel !== null ? all.find((t) => t.root.Id === sel) : undefined;

  return (
    <>
      {visible.map((p) => p.pos && (
        <button key={p.t.root.Id} type="button" style={{ ...S.pin, left: p.pos.x, top: p.pos.y, opacity: p.t.status === 'Vyřešeno' ? 0.5 : 1 }}
          title={String(p.t.root.Text)} data-testid="fb-pin" onClick={() => { setSel(p.t.root.Id as number); setOpen(true); setDraft(null); }}>{num(p.t)}</button>
      ))}
      {slot ? createPortal(tlacitko, slot) : tlacitko}
      {hoverBox && <div style={{ ...S.hover, left: hoverBox.left - hostBox.left, top: hoverBox.top - hostBox.top, width: hoverBox.width, height: hoverBox.height }} data-testid="fb-hover" />}
      {picking && <div style={{ ...S.hint, top: 112, ...podListou }} data-testid="fb-hint">Klikni na prvek, ke kterému připomínka patří. Esc výběr zruší.</div>}
      {open && (
        <div style={{ ...S.panel, ...podListou }} data-testid="fb-panel">
          {err && <p style={{ color: C.error, margin: '0 0 6px' }}>{err}</p>}
          {draft ? (
            <div>
              <strong>Nová připomínka</strong>
              <p style={S.meta}>u prvku „{draft.text?.slice(0, 80)}“</p>
              <textarea style={S.ta} value={text} onChange={(e) => setText(e.target.value)} aria-label="Text připomínky" autoFocus />
              <button type="button" style={S.btn} disabled={!text.trim()} onClick={() => { saveDraft().catch(() => undefined); }}>Uložit</button>
              <button type="button" style={S.btn} onClick={() => setDraft(null)}>Zrušit</button>
            </div>
          ) : cur ? (
            <div>
              <button type="button" style={S.btn} onClick={() => setSel(null)}>← seznam</button>
              {[cur.root, ...cur.replies].map((i) => (
                <div key={i.Id} style={S.item}>
                  <div>{String(i.Text)}</div>
                  <div style={S.meta}>{String(i._author ?? '')}{i.Zdroj === 'agent' ? ' · agent' : ''}{i.Stav && i !== cur.root ? ` · ${String(i.Stav)}` : ''}</div>
                </div>
              ))}
              <textarea style={S.ta} value={text} onChange={(e) => setText(e.target.value)} aria-label="Odpověď" />
              <button type="button" style={S.btn} disabled={!text.trim()} onClick={() => { reply(cur).catch(() => undefined); }}>Odpovědět</button>
              {cur.status === 'Otevřeno'
                ? <button type="button" style={S.btn} onClick={() => { reply(cur, 'Vyřešeno').catch(() => undefined); }}>Vyřešit</button>
                : <button type="button" style={S.btn} onClick={() => { reply(cur, 'Otevřeno').catch(() => undefined); }}>Znovu otevřít</button>}
            </div>
          ) : (
            <div>
              <button type="button" style={S.btn} data-testid="fb-add" onClick={() => { setPicking(true); setOpen(false); }}>+ Připomínka (klikni na prvek)</button>
              <label style={S.meta}><input type="checkbox" checked={showDone} onChange={(e) => setShowDone(e.target.checked)} /> i vyřešené</label>
              {visible.length === 0 && <p style={S.meta}>Zatím žádné připomínky.</p>}
              {visible.map((p) => (
                <div key={p.t.root.Id} style={{ ...S.item, cursor: 'pointer' }} onClick={() => setSel(p.t.root.Id as number)}>
                  <div><b>{num(p.t)}.</b> {String(p.t.root.Text)}</div>
                  <div style={S.meta}>{p.t.status} · {p.t.replies.length} odp.{p.pos ? (p.exact ? '' : ' · řádek už není, u kontejneru') : ' · nepřipnuto'} · {String(p.t.root._author ?? '')}</div>
                </div>
              ))}
              <p style={S.meta}>{o.env} · verze {o.verze}</p>
            </div>
          )}
        </div>
      )}
    </>
  );
}

export function mountFeedback(host: HTMLElement, appEl: HTMLElement, source: DataSource, opts: FeedbackOpts): () => void {
  if (getComputedStyle(host).position === 'static') host.style.position = 'relative';
  const div = document.createElement('div');
  div.setAttribute('data-cadk-feedback', '');
  host.appendChild(div);
  const root = createRoot(div);
  root.render(<Layer host={host} appEl={appEl} source={source} o={opts} />);
  return () => { root.unmount(); div.remove(); };
}
