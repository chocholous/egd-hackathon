// Typ manifestu appky. Obsah sem generuje tools/gen.mjs z sp/app.manifest.json
// (soubor generated/appManifest.ts) včetně vypočteného titulu a URL každého listu.
export interface FieldDef { name: string; type: string; display?: string; required?: boolean; indexed?: boolean; unique?: boolean; multi?: boolean; choices?: string[]; default?: string; list?: string }
export interface ContainerDef { class: 'config' | 'initial' | 'operational'; title: string; url: string; key?: string; itemScope?: 'own' | 'own-write'; versioning?: { majorVersionLimit: number }; fields?: FieldDef[]; access: Record<string, string>; source?: string }
export interface AppManifest {
  prefix: string;
  roles: Record<string, { popis: string }>;
  /** úrovně oprávnění → práva podle SPBasePermissions (gen.mjs je rozepíše i pro vestavěné úrovně); mock podle nich počítá can() */
  levels?: Record<string, { rights: string[] }>;
  lists: Record<string, ContainerDef>;
  libraries: Record<string, ContainerDef>;
}

/** URL listu/knihovny relativně k serveru (/sites/x/Lists/CADKHlaseni) — identita v SP REST (web/GetList). */
export const spPath = (m: AppManifest, webUrl: string, name: string): string => {
  const def = m.lists[name] || m.libraries[name];
  if (!def) throw new Error(`manifest nezná list ani knihovnu "${name}"`);
  return `${new URL(webUrl).pathname.replace(/\/$/, '')}/${def.url}`;
};
