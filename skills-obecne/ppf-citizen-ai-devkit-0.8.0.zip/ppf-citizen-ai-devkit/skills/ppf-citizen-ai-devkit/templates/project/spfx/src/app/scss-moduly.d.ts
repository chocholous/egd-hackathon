// Záložní typy pro *.module.scss: samostatný `tsc` (npm run typecheck) nemá typy, které při buildu generuje heft
// (temp/sass-ts). Při buildu se použijí ty skutečné (konkrétní soubor má před zástupným názvem přednost).
declare module '*.module.scss' {
  const styles: Record<string, string>;
  export default styles;
}
