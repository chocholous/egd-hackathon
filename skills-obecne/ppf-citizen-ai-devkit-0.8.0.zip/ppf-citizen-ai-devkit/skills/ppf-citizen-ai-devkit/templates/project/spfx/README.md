# spfx — SPFx host appky

Tenký SharePoint Framework obal (solution, web part `AppWebPart`, lokální harness) kolem appky ve
`src/app/`. Nespouštěj tady nic ručně: build, lokální vývoj i nasazení jdou z kořene projektu přes
`npm run …` (viz `../CLAUDE.md` a skill `ppf-citizen-ai-devkit`). SPFx 1.24.1, React 18.3.1, heft.
