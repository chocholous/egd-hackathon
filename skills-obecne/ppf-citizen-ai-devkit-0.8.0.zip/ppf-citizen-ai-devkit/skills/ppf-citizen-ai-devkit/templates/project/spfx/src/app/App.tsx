import * as React from 'react';
import Link from '@mui/material/Link';
import TextField from '@mui/material/TextField';
import { DataSource, Item } from './data/types';
import {
  AppShell, CellTitle, Column, DataTable, DetailPanel, EmptyState, FilterChip, FilterGroup, Fields, Mono, Notice,
  Primary, Quiet, SearchField, Section, StatusBadge, Tone,
} from './ppf/blocks';
import { PPF } from './ppf/ppfMuiTheme';
import styles from './App.module.scss';

interface Texty { nadpis: string; uvod: string }

/** Vlastnosti web partu: na SharePointu z instance na stránce (plán je zapíše z manifestu stránek),
 *  lokálně z generated/localProps.ts. Obojí vzniká z téhož sp/app.manifest.json → pages.
 *  pripominky: zapne vrstvu připomínek (jen DEV/TEST, dosadí nasazení kitu; čte ji hostitel, ne App). */
export interface AppProps { seznam?: string; napoveda?: string; pripominky?: { list: string; env: string; verze: string } }

// Rozvržení podle ppf-material (references/app-design.md §2): AppShell (lišta + záložky + sloupce),
// jedna tabulka, řádek otevírá detail v panelu vpravo, nový záznam se zadává v panelu, ne v okně.
// Kotvy pro připomínky: klíčové prvky mají data-cadk-id (stabilní jméno), opakované řádky data-cadk-key
// (Id položky; DataTable ho dává sám). Připomínka se pak po novém nasazení ukáže u stejného prvku.

// klíče = hodnoty sloupce Stav v sp/app.manifest.json (choices)
const TON: Record<string, Tone> = { 'Nové': 'accent', 'Řeší se': 'caution', 'Uzavřeno': 'positive' };
type Panel = { kind: 'detail'; id: number } | { kind: 'nove' } | undefined;

export function App({ source, props = {} }: { source: DataSource; props?: AppProps }): React.ReactElement {
  const list = props.seznam || 'Hlaseni'; // klíč listu z manifestu (@list:)
  const [texty, setTexty] = React.useState<Texty | undefined>();
  const [kategorie, setKategorie] = React.useState<Item[]>([]);
  const [hlaseni, setHlaseni] = React.useState<Item[]>([]);
  const [canAdd, setCanAdd] = React.useState(false);
  const [canAll, setCanAll] = React.useState(false);
  const [ja, setJa] = React.useState('');
  const [error, setError] = React.useState('');
  const [tab, setTab] = React.useState('hlaseni');
  const [filtr, setFiltr] = React.useState<string[]>([]);
  const [hledat, setHledat] = React.useState('');
  const [panel, setPanel] = React.useState<Panel>(undefined);
  const [title, setTitle] = React.useState('');
  const [kat, setKat] = React.useState('');

  const load = React.useCallback(async () => {
    setError('');
    try {
      const [t, k, h, a, all, me] = await Promise.all([
        source.getAssetJson<Texty>('texty.json'),
        source.getItems('Kategorie'),
        source.getItems(list),
        source.can(list, 'add'),
        source.can(list, 'edit-all'),
        source.currentUser(),
      ]);
      setTexty(t); setKategorie(k); setHlaseni(h); setCanAdd(a); setCanAll(all); setJa(me.name);
      setKat((v) => v || (k[0] ? String(k[0].Kod) : ''));
    } catch (e) {
      setError((e as Error).message);
    }
  }, [source, list]);

  React.useEffect(() => { load().catch(() => undefined); }, [load]);

  const submit = async (): Promise<void> => {
    try {
      const novy = await source.addItem(list, { Title: title, Kategorie: kat, Stav: 'Nové' });
      setTitle('');
      await load();
      setPanel(novy && typeof novy.Id === 'number' ? { kind: 'detail', id: novy.Id } : undefined);
    } catch (e) {
      setError((e as Error).message);
    }
  };

  const katName = (kod: unknown): string => String(kategorie.find((k) => k.Kod === kod)?.Title ?? kod ?? '');
  const q = hledat.trim().toLowerCase();
  const rows = hlaseni.filter((h) => (!filtr.length || filtr.includes(String(h.Kategorie))) && (!q || String(h.Title).toLowerCase().includes(q)));
  const vybrane = panel?.kind === 'detail' ? hlaseni.find((h) => h.Id === panel.id) : undefined;
  const stav = (h: Item): React.ReactElement => <StatusBadge tone={TON[String(h.Stav)] || 'neutral'}>{String(h.Stav ?? '')}</StatusBadge>;

  const sloupce: Column<Item>[] = [
    { key: 'Title', label: 'Hlášení', width: '2.4fr', render: (h) => <CellTitle title={String(h.Title)} sub={`#${h.Id}`} /> },
    { key: 'Kategorie', label: 'Kategorie', render: (h) => katName(h.Kategorie) },
    { key: '_author', label: 'Zadal', render: (h) => String(h._author ?? '') },
    { key: 'Stav', label: 'Stav', width: '140px', align: 'right', render: stav },
  ];

  const detail = panel?.kind === 'nove' ? (
    <DetailPanel eyebrow="Nové hlášení" title="Co se stalo" onClose={() => setPanel(undefined)}
      actions={<><Primary onClick={() => { submit().catch(() => undefined); }} disabled={!title.trim()} testId="app-pridat">Přidat</Primary><Quiet onClick={() => setPanel(undefined)}>Zrušit</Quiet></>}>
      <Section label="Hlášení">
        <div data-cadk-id="formular" style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <TextField label="Název hlášení" value={title} onChange={(e) => setTitle(e.target.value)} autoFocus fullWidth />
          <TextField select label="Kategorie" value={kat} onChange={(e) => setKat(e.target.value)} fullWidth slotProps={{ select: { native: true } }}>
            {kategorie.map((k) => <option key={String(k.Kod)} value={String(k.Kod)}>{k.Title}</option>)}
          </TextField>
        </div>
      </Section>
    </DetailPanel>
  ) : vybrane ? (
    <DetailPanel eyebrow={`#${vybrane.Id}`} title={String(vybrane.Title)} onClose={() => setPanel(undefined)} status={stav(vybrane)} meta={katName(vybrane.Kategorie)}>
      <Section label="Údaje">
        <Fields items={[
          { label: 'Kategorie', value: katName(vybrane.Kategorie) },
          { label: 'Zadal', value: String(vybrane._author ?? '') },
          { label: 'Číslo', value: String(vybrane.Id), mono: true },
          { label: 'Stav', value: String(vybrane.Stav ?? '') },
        ]} />
      </Section>
    </DetailPanel>
  ) : null;

  return (
    <div className={styles.root} data-testid="app-app">
      <AppShell title={texty?.nadpis ?? '…'} icon="report" user={ja}
        actions={props.napoveda ? <Link href={props.napoveda} data-testid="app-napoveda" color="inherit" variant="body2">Nápověda</Link> : undefined}
        tabs={[{ id: 'hlaseni', label: 'Hlášení', count: hlaseni.length }, { id: 'kategorie', label: 'Kategorie', count: kategorie.length }]}
        tab={tab} onTab={(t) => { setTab(t); setPanel(undefined); }}
        rail={tab === 'hlaseni' ? (
          <>
            <SearchField value={hledat} onChange={setHledat} placeholder="Hledat v hlášeních" />
            <FilterGroup label="Kategorie">
              {kategorie.map((k) => {
                const kod = String(k.Kod);
                const on = filtr.includes(kod);
                return <FilterChip key={kod} selected={on} count={hlaseni.filter((h) => h.Kategorie === k.Kod).length}
                  onClick={() => setFiltr(on ? filtr.filter((x) => x !== kod) : [...filtr, kod])}>{k.Title}</FilterChip>;
              })}
            </FilterGroup>
            <span style={{ fontSize: 12, color: PPF.inkSecondary }} data-testid="app-source">{source.label} · {canAll ? 'vidíte všechna hlášení' : 'vidíte jen svá hlášení'}</span>
          </>
        ) : undefined}
        detail={tab === 'hlaseni' ? detail : null}>
        {error && <div style={{ marginBottom: 16 }} data-testid="app-error"><Notice tone="negative">{error}</Notice></div>}
        {tab === 'hlaseni' ? (
          <div data-cadk-id="hlaseni" style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, minHeight: 44 }}>
              <span style={{ flex: 1, fontSize: 14, color: PPF.inkSecondary }} data-cadk-id="uvod">{texty?.uvod}</span>
              {canAdd && !panel && <Primary icon="add" onClick={() => setPanel({ kind: 'nove' })} testId="app-nove">Nové hlášení</Primary>}
            </div>
            {!canAdd && <div data-testid="app-noadd"><Notice>Hlášení zadávají jen členové týmu.</Notice></div>}
            <div data-testid="app-hlaseni">
              <DataTable label="Hlášení" columns={sloupce} rows={rows} rowKey={(h) => String(h.Id)}
                selectedKey={vybrane ? String(vybrane.Id) : undefined} onOpen={(h) => setPanel({ kind: 'detail', id: h.Id as number })}
                empty={<EmptyState title={hlaseni.length ? 'Filtru nic neodpovídá' : 'Zatím žádná hlášení'} text={hlaseni.length ? 'Změňte filtr nebo hledaný text.' : canAdd ? 'Nové hlášení přidáte tlačítkem vpravo nahoře.' : undefined} />} />
            </div>
          </div>
        ) : (
          <div data-cadk-id="kategorie" data-testid="app-kategorie" style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <span style={{ fontSize: 14, color: PPF.inkSecondary }}>Číselník je konfigurace z gitu, mění se nasazením.</span>
            <DataTable label="Kategorie" rows={kategorie} rowKey={(k) => String(k.Kod)}
              columns={[{ key: 'Kod', label: 'Kód', width: '160px', render: (k) => <Mono>{String(k.Kod)}</Mono> }, { key: 'Title', label: 'Název' }]} />
          </div>
        )}
      </AppShell>
    </div>
  );
}
