// Společné rozhraní datové vrstvy. Appka zná jen tohle — neví, jestli běží nad mocky,
// nebo nad SharePointem, a nikdy nezná jména skupin: ptá se na schopnosti (can).

export type Action = 'read' | 'add' | 'edit' | 'edit-all';

export interface Item {
  Id?: number;
  Title: string;
  [field: string]: unknown;
}

/** Příloha položky listu (AttachmentFiles). url jde dát do <a href> i <img src>; itemId = položka, ke které patří.
 *  itemAuthor = autor POLOŽKY, ne přílohy: SP u přílohy autora nevrací (SP.Attachment má jen FileName, FileNameAsPath, ServerRelativePath, ServerRelativeUrl). */
export interface Attachment { name: string; url: string; itemId: number; itemAuthor?: string }
export interface Person { name: string; email?: string }
/** Jedna verze položky listu (historie verzí SharePointu). verze = popisek (1.0, 2.0…), kdy = ISO čas uložení verze,
 *  kdo = zobrazované jméno toho, kdo verzi uložil, pole = hodnoty sloupců z manifestu (a Title) v té verzi. */
export interface Version { verze: string; kdy: string; kdo: string; pole: Record<string, unknown> }
/** Filtrované čtení: jen položky, kde se pole rovná hodnotě (na SP $filter=… eq …; pole má být indexované). */
export interface GetOptions { where?: Record<string, string | number> }

export interface DataSource {
  /** krátký popis zdroje pro UI (např. "mock · anna" nebo "SharePoint · DEV web") */
  readonly label: string;
  /** volitelná asynchronní příprava před prvním vykreslením (např. zjištění URL knihoven) */
  init?(): Promise<void>;
  currentUser(): Promise<{ name: string }>;
  can(list: string, action: Action): Promise<boolean>;
  getItems(list: string, options?: GetOptions): Promise<Item[]>;
  /** přidá soubor jako přílohu položky listu (potřebuje úpravy položky; u itemScope own jen vlastní); stejné jméno v položce nepřepíše (chyba) */
  addAttachment(list: string, itemId: number, name: string, data: Blob): Promise<Attachment>;
  /** přílohy položek listu, které uživatel vidí (stejná viditelnost jako getItems, včetně itemScope own) */
  listAttachments(list: string, options?: GetOptions): Promise<Attachment[]>;
  /** hledání lidí podle části jména nebo e-mailu (nejvýš PEOPLE_LIMIT výsledků) */
  searchPeople(query: string): Promise<Person[]>;
  addItem(list: string, item: Item): Promise<Item>;
  /** úprava položky (jen předaná pole); u itemScope own/own-write cizí položku odmítne SharePoint (403) */
  updateItem(list: string, id: number, changes: Item | Record<string, unknown>): Promise<void>;
  /** Verze položky od nejstarší. Vidí je, kdo vidí položku (itemScope) a má na listu ViewVersions; list bez verzí vrátí jen
   *  aktuální stav. Kolik verzí se drží, určuje versioning.majorVersionLimit v manifestu (starší SharePoint zahodí). */
  getVersions(list: string, id: number): Promise<Version[]>;
  assetUrl(name: string): string;
  getAssetJson<T>(name: string): Promise<T>;
}

/** Strop počtu výsledků hledání lidí: našeptávač, ne výpis adresáře; vlastní limit appky (není ze zadání). */
export const PEOPLE_LIMIT = 20;

export class AccessDenied extends Error {
  public readonly status = 403;
  constructor(list: string, action: Action) {
    super(`Nemáte oprávnění „${action}“ na ${list}`);
  }
}
