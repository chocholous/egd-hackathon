// Ladicí server přes http, bez vývojového certifikátu (npm --prefix spfx start).
//
// Proč: heft (heft-webpack5-plugin) si vyžádá důvěryhodný certifikát jen tehdy, když konfigurace
// webpacku neurčuje devServer.server. Na macOS to znamená heslo správce; přes http to odpadá.
// SharePoint v ladicím režimu (?loadSPFX=true&debugManifestsFile=…) povoluje v CSP i http://localhost:*
// a Chrome/Edge berou localhost jako bezpečný původ (ověřeno na DEV web 2026-11-10).
//
// Co dělá, když config/serve.json má "https": false (výchozí v šabloně):
//   1) devServer.server = http → heft certifikát nežádá;
//   2) SPFx do temp/build/manifests.js natvrdo píše https://localhost:4321 (CumulativeManifestProcessor
//      a "https" ze serve.json ignoruje), proto ho při servírování přepíše na http;
//   3) hot reload klient přes ws místo wss.
// Varianta https na přání vývojáře: "https": true v serve.json → patch nic nemění a platí
// klasické SPFx s certifikátem (npm run cert).
// Při chybě (chybí nebo je nečitelný serve.json) vyhodí výjimku; heft ji nahlásí jako chybu patche.
const fs = require('node:fs');
const path = require('node:path');

const SERVE_JSON = path.resolve(__dirname, '..', 'serve.json');
const MANIFESTS = path.resolve(__dirname, '..', '..', 'temp', 'build', 'manifests.js');

function devServerHttp(config, { https, manifestsFile }) {
  if (https) return config;
  for (const c of Array.isArray(config) ? config : [config]) {
    const ds = c.devServer;
    if (!ds) continue;
    ds.server = { type: 'http' };
    if (ds.client && ds.client.webSocketURL) ds.client.webSocketURL.protocol = 'ws';
    const original = ds.setupMiddlewares;
    ds.setupMiddlewares = (middlewares, server) => {
      const result = original ? original(middlewares, server) : middlewares;
      result.unshift({
        name: 'manifests-http',
        path: '/temp/build/manifests.js',
        middleware: (req, res) => {
          const body = fs.readFileSync(manifestsFile, 'utf8').replaceAll('https://localhost:', 'http://localhost:');
          res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
          res.setHeader('Access-Control-Allow-Origin', '*');
          res.setHeader('Access-Control-Allow-Private-Network', 'true');
          res.end(body);
        }
      });
      return result;
    };
  }
  return config;
}

module.exports = (config) => {
  const https = JSON.parse(fs.readFileSync(SERVE_JSON, 'utf8')).https === true;
  return devServerHttp(config, { https, manifestsFile: MANIFESTS });
};
module.exports.devServerHttp = devServerHttp;
