// npm run sp -- plan --env <prostředí> [--json]
// npm run sp -- pull --env <prostředí> [--write]
// npm run sp -- prava --env <prostředí> --user <upn> [--role <role>[,<role>]]
//
// Srovná SharePoint web s manifestem appky (sp/app.manifest.json) a gitem — jen čte. Zápis na web je
// jediná cesta: npm run deploy (balíček + tenhle plán, potvrzený hashem). Tenhle soubor je jen CLI:
//   lib/project.mjs         načte git, čte web, skládá plán (společné s deploy.mjs)
//   lib/manifest.mjs        kontrola manifestu a dat, model s URL a titulem každého listu
//   lib/state.mjs           přečte web (jen GET) do prostého JSON stavu
//   lib/plan/*.mjs          čisté funkce (model, stav) → akce + nálezy
// pull: rozdíl konfigurace web → git; --write ho zapíše do sp/data/config (záchrana ruční změny na webu).
// prava: skutečná oprávnění jednoho uživatele na listech appky proti manifestu, bez jeho účtu (lib/prava.mjs).
// plan: poslední řádek je STAV: prázdný | akce | nálezy | chyba (s --json je STAV na stderr a "stav" v JSON).
// Exit (lib/kody.mjs): 0 OK, 10 plán má akce nebo nálezy / práva uživatele se liší od manifestu (nic se nezapsalo), 1 selhání, 2 použití.
import { writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { ROOT } from './lib/config.mjs';
import { assertTenant, setFatalTail } from './lib/m365.mjs';
import { pullConfig, gitForm } from './lib/plan/config.mjs';
import { loadProject } from './lib/project.mjs';
import { outcome, STAV } from './lib/apply.mjs';
import { KOD } from './lib/kody.mjs';
import { groupOf } from './lib/plan/perms.mjs';
import { readUserPerms, evaluateUserPerms, formatUserPerms } from './lib/prava.mjs';

const argv = process.argv.slice(2);
const cmd = argv[0];
const opt = (n) => (argv.includes(n) ? argv[argv.indexOf(n) + 1] : undefined);
const flag = (n) => argv.includes(n);
if (cmd === 'apply') { console.error(`zápis na web je jen přes nasazení: npm run deploy -- --env ${opt('--env') || '<prostředí>'} (plán a pak --confirm <hash>)`); process.exit(2); }
// STAV (poslední řádek) má jen plán; s --json jde na stderr, aby stdout zůstal čistý JSON
const stavOut = (line) => (flag('--json') ? console.error(line) : console.log(line));
if (cmd === 'plan') setFatalTail(STAV.chyba);
if (!['plan', 'pull', 'prava'].includes(cmd) || !opt('--env') || (cmd === 'prava' && !opt('--user'))) {
  console.error('použití: npm run sp -- plan|pull|prava --env <prostředí> [--json] [--write] [--user <upn> [--role <role>,…]]');
  if (cmd === 'plan') stavOut(STAV.chyba);
  process.exit(2);
}
const ENV = opt('--env');
let P;
try { P = loadProject(ENV); } catch (e) { console.error(e.message); if (cmd === 'plan') stavOut(STAV.chyba); process.exit(1); }
assertTenant(P.cfg.m365.tenantId);

if (cmd === 'plan') {
  const p = P.buildPlan(P.read());
  P.printPlan(p, { json: flag('--json'), next: (h) => `zapsat (s balíčkem): npm run deploy -- --env ${ENV}   (plán nasazení má vlastní hash, ne ${h})` });
  const o = outcome(p);
  stavOut(o.stav);
  process.exitCode = o.code;
} else if (cmd === 'prava') {
  const data = readUserPerms({ model: P.model, api: P.api, login: opt('--user') });
  const roles = opt('--role') ? opt('--role').split(',').map((x) => x.trim()).filter(Boolean) : undefined;
  const res = evaluateUserPerms({ model: P.model, env: P.env, data, roles, groupOf: groupOf(P.model, P.env) });
  if (flag('--json')) console.log(JSON.stringify({ env: ENV, login: data.login, ...res }, null, 2));
  const { lines, ok } = formatUserPerms(res, { login: data.login, envName: ENV });
  if (!flag('--json')) console.log(lines.join('\n'));
  process.exitCode = ok ? KOD.hotovo : KOD.plan;
} else {
  const { model, configData } = P;
  const state = P.read();
  const target = pullConfig(model, state);
  let changed = 0;
  const strip = (i) => Object.fromEntries(Object.entries(i).filter(([, v]) => v !== null));
  for (const c of model.containers.filter((x) => x.class === 'config' && x.kind === 'list')) {
    const items = target[c.key].map(strip);
    const g = new Map(configData[c.key].map((i) => [String(i[c.keyField]), JSON.stringify(strip(gitForm(c, i, { model, state, side: 'git' })))]));
    const t = new Map(items.map((i) => [String(i[c.keyField]), JSON.stringify(i)]));
    const diff = [...new Set([...g.keys(), ...t.keys()])].filter((k) => g.get(k) !== t.get(k));
    if (!diff.length) { console.log(`${c.key}: shodné s gitem`); continue; }
    changed++;
    console.log(`${c.key}: liší se od gitu`);
    for (const k of diff) console.log(`  ${!g.has(k) ? '+ jen na webu' : !t.has(k) ? '- jen v gitu ' : '~ změněno   '} ${k}${t.has(k) ? ` → ${t.get(k)}` : ''}`);
    if (flag('--write')) {
      writeFileSync(join(ROOT, 'sp', 'data', 'config', `${c.key}.json`), JSON.stringify(items, null, 2) + '\n');
      console.log(`  zapsáno do sp/data/config/${c.key}.json — zkontroluj git diff a commitni`);
    }
  }
  if (changed && !flag('--write')) console.log(`\nzapsat do gitu: npm run sp -- pull --env ${ENV} --write`);
}
