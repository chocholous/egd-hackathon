// npm test — MockSource (lokální zdroj dat harnessu): práva z manifestu jako na SP (itemScope own/own-write,
// úprava jen vlastních položek, 403) a uložení dat mezi přepnutím uživatele (persist).
// Proč: harness je místo, kde se tok mezi rolemi zkouší jako první; když mock povolí víc než SP, chyba se ukáže až na DEV.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { ROOT } from '../lib/config.mjs';

const SPFX = join(ROOT, 'spfx');
async function load() {
  if (!existsSync(join(SPFX, 'node_modules', 'esbuild'))) throw new Error('chybí spfx/node_modules/esbuild — npm --prefix spfx install');
  const esbuild = createRequire(join(SPFX, 'package.json'))('esbuild');
  const out = await esbuild.build({ entryPoints: [join(SPFX, 'src', 'app', 'data', 'MockSource.ts')], bundle: true, format: 'esm', platform: 'neutral', write: false, logLevel: 'silent' });
  return import(`data:text/javascript;base64,${Buffer.from(out.outputFiles[0].text).toString('base64')}`);
}
const { MockSource } = await load();

const MANIFEST = {
  prefix: 'T', roles: {}, libraries: {},
  lists: {
    Pozadavky: { class: 'operational', itemScope: 'own-write', access: { it: 'edit', security: 'read', boss: 'edit-all' } },
    Rozhodnuti: { class: 'operational', access: { it: 'read', security: 'add' } },
  },
};
const USERS = { ivana: ['it'], igor: ['it'], sara: ['security'], bob: ['boss'], ja: ['owner'] };
const DATA = { Pozadavky: [{ Title: 'a', _author: 'ivana' }, { Title: 'b', _author: 'igor' }], Rozhodnuti: [] };
const mock = (user, persist) => new MockSource({ manifest: MANIFEST, users: USERS, user, data: structuredClone(DATA), assetBase: '/a', persist });
const memory = () => { const m = new Map(); return { getItem: (k) => m.get(k) ?? null, setItem: (k, v) => m.set(k, v), removeItem: (k) => m.delete(k) }; };

test('updateItem: own-write = vidí vše, upraví jen své; edit-all a owner upraví cizí; read/add neupraví nic', async () => {
  const iv = mock('ivana');
  assert.equal((await iv.getItems('Pozadavky')).length, 2, 'own-write: vidí i cizí');
  await iv.updateItem('Pozadavky', 1, { Title: 'a2' });
  await assert.rejects(iv.updateItem('Pozadavky', 2, { Title: 'x' }), (e) => e.status === 403);
  await mock('bob').updateItem('Pozadavky', 2, { Title: 'b2' });
  await mock('ja').updateItem('Pozadavky', 2, { Title: 'b3' });
  await assert.rejects(mock('sara').updateItem('Pozadavky', 1, { Title: 'x' }), (e) => e.status === 403);
  await assert.rejects(mock('sara').updateItem('Rozhodnuti', 1, {}), (e) => e.status === 403, 'add = přidat, ne upravit');
  await assert.rejects(iv.updateItem('Pozadavky', 99, {}), /neexistuje/);
});

test('updateItem mění jen předaná pole, Id a _pole ignoruje', async () => {
  const iv = mock('ivana');
  await iv.updateItem('Pozadavky', 1, { Popis: 'p', Id: 5, _author: 'igor' });
  const it = (await iv.getItems('Pozadavky')).find((i) => i.Id === 1);
  assert.deepEqual([it.Title, it.Popis, it._author, it.Id], ['a', 'p', 'ivana', 1]);
});

test('persist: data přežijí přepnutí uživatele; bez úložiště nebo s poškozeným obsahem fixtures', async () => {
  const st = memory();
  const persist = { storage: st, key: 'k' };
  await mock('ivana', persist).addItem('Pozadavky', { Title: 'nový' });
  await mock('sara', persist).addItem('Rozhodnuti', { Title: 'ok', Pozadavek: 3 });
  const igor = mock('igor', persist);
  assert.equal((await igor.getItems('Pozadavky')).length, 3);
  assert.equal((await igor.getItems('Rozhodnuti')).length, 1);
  st.setItem('k', '{rozbité');
  assert.equal((await mock('igor', persist).getItems('Pozadavky')).length, 2);
  const broken = { storage: { getItem: () => { throw new Error('zakázáno'); }, setItem: () => { throw new Error('zakázáno'); } }, key: 'k' };
  const m = mock('ivana', broken);
  await m.addItem('Pozadavky', { Title: 'x' });
  assert.equal((await m.getItems('Pozadavky')).length, 3);
});

// ── itemScope own, filtrované čtení, přílohy položek, hledání lidí, hodiny ──
const M2 = {
  prefix: 'T', roles: {},
  lists: {
    Zpravy: { class: 'operational', itemScope: 'own', access: { zadavatel: 'add', resitel: 'edit-all' } }, Poznamky: { class: 'operational', access: { resitel: 'edit' } },
    Soubory: { class: 'operational', itemScope: 'own', access: { zadavatel: 'edit', resitel: 'edit-all' } },
  },
  libraries: {},
};
const U2 = { anna: ['zadavatel'], bara: ['zadavatel'], petr: ['zadavatel', 'resitel'], cizi: [] };
const mock2 = (user, persist, now) => new MockSource({ manifest: M2, users: U2, user, data: { Zpravy: [{ Title: 'a', Pozadavek: 1, _author: 'anna' }, { Title: 'b', Pozadavek: 2, _author: 'bara' }, { Title: 'c', Pozadavek: 1, _author: 'petr' }] }, assetBase: '/a', persist, now });

test('itemScope own + add: zadavatel vidí jen své, neupraví ani své; řešitel (edit-all) vidí vše; where filtruje', async () => {
  assert.deepEqual((await mock2('anna').getItems('Zpravy')).map((i) => i.Title), ['a']);
  await assert.rejects(mock2('anna').updateItem('Zpravy', 1, { Title: 'x' }), (e) => e.status === 403);
  assert.equal((await mock2('petr').getItems('Zpravy')).length, 3);
  assert.deepEqual((await mock2('petr').getItems('Zpravy', { where: { Pozadavek: 1 } })).map((i) => i.Title), ['a', 'c']);
  await assert.rejects(mock2('anna').getItems('Poznamky'), (e) => e.status === 403, 'list bez přístupu');
});

test('addItem doplní Created z hodin mocku', async () => {
  const it = await mock2('anna', undefined, () => new Date('2026-12-01T10:00:00Z')).addItem('Zpravy', { Title: 'n', Pozadavek: 1 });
  assert.equal(it.Created, '2026-12-01T10:00:00.000Z');
});

test('přílohy položek: zadavatel (edit + itemScope own) přiloží jen ke své položce, řešitel (edit-all) i k cizí; autor položky se nemění; stejné jméno nepřepíše', async () => {
  const st = memory(); const persist = { storage: st, key: 'k' };
  const sada = await mock2('anna', persist).addItem('Soubory', { Title: 'PROV-1', Pozadavek: 1 });
  const a = await mock2('anna', persist).addAttachment('Soubory', sada.Id, 'obr-1.png', new Blob(['abc'], { type: 'image/png' }));
  assert.deepEqual(a, { name: 'obr-1.png', url: 'data:image/png;base64,YWJj', itemId: sada.Id, itemAuthor: 'anna' });
  await assert.rejects(mock2('anna', persist).addAttachment('Soubory', sada.Id, 'OBR-1.png', new Blob(['x'])), /už existuje/);
  await assert.rejects(mock2('bara', persist).addAttachment('Soubory', sada.Id, 'x.txt', new Blob(['x'])), (e) => e.status === 403, 'cizí položka');
  await assert.rejects(mock2('cizi', persist).addAttachment('Soubory', sada.Id, 'x.txt', new Blob(['x'])), (e) => e.status === 403, 'bez práva');
  await assert.rejects(mock2('anna', persist).addAttachment('Soubory', 99, 'x.txt', new Blob(['x'])), /neexistuje/);
  const r = await mock2('petr', persist).addAttachment('Soubory', sada.Id, 'obr-2.png', new Blob(['x']));
  assert.equal(r.itemAuthor, 'anna', 'příloha řešitele v sadě zadavatele: autor položky zůstává zadavatel');
  await mock2('petr', persist).updateItem('Soubory', sada.Id, { Title: 'změna', _author: 'petr' });
  assert.equal((await mock2('petr', persist).getItems('Soubory'))[0]._author, 'anna', 'úprava položky nemění autora');
  assert.equal((await mock2('petr', persist).getItems('Zpravy')).length, 3, 'přílohy nerozbijí ostatní listy v úložišti');
});

test('listAttachments: viditelnost podle autora položky — zadavatel vidí i soubor řešitele ve své sadě, jiný zadavatel nic; where filtruje', async () => {
  const st = memory(); const persist = { storage: st, key: 'k' };
  const sa = await mock2('anna', persist).addItem('Soubory', { Title: 'PROV-1', Pozadavek: 1 });
  await mock2('anna', persist).addAttachment('Soubory', sa.Id, 'log.txt', new Blob(['a']));
  await mock2('petr', persist).addAttachment('Soubory', sa.Id, 'obr-1.png', new Blob(['p']));
  const sb = await mock2('bara', persist).addItem('Soubory', { Title: 'PROV-2', Pozadavek: 2 });
  await mock2('bara', persist).addAttachment('Soubory', sb.Id, 'bara.txt', new Blob(['b']));
  const jmena = async (u, o) => (await mock2(u, persist).listAttachments('Soubory', o)).map((x) => `${x.itemAuthor}:${x.name}`);
  assert.deepEqual(await jmena('anna'), ['anna:log.txt', 'anna:obr-1.png'], 'anna vidí i obrázek řešitele, ne sadu bary');
  assert.deepEqual(await jmena('bara', { where: { Pozadavek: 1 } }), [], 'bara nevidí přílohy anny');
  assert.deepEqual(await jmena('petr', { where: { Pozadavek: 1 } }), ['anna:log.txt', 'anna:obr-1.png']);
  assert.equal((await mock2('petr', persist).listAttachments('Soubory')).length, 3);
  await assert.rejects(mock2('cizi', persist).listAttachments('Soubory'), (e) => e.status === 403);
});

test('Soubory s úrovní edit: zadavatel smí přepsat Pozadavek své sady (jako na SP); položka si nese autora, podle něj ji appka pozná jako cizí', async () => {
  const st = memory(); const persist = { storage: st, key: 'k' };
  const sa = await mock2('anna', persist).addItem('Soubory', { Title: 'PROV-1', Pozadavek: 1 });
  await mock2('anna', persist).updateItem('Soubory', sa.Id, { Pozadavek: 2 });
  assert.deepEqual((await mock2('petr', persist).getItems('Soubory', { where: { Pozadavek: 2 } })).map((i) => i._author), ['anna']);
});

test('searchPeople: část jména bez ohledu na velikost, prázdný dotaz nic', async () => {
  assert.deepEqual((await mock2('anna').searchPeople('AR')).map((p) => p.name), ['bara']);
  assert.deepEqual(await mock2('anna').searchPeople(' '), []);
});

test('getItems vrací kopie: změna vráceného objektu se do úložiště nepropíše a po updateItem je vidět nová hodnota', async () => {
  const st = memory(); const persist = { storage: st, key: 'k' };
  const m = mock2('petr', persist);
  const [a] = await m.getItems('Zpravy');
  a.Title = 'přepsáno mimo updateItem';
  assert.equal((await m.getItems('Zpravy'))[0].Title, 'a');
  await m.updateItem('Zpravy', a.Id, { Title: 'nové' });
  assert.equal(a.Title, 'přepsáno mimo updateItem', 'dřív vrácený objekt se sám nezmění');
  assert.equal((await m.getItems('Zpravy'))[0].Title, 'nové');
  const s = await m.addItem('Soubory', { Title: 's', Pozadavek: 1 });
  await m.addAttachment('Soubory', s.Id, 'x.txt', new Blob(['x']));
  assert.equal('_attachments' in (await m.getItems('Soubory'))[0], false, 'přílohy jdou jen přes listAttachments');
});

// ── verze položek (getVersions): mock je sám vede při updateItem, jako SP s versioning ──
const M3 = {
  prefix: 'T', roles: {},
  lists: {
    Pozadavky: { class: 'operational', itemScope: 'own', versioning: { majorVersionLimit: 3 }, access: { zadavatel: 'add', resitel: 'edit-all' } },
    Bez: { class: 'operational', access: { resitel: 'edit' } },
  },
  libraries: {},
};
const mock3 = (user, persist, now) => new MockSource({ manifest: M3, users: U2, user, persist, now, assetBase: '/a', data: {
  Pozadavky: [{ Id: 1, Title: 'a', Stav: 'Nový', Created: '2026-11-01T08:00:00Z', _author: 'anna' }, { Id: 2, Title: 'b', Stav: 'Nový', _author: 'bara' }],
  Bez: [{ Id: 1, Title: 'x', _author: 'petr' }],
} });

test('getVersions: položka ze seedu má verzi 1.0 (autor, Created); každá úprava = další verze (kdo, kdy z hodin mocku, celé hodnoty)', async () => {
  const persist = { storage: memory(), key: 'k' };
  const kdy = () => new Date('2026-11-11T10:00:00Z');
  assert.deepEqual(await mock3('anna', persist).getVersions('Pozadavky', 1), [{ verze: '1.0', kdy: '2026-11-01T08:00:00Z', kdo: 'anna', pole: { Title: 'a', Stav: 'Nový' } }]);
  await mock3('petr', persist, kdy).updateItem('Pozadavky', 1, { Stav: 'Analýza' });
  const v = await mock3('anna', persist).getVersions('Pozadavky', 1);
  assert.deepEqual(v.map((x) => `${x.verze}:${x.kdo}:${x.kdy}:${x.pole.Stav}`), ['1.0:anna:2026-11-01T08:00:00Z:Nový', '2.0:petr:2026-11-11T10:00:00.000Z:Analýza']);
  v[0].pole.Stav = 'změněno mimo';
  assert.equal((await mock3('anna', persist).getVersions('Pozadavky', 1))[0].pole.Stav, 'Nový', 'vrací kopie');
  assert.equal('_versions' in v[0].pole || '_author' in v[0].pole || 'Id' in v[0].pole, false, 'vnitřní pole mocku ve verzích nejsou');
});

test('getVersions: nová položka začíná 1.0; nad majorVersionLimit se nejstarší zahodí; list bez versioning = jen aktuální stav', async () => {
  const persist = { storage: memory(), key: 'k' };
  const n = await mock3('anna', persist).addItem('Pozadavky', { Title: 'n', Stav: 'Nový' });
  for (const s of ['A', 'B', 'C']) await mock3('petr', persist).updateItem('Pozadavky', n.Id, { Stav: s });
  assert.deepEqual((await mock3('anna', persist).getVersions('Pozadavky', n.Id)).map((x) => `${x.verze}:${x.pole.Stav}`), ['2.0:A', '3.0:B', '4.0:C'], 'limit 3: verze 1.0 zahozena');
  await mock3('petr', persist).updateItem('Bez', 1, { Title: 'y' });
  assert.deepEqual((await mock3('petr', persist).getVersions('Bez', 1)).map((x) => `${x.verze}:${x.pole.Title}`), ['1.0:y']);
});

test('getVersions: stejná viditelnost jako getItems — cizí položku u itemScope own zadavatel nedostane, list bez práva 403', async () => {
  await assert.rejects(mock3('anna').getVersions('Pozadavky', 2), /nevidíte/);
  assert.equal((await mock3('petr').getVersions('Pozadavky', 2)).length, 1, 'edit-all vidí verze cizí položky');
  await assert.rejects(mock3('anna').getVersions('Bez', 1), (e) => e.status === 403);
});

test('getVersions: getItems ani addItem vnitřní _versions appce nevrací', async () => {
  const persist = { storage: memory(), key: 'k' };
  const n = await mock3('anna', persist).addItem('Pozadavky', { Title: 'n' });
  assert.equal('_versions' in n, false);
  await mock3('petr', persist).updateItem('Pozadavky', n.Id, { Title: 'm' });
  assert.equal((await mock3('petr', persist).getItems('Pozadavky')).some((i) => '_versions' in i), false);
  assert.equal((await mock3('anna', persist).getVersions('Pozadavky', n.Id)).length, 2);
});

// --- úrovně z manifestu (levels → rights) a unikátní sloupce -------------------------------------------------------
const UR_LEVELS = {
  read: { rights: ['ViewListItems'] },
  'read-all': { rights: ['ViewListItems', 'CancelCheckout'] },
  zapis: { rights: ['ViewListItems', 'AddListItems', 'EditListItems'] },
  slepa: { rights: ['AddListItems'] },
};
const UR_M = {
  prefix: 'T', roles: {}, libraries: {}, levels: UR_LEVELS,
  lists: {
    Moje: { class: 'operational', itemScope: 'own', access: { ctenar: 'read', dohled: 'read-all', pisar: 'zapis', vhoz: 'slepa', cizi: 'neznama' } },
    Kody: { class: 'config', fields: [{ name: 'Kod', type: 'text', unique: true }, { name: 'Popis', type: 'text' }], access: { pisar: 'zapis' } },
  },
};
const UR_U = { cyril: ['ctenar'], dana: ['dohled'], petr: ['pisar'], pavla: ['pisar'], vera: ['vhoz'], cenek: ['cizi'], oba: ['ctenar', 'vhoz'] };
const UR_D = { Moje: [{ Title: 'p', _author: 'petr' }, { Title: 'q', _author: 'pavla' }], Kody: [{ Kod: 'A1', Popis: 'první' }] };
const urMock = (user) => new MockSource({ manifest: UR_M, users: UR_U, user, data: structuredClone(UR_D), assetBase: '/a' });

test('vlastní úroveň se počítá z rights: read-all čte i cizí položky u itemScope own a nic nezapíše', async () => {
  const d = urMock('dana');
  assert.equal((await d.getItems('Moje')).length, 2, 'CancelCheckout ruší „jen své“');
  assert.equal(await d.can('Moje', 'add'), false);
  assert.equal(await d.can('Moje', 'edit'), false);
  assert.equal(await d.can('Moje', 'edit-all'), false, 'edit-all chce i EditListItems');
  await assert.rejects(d.updateItem('Moje', 1, { Title: 'x' }), (e) => e.status === 403);
  assert.equal((await urMock('cyril').getItems('Moje')).length, 0, 'read bez CancelCheckout vidí jen své');
  assert.equal((await urMock('petr').getItems('Moje')).length, 1);
});

test('úroveň bez ViewListItems nečte, neznámá úroveň nedává nic, práva rolí se sčítají', async () => {
  const v = urMock('vera');
  assert.equal(await v.can('Moje', 'add'), true);
  await assert.rejects(v.getItems('Moje'), (e) => e.status === 403);
  const c = urMock('cenek');
  for (const a of ['read', 'add', 'edit', 'edit-all']) assert.equal(await c.can('Moje', a), false, a);
  const o = urMock('oba');
  assert.equal(await o.can('Moje', 'read'), true);
  assert.equal(await o.can('Moje', 'add'), true);
});

test('unique: druhá položka se stejnou hodnotou neprojde (bez ohledu na velikost písmen), vlastní úprava ano', async () => {
  const p = urMock('petr');
  await assert.rejects(p.addItem('Kody', { Kod: 'a1' }), /už existuje/);
  await p.addItem('Kody', { Kod: 'B2' });
  await assert.rejects(p.updateItem('Kody', 2, { Kod: 'A1' }), /už existuje/);
  await p.updateItem('Kody', 1, { Kod: 'A1', Popis: 'změna' });
  await p.updateItem('Kody', 2, { Popis: 'bez kódu' });
  assert.equal((await p.getItems('Kody')).length, 2);
});

// ---------- hodnoty zápisu proti sloupcům manifestu (povinná pole, volby, typy) ----------
const POLE = {
  prefix: 'T', roles: {}, libraries: {},
  lists: {
    Ukoly: {
      class: 'operational', access: { it: 'edit' },
      fields: [
        { name: 'Kod', type: 'text', required: true },
        { name: 'Stav', type: 'choice', choices: ['Nové', 'Hotovo'], default: 'Nové', required: true },
        { name: 'Pocet', type: 'number' },
        { name: 'Hotovo', type: 'boolean' },
        { name: 'Termin', type: 'date' },
        { name: 'Zmeneno', type: 'datetime' },
        { name: 'Resitel', type: 'user' },
      ],
    },
  },
};
const sPoli = () => new MockSource({ manifest: POLE, users: { ivana: ['it'] }, user: 'ivana', data: { Ukoly: [] }, assetBase: '/a' });

test('addItem: povinné pole bez hodnoty odmítne; pole s výchozí hodnotou ji dostane', async () => {
  const m = sPoli();
  await assert.rejects(m.addItem('Ukoly', { Title: 'a' }), /Kod je povinný/);
  await assert.rejects(m.addItem('Ukoly', { Title: 'a', Kod: '' }), /Kod je povinný/);
  const it = await m.addItem('Ukoly', { Title: 'a', Kod: 'K1' });
  assert.equal(it.Stav, 'Nové', 'default sloupce choice');
});

test('addItem a updateItem: volba mimo choices a špatný typ se odmítnou, správné hodnoty projdou', async () => {
  const m = sPoli();
  const ok = await m.addItem('Ukoly', { Title: 'a', Kod: 'K1', Stav: 'Hotovo', Pocet: 3, Hotovo: true, Termin: '2026-11-14', Zmeneno: '2026-11-14T10:00:00Z', Resitel: { cokoliv: 1 } });
  await assert.rejects(m.addItem('Ukoly', { Kod: 'K2', Stav: 'Rozpracováno' }), /nemá volbu „Rozpracováno“/);
  await assert.rejects(m.addItem('Ukoly', { Kod: 'K2', Pocet: '3' }), /Pocet \(number\) čeká číslo/);
  await assert.rejects(m.addItem('Ukoly', { Kod: 'K2', Hotovo: 'ano' }), /Hotovo \(boolean\)/);
  await assert.rejects(m.addItem('Ukoly', { Kod: 'K2', Termin: '14. 11. 2026' }), /Termin \(date\)/);
  await assert.rejects(m.addItem('Ukoly', { Kod: 'K2', Zmeneno: 'včera' }), /Zmeneno \(datetime\)/);
  await assert.rejects(m.addItem('Ukoly', { Kod: 7 }), /Kod \(text\) čeká text/);
  await assert.rejects(m.updateItem('Ukoly', ok.Id, { Stav: 'Jiné' }), /nemá volbu/);
  await assert.rejects(m.updateItem('Ukoly', ok.Id, { Kod: '' }), /Kod je povinný/, 'povinné pole nejde vyprázdnit');
  await m.updateItem('Ukoly', ok.Id, { Pocet: null, Termin: '' });   // nepovinné pole vyprázdnit jde
  await m.updateItem('Ukoly', ok.Id, { Title: 'b' });                // změna, která povinná pole nezmiňuje, projde
  assert.equal((await m.getItems('Ukoly')).length, 1, 'odmítnutý zápis nic nepřidal');
});

test('list bez fields v manifestu se nekontroluje (starší manifest, testy)', async () => {
  const it = await mock('ja').addItem('Pozadavky', { Title: 'x', Cokoli: 5 });
  assert.equal(it.Cokoli, 5);
});
