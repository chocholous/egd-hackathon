// Poslední krok `npm run build`: zapíše .devkit/balicek.json (otisk kódu, ze kterého balíček vznikl, a sha
// souboru .sppkg). Plán nasazení podle něj pozná, že balíček odpovídá dnešnímu kódu (lib/otisk.mjs → stavBalicku).
// Proč samostatně: build dělá Heft ve spfx/; záznam smí vzniknout až po jeho úspěšném doběhu.
// Chyba: chybějící .sppkg = hláška a exit 1 (záznam se nezapíše).
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { ROOT } from './lib/config.mjs';
import { readPackage } from './lib/spfx-package.mjs';
import { zapisBalicek } from './lib/otisk.mjs';
import { stavNaKonci } from './lib/stav.mjs';

// Závěrečné řádky `npm run build` (lib/stav.mjs). Selže-li build dřív (gen, Heft), sem se nedojde: gen vypíše
// svůj STAV: chyba, Heft skončí vlastní chybou a nenulovým kódem.
stavNaKonci((kod) => (kod === 0 ? 'commitni a pushni; plán nasazení: npm run deploy -- --env dev'
  : 'oprav chybu buildu výše a spusť znovu npm run build'));

const pkg = readPackage(join(ROOT, 'spfx'));
if (!existsSync(pkg.zippedPackage)) { console.error(`build nevyrobil ${pkg.zippedPackage} — záznam o buildu se nezapsal`); process.exit(1); }
const z = zapisBalicek(ROOT, pkg.zippedPackage);
console.log(`balíček ${pkg.solution.name} ${pkg.solution.version}: otisk kódu ${z.otisk} (.devkit/balicek.json)`);
