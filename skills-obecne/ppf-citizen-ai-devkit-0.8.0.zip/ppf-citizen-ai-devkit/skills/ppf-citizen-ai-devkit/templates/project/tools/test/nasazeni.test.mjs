// npm test — spolehlivost a čitelný výsledek nasazení, bez sítě a bez přihlášení:
//   časový limit volání m365 a hláška „výsledek neznámý“ (lib/m365.mjs, D01), hláška nepřihlášení (U09),
//   průběh zápisu a STAV/návratový kód (lib/apply.mjs, D02, U02), kontrola gitu před zápisem
//   (lib/gitcheck.mjs, D15; dočasná git repa v os.tmpdir()), ověření práv uživatele (lib/prava.mjs, D07)
//   nad falešným m365 (M365_FAKE).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { writeFileSync, readFileSync, mkdtempSync, mkdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';

const FAKE = join(mkdtempSync(join(tmpdir(), 'm365fake-')), 'fake.json');
const withFake = (table) => { writeFileSync(FAKE, JSON.stringify(table)); process.env.M365_FAKE = FAKE; };
withFake({});
const { m365, timeouts, notLoggedIn, assertTenant, TIMEOUT_MARK, M365_HOME } = await import('../lib/m365.mjs');
const { applyActions, failureReport, outcome, planStav, planVypis, planJson, STAV } = await import('../lib/apply.mjs');
const { KOD } = await import('../lib/kody.mjs');
const { gitState, gitFindings, deployGitFindings } = await import('../lib/gitcheck.mjs');
const { m365Home, hlavniCheckout } = await import('../lib/m365-home.mjs');
const { runAction } = await import('../lib/run.mjs');

// ---------- D01: časový limit ----------
test('timeouts: sekundy z project_config.json → ms, null/chybí = bez limitu, nesmysl = chyba', () => {
  assert.deepEqual(timeouts({ timeoutS: 120, timeoutBalicekS: null }), { call: 120000, pkg: null });
  assert.deepEqual(timeouts({}), { call: null, pkg: null });
  assert.throws(() => timeouts({ timeoutS: 0 }), /m365\.timeoutS musí být kladný počet sekund/);
  assert.throws(() => timeouts({ timeoutBalicekS: '600' }), /m365\.timeoutBalicekS/);
  // šablona: potvrzených 120 s, limit balíčku zatím neurčený
  assert.deepEqual(timeouts(), { call: 120000, pkg: null });
});

test('vypršený limit: status 124, hláška „výsledek neznámý“, žádné opakování; run.mjs z toho udělá výjimku', () => {
  withFake({ 'spo field add --webUrl W --output json': { timedOut: true } });
  const r = m365(['spo', 'field', 'add', '--webUrl', 'W']);
  assert.equal(r.status, 124);
  assert.equal(r.timedOut, true);
  assert.match(r.err, new RegExp(`nedoběhlo do 120 s \\(project_config.json m365.timeoutS\\).*${TIMEOUT_MARK}`));
  assert.match(r.err, /Nic neopakuj/);
  let calls = 0;
  const counting = (args) => { calls++; return m365(args); };
  assert.throws(() => runAction({ desc: 'přidat sloupec', m365: ['spo', 'field', 'add', '--webUrl', 'W'] }, { site: 'S', api: {}, m365: counting, rest: () => ({}) }), new RegExp(`přidat sloupec: .*${TIMEOUT_MARK}`));
  assert.equal(calls, 1, 'volání se neopakuje');
  // nahrání balíčku má vlastní klíč (v šabloně bez limitu, hláška ho jmenuje)
  withFake({ 'spo app add --filePath x --output json': { timedOut: true } });
  assert.match(m365(['spo', 'app', 'add', '--filePath', 'x']).err, /nedoběhlo do \? s \(project_config.json m365.timeoutBalicekS\)/);
});

test('apply: vypršený limit zastaví zápis a hláška řekne „neopakuj, počkej, nový plán“', () => {
  const actions = [{ area: 'struktura', desc: 'a' }, { area: 'struktura', desc: 'b' }, { area: 'práva', desc: 'c' }];
  const ran = [];
  const res = applyActions(actions, (a) => { ran.push(a.desc); if (a.desc === 'b') throw new Error(`b: m365 … ${TIMEOUT_MARK}: …`); }, { log: () => {} });
  assert.deepEqual(ran, ['a', 'b']);
  assert.equal(res.failed.timedOut, true);
  const msg = failureReport(res, 'dev');
  assert.match(msg, /proběhlo 1 z 3 akcí; selhala 2\. akce/);
  assert.match(msg, /NEOPAKUJ/);
  assert.match(msg, /nový plán: npm run deploy -- --env dev/);
  const plain = failureReport(applyActions(actions, (a) => { if (a.desc === 'a') throw new Error('Access denied'); }, { log: () => {} }), 'dev');
  assert.doesNotMatch(plain, /NEOPAKUJ/);
  assert.match(plain, /odstraň příčinu/);
});

// ---------- D02: průběh ----------
test('apply: každá akce „n/N“ s dobou trvání a celkovým časem', () => {
  let t = 0;
  const now = () => t;
  const out = [];
  const res = applyActions([{ area: 'balíček', desc: 'nahrát' }, { area: 'stránky', desc: 'publikovat' }], () => { t += 61500; }, { log: (s) => out.push(s), now });
  assert.equal(res.done, 2);
  assert.equal(out.join(''), '> 1/2 [balíček] nahrát … ok (61,5 s, celkem 1:02)\n> 2/2 [stránky] publikovat … ok (61,5 s, celkem 2:03)\n');
});

// ---------- U02: STAV a návratový kód ----------
test('STAV: přesně pět hodnot; plán bez zápisu = kód 10 při akcích i nálezech (nic se nezapsalo)', () => {
  assert.deepEqual(Object.values(STAV), ['STAV: prázdný', 'STAV: akce', 'STAV: nálezy', 'STAV: blokováno', 'STAV: chyba']);
  const navic = { kind: 'navíc', desc: 'sloupec X' };
  assert.deepEqual(outcome({ actions: [], findings: [] }), { stav: 'STAV: prázdný', code: 0 });
  assert.deepEqual(outcome({ actions: [{}], findings: [navic] }), { stav: 'STAV: akce', code: 10 });
  assert.deepEqual(outcome({ actions: [], findings: [navic] }), { stav: 'STAV: nálezy', code: 10 });
  assert.deepEqual(KOD, { hotovo: 0, chyba: 1, pouziti: 2, plan: 10, upozorneni: 11 });
  assert.equal(planStav({ actions: [], findings: [{ kind: 'git' }] }), 'STAV: nálezy');
});

test('STAV: blokující nález má přednost před akcemi i nálezy; kód plánu zůstává 10 (M18)', () => {
  const git = { kind: 'git', block: true, desc: 'necommitnuto' }, navic = { kind: 'navíc', desc: 'sloupec X' };
  assert.deepEqual(outcome({ actions: [{}, {}], findings: [git] }), { stav: 'STAV: blokováno', code: 10 });
  assert.deepEqual(outcome({ actions: [], findings: [navic, git] }), { stav: 'STAV: blokováno', code: 10 });
  assert.deepEqual(outcome({ actions: [{}], findings: [git] }, { written: true }), { stav: 'STAV: blokováno', code: 11 });
});

test('výpis plánu: blokující nálezy jsou první oddíl a potvrzení se nenabízí; bez nich potvrzení zůstává (M18)', () => {
  const o = { envName: 'dev', site: 'https://x/sites/Dev', areas: ['balíček', 'struktura'], withPackage: true, next: (h) => `potvrzení: npm run deploy -- --env dev --confirm ${h}` };
  const akce = [{ area: 'balíček', desc: 'nahrát' }, { area: 'struktura', desc: 'založit list' }];
  const p = { hash: 'abc', actions: akce, findings: [{ kind: 'navíc', desc: 'sloupec X' }, { kind: 'git', block: true, desc: 'necommitnuté změny' }, { kind: 'cockpit', block: true, desc: 'cockpit.url je prázdné' }], poznamky: [] };
  const radky = planVypis(p, o).split('\n').filter(Boolean);
  assert.match(radky[1], /^## BLOKUJE ZÁPIS \(2\)/);
  assert.deepEqual(radky.slice(2, 4), ['  ! git: necommitnuté změny', '  ! cockpit: cockpit.url je prázdné']);
  assert.ok(radky.indexOf('## balíček') > 3, 'akce až za blokujícími nálezy');
  assert.equal(radky.filter((r) => r.includes('git: necommitnuté')).length, 1, 'blokující nález se neopakuje v oddílu nálezy');
  assert.ok(radky.includes('  ! navíc: sloupec X'));
  assert.doesNotMatch(planVypis(p, o), /--confirm|potvrzení:/);
  assert.match(radky.at(-1), /^zápis je blokovaný: odstraň blokující nálezy z prvního oddílu a spusť plán znovu \(2 akcí čeká\)$/);
  const volny = planVypis({ ...p, findings: [p.findings[0]] }, o);
  assert.doesNotMatch(volny, /BLOKUJE/);
  assert.match(volny, /potvrzení: npm run deploy -- --env dev --confirm abc$/);
  const j = planJson(p, o);
  assert.equal(j.stav, 'blokováno');
  assert.deepEqual(j.blokuje.map((f) => f.kind), ['git', 'cockpit']);
  assert.equal(j.findings.length, 3);
  assert.equal(planJson({ ...p, findings: [] }, o).stav, 'akce');
});

test('kontrolní plán po zápisu: prázdný = 0; cokoli zbylo (i jen „navíc“) = 11, zapsáno s upozorněním', () => {
  const navic = { kind: 'navíc', desc: 'sloupec X' };
  assert.deepEqual(outcome({ actions: [], findings: [] }, { written: true }), { stav: 'STAV: prázdný', code: 0 });
  assert.deepEqual(outcome({ actions: [], findings: [navic, navic] }, { written: true }), { stav: 'STAV: nálezy', code: 11 });
  for (const kind of ['odchylka', 'konflikt', 'migrace', 'git']) assert.equal(outcome({ actions: [], findings: [navic, { kind }] }, { written: true }).code, 11, kind);
  assert.equal(outcome({ actions: [], findings: [{ kind: 'navíc', block: true }] }, { written: true }).code, 11);
  assert.deepEqual(outcome({ actions: [{}], findings: [] }, { written: true }), { stav: 'STAV: akce', code: 11 });
});

// ---------- U09: hláška nepřihlášení ----------
test('nepřihlášeno: řekne, kde přihlášení žije (vlastní domov, nebo společný v hlavním checkoutu), a přesný příkaz', () => {
  const cfg = { appId: 'APP', tenantId: 'TEN' };
  const vlastni = { home: '/p/app/.m365-home', spolecny: false, hlavni: null };
  const m = notLoggedIn({ homeExisted: false, m365cfg: cfg, domov: vlastni });
  assert.match(m, /přihlášení platí pro tenhle projekt \(domov \/p\/app\/\.m365-home — složka ještě neexistovala: nově založený projekt nebo čerstvý klon\)/);
  assert.match(m, /npm run m365 -- login --authType browser --appId APP --tenant TEN/);
  assert.doesNotMatch(notLoggedIn({ homeExisted: true, m365cfg: cfg, domov: vlastni }), /neexistovala/);
  const spolecny = notLoggedIn({ homeExisted: true, m365cfg: cfg, domov: { home: '/p/app/.m365-home', spolecny: true, hlavni: '/p/app' } });
  assert.match(spolecny, /společné pro všechny worktree tohoto repa a žije v hlavním checkoutu \(\/p\/app\/\.m365-home\); stačí se přihlásit jednou/);
  assert.ok(notLoggedIn({ m365cfg: cfg }).includes(M365_HOME));
  assert.match(notLoggedIn({ homeExisted: true, m365cfg: {} }), /doplň m365\.tenantId a m365\.appId/);
  withFake({ 'status --output json': { out: '{}' } });
  assert.throws(() => assertTenant('t'), /m365 není přihlášené; přihlášení (platí pro tenhle projekt|je společné pro všechny worktree)/);
});

// ---------- D15: git před zápisem ----------
const git = (cwd, ...a) => {
  const r = spawnSync('git', a, { cwd, encoding: 'utf8' });
  assert.equal(r.status, 0, `git ${a.join(' ')}: ${r.stderr}`);
  return r.stdout.trim();
};
function repo() {
  const d = mkdtempSync(join(tmpdir(), 'devkit-git-'));
  git(d, 'init', '-q', '-b', 'main');
  git(d, 'config', 'user.email', 'test@example.invalid');
  git(d, 'config', 'user.name', 'Test');
  git(d, 'config', 'commit.gpgsign', 'false');
  writeFileSync(join(d, 'a.txt'), 'a\n');
  git(d, 'add', 'a.txt');
  git(d, 'commit', '-q', '-m', 'první');
  return d;
}
function withRemote(d) {
  const bare = mkdtempSync(join(tmpdir(), 'devkit-git-remote-'));
  git(bare, 'init', '-q', '--bare');
  git(d, 'remote', 'add', 'origin', bare);
  git(d, 'push', '-q', 'origin', 'main');
  return d;
}

test('git: čistý a pushnutý strom = žádný nález', () => {
  const d = withRemote(repo());
  const s = gitState(d);
  assert.equal(s.repo, true);
  assert.deepEqual(s.dirty, []);
  assert.deepEqual(s.pushedTo, ['origin/main']);
  assert.deepEqual(gitFindings(s), []);
});

test('git: necommitnutá změna i nový soubor = blokující nález; ani releases/ nemá výjimku (záznam o nasazení je od 0.6 jen na webu)', () => {
  const r = withRemote(repo());
  mkdirSync(join(r, 'releases'));
  writeFileSync(join(r, 'releases', 'dev.jsonl'), '{}\n');
  assert.match(gitFindings(gitState(r))[0].desc, /necommitnuté změny \(releases\/(dev\.jsonl)?\)/);
  const d = withRemote(repo());
  writeFileSync(join(d, 'a.txt'), 'změna\n');
  writeFileSync(join(d, 'nový soubor.txt'), 'x\n');
  const f = gitFindings(gitState(d));
  assert.equal(f.length, 1);
  assert.equal(f[0].kind, 'git');
  assert.equal(f[0].block, true);
  assert.match(f[0].desc, /necommitnuté změny \(a\.txt, nový soubor\.txt\)/);
});

test('git: commit, který není v žádné vzdálené větvi = nález „git push“', () => {
  const d = withRemote(repo());
  writeFileSync(join(d, 'b.txt'), 'b\n');
  git(d, 'add', 'b.txt');
  git(d, 'commit', '-q', '-m', 'druhý');
  const f = gitFindings(gitState(d));
  assert.equal(f.length, 1);
  assert.match(f[0].desc, /není v žádné vzdálené větvi \(origin\) — git push/);
  git(d, 'push', '-q', 'origin', 'main');
  assert.deepEqual(gitFindings(gitState(d)), []);
});

test('git: repo bez remote a složka mimo git = odmítnutí s návodem', () => {
  const f = gitFindings(gitState(repo()));
  assert.equal(f.length, 1);
  assert.match(f[0].desc, /repo nemá remote — přidej ho \(git remote add origin <url>/);
  const none = gitFindings(gitState(mkdtempSync(join(tmpdir(), 'devkit-nogit-'))));
  assert.equal(none.length, 1);
  assert.match(none[0].desc, /není git repo/);
});

test('git: stejneRepo pozná jinak zapsanou adresu téhož repa a odliší jiné repo', async () => {
  const { stejneRepo } = await import('../lib/gitcheck.mjs');
  const zaklad = 'https://host.example/org/repo.git';
  for (const jina of ['https://host.example/org/repo', 'https://host.example/org/repo/', 'https://HOST.example/org/repo.git', 'https://uzivatel@host.example/org/repo.git', 'git@host.example:org/repo.git', 'ssh://git@host.example:22/org/repo'])
    assert.equal(stejneRepo(zaklad, jina), true, jina);
  for (const jina of ['https://host.example/org/jine.git', 'https://host.example/jina-org/repo.git', 'https://jinde.example/org/repo.git', 'https://host.example/org/Repo.git', ''])
    assert.equal(stejneRepo(zaklad, jina), false, jina);
  assert.equal(stejneRepo('/cesta/k/repu', '/cesta/k/repu'), true);
});

test('git: project_config.json → git.remote na jiné repo než origin = blokující nález (prereq to hlásí jako FAIL); jiný zápis téhož repa, shoda a prázdná hodnota ne', () => {
  const d = withRemote(repo());
  const origin = gitState(d).origin;
  assert.ok(origin, 'gitState nese adresu origin');
  assert.deepEqual(gitFindings(gitState(d), { remote: origin }), []);
  assert.deepEqual(gitFindings(gitState(d), { remote: '' }), []);
  const f = gitFindings(gitState(d), { remote: 'https://jinde/repo.git' });
  assert.deepEqual(f.map((x) => [x.kind, x.block]), [['git', true]]);
  assert.match(f[0].desc, /git\.remote \(https:\/\/jinde\/repo\.git\) míří na jiné repo než origin/);
  assert.deepEqual(gitFindings({ ...gitState(d), origin: 'https://host.example/org/repo.git' }, { remote: 'git@host.example:org/repo' }), []);
});

test('nástroje: jedna kontrola pro prereq i plán — s https bez certifikátu je řádek FAIL blokující nález; verze Node a nástrojů se nekontrolují', async () => {
  const { kontrolaNastroju, nastrojeNalezy } = await import('../lib/nastroje.mjs');
  const d = mkdtempSync(join(tmpdir(), 'devkit-nastroje-'));
  // projekt bez spfx/: žádný řádek; chybějící node_modules ani jiná verze nástroje nález nejsou (hlídá npm ci)
  writeFileSync(join(d, 'package.json'), JSON.stringify({ engines: { node: '>=998.0.0 <999.0.0' }, devDependencies: { 'nastroj-a': '1.2.3' } }));
  assert.deepEqual(kontrolaNastroju(d), []);
  assert.deepEqual(nastrojeNalezy(d), []);
  // ladicí server na http: jeden řádek OK
  mkdirSync(join(d, 'spfx', 'config'), { recursive: true });
  writeFileSync(join(d, 'spfx', 'package.json'), '{}');
  assert.deepEqual(kontrolaNastroju(d).map((x) => [x.name, x.level]), [['ladicí server', 'OK']]);
  // tenhle projekt: bez nálezů
  assert.deepEqual(nastrojeNalezy(), []);
});

test('git: obejití jen pro testy — DEVKIT_TEST_BEZ_GITU platí výhradně spolu s M365_FAKE', () => {
  const d = repo(); // bez remote → normálně nález
  assert.equal(deployGitFindings(d, { DEVKIT_TEST_BEZ_GITU: '1' }).length, 1, 'bez M365_FAKE se proměnná ignoruje');
  assert.deepEqual(deployGitFindings(d, { DEVKIT_TEST_BEZ_GITU: '1', M365_FAKE: FAKE }), []);
  assert.equal(deployGitFindings(d, { M365_FAKE: FAKE }).length, 1, 'samotné M365_FAKE kontrolu nevypne');
});

// ---------- D07: práva uživatele bez jeho účtu ----------
test('prava: přímé členství → role, getusereffectivepermissions po listech, shoda / odchylka proti manifestu', async () => {
  const { buildModel } = await import('../lib/manifest.mjs');
  const { spApi } = await import('../lib/state.mjs');
  const { groupOf, PERMISSION_KIND } = await import('../lib/plan/perms.mjs');
  const { readUserPerms, evaluateUserPerms, formatUserPerms, claimsOf } = await import('../lib/prava.mjs');
  const SITE = 'https://t.sharepoint.com/sites/x';
  const model = buildModel({
    roles: { owner: {}, user: {}, editor: {} },
    levels: { read: { builtin: 'Read' }, edit: { builtin: 'Contribute' } },
    lists: {
      Hlaseni: { class: 'operational', access: { user: 'edit', editor: 'edit' } },
      Kategorie: { class: 'config', key: 'Kod', access: { user: 'read', editor: 'edit' } },
      Volny: { class: 'operational', access: 'inherit' },
    },
  }, 'CADK');
  const env = { roles: { user: { bindTo: '@members' }, editor: { members: { emails: [] } } } };
  const low = (...names) => String(names.reduce((m, n) => m | (1 << (PERMISSION_KIND[n] - 1)), 0));
  const READ = { High: 0, Low: low('ViewListItems', 'OpenItems', 'ViewVersions', 'Open', 'ViewPages') };
  const CONTRIB = { High: 0, Low: low('ViewListItems', 'AddListItems', 'EditListItems', 'DeleteListItems', 'OpenItems', 'Open', 'ViewPages') };
  const key = (url) => `request --url ${SITE}/_api/${url} --method get --accept application/json;odata=nometadata --output json`;
  const login = claimsOf('Anna@Firma.cz');
  assert.equal(login, 'i:0#.f|membership|anna@firma.cz');
  const enc = encodeURIComponent(login);
  const ql = encodeURIComponent(login);
  const list = (u) => `web/GetList('${encodeURIComponent(`/sites/x/${u}`)}')/getusereffectivepermissions(@u)?@u='${enc}'`;
  withFake({
    [key('web/AssociatedOwnerGroup?$select=Title')]: { out: '{"Title":"x Owners"}' },
    [key('web/AssociatedMemberGroup?$select=Title')]: { out: '{"Title":"x Members"}' },
    [key('web/AssociatedVisitorGroup?$select=Title')]: { out: '{"Title":"x Visitors"}' },
    [key(`web/siteusers/GetByLoginName('${ql}')?$select=Id,Title,Email,IsSiteAdmin`)]: { out: '{"Id":7,"Title":"Anna","IsSiteAdmin":false}' },
    [key(`web/siteusers/GetByLoginName('${ql}')/Groups?$select=Title`)]: { out: '{"value":[{"Title":"x Members"}]}' },
    [key('web/roledefinitions?$select=Id,Name,RoleTypeKind,Hidden,BasePermissions')]: { out: JSON.stringify({ value: [
      { Id: 1, Name: 'Čtení', RoleTypeKind: 2, Hidden: false, BasePermissions: READ },
      { Id: 2, Name: 'Přispívání', RoleTypeKind: 3, Hidden: false, BasePermissions: CONTRIB },
      { Id: 3, Name: 'Úplné řízení', RoleTypeKind: 5, Hidden: false, BasePermissions: { High: '2147483647', Low: '4294967295' } },
    ] }) },
    [key(list('Lists/CADKHlaseni'))]: { out: JSON.stringify(CONTRIB) },
    [key(list('Lists/CADKKategorie'))]: { out: JSON.stringify(CONTRIB) }, // má víc, než manifest dává roli user
    [key(list('Lists/CADKVolny'))]: { out: JSON.stringify(READ) },
  });
  const data = readUserPerms({ model, api: spApi(SITE), login: 'Anna@Firma.cz' });
  const res = evaluateUserPerms({ model, env, data, groupOf: groupOf(model, env) });
  assert.deepEqual(res.roles, ['user']);
  const by = Object.fromEntries(res.rows.map((r) => [r.key, r]));
  assert.equal(by.Hlaseni.verdict, 'shoda');
  assert.equal(by.Kategorie.verdict, 'odchylka');
  assert.deepEqual(by.Kategorie.extra, ['přidá', 'upraví', 'maže']);
  assert.deepEqual(by.Kategorie.missing, []);
  assert.equal(by.Volny.verdict, 'dědí');
  const { lines, ok } = formatUserPerms(res, { login, envName: 'dev' });
  assert.equal(ok, false);
  assert.ok(lines.some((l) => /!! CADK-Kategorie: má čte, přidá, upraví, maže; podle manifestu čte \(user → read\)/.test(l)), lines.join('\n'));
  // výslovná role přebije odvození: editor má na Kategorie Contribute → shoda
  const asEditor = evaluateUserPerms({ model, env, data, roles: ['editor'], groupOf: groupOf(model, env) });
  assert.equal(asEditor.rows.find((r) => r.key === 'Kategorie').verdict, 'shoda');
  assert.equal(asEditor.rolesFrom, '--role');
});

// ---------- Z-LOGIN: společný domov přihlášení pro worktree ----------
test('m365Home: hlavní checkout vlastní; nový worktree společný; worktree s vlastním domovem si ho nechá; mimo git vlastní', () => {
  const real = (p) => spawnSync('node', ['-e', 'process.stdout.write(require("fs").realpathSync(process.argv[1]))', p], { encoding: 'utf8' }).stdout;
  const base = real(mkdtempSync(join(tmpdir(), 'devkit-m365home-')));
  const hlavni = join(base, 'app');
  mkdirSync(hlavni);
  const git = (cwd, ...a) => { const r = spawnSync('git', ['-c', 'user.name=t', '-c', 'user.email=t@t', ...a], { cwd, encoding: 'utf8' }); assert.equal(r.status, 0, r.stderr); };
  assert.deepEqual(m365Home(hlavni), { home: join(hlavni, '.m365-home'), spolecny: false, hlavni: null }); // mimo git
  git(hlavni, 'init', '-q');
  writeFileSync(join(hlavni, 'a.txt'), '1');
  git(hlavni, 'add', 'a.txt');
  git(hlavni, 'commit', '-q', '-m', 'x');
  assert.equal(hlavniCheckout(hlavni), null);
  assert.deepEqual(m365Home(hlavni), { home: join(hlavni, '.m365-home'), spolecny: false, hlavni: null });
  const wt = join(base, 'app.wt', 'vetev');
  git(hlavni, 'worktree', 'add', '-q', '-b', 'vetev', wt);
  // nový worktree: společný domov hlavního checkoutu, i když tam ještě není (první přihlášení ho založí tam)
  assert.deepEqual(m365Home(wt), { home: join(hlavni, '.m365-home'), spolecny: true, hlavni });
  assert.deepEqual(m365Home(join(wt)), m365Home(wt));
  // worktree přihlášený před 0.5.1 má vlastní domov: má přednost, nikdo není odhlášen a nic se nepřesouvá
  mkdirSync(join(wt, '.m365-home'));
  writeFileSync(join(wt, '.m365-home', 'spojeni.json'), '{}');
  mkdirSync(join(hlavni, '.m365-home'));
  assert.deepEqual(m365Home(wt), { home: join(wt, '.m365-home'), spolecny: false, hlavni: null });
  assert.equal(readFileSync(join(wt, '.m365-home', 'spojeni.json'), 'utf8'), '{}');
});
