// npm test — SpSource (datová vrstva nad SharePointem) s podvrženým fetch: tvar REST volání, stránkování
// přes odata.nextLink, bity EffectiveBasePermissions, request digest a odmítnutí 403. Bez sítě, bez emulátoru.
// Proč: SpSource jinak běží jen na skutečné stránce SP, takže chyba v něm by se ukázala až na DEV.
// SpSource.ts se pro test přeloží esbuildem ze spfx/node_modules (týž, kterým staví harness npm run dev);
// bez `npm --prefix spfx install` test selže s návodem, nepřeskočí se.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { ROOT } from '../lib/config.mjs';

const SPFX = join(ROOT, 'spfx');
async function load() {
  if (!existsSync(join(SPFX, 'node_modules', 'esbuild'))) throw new Error('chybí spfx/node_modules/esbuild — npm --prefix spfx install');
  const esbuild = createRequire(join(SPFX, 'package.json'))('esbuild');
  const out = await esbuild.build({ entryPoints: [join(SPFX, 'src', 'app', 'data', 'SpSource.ts')], bundle: true, format: 'esm', platform: 'neutral', write: false, logLevel: 'silent' });
  return import(`data:text/javascript;base64,${Buffer.from(out.outputFiles[0].text).toString('base64')}`);
}
const { SpSource } = await load();

const WEB = 'https://t.sharepoint.com/sites/x';
const MANIFEST = {
  prefix: 'CADK', roles: {},
  lists: {
    Hlaseni: { class: 'operational', title: 'CADK-Hlášení', url: 'Lists/CADKHlaseni', access: {}, fields: [{ name: 'Kategorie', type: 'Text' }, { name: 'Popis', type: 'Note' }] },
    Terminy: { class: 'operational', title: 'CADK-Termíny', url: 'Lists/CADKTerminy', access: {}, fields: [{ name: 'Termin', type: 'date' }, { name: 'Kdy', type: 'datetime' }] },
    Divne: { class: 'config', title: "O'Neil", url: "Lists/O'Neil", access: {} },
  },
  libraries: { Assets: { class: 'config', title: 'CADK-Assets', url: 'CADKAssets', access: {} } },
};
const LIST = `${WEB}/_api/web/GetList('${encodeURIComponent('/sites/x/Lists/CADKHlaseni')}')`;

// podvržený fetch: odpovědi podle URL (a metody), zapisuje každé volání
function fakeFetch(routes) {
  const calls = [];
  globalThis.fetch = async (url, init = {}) => {
    calls.push({ url, method: init.method || 'GET', headers: init.headers || {}, body: init.body });
    const r = routes[`${init.method || 'GET'} ${url}`];
    if (!r) return { ok: false, status: 404, json: async () => ({}), text: async () => 'nenalezeno' };
    const status = r.status || 200;
    return { ok: status < 400, status, json: async () => r.json, text: async () => JSON.stringify(r.json ?? '') };
  };
  return calls;
}
const src = () => new SpSource(WEB, MANIFEST, 'Anna');

test('can: GetList podle URL z manifestu, bity Low (view 1, add 2, edit 3, override 9), jedno volání na list', async () => {
  const calls = fakeFetch({ [`GET ${LIST}/EffectiveBasePermissions`]: { json: { High: '0', Low: String(1 | 2 | 4) } } });
  const s = src();
  assert.deepEqual([await s.can('Hlaseni', 'read'), await s.can('Hlaseni', 'add'), await s.can('Hlaseni', 'edit'), await s.can('Hlaseni', 'edit-all')], [true, true, true, false]);
  assert.equal(calls.length, 1, 'práva listu se čtou jednou');
  fakeFetch({ [`GET ${LIST}/EffectiveBasePermissions`]: { json: { Low: String(1 | 4 | 256) } } });
  const t = src();
  assert.deepEqual([await t.can('Hlaseni', 'add'), await t.can('Hlaseni', 'edit-all')], [false, true]);
});

test('can: list, který uživatel nevidí (403/404), = žádná práva; apostrof v URL se zdvojí', async () => {
  const calls = fakeFetch({ [`GET ${LIST}/EffectiveBasePermissions`]: { status: 403 } });
  const s = src();
  assert.equal(await s.can('Hlaseni', 'read'), false);
  assert.equal(await s.can('Divne', 'read'), false);
  assert.equal(calls[1].url, `${WEB}/_api/web/GetList('${encodeURIComponent("/sites/x/Lists/O''Neil")}')/EffectiveBasePermissions`);
  // 403/404 se pamatuje do znovunačtení stránky: druhý dotaz už nejde na síť
  await s.can('Hlaseni', 'add');
  assert.equal(calls.length, 2);
});

test('can: chyba sítě a 5xx NEJSOU „bez práva“ — hází se, nepamatují se a další volání to zkusí znovu (D10)', async () => {
  fakeFetch({ [`GET ${LIST}/EffectiveBasePermissions`]: { status: 503 } });
  const s = src();
  await assert.rejects(s.can('Hlaseni', 'read'), (e) => e.status === 503 && /HTTP 503/.test(e.message));
  const calls = fakeFetch({ [`GET ${LIST}/EffectiveBasePermissions`]: { json: { Low: String(1) } } });
  assert.equal(await s.can('Hlaseni', 'read'), true, 'po chybě nový pokus');
  assert.equal(calls.length, 1);
  globalThis.fetch = async () => { throw new TypeError('Failed to fetch'); };
  await assert.rejects(src().can('Hlaseni', 'read'), /Failed to fetch/);
});

test('getItems: $select z polí manifestu + autor, stránkuje přes odata.nextLink do konce, 403 = AccessDenied', async () => {
  const first = `${LIST}/items?$select=Id,Title,Created,Modified,Kategorie,Popis,Author/Title&$expand=Author`;
  const next = `${LIST}/items?%24skiptoken=Paged%3dTRUE%26p_ID%3d2`;
  const calls = fakeFetch({
    [`GET ${first}`]: { json: { value: [{ Id: 1, Title: 'a', Author: { Title: 'Anna' } }, { Id: 2, Title: 'b' }], 'odata.nextLink': next } },
    [`GET ${next}`]: { json: { value: [{ Id: 3, Title: 'c', Author: { Title: 'Bob' } }] } },
  });
  const items = await src().getItems('Hlaseni');
  assert.deepEqual(items.map((i) => [i.Id, i._author]), [[1, 'Anna'], [2, undefined], [3, 'Bob']]);
  assert.deepEqual(calls.map((c) => c.url), [first, next]);
  assert.equal(calls[0].headers.Accept, 'application/json;odata=nometadata');
  fakeFetch({ [`GET ${first}`]: { status: 403 } });
  await assert.rejects(src().getItems('Hlaseni'), (e) => e.status === 403 && /read/.test(e.message));
});

test('addItem: digest z contextinfo jednou na víc zápisů, tělo bez Id a _polí, 403 = AccessDenied', async () => {
  const calls = fakeFetch({
    [`POST ${WEB}/_api/contextinfo`]: { json: { FormDigestValue: 'DIG', FormDigestTimeoutSeconds: 1800 } },
    [`POST ${LIST}/items`]: { json: { Id: 9, Title: 'nové' } },
  });
  const s = src();
  assert.equal((await s.addItem('Hlaseni', { Id: 5, Title: 'nové', Kategorie: 'IT', _author: 'Anna' })).Id, 9);
  await s.addItem('Hlaseni', { Title: 'druhé' });
  assert.deepEqual(calls.map((c) => `${c.method} ${c.url.replace(WEB, '')}`), ['POST /_api/contextinfo', `POST ${LIST.replace(WEB, '')}/items`, `POST ${LIST.replace(WEB, '')}/items`]);
  assert.deepEqual(JSON.parse(calls[1].body), { Title: 'nové', Kategorie: 'IT' });
  assert.equal(calls[1].headers['X-RequestDigest'], 'DIG');
  fakeFetch({ [`POST ${WEB}/_api/contextinfo`]: { json: { FormDigestValue: 'D', FormDigestTimeoutSeconds: 1800 } }, [`POST ${LIST}/items`]: { status: 403 } });
  await assert.rejects(src().addItem('Hlaseni', { Title: 'x' }), (e) => e.status === 403 && /add/.test(e.message));
});

test('updateItem: MERGE na items(id) s IF-MATCH *, tělo bez Id a _polí, 403 = AccessDenied edit', async () => {
  const calls = fakeFetch({
    [`POST ${WEB}/_api/contextinfo`]: { json: { FormDigestValue: 'DIG', FormDigestTimeoutSeconds: 1800 } },
    [`POST ${LIST}/items(7)`]: { status: 204 },
  });
  await src().updateItem('Hlaseni', 7, { Id: 7, Popis: 'nový', _author: 'Anna' });
  const c = calls[1];
  assert.equal(c.url, `${LIST}/items(7)`);
  assert.deepEqual([c.headers['X-HTTP-Method'], c.headers['IF-MATCH'], c.headers['X-RequestDigest']], ['MERGE', '*', 'DIG']);
  assert.deepEqual(JSON.parse(c.body), { Popis: 'nový' });
  fakeFetch({ [`POST ${WEB}/_api/contextinfo`]: { json: { FormDigestValue: 'D', FormDigestTimeoutSeconds: 1800 } }, [`POST ${LIST}/items(7)`]: { status: 403 } });
  await assert.rejects(src().updateItem('Hlaseni', 7, { Popis: 'x' }), (e) => e.status === 403 && /edit/.test(e.message));
});

test('assety: přímá URL knihovny z manifestu (origin + cesta), jméno zakódované; neznámý list = chyba', async () => {
  const s = src();
  await s.init();
  assert.equal(s.assetUrl('logo firmy.svg'), 'https://t.sharepoint.com/sites/x/CADKAssets/logo%20firmy.svg');
  fakeFetch({});
  await assert.rejects(s.getItems('Neni'), /manifest nezná list ani knihovnu "Neni"/);
});

// ── filtrované čtení, přílohy položek, hledání lidí ──
const SEL = `${LIST}/items?$select=Id,Title,Created,Modified,Kategorie,Popis,Author/Title&$expand=Author`;

test('getItems s where: $filter pole eq hodnota (číslo holé, text v apostrofech se zdvojením), víc podmínek and', async () => {
  const url = `${SEL}&$filter=Pozadavek eq 12 and Kategorie eq '${encodeURIComponent("O''Neil")}'`;
  const calls = fakeFetch({ [`GET ${url}`]: { json: { value: [{ Id: 1, Title: 'a' }] } } });
  assert.equal((await src().getItems('Hlaseni', { where: { Pozadavek: 12, Kategorie: "O'Neil" } })).length, 1);
  assert.equal(calls[0].url, url);
});

test('addAttachment: POST items(id)/AttachmentFiles/add(FileName=…) s digestem a tělem souboru; 403 = AccessDenied edit', async () => {
  const add = `${LIST}/items(5)/AttachmentFiles/add(FileName='obr-1.png')`;
  const calls = fakeFetch({
    [`POST ${WEB}/_api/contextinfo`]: { json: { FormDigestValue: 'DIG', FormDigestTimeoutSeconds: 1800 } },
    [`POST ${add}`]: { json: { FileName: 'obr-1.png', ServerRelativeUrl: '/sites/x/Lists/CADKHlaseni/Attachments/5/obr-1.png' } },
  });
  const blob = new Blob(['abc'], { type: 'image/png' });
  const a = await src().addAttachment('Hlaseni', 5, 'obr-1.png', blob);
  assert.deepEqual(a, { name: 'obr-1.png', url: 'https://t.sharepoint.com/sites/x/Lists/CADKHlaseni/Attachments/5/obr-1.png', itemId: 5 }, 'autora položky ani přílohy odpověď nenese — nevymýšlí se');
  assert.equal(calls[1].body, blob);
  assert.equal(calls[1].headers['X-RequestDigest'], 'DIG');
  fakeFetch({ [`POST ${WEB}/_api/contextinfo`]: { json: { FormDigestValue: 'D', FormDigestTimeoutSeconds: 1800 } }, [`POST ${add}`]: { status: 403 } });
  await assert.rejects(src().addAttachment('Hlaseni', 5, 'obr-1.png', blob), (e) => e.status === 403 && /edit/.test(e.message));
  fakeFetch({ [`POST ${WEB}/_api/contextinfo`]: { json: { FormDigestValue: 'D', FormDigestTimeoutSeconds: 1800 } }, [`POST ${add}`]: { status: 400 } });
  await assert.rejects(src().addAttachment('Hlaseni', 5, 'obr-1.png', blob), /HTTP 400/);
});

test('listAttachments: items s $expand=AttachmentFiles,Author (autor POLOŽKY, příloha autora nemá), filtr where, stránkování nextLink, URL zakódovaná po částech; 403 = AccessDenied read', async () => {
  const url = `${LIST}/items?$select=Id,Author/Title,AttachmentFiles&$expand=Author,AttachmentFiles&$filter=Pozadavek eq 7`;
  const next = `${url}&$skiptoken=x`;
  const calls = fakeFetch({
    [`GET ${url}`]: { json: { value: [{ Id: 1, Author: { Title: 'Anna' }, AttachmentFiles: [{ FileName: 'a b.pdf', ServerRelativeUrl: '/sites/x/Lists/CADKHlaseni/Attachments/1/a b.pdf' }] }, { Id: 2, Author: { Title: 'Petr' }, AttachmentFiles: [] }], 'odata.nextLink': next } },
    [`GET ${next}`]: { json: { value: [{ Id: 3, Author: { Title: 'Petr' }, AttachmentFiles: [{ FileName: 'obr-2.png', ServerRelativeUrl: '/sites/x/Lists/CADKHlaseni/Attachments/3/obr-2.png' }] }] } },
  });
  assert.deepEqual(await src().listAttachments('Hlaseni', { where: { Pozadavek: 7 } }), [
    { name: 'a b.pdf', url: 'https://t.sharepoint.com/sites/x/Lists/CADKHlaseni/Attachments/1/a%20b.pdf', itemId: 1, itemAuthor: 'Anna' },
    { name: 'obr-2.png', url: 'https://t.sharepoint.com/sites/x/Lists/CADKHlaseni/Attachments/3/obr-2.png', itemId: 3, itemAuthor: 'Petr' },
  ]);
  assert.equal(calls.length, 2);
  fakeFetch({ [`GET ${url}`]: { status: 403 } });
  await assert.rejects(src().listAttachments('Hlaseni', { where: { Pozadavek: 7 } }), (e) => e.status === 403);
});

test('searchPeople: siteusers jen lidé, substringof ve jménu nebo e-mailu, $top; prázdný dotaz nevolá síť', async () => {
  const url = `${WEB}/_api/web/siteusers?$select=Title,Email&$filter=PrincipalType eq 1 and (substringof('nov',Title) or substringof('nov',Email))&$top=20`;
  const calls = fakeFetch({ [`GET ${url}`]: { json: { value: [{ Title: 'Jan Novák', Email: 'jan.novak@x.cz' }, { Title: 'Nova', Email: '' }] } } });
  assert.deepEqual(await src().searchPeople(' nov '), [{ name: 'Jan Novák', email: 'jan.novak@x.cz' }, { name: 'Nova', email: undefined }]);
  assert.deepEqual(await src().searchPeople('  '), []);
  assert.equal(calls.length, 1);
});

// ── verze položky: tvar odpovědi podle čtení na tenantu PPF 2026-11-11 (od nejnovější, VersionId, Editor.LookupValue, Modified se Z) ──
test('getVersions: GET items(id)/versions, seřadí od nejstarší podle VersionId, kdo = Editor.LookupValue, kdy = Modified, jen pole manifestu + Title; 403 = AccessDenied read', async () => {
  const url = `${LIST}/items(7)/versions`;
  const calls = fakeFetch({ [`GET ${url}`]: { json: { value: [
    { VersionId: 1024, VersionLabel: '2.0', IsCurrentVersion: true, Created: '2026-11-11T14:19:31', Modified: '2026-11-11T14:19:31Z', Editor: { LookupId: 6, LookupValue: 'Petr', Email: 'p@x.cz' }, Title: 'a', Kategorie: 'DOTAZ', Popis: null, Stav: 'Analýza', OData__x005f_UIVersionString: '2.0' },
    { VersionId: 512, VersionLabel: '1.0', IsCurrentVersion: false, Created: '2026-11-11T14:19:11', Modified: '2026-11-11T14:19:11Z', Editor: { LookupId: 5, LookupValue: 'Anna', Email: 'a@x.cz' }, Title: 'a', Kategorie: 'NEFUNGUJE' },
  ] } } });
  assert.deepEqual(await src().getVersions('Hlaseni', 7), [
    { verze: '1.0', kdy: '2026-11-11T14:19:11Z', kdo: 'Anna', pole: { Title: 'a', Kategorie: 'NEFUNGUJE', Popis: null } },
    { verze: '2.0', kdy: '2026-11-11T14:19:31Z', kdo: 'Petr', pole: { Title: 'a', Kategorie: 'DOTAZ', Popis: null } },
  ]);
  assert.equal(calls[0].url, url);
  fakeFetch({ [`GET ${url}`]: { status: 403 } });
  await assert.rejects(src().getVersions('Hlaseni', 7), (e) => e.status === 403 && /read/.test(e.message));
});

test('data: sloupec date z UTC na místní den a zpět (Praha), datetime beze změny; formát d. M. yyyy', async () => {
  const tz = process.env.TZ;
  process.env.TZ = 'Europe/Prague';
  try {
    const TL = `${WEB}/_api/web/GetList('${encodeURIComponent('/sites/x/Lists/CADKTerminy')}')`;
    const sel = `${TL}/items?$select=Id,Title,Created,Modified,Termin,Kdy,Author/Title&$expand=Author`;
    const calls = fakeFetch({
      [`GET ${sel}`]: { json: { value: [{ Id: 1, Title: 'a', Termin: '2026-11-12T23:00:00Z', Kdy: '2026-11-12T23:30:00Z', Author: { Title: 'Anna' } }, { Id: 2, Title: 'b', Termin: null }] } },
      [`POST ${WEB}/_api/contextinfo`]: { json: { FormDigestValue: 'd', FormDigestTimeoutSeconds: 1800 } },
      [`POST ${TL}/items(1)`]: { status: 204 },
    });
    const s = src();
    const [a, b] = await s.getItems('Terminy');
    assert.equal(a.Termin, '2026-11-13', 'půlnoc v Praze je předchozí den 23:00Z — appka musí vidět 13.');
    assert.equal(a.Kdy, '2026-11-12T23:30:00Z');
    assert.equal(b.Termin, null);
    await s.updateItem('Terminy', 1, { Termin: '2026-11-13', Title: 'x' });
    assert.deepEqual(JSON.parse(calls.at(-1).body), { Termin: '2026-11-12T23:00:00.000Z', Title: 'x' });
    const { formatDate, formatDateTime, localDate } = await loadDates();
    assert.equal(formatDate('2026-11-12T23:00:00Z'), '13. 11. 2026');
    assert.equal(formatDate('2026-07-01'), '1. 7. 2026');
    assert.equal(formatDateTime('2026-07-01T06:05:00Z'), '1. 7. 2026 8:05', 'letní čas UTC+2');
    assert.equal(localDate(''), null);
  } finally {
    if (tz === undefined) delete process.env.TZ; else process.env.TZ = tz;
  }
});

async function loadDates() {
  const esbuild = createRequire(join(SPFX, 'package.json'))('esbuild');
  const out = await esbuild.build({ entryPoints: [join(SPFX, 'src', 'app', 'data', 'dates.ts')], bundle: true, format: 'esm', platform: 'neutral', write: false, logLevel: 'silent' });
  return import(`data:text/javascript;base64,${Buffer.from(out.outputFiles[0].text).toString('base64')}`);
}
