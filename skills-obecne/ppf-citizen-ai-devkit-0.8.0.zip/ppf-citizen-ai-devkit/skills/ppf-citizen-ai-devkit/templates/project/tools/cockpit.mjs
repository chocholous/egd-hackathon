// npm run cockpit [-- --env dev --env test]
//
// Export pro cockpit (references/cockpit.md): pro KAŽDÉ prostředí z project_config.json kromě local (nebo jen pro
// --env) zapíše .devkit/cockpit/<env>.json = tělo dokumentu prostredi/<env> (poslední nasazení ze záznamu na webu
// _deploy/<env>.json, vlákna připomínek z webu). Prostředí bez vyplněného "site" dostane dokument se stavem
// „nezaloženo“ (web se nečte), aby cockpit ukazoval všechna prostředí, ne jen ta nasazená. Agent ho pak zapíše nástrojem ArtifactData (get → set s if_version, file_path).
// Jen čte (REST GET přes m365 request) a zapisuje do gitignored .devkit/. Logika je v lib/cockpit.mjs.
// Vždy zapíše i .devkit/cockpit/projekt.json = { schema, nazev, prefix, web: null, prace } pro meta/projekt: název
// a prefix z project_config.json, prace = jméno složky, repo, větev (bez cesty a názvu stroje).
// A .devkit/cockpit/obsah.json = dokument meta/obsah (co v appce je: role, seznamy, knihovny, stránky) z manifestu.
// npm run cockpit -- --log <export.json>: deník rozhodnutí do gitu (jen databáze → git, bez sítě): z JSON exportu db
// (formát v references/cockpit.md §Deník rozhodnutí) PŘIDÁ nové záznamy do docs/cockpit/rozhodnuti.jsonl a obnoví
// docs/cockpit/{zadani,otazky,ukoly}.json bez osobních polí. Žádný jiný výstup se v tomhle režimu nevyrábí.
// Exit (lib/kody.mjs): 0 export vznikl celý (prostředí bez "site" i web před prvním nasazením bez listu připomínek
// jsou stav, ne chyba), 11 export vznikl, ale některé prostředí s vyplněným "site" se nepodařilo přečíst (nepřihlášeno,
// web nedostupný: soubor pro něj má stav „necteno“ a důvod je vypsaný), 2 použití. Kód 10 tenhle příkaz nevrací.
import { existsSync, mkdirSync, readFileSync, readdirSync, realpathSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { spawnSync } from 'node:child_process';
import { ROOT, loadConfig, loadManifest } from './lib/config.mjs';
import { KOD } from './lib/kody.mjs';
import { DATA_DIRS } from './lib/mockgen.mjs';
import { loadProject } from './lib/project.mjs';
import { readFeedbackItems, feedbackListExists, threads, withFeedback, FEEDBACK_KEY } from './lib/feedback.mjs';
import { envDoc, workDoc, contentDoc, checkSize, normalizeExport, decisionRecords, appendLog, snapshots } from './lib/cockpit.mjs';
import { LOCAL_URL, isLocalCockpit, readDb, writeDoc, startCockpitServer } from './lib/cockpit-local.mjs';

const OUT_DIR = join(ROOT, '.devkit', 'cockpit'); // gitignored (.devkit/)
const argv = process.argv.slice(2);
const USAGE = 'použití: npm run cockpit [-- --env dev --env test]\n  bez --env: všechna prostředí z project_config.json kromě local (bez "site" se stavem „nezaloženo“)\n       npm run cockpit -- --log <export-db.json>   (deník rozhodnutí do docs/cockpit/)';
const USAGE_MISTNI = `\n       npm run cockpit -- --serve   (místní cockpit: project_config.json → cockpit.url je "${LOCAL_URL}"; server na 127.0.0.1, adresu vypíše a zapíše do .devkit/cockpit/adresa.txt, běží do ukončení)\n       npm run cockpit -- --log     (místní cockpit: deník z .devkit/cockpit/db, bez souboru)`;
if (argv.includes('--help') || argv.includes('-h')) { console.log(USAGE + USAGE_MISTNI); process.exit(0); }
// Místní cockpit (lib/cockpit-local.mjs): data jsou JSON soubory v .devkit/cockpit/db, stránku vydává tento server.
const MISTNI = isLocalCockpit(loadConfig());
if (argv.includes('--serve')) {
  if (!MISTNI) { console.error(`--serve je jen pro místní cockpit: project_config.json → cockpit.url musí být "${LOCAL_URL}" (references/cockpit.md §Místní cockpit)`); process.exit(2); }
  const html = join(ROOT, '.devkit', 'cockpit.html');
  if (!existsSync(html)) { console.error(`chybí ${html}: zkopíruj do ní šablonu cockpitu z kitu (references/cockpit.md §Místní cockpit)`); process.exit(2); }
  mkdirSync(OUT_DIR, { recursive: true });
  const { url } = await startCockpitServer({ root: ROOT, html });
  writeFileSync(join(OUT_DIR, 'adresa.txt'), `${url}\n`);
  console.log(`cockpit: ${url} (adresa je i v ${join(OUT_DIR, 'adresa.txt')}); běží do ukončení (Ctrl+C)`);
  await new Promise(() => {}); // server drží proces
}
const logAt = argv.indexOf('--log');
if (logAt >= 0) {
  const src = argv[logAt + 1], zDisku = MISTNI && (!src || src.startsWith('--'));
  if (!zDisku && (!src || src.startsWith('--'))) { console.error(USAGE + USAGE_MISTNI); process.exit(2); }
  let raw;
  if (zDisku) { const { db, vadne } = readDb(ROOT); raw = db; for (const v of vadne) console.error(`POZOR: .devkit/cockpit/db/${v} není čitelný JSON, do deníku se nedostal`); }
  else try { raw = JSON.parse(readFileSync(src, 'utf8')); } catch (e) { console.error(`export ${src} se nepodařilo přečíst jako JSON — ${e.message}`); process.exit(2); }
  const data = normalizeExport(raw);
  const dir = join(ROOT, 'docs', 'cockpit');
  mkdirSync(dir, { recursive: true });
  const logFile = join(dir, 'rozhodnuti.jsonl');
  const { text, pridano } = appendLog(existsSync(logFile) ? readFileSync(logFile, 'utf8') : '', decisionRecords(data.rozhodnuti));
  if (pridano) writeFileSync(logFile, text);
  for (const [name, body] of Object.entries(snapshots(data))) writeFileSync(join(dir, name), body);
  console.log(`deník: ${logFile} — přidáno ${pridano} záznamů; snapshoty zadani.json, otazky.json, ukoly.json v ${dir}\nDál (agent): commit docs/cockpit/ (git add -- docs/cockpit).`);
  process.exit(0);
}
const wanted = argv.flatMap((a, i) => (a === '--env' ? [argv[i + 1]] : []));
if (wanted.some((e) => !e || e.startsWith('--'))) { console.error(USAGE); process.exit(2); }

const cfg = loadConfig();
const envs = (wanted.length ? wanted : Object.keys(cfg.environments || {}).filter((n) => n !== 'local'));
const neznama = wanted.filter((e) => !cfg.environments?.[e]);
if (neznama.length) { console.error(`project_config.json nemá prostředí ${neznama.join(', ')} (má: ${Object.keys(cfg.environments || {}).join(', ')})\n${USAGE}`); process.exit(2); }
mkdirSync(OUT_DIR, { recursive: true });

// Kde agent pracuje → .devkit/cockpit/projekt.json = celý dokument pro `ArtifactData set meta/projekt`.
// SET, ne update: update slučuje do hloubky, takže by v dokumentu nechal pole, která export už nenese
// (prace.cesta a prace.stroj ze starších nástrojů, ručně zapsané web) — nález U11.
// Dočasné kořeny: tmpdir() procesu a /tmp (na macOS dva různé adresáře); realpath kvůli symlinku /tmp → /private/tmp.
const TMP_ROOTS = [tmpdir(), '/tmp'].filter((d) => existsSync(d)).map((d) => realpathSync(d));
const git = (...a) => { const r = spawnSync('git', a, { cwd: ROOT, encoding: 'utf8' }); return r.status === 0 ? r.stdout.trim() : ''; };
// Lokální instance: adresu zapisuje npm run dev do .devkit/dev-server.json; jestli běží, zjistí krátký dotaz.
// 2 s na odpověď stačí lokálnímu serveru bohatě; déle export nezdržujeme.
const LOCAL_PROBE_MS = 2000;
let lokalni = null;
try {
  const d = JSON.parse(readFileSync(join(ROOT, '.devkit', 'dev-server.json'), 'utf8'));
  let bezi = false;
  try { bezi = (await fetch(d.url, { signal: AbortSignal.timeout(LOCAL_PROBE_MS) })).ok; } catch { /* neběží */ }
  lokalni = { url: d.url, bezi };
} catch { /* dev server se tu ještě nespustil */ }
const work = workDoc({
  cesta: realpathSync(ROOT), remote: git('remote', 'get-url', 'origin'), vetev: git('branch', '--show-current'),
  commit: git('rev-parse', '--short', 'HEAD'), dirty: git('status', '--porcelain') !== '', tmpRoots: TMP_ROOTS, lokalni, now: new Date().toISOString(),
  nazev: cfg.app?.name, prefix: cfg.app?.prefix,
});
writeFileSync(join(OUT_DIR, 'projekt.json'), JSON.stringify(work, null, 2));
// místní cockpit: export jde rovnou do místní databáze (v artefaktu ho tam zapisuje agent přes ArtifactData)
const doDb = (kolekce, id, doc) => { if (MISTNI) writeDoc(ROOT, kolekce, id, doc); };
doDb('meta', 'projekt', work);
console.log(`projekt: ${join(OUT_DIR, 'projekt.json')} — ${work.nazev || '?'} (${work.prefix || '?'}), ${work.prace.slozka}, ${work.prace.repo.remote || 'bez remote'}, větev ${work.prace.repo.vetev || '?'}${work.prace.docasna ? ' — POZOR: dočasná složka' : ''}`);
// Co v appce je → .devkit/cockpit/obsah.json pro `ArtifactData set meta/obsah`. Jen z gitu (manifest, sp/data/config, source knihoven).
// Ukázka dat: první řádky ze sp/data/config (skutečná konfigurace), jinak sp/data/initial (výchozí sada), jinak sp/data/seed (data lokálního mocku).
// 3 řádky stačí na představu o tvaru dat a drží dokument malý; víc ukáže appka sama.
const SAMPLE_ROWS = 3;
const manifest = withFeedback(loadManifest()); // včetně seznamu připomínek, který zakládá kit
const rows = (dir, id) => { const f = join(ROOT, 'sp', 'data', dir, `${id}.json`); if (!existsSync(f)) return null; try { const j = JSON.parse(readFileSync(f, 'utf8')); return Array.isArray(j) ? j : null; } catch { return null; } };
const samples = Object.fromEntries(Object.keys(manifest.lists || {}).map((id) => { const zdroj = DATA_DIRS.find((d) => rows(d, id)); const r = zdroj && rows(zdroj, id); return r ? [id, { zdroj, celkem: r.length, radky: r.slice(0, SAMPLE_ROWS) }] : null; }).filter(Boolean));
const names = (dir) => (existsSync(dir) ? readdirSync(dir, { withFileTypes: true }).filter((e) => e.isFile()).map((e) => e.name).sort() : []);
const files = Object.fromEntries(Object.entries(manifest.libraries || {}).filter(([, l]) => l.source).map(([id, l]) => [id, names(join(ROOT, l.source))]));
const obsah = contentDoc({ manifest, prefix: cfg.app?.prefix || '', files, samples, kitLists: manifest.feedback === true ? [FEEDBACK_KEY] : [], now: new Date().toISOString() });
checkSize(obsah, 'obsah');
writeFileSync(join(OUT_DIR, 'obsah.json'), JSON.stringify(obsah, null, 2));
doDb('meta', 'obsah', obsah);
console.log(`obsah: ${join(OUT_DIR, 'obsah.json')} — ${obsah.data.length} seznamů a knihoven, ${obsah.stranky.length} stránek, ${obsah.role.length} rolí`);
if (!envs.length) { console.log(MISTNI ? 'project_config.json nemá žádné prostředí kromě local — stav prostředí se neexportuje; místní cockpit: meta/projekt a meta/obsah jsou zapsané v .devkit/cockpit/db' : 'project_config.json nemá žádné prostředí kromě local — stav prostředí se neexportuje\n\nDál (agent): ArtifactData set meta/projekt s file_path .devkit/cockpit/projekt.json (set, ne update: update slučuje do hloubky a nechal by stará pole; existující s if_version); ArtifactData set meta/obsah s file_path .devkit/cockpit/obsah.json.'); process.exit(0); }

let failed = false;
for (const env of envs) {
  const now = new Date().toISOString();
  let site = cfg.environments?.[env]?.site || null, ths = null, zaznam = null, precteno = true;
  if (!site) {
    // prostředí bez webu: web se nečte, dokument říká „nezaloženo“
    const doc = envDoc({ env, site: null, zaznam: null, threads: null, pages: [], now });
    writeFileSync(join(OUT_DIR, `${env}.json`), JSON.stringify(doc, null, 2));
    doDb('prostredi', env, doc);
    console.log(`${env}: ${join(OUT_DIR, `${env}.json`)} — nezaloženo (project_config.json → environments.${env}.site je prázdné)`);
    continue;
  }
  try {
    const P = loadProject(env);
    site = P.env.site;
    zaznam = P.readRecord();
    // před prvním nasazením list připomínek na webu není: prázdný seznam vláken, ne chyba
    if (P.model.byKey[FEEDBACK_KEY]) {
      if (feedbackListExists(P)) ths = threads(readFeedbackItems(P));
      else { ths = []; console.log(`${env}: list připomínek na webu ještě není (založí ho první nasazení) — exportuju bez připomínek`); }
    }
  } catch (e) { failed = true; precteno = false; console.error(`${env}: web se nepodařilo přečíst celý — ${e.message}`); }
  const doc = envDoc({ env, site, zaznam, threads: ths, pages: obsah.stranky, now, precteno });
  const bytes = checkSize(doc, env);
  const file = join(OUT_DIR, `${env}.json`);
  writeFileSync(file, JSON.stringify(doc, null, 2));
  doDb('prostredi', env, doc);
  console.log(`${env}: ${file} (${bytes} B) — ${doc.stav === 'necteno' ? 'NEČTENO, ' : ''}nasazení ${doc.nasazeni ? `${doc.nasazeni.verze} ${doc.nasazeni.kdy}` : 'žádné'}, připomínky ${doc.pripominky ? `${doc.pripominky.souhrn.open} otevřených / ${doc.pripominky.souhrn.total}` : 'nečteno'}`);
}
if (MISTNI) console.log('\nmístní cockpit: export je zapsaný v .devkit/cockpit/db (meta/projekt, meta/obsah, prostredi/<env>); stránku vydává npm run cockpit -- --serve');
else console.log(`\nDál (agent): ArtifactData set meta/projekt s file_path .devkit/cockpit/projekt.json (set, ne update: update slučuje do hloubky a nechal by stará pole; existující s if_version); ArtifactData set meta/obsah s file_path .devkit/cockpit/obsah.json (existující s if_version); ArtifactData get prostredi/<env> (verze) → set s if_version a file_path .devkit/cockpit/<env>.json; nový dokument bez if_version.`);
if (failed) console.error(`\nexport vznikl, ale neúplný (návratový kód ${KOD.upozorneni}): důvod je u prostředí výše`);
process.exit(failed ? KOD.upozorneni : KOD.hotovo);
