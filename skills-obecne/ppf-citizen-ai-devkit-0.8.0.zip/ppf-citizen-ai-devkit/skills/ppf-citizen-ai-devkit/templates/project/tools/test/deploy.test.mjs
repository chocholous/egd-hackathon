// npm test — plán balíčku (lib/plan/package.mjs), záznam o nasazení na webu (lib/records.mjs) a pojistka prostředí
// (lib/config.mjs). Bez sítě: SharePoint a m365 jsou v testu záznamů podstrčené funkce.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, readFileSync, writeFileSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { planPackage } from '../lib/plan/package.mjs';
import { writeRecord, otiskBalicku, zaznamCesta, historieCesta, radkyHistorie } from '../lib/records.mjs';
import { assertDeployEnv, DEPLOY_ENVS } from '../lib/config.mjs';

const SITE = 'https://t.sharepoint.com/sites/x';
const pkg = (o = {}) => ({ solution: { id: 'sol-1', name: 'app', version: '1.0.0.1' }, zippedPackage: '/p/app.sppkg', exists: true, stale: null, ...o });
const verbs = (r) => r.actions.map((a) => a.m365[2]);

test('poprvé: nahrát, nasadit, nainstalovat; installs pustí stránky', () => {
  const r = planPackage(pkg(), null, { site: SITE });
  assert.deepEqual(verbs(r), ['add', 'deploy', 'install']);
  assert.equal(r.installs, true);
  assert.deepEqual(r.findings, []);
});

test('nová verze proti nainstalované: nahrát, nasadit, upgrade', () => {
  const r = planPackage(pkg(), { version: '1.0.0.0', deployed: true, installed: '1.0.0.0' }, { site: SITE });
  assert.deepEqual(verbs(r), ['add', 'deploy', 'upgrade']);
});

test('skipFeatureDeployment: nová verze bez upgradu, stará InstalledVersion nevadí ani podruhé', () => {
  const sfd = pkg({ solution: { id: 'sol-1', name: 'app', version: '1.0.0.1', skipFeatureDeployment: true } });
  const r = planPackage(sfd, { version: '1.0.0.0', deployed: true, installed: '1.0.0.0' }, { site: SITE });
  assert.deepEqual(verbs(r), ['add', 'deploy']);
  assert.equal(r.installs, true);
  const again = planPackage(sfd, { version: '1.0.0.1', deployed: true, installed: '1.0.0.0' }, { site: SITE });
  assert.deepEqual(again.actions, []);
  assert.deepEqual(verbs(planPackage(sfd, null, { site: SITE })), ['add', 'deploy', 'install']);
});

test('stejná verze v katalogu i na webu: nic (druhé nasazení = prázdný plán)', () => {
  const r = planPackage(pkg(), { version: '1.0.0.1', deployed: true, installed: '1.0.0.1' }, { site: SITE });
  assert.deepEqual(r.actions, []);
  assert.equal(r.installs, false);
});

test('stejná verze s --same-version: znovu nahrát i upgradovat', () => {
  const r = planPackage(pkg(), { version: '1.0.0.1', deployed: true, installed: '1.0.0.1' }, { site: SITE, sameVersion: true });
  assert.deepEqual(verbs(r), ['add', 'deploy', 'upgrade']);
});

test('v katalogu nahraná, nenasazená a nenainstalovaná', () => {
  const r = planPackage(pkg(), { version: '1.0.0.1', deployed: false, installed: null }, { site: SITE });
  assert.deepEqual(verbs(r), ['deploy', 'install']);
});

test('web bez katalogu aplikací: blokující nález katalog a žádné akce balíčku; nečtený katalog nic nemění (M02)', () => {
  const r = planPackage(pkg(), null, { site: SITE, katalogWebu: null });
  assert.deepEqual(r.actions, []);
  assert.equal(r.installs, false);
  assert.deepEqual(r.findings.map((f) => [f.kind, f.block]), [['katalog', true]]);
  assert.match(r.findings[0].desc, /site collection app catalog.*správce SharePointu/);
  assert.deepEqual(verbs(planPackage(pkg(), null, { site: SITE, katalogWebu: 'Apps for SharePoint' })), ['add', 'deploy', 'install']);
  assert.deepEqual(verbs(planPackage(pkg(), null, { site: SITE })), ['add', 'deploy', 'install']);
});

test('chybějící a zastaralý .sppkg = blokující nález', () => {
  const missing = planPackage(pkg({ exists: false }), null, { site: SITE });
  assert.deepEqual(missing.actions, []);
  assert.equal(missing.findings[0].block, true);
  const stale = planPackage(pkg({ stale: 'kód ve spfx/ se od buildu změnil (build aaaa, teď bbbb)' }), null, { site: SITE });
  assert.ok(stale.findings.some((f) => f.block && /neodpovídá kódu.*npm run build/.test(f.desc)));
});

const NA_WEBU = { version: '1.0.0.1', deployed: true, installed: '1.0.0.1' };

test('stejná verze, jiný kód: blokující nález; stejný kód nic; --same-version nahraje', () => {
  const jiny = planPackage(pkg(), NA_WEBU, { site: SITE, otisk: 'bbbb', nasazeno: { version: '1.0.0.1', otisk: 'aaaa' } });
  assert.deepEqual(jiny.actions, []);
  assert.equal(jiny.findings.length, 1);
  assert.equal(jiny.findings[0].block, true);
  assert.match(jiny.findings[0].desc, /verze 1\.0\.0\.1 už na webu je, ale z jiného kódu \(otisk na webu aaaa, teď bbbb\).*zvedni solution\.version/);
  const stejny = planPackage(pkg(), NA_WEBU, { site: SITE, otisk: 'aaaa', nasazeno: { version: '1.0.0.1', otisk: 'aaaa' } });
  assert.deepEqual([stejny.actions, stejny.findings, stejny.poznamky], [[], [], []]);
  const vedome = planPackage(pkg(), NA_WEBU, { site: SITE, sameVersion: true, otisk: 'bbbb', nasazeno: { version: '1.0.0.1', otisk: 'aaaa' } });
  assert.deepEqual(verbs(vedome), ['add', 'deploy', 'upgrade']);
  assert.deepEqual(vedome.findings, []);
});

test('stejná verze a záznam bez otisku (nasazeno před 0.5.1, nebo záznam k jiné verzi): jen poznámka, ne nález', () => {
  for (const nasazeno of [null, { version: '1.0.0.1', otisk: null }, { version: '1.0.0.0', otisk: 'aaaa' }]) {
    const r = planPackage(pkg(), NA_WEBU, { site: SITE, otisk: 'bbbb', nasazeno });
    assert.deepEqual(r.findings, []);
    assert.equal(r.poznamky.length, 1);
    assert.match(r.poznamky[0], /nemá otisk kódu/);
  }
  // nová verze: otisk se neporovnává
  const nova = planPackage(pkg(), { version: '1.0.0.0', deployed: true, installed: '1.0.0.0' }, { site: SITE, otisk: 'bbbb', nasazeno: { version: '1.0.0.0', otisk: 'aaaa' } });
  assert.deepEqual([nova.findings, nova.poznamky], [[], []]);
});

test('otisk balíčku v záznamu: nahráno = dnešní, nenahráno = z posledního záznamu téže verze, jinak null', () => {
  const nahrano = { actions: [{ area: 'balíček', m365: ['spo', 'app', 'add'] }] };
  const jenStranky = { actions: [{ area: 'stránky' }] };
  assert.equal(otiskBalicku({ plan: nahrano, otisk: 'bbbb', version: '2', predchozi: { version: '1', otisk: 'aaaa' } }), 'bbbb');
  assert.equal(otiskBalicku({ plan: jenStranky, otisk: 'bbbb', version: '1', predchozi: { version: '1', otisk: 'aaaa' } }), 'aaaa');
  assert.equal(otiskBalicku({ plan: jenStranky, otisk: 'bbbb', version: '1', predchozi: { version: '1', otisk: null } }), null);
  assert.equal(otiskBalicku({ plan: jenStranky, otisk: 'bbbb', version: '2', predchozi: { version: '1', otisk: 'aaaa' } }), null);
  assert.equal(otiskBalicku({ plan: jenStranky, otisk: 'bbbb', version: '1', predchozi: null }), null);
});

// podstrčený web: soubory = cesta → text; api.get vrací null u toho, co na webu není; nahrání čte dočasný soubor
const zaznam = (o = {}) => {
  const root = mkdtempSync(join(tmpdir(), 'devkit-records-'));
  const volani = [];
  const web = { slozka: true, soubory: {}, ...(o.web || {}) };
  const LIB = '/sites/x/APP_Config';
  const ctx = {
    root, envName: 'dev', site: SITE, version: '1.0.0.1', otisk: 'bbbb', areas: ['balíček', 'stránky'], libUrl: 'APP_Config',
    plan: { hash: 'h1', actions: [{ area: 'balíček' }, { area: 'balíček' }], newRecord: { items: { L: { a: 'x' } }, assets: {} } },
    commit: 'c'.repeat(40), dirty: false, at: '2026-11-14T10:00:00.000Z',
    api: {
      get: (p) => { const u = decodeURIComponent(p); if (u.includes('GetFolderByServerRelativeUrl')) return web.slozka ? { Name: '_deploy' } : null; const m = /GetFileByServerRelativeUrl\('(.+)'\)/.exec(u); return m && m[1] in web.soubory ? { Name: 'x' } : null; },
      file: (u) => (web.soubory[u] == null ? null : Buffer.from(web.soubory[u])),
    },
    m365: (a) => {
      volani.push(a);
      if (a[2] === 'add' && a[1] === 'file') { const f = a[a.indexOf('--path') + 1]; web.soubory[`${a[a.indexOf('--folder') + 1]}/${f.split('/').pop()}`] = readFileSync(f, 'utf8'); }
      if (a[1] === 'folder') web.slozka = true;
      return { status: 0, out: '', err: '' };
    },
    ...(o.ctx || {}),
  };
  const radky = () => radkyHistorie(web.soubory[`${LIB}/_deploy/dev.historie.jsonl`]); // neplatné řádky převzaté z gitu zůstanou v souboru, čtení je přeskočí
  return { root, volani, ctx, web, LIB, radky, prikazy: () => volani.map((a) => a.slice(0, 3).join(' ')) };
};
const RADEK = { at: '2026-11-14T10:00:00.000Z', env: 'dev', site: SITE, version: '1.0.0.1', otisk: 'bbbb', commit: 'c'.repeat(40), dirty: false, hash: 'h1', actions: { 'balíček': 2 } };

test('záznam: jen na web — historie a pak poslední stav, obojí s verzí, otiskem a počty akcí; do gitu nic', () => {
  const z = zaznam();
  assert.deepEqual(writeRecord(z.ctx), { web: true, webChyba: null, prevzato: 0 });
  assert.deepEqual(z.radky(), [RADEK]);
  assert.deepEqual(z.volani.map((a) => a[a.indexOf('--path') + 1].split('/').pop()), ['dev.historie.jsonl', 'dev.json'], 'záznam se zapisuje jako poslední');
  const web = JSON.parse(z.web.soubory[`${z.LIB}/_deploy/dev.json`]);
  assert.deepEqual([web.version, web.otisk, web.hash, web.actions, web.items], ['1.0.0.1', 'bbbb', 'h1', { 'balíček': 2 }, { L: { a: 'x' } }]);
  assert.equal(existsSync(join(z.root, 'releases')), false, 'řádek v gitu se od 0.6 nepíše');
  assert.equal(zaznamCesta('dev'), '_deploy/dev.json');
  assert.equal(historieCesta('test'), '_deploy/test.historie.jsonl');
});

test('záznam: složka _deploy se zakládá jen když chybí; další nasazení řádek do historie připíše', () => {
  const z = zaznam({ web: { slozka: false } });
  writeRecord(z.ctx);
  assert.deepEqual(z.prikazy(), ['spo folder add', 'spo file add', 'spo file add']);
  writeRecord({ ...z.ctx, at: '2026-11-15T10:00:00.000Z', version: '1.0.0.2' });
  assert.deepEqual(z.radky().map((r) => r.version), ['1.0.0.1', '1.0.0.2']);
  assert.deepEqual(z.prikazy().filter((p) => p === 'spo folder add').length, 1);
});

test('záznam: starý projekt — první nasazení převezme řádky z releases/<env>.jsonl do historie na webu, soubor v gitu nechá být', () => {
  const z = zaznam();
  mkdirSync(join(z.root, 'releases'));
  const stare = '{"at":"2026-11-01T08:00:00.000Z","env":"dev","version":"1.0.0.0"}\ntohle není json\n{"at":"2026-11-02T08:00:00.000Z","env":"dev","version":"1.0.0.0"}';
  writeFileSync(join(z.root, 'releases', 'dev.jsonl'), stare);
  assert.deepEqual(writeRecord(z.ctx), { web: true, webChyba: null, prevzato: 2 });
  assert.deepEqual(z.radky().map((r) => r.at), ['2026-11-01T08:00:00.000Z', '2026-11-02T08:00:00.000Z', '2026-11-14T10:00:00.000Z']);
  assert.equal(readFileSync(join(z.root, 'releases', 'dev.jsonl'), 'utf8'), stare);
  // historie na webu už je → z gitu se podruhé nic nepřebírá
  assert.equal(writeRecord({ ...z.ctx, at: '2026-11-15T10:00:00.000Z' }).prevzato, 0);
  assert.equal(z.radky().length, 4);
  assert.deepEqual(radkyHistorie('{"a":1}\n\nxx\n{"a":2}'), [{ a: 1 }, { a: 2 }]);
});

test('záznam: selhání webu nevyhodí výjimku a chyba je pojmenovaná; nečitelná historie se nepřepíše', () => {
  const z = zaznam({ ctx: { m365: () => ({ status: 1, out: '', err: 'Access denied' }) } });
  const r = writeRecord(z.ctx);
  assert.equal(r.web, false);
  assert.match(r.webChyba, /historie nasazení: Access denied/);
  const pad = zaznam({ ctx: { api: { get: () => { throw new Error('síť spadla'); } } } });
  assert.deepEqual([writeRecord(pad.ctx).web, writeRecord(pad.ctx).webChyba], [false, 'síť spadla']);
  const necitelna = zaznam();
  necitelna.web.soubory[`${necitelna.LIB}/_deploy/dev.historie.jsonl`] = null; // existuje (get), ale obsah nejde přečíst (file → null)
  necitelna.ctx.api.get = (p) => (/GetFileBy/.test(p) ? { Name: 'x' } : { Name: '_deploy' });
  const n = writeRecord(necitelna.ctx);
  assert.equal(n.web, false);
  assert.match(n.webChyba, /nepřepisuju ji/);
  assert.equal(necitelna.volani.length, 0, 'nic se nenahrálo');
});

test('záznam: „already exists“ u čerstvé složky = jeden nový pokus; appka bez konfigurační knihovny = web null', () => {
  let n = 0;
  const z = zaznam({ ctx: { m365: () => (++n === 1 ? { status: 1, out: '', err: 'The folder already exists' } : { status: 0, out: '', err: '' }) } });
  assert.equal(writeRecord(z.ctx).web, true);
  assert.equal(n, 3, 'historie na druhý pokus, záznam napoprvé');
  const bez = zaznam({ ctx: { libUrl: null } });
  assert.deepEqual(writeRecord(bez.ctx), { web: null, webChyba: null, prevzato: 0 });
  assert.equal(bez.volani.length, 0);
  assert.equal(existsSync(join(bez.root, '.devkit-tmp')), false);
});

test('zápis jen do DEV a TEST; produkce a cokoli jiného = chyba', () => {
  assert.deepEqual(DEPLOY_ENVS, ['dev', 'test']);
  for (const ok of ['dev', 'test']) assert.doesNotThrow(() => assertDeployEnv(ok));
  for (const bad of ['prod', 'PROD', 'production', 'local', 'Dev']) assert.throws(() => assertDeployEnv(bad), /odmítá/);
});

test('záznam o nasazení: plán předem řekne, co zápis přidá ke svým akcím; počet převzatých řádků je vyskloňovaný (U06, U07)', async () => {
  const { prevzatoText, zaznamPoznamka } = await import('../lib/records.mjs');
  assert.deepEqual([1, 2, 4, 5, 12].map(prevzatoText), ['převzat 1 starší záznam', 'převzaty 2 starší záznamy', 'převzaty 4 starší záznamy', 'převzato 5 starších záznamů', 'převzato 12 starších záznamů']);
  const { mkdtempSync, mkdirSync, writeFileSync } = await import('node:fs');
  const { tmpdir } = await import('node:os');
  const { join } = await import('node:path');
  const d = mkdtempSync(join(tmpdir(), 'devkit-zaznam-'));
  const bez = zaznamPoznamka({ root: d, envName: 'dev', libUrl: 'XAssets' });
  assert.match(bez, /knihovny XAssets .*přepíše _deploy\/dev\.json a připíše řádek do _deploy\/dev\.historie\.jsonl$/);
  mkdirSync(join(d, 'releases'));
  writeFileSync(join(d, 'releases', 'dev.jsonl'), '{"version":"1.0.0.0"}\n');
  assert.match(zaznamPoznamka({ root: d, envName: 'dev', libUrl: 'XAssets' }), /není-li historie na webu, převezme do ní i 1 řádek z releases\/dev\.jsonl \(soubor v gitu zůstane\)$/);
  assert.equal(zaznamPoznamka({ root: d, envName: 'test', libUrl: 'XAssets' }).includes('releases/'), false);
});
