// npm test — sonda stránek (lib/probe.mjs: adresy z manifestu a configu, třídění konzole, verdikt)
// a selhání uprostřed zápisu (lib/apply.mjs). Bez sítě a bez prohlížeče.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { join } from 'node:path';
import { probeTargets, classifyConsole, verdict, pageUrl, PROBE_DIR, launchProbeBrowser } from '../lib/probe.mjs';
import { uuidV5 } from '../lib/manifest.mjs';
import { applyActions, failureReport } from '../lib/apply.mjs';

const SOL = '11111111-2222-3333-4444-555555555555';
const WP = { AppWebPart: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee' };
const cfg = { app: { prefix: 'CADK' }, environments: { local: {}, dev: { site: 'https://t.sharepoint.com/sites/Dev/' }, test: { site: '' } } };
const manifest = {
  pages: {
    App: { webparts: [{ id: 'app', webpart: 'AppWebPart' }] },
    Sprava: { webparts: [{ id: 'hlavni', webpart: 'AppWebPart' }, { id: 'vedlejsi', webpart: 'AppWebPart' }] },
  },
};
const base = { cfg, manifest, envName: 'dev', webparts: WP, solutionId: SOL, root: '/proj' };

test('bez --page: všechny stránky appky, adresa = site + /SitePages/<PREFIX>-<Klíč>.aspx?env=WebView (bez dvojitého lomítka)', () => {
  const t = probeTargets(base);
  assert.deepEqual(t.map((x) => x.url), ['https://t.sharepoint.com/sites/Dev/SitePages/CADK-App.aspx?env=WebView', 'https://t.sharepoint.com/sites/Dev/SitePages/CADK-Sprava.aspx?env=WebView']);
  assert.deepEqual(t.map((x) => x.shot), [join('/proj', PROBE_DIR, 'probe-App.png'), join('/proj', PROBE_DIR, 'probe-Sprava.png')]);
  assert.equal(pageUrl('https://x/sites/a', 'P-K.aspx'), 'https://x/sites/a/SitePages/P-K.aspx');
});

test('očekávané web party mají deterministické instanceId (stejné jako zakládá deploy)', () => {
  const [, sprava] = probeTargets(base);
  assert.deepEqual(sprava.expect.map((w) => w.instanceId), [uuidV5(SOL, 'Sprava/hlavni'), uuidV5(SOL, 'Sprava/vedlejsi')]);
  assert.equal(sprava.expect[0].webPartId, WP.AppWebPart);
});

test('--page vybere jednu stránku; neznámý klíč = chyba se seznamem', () => {
  const t = probeTargets({ ...base, page: 'Sprava' });
  assert.equal(t.length, 1);
  assert.equal(t[0].key, 'Sprava');
  assert.throws(() => probeTargets({ ...base, page: 'Nic' }), /má: App, Sprava/);
});

test('--url: stránka appky dostane i web party, cizí stránka jen obecné kontroly; --shot přebije cestu', () => {
  const own = probeTargets({ ...base, url: 'https://t.sharepoint.com/sites/Dev/SitePages/cadk-app.aspx' });
  assert.equal(own[0].key, 'App');
  assert.equal(own[0].expect.length, 1);
  const home = probeTargets({ ...base, url: 'https://t.sharepoint.com/sites/Dev/SitePages/Home.aspx', shot: '/tmp/x.png' });
  assert.deepEqual(home.map(({ key, expect, shot }) => ({ key, expect, shot })), [{ key: 'Home', expect: [], shot: '/tmp/x.png' }]);
  assert.throws(() => probeTargets({ ...base, url: 'neni-adresa' }), /není adresa/);
});

test('chyby: prostředí bez webu, neznámé prostředí, local, --shot u více stránek', () => {
  assert.throws(() => probeTargets({ ...base, envName: 'test' }), /nemá "site"/);
  assert.throws(() => probeTargets({ ...base, envName: 'prod' }), /nemá prostředí "prod"/);
  assert.throws(() => probeTargets({ ...base, envName: 'local' }), /local/);
  assert.throws(() => probeTargets({ ...base, shot: '/tmp/a.png' }), /jen s jednou/);
  assert.throws(() => probeTargets({ ...base, manifest: {} }), /žádné stránky/);
});

test('konzole: chyby appky podle id solution / web partu / aliasu, zbytek je šum; warn se ignoruje', () => {
  const r = classifyConsole([
    { type: 'error', text: 'TypeError: x is undefined', url: `https://t.sharepoint.com/sites/Dev/ClientSideAssets/${SOL}/app-web-part_abc.js` },
    { type: 'pageerror', text: 'Error in AppWebPart render', url: '' },
    { type: 'error', text: 'Failed to load resource: 429', url: 'https://substrate.office.com/x' },
    { type: 'warning', text: `deprecated ${SOL}`, url: '' },
  ], { solutionId: SOL, webparts: WP });
  assert.equal(r.app.length, 2);
  assert.equal(r.other.length, 1);
});

test('verdikt: OK jen při HTTP 200, přihlášení, bez chyb a s vykreslenými web party', () => {
  const ok = { status: 200, worst: 302, loggedIn: true, notFound: false, wpErrors: 0, missing: [], appErrors: [] };
  assert.deepEqual(verdict(ok), { ok: true, reasons: [] });
  assert.match(verdict({ ...ok, status: 404, worst: 404 }).reasons[0], /HTTP 404.*neexistuje/);
  assert.match(verdict({ ...ok, worst: 404 }).reasons[0], /HTTP 404/);
  assert.match(verdict({ ...ok, loggedIn: false }).reasons.join(), /login/);
  assert.equal(verdict({ ...ok, loggedIn: false, status: 404 }).reasons.length, 1); // na loginu nic dalšího neříká
  assert.match(verdict({ ...ok, wpErrors: 1 }).reasons[0], /chyba web partu/);
  assert.match(verdict({ ...ok, missing: [{ alias: 'AppWebPart', id: 'app' }] }).reasons[0], /AppWebPart.*nevykreslil/);
  assert.match(verdict({ ...ok, appErrors: [{}] }).reasons[0], /konzoli/);
  assert.match(verdict({ ...ok, notFound: true }).reasons[0], /404 NOT FOUND/);
});

test('zápis: selhání uprostřed zastaví další akce a řekne, kolik proběhlo a co dál', () => {
  const actions = [{ area: 'struktura', desc: 'list A' }, { area: 'struktura', desc: 'list B' }, { area: 'stránky', desc: 'stránka C' }];
  const ran = [];
  const out = [];
  const r = applyActions(actions, (a) => { if (a.desc === 'list B') throw new Error('Access denied'); ran.push(a.desc); }, { log: (s) => out.push(s) });
  assert.deepEqual(ran, ['list A']);
  assert.equal(r.done, 1);
  assert.equal(r.total, 3);
  assert.equal(r.failed.index, 1);
  assert.equal(r.failed.message, 'Access denied');
  assert.match(out.join(''), /list B … CHYBA/);
  const msg = failureReport(r, 'dev');
  assert.match(msg, /proběhlo 1 z 3 akcí; selhala 2\. akce \[struktura\] list B/);
  assert.match(msg, /Access denied/);
  assert.match(msg, /NEZAPSAL/);
  assert.match(msg, /npm run deploy -- --env dev$/m);
});

test('zápis: pojistka před akcí (tenant) se hlásí jako selhání té akce; bez chyby proběhne vše', () => {
  const r = applyActions([{ area: 'balíček', desc: 'add' }], () => {}, { log: () => {}, before: () => { throw new Error('jiný tenant'); } });
  assert.equal(r.done, 0);
  assert.equal(r.failed.message, 'jiný tenant');
  const all = applyActions([{ area: 'a', desc: '1' }, { area: 'a', desc: '2' }], () => {}, { log: () => {} });
  assert.deepEqual(all, { done: 2, total: 2, failed: null });
});

test('font ikon: stav z document.fonts (check() sám nestačí — nedeklarovaná rodina vrací true)', async () => {
  const { iconFontState, iconFontWarning, ICON_FONT } = await import('../lib/probe.mjs');
  const fake = (faces, check = true) => { globalThis.document = { fonts: Object.assign(faces, { check: () => check }) }; };
  try {
    fake([{ family: `"${ICON_FONT}"`, status: 'loaded' }, { family: 'JetBrains Mono', status: 'loaded' }]);
    assert.deepEqual(iconFontState(ICON_FONT), { declared: true, loaded: true, check: true, statuses: ['loaded'] });
    assert.equal(iconFontWarning(iconFontState(ICON_FONT)), null);
    fake([], true);
    const none = iconFontState(ICON_FONT);
    assert.equal(none.check, true);
    assert.equal(none.declared, false);
    assert.match(iconFontWarning(none), /není deklarovaný/);
    fake([{ family: ICON_FONT, status: 'error' }], false);
    assert.match(iconFontWarning(iconFontState(ICON_FONT)), /nenačetl.*error/);
    fake([{ family: ICON_FONT, status: 'unloaded' }], false);
    assert.match(iconFontWarning(iconFontState(ICON_FONT)), /nepoužila/);
    fake([{ family: ICON_FONT, status: 'loading' }], false);
    assert.match(iconFontWarning(iconFontState(ICON_FONT)), /načítá/);
    assert.match(iconFontWarning(null), /nejde zjistit/);
  } finally { delete globalThis.document; }
});

// launchProbeBrowser: přibalené Chromium, záloha Edge — s podvrženým launcherem (bez prohlížeče)
const fakeType = (impl) => { const calls = []; return { calls, launch: async (o) => { calls.push(o); return impl(o, calls.length); } }; };

test('launchProbeBrowser: přibalené Chromium stačí, Edge se nezkouší', async () => {
  const t = fakeType(() => 'chromium');
  assert.equal(await launchProbeBrowser(t, { headless: true }), 'chromium');
  assert.deepEqual(t.calls, [{ headless: true }]);
});

test('launchProbeBrowser: Chromium nejde → záloha channel msedge se zbylými volbami', async () => {
  const t = fakeType((o, n) => { if (n === 1) throw new Error("Executable doesn't exist\nvíc řádků"); return 'edge'; });
  assert.equal(await launchProbeBrowser(t, { headless: true }), 'edge');
  assert.deepEqual(t.calls, [{ headless: true }, { headless: true, channel: 'msedge' }]);
});

test('launchProbeBrowser: selžou oba → výjimka s hláškou obou pokusů', async () => {
  const t = fakeType((o) => { throw new Error(o.channel ? 'edge chybí' : 'chromium chybí'); });
  await assert.rejects(() => launchProbeBrowser(t), /chromium chybí.*msedge.*edge chybí/);
});
