// npm test — export pro cockpit (lib/cockpit.mjs): poslední nasazení z jsonl, dokument prostředí, limit velikosti.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { lastRelease, envDoc, workDoc, contentDoc, accessKind, checkSize, DOC_LIMIT_BYTES, SCHEMA_VERSION, TEMPLATE_VERSION, normalizeExport, decisionRecords, appendLog, snapshots, stableJson } from '../lib/cockpit.mjs';
import { threads } from '../lib/feedback.mjs';

test('accessKind: druh a popis z práv úrovně a rozsahu položek', () => {
  const levels = { read: { builtin: 'Read' }, add: { custom: 'Přidávání', rights: ['ViewListItems', 'AddListItems'] }, edit: { custom: 'Úpravy', rights: ['AddListItems', 'EditListItems'] },
    all: { custom: 'Vše', rights: ['AddListItems', 'EditListItems', 'CancelCheckout'] }, con: { builtin: 'Contribute' } };
  const k = (l, s) => { const a = accessKind(l, levels, s); return [a.druh, a.popis, a.maze]; };
  assert.deepEqual(k('none'), ['nevidi', 'nevidí', false]);
  assert.deepEqual(k('read'), ['cte', 'jen čte', false]);
  assert.deepEqual(k('read', 'own'), ['cte-sve', 'čte jen své', false]);
  assert.deepEqual(k('add'), ['pridava', 'čte a přidává, neupraví', false]);
  assert.deepEqual(k('add', 'own'), ['pridava-sve', 'přidává, vidí jen své', false]);
  assert.deepEqual(k('edit'), ['upravuje', 'čte a upravuje', false]);
  assert.deepEqual(k('edit', 'own'), ['upravuje-sve', 'vidí a upravuje jen své', false]);
  assert.deepEqual(k('all', 'own'), ['upravuje', 'vidí a upravuje vše', false]);
  assert.deepEqual(k('con', 'own-write'), ['upravuje-sve', 'čte vše, upravuje jen své', true]);
  assert.equal(accessKind('add', levels).uroven, 'Přidávání');
});

test('contentDoc: seznamy, knihovny, stránky a role z manifestu; pole, ukázka, práva slovy', () => {
  const manifest = {
    roles: { owner: { popis: 'správce' }, ctenar: { popis: 'čte' } },
    levels: { read: { builtin: 'Read' }, add: { custom: 'Přidávání', rights: ['AddListItems'] } },
    lists: { Polozky: { class: 'operational', itemScope: 'own', popis: 'Položky lidí', pozn: 'technická', versioning: { majorVersionLimit: 5 }, fields: [{ name: 'A', type: 'text', required: true }, { name: 'B', type: 'choice', choices: ['x', 'y'], display: 'Béčko' }], access: { ctenar: 'add' } },
      Kody: { class: 'config', key: 'Kod', pozn: 'číselník kódů', fields: [{ name: 'Kod', type: 'text', required: true, unique: true }], access: { ctenar: 'read' } },
      Pripominky: { class: 'operational', itemScope: 'own-write', fields: [], access: 'inherit' } },
    libraries: { Assets: { class: 'config', source: 'sp/assets/config', access: { ctenar: 'read' } } },
    pages: { App: { title: 'Appka', webparts: [{ id: 'app', webpart: 'AppWebPart' }] } },
  };
  const d = contentDoc({ manifest, prefix: 'PX', files: { Assets: ['logo.svg'] }, samples: { Kody: { zdroj: 'config', celkem: 4, radky: [{ Kod: 'A' }] } }, kitLists: ['Pripominky'], now: 'T' });
  assert.deepEqual(d.role.map((r) => r.id), ['owner', 'ctenar']);
  assert.deepEqual(d.data.map((x) => x.nazev), ['PX-Polozky', 'PX-Kody', 'PX-Pripominky', 'PX-Assets']);
  const p = d.data[0];
  assert.equal(p.popis, 'Položky lidí'); assert.equal(p.verze, 5); assert.equal(p.rozsah, 'own'); assert.equal(p.kit, false);
  assert.deepEqual(p.pole[1], { nazev: 'B', popisek: 'Béčko', typ: 'choice', povinne: false, unikatni: false, volby: ['x', 'y'], cil: null, pozn: null });
  assert.deepEqual(p.prava.ctenar, { uroven: 'Přidávání', druh: 'pridava-sve', popis: 'přidává, vidí jen své', maze: false });
  assert.equal(d.data[1].popis, 'číselník kódů'); assert.equal(d.data[1].klic, 'Kod'); assert.deepEqual(d.data[1].ukazka, { zdroj: 'config', celkem: 4, radky: [{ Kod: 'A' }] });
  assert.equal(d.data[2].kit, true); assert.equal(d.data[2].prava, 'inherit');
  assert.equal(d.data[3].druh, 'knihovna'); assert.deepEqual(d.data[3].soubory, ['logo.svg']); assert.equal(d.data[3].pole, null);
  assert.deepEqual(d.stranky, [{ id: 'App', soubor: 'PX-App.aspx', titulek: 'Appka', popis: '', webparty: ['AppWebPart'] }]);
});

// poslední záznam o nasazení, jak ho nasazení zapisuje na web (_deploy/<env>.json; lib/records.mjs)
const ZAZNAM = { env: 'dev', appliedAt: '2026-11-11T11:45:33.471Z', version: '1.0.0.1', otisk: 'bbbb', commit: 'bbb', dirty: true, hash: 'y', actions: { 'balíček': 2, 'stránky': 2 }, items: {}, assets: {} };

test('lastRelease: ze záznamu na webu; starší záznam bez počtů akcí a řádek historie (at) se čtou taky; bez záznamu null', () => {
  assert.deepEqual(lastRelease(ZAZNAM), { verze: '1.0.0.1', kdy: '2026-11-11T11:45:33.471Z', commit: 'bbb', dirty: true, akce: { 'balíček': 2, 'stránky': 2 } });
  assert.deepEqual(lastRelease({ version: '1.0.0.0', appliedAt: 'T', commit: 'aaa', dirty: false }), { verze: '1.0.0.0', kdy: 'T', commit: 'aaa', dirty: false, akce: {} });
  assert.equal(lastRelease({ at: 'T2', version: '1' }).kdy, 'T2');
  assert.equal(lastRelease(null), null);
  assert.equal(lastRelease(undefined), null);
});

test('envDoc: nasazení + vlákna připomínek (i vyřešená), bez čtení připomínek pripominky: null', () => {
  const ths = threads([
    { Id: 1, Text: 'První', Stav: 'Otevřeno', Kotva: 'zalozky', Stranka: 'A.aspx', Verze: '1.0.0.0', Autor: 'Ivana', Created: '2026-11-11T10:00:00Z' },
    { Id: 2, Text: 'odpověď', NadrazenaId: 1, Stav: 'Vyřešeno', Zdroj: 'člověk', Autor: 'Pavel', Created: '2026-11-11T11:00:00Z' },
    { Id: 3, Text: 'Druhá', Stav: 'Otevřeno', Autor: 'Igor', Created: '2026-11-11T12:00:00Z' },
  ]);
  const d = envDoc({ env: 'dev', site: 'https://x/sites/Dev', zaznam: ZAZNAM, threads: ths, now: 'T' });
  assert.equal(d.env, 'dev'); assert.equal(d.site, 'https://x/sites/Dev'); assert.equal(d.exportovano, 'T');
  assert.equal(d.nasazeni.verze, '1.0.0.1'); assert.deepEqual(d.stranky, []);
  assert.deepEqual(envDoc({ env: 'dev', site: 'https://x/sites/Dev/', zaznam: null, threads: null, pages: [{ titulek: 'Appka', soubor: 'PX-App.aspx' }], now: 'T' }).stranky, [{ titulek: 'Appka', url: 'https://x/sites/Dev/SitePages/PX-App.aspx?env=WebView' }]);
  assert.deepEqual(d.pripominky.souhrn, { open: 1, resolved: 1, total: 2 });
  assert.equal(d.pripominky.vlakna.length, 2); // i vyřešené: cockpit je ukáže jako vyřízené
  const v = d.pripominky.vlakna[0];
  assert.equal(v.id, 1); assert.equal(v.stav, 'Vyřešeno'); assert.equal(v.kotva, 'zalozky'); assert.equal(v.autor, 'Ivana');
  assert.deepEqual(v.odpovedi, [{ id: 2, autor: 'Pavel', kdy: '2026-11-11T11:00:00Z', zdroj: 'člověk', stav: 'Vyřešeno', text: 'odpověď' }]);
  const n = envDoc({ env: 'test', site: null, zaznam: null, threads: null, now: 'T' });
  assert.equal(n.nasazeni, null); assert.equal(n.pripominky, null);
  // stav prostředí (M10): dokument vzniká pro každé prostředí, i bez webu
  assert.deepEqual(n, { env: 'test', site: null, stav: 'nezalozeno', nasazeni: null, pripominky: null, stranky: [], exportovano: 'T' });
  assert.equal(d.stav, 'nasazeno');
  assert.equal(envDoc({ env: 'dev', site: 'https://x/sites/Dev', zaznam: null, threads: [], now: 'T' }).stav, 'nenasazeno');
  assert.equal(envDoc({ env: 'dev', site: 'https://x/sites/Dev', zaznam: null, threads: null, now: 'T', precteno: false }).stav, 'necteno');
});

test('checkSize: velikost v bajtech, nad limitem db chyba', () => {
  assert.ok(checkSize({ a: 1 }, 'dev') < 100);
  assert.throws(() => checkSize({ x: 'ž'.repeat(DOC_LIMIT_BYTES) }, 'dev'), /limit db/);
});

test('workDoc: jen jméno složky (bez cesty a jména stroje), repo; dočasná složka jen pod kořenem (ne shodou předpony jména)', () => {
  const base = { remote: 'https://x/y.git', vetev: 'main', commit: 'abc1234', dirty: false, tmpRoots: ['/private/tmp', '/var/folders/x/T'], now: 'T' };
  assert.deepEqual(workDoc({ ...base, cesta: '/Users/a/Projects/app' }).prace, { slozka: 'app', docasna: false, repo: { remote: 'https://x/y.git', vetev: 'main', commit: 'abc1234', dirty: false }, lokalni: null, kdy: 'T' });
  assert.equal(workDoc({ ...base, cesta: '/private/tmp/claude/app' }).prace.docasna, true);
  assert.equal(workDoc({ ...base, cesta: '/private/tmpfoo/app' }).prace.docasna, false);
  assert.equal(workDoc({ ...base, cesta: '/x', remote: '' }).prace.repo.remote, null);
});

test('workDoc: nese verzi schématu dat; konstanty zrcadlí meta značky templates/cockpit.html', () => {
  assert.equal(SCHEMA_VERSION, 1); assert.equal(TEMPLATE_VERSION, 4);
  assert.equal(workDoc({ cesta: '/x', now: 'T' }).schema, SCHEMA_VERSION);
  // meta/projekt nese název a prefix z konfigurace; web: null vynuluje ručně zapsanou adresu ze starších dat (M10)
  const w = workDoc({ cesta: '/x', now: 'T', nazev: 'Evidence', prefix: 'EV' });
  assert.deepEqual([w.nazev, w.prefix, w.web], ['Evidence', 'EV', null]);
  assert.deepEqual(Object.keys(w), ['schema', 'nazev', 'prefix', 'web', 'prace']);
});

const EXPORT = {
  rozhodnuti: [
    { id: 'zadani:z2:role', data: { vysledek: 'schvaleno', komentar: 'Jan Novák to chce jinak', kolo: 1, kdy: '2026-11-11T12:10:00Z' } },
    { id: 'otazka:q1', data: { vysledek: 'zvoleno', moznost: 'web', komentar: 'petr@x.cz', kolo: 1, kdy: '2026-11-11T12:30:00Z' } },
    { id: 'p-dev-3', data: { navrh: { vysledek: 'schvaleno', komentar: '', kolo: 1, kdy: '2026-11-11T12:21:00Z' }, prevzeti: { vysledek: 'prijato', komentar: 'Anna Nováková', kolo: 2, kdy: '2026-11-11T12:50:00Z' } } },
    { id: 'pripominka:dev-8', data: { vysledek: 'prijato', kolo: 1, kdy: '2026-11-11T12:45:00Z' } },
  ],
  zadani: [{ id: 'z2', data: { nazev: 'Evidence školení', faze: 'navrh', verbatim: 'Jan Novák: chci appku', zdroj: { jak: 'chat', autor: 'Jan Novák' }, vytvoreno: 'V', casti: [{ id: 'role', nazev: 'Role', kolo: 1, text: 'hr zadává', obrazky: [{ url: '/_blob/x' }] }] } }],
  otazky: { q1: { nazev: 'Konflikt', text: 'Co s tím?', moznosti: [{ id: 'git', text: 'git' }], kolo: 1, vytvoreno: 'V', vazba: { ukol: 'p-dev-3' } } },
  ukoly: [{ id: 'p-dev-3', cislo: 3, nazev: 'Řazení', faze: 'navrh', kolo: 1, verbatim: 'Řadit, píše Ivana', zdroj: { autor: 'Ivana' } }],
};

test('deník: záznamy {klic, typ, vysledek, kolo, kdy}, bez komentářů; úkol má dva kroky', () => {
  const r = decisionRecords(normalizeExport(EXPORT).rozhodnuti);
  assert.deepEqual(r.map((x) => x.klic), ['zadani:z2:role', 'p-dev-3.navrh', 'otazka:q1', 'pripominka:dev-8', 'p-dev-3.prevzeti']);
  assert.deepEqual(r.map((x) => x.typ), ['zadani-cast', 'ukol-navrh', 'otazka', 'pripominka', 'ukol-prevzeti']);
  assert.deepEqual(r.find((x) => x.klic === 'otazka:q1'), { klic: 'otazka:q1', typ: 'otazka', vysledek: 'zvoleno', kolo: 1, kdy: '2026-11-11T12:30:00Z', moznost: 'web' });
  assert.ok(!JSON.stringify(r).includes('komentar'));
});

test('deník: idempotence (druhý běh nepřidá nic), append-only (staré řádky beze změny), LF', () => {
  const rec = decisionRecords(normalizeExport(EXPORT).rozhodnuti);
  const a = appendLog('', rec);
  assert.equal(a.pridano, 5); assert.ok(!a.text.includes('\r')); assert.ok(a.text.endsWith('\n'));
  const b = appendLog(a.text, rec);
  assert.equal(b.pridano, 0); assert.equal(b.text, a.text);
  const novy = { klic: 'otazka:q9', typ: 'otazka', vysledek: 'zvoleno', kolo: 1, kdy: '2026-11-12T00:00:00Z' };
  const c = appendLog(a.text.trimEnd(), [...rec, novy]); // soubor bez koncového LF
  assert.ok(c.text.startsWith(a.text)); assert.equal(c.pridano, 1);
  assert.equal(c.text.split('\n').filter(Boolean).length, 6);
});

test('deník: stabilní řazení klíčů a řádků bez ohledu na pořadí vstupu', () => {
  assert.equal(stableJson({ b: 1, a: { d: 1, c: 2 } }), '{"a":{"c":2,"d":1},"b":1}');
  const rows = EXPORT.rozhodnuti;
  const x = appendLog('', decisionRecords(normalizeExport({ rozhodnuti: rows }).rozhodnuti)).text;
  const y = appendLog('', decisionRecords(normalizeExport({ rozhodnuti: rows.slice().reverse() }).rozhodnuti)).text;
  assert.equal(x, y);
  assert.match(x.split('\n')[0], /^\{"klic":"[^"]+","kdy":|^\{"kdy":/);
});

test('deník: osobní pole (verbatim, jména, komentáře, autor) ve výstupu nejsou', () => {
  const data = normalizeExport(EXPORT);
  const out = appendLog('', decisionRecords(data.rozhodnuti)).text + Object.values(snapshots(data)).join('\n');
  for (const s of ['verbatim', 'Jan Novák', 'Anna Nováková', 'Ivana', 'petr@x.cz', 'komentar', 'autor', '/_blob/x', 'Řadit, píše']) assert.ok(!out.includes(s), s);
  // strukturovaná pole zůstala
  const sn = snapshots(data);
  assert.deepEqual(JSON.parse(sn['ukoly.json']), [{ cislo: 3, faze: 'navrh', id: 'p-dev-3', kolo: 1, nazev: 'Řazení' }]);
  assert.equal(JSON.parse(sn['zadani.json'])[0].casti[0].text, 'hr zadává');
  assert.deepEqual(JSON.parse(sn['otazky.json'])[0].vazba, { ukol: 'p-dev-3' });
});
