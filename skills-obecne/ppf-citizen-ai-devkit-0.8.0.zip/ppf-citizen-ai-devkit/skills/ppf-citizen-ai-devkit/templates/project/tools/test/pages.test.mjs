// npm test — stránky appky a web party (P5): model a kontrola v manifest.mjs, readPages nad falešným REST,
// plan/pages.mjs nad JSON stavem webu, readPackage nad dočasným spfx/. Bez sítě, bez emulátoru SharePointu.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { buildModel, validateManifest, resolveProps, uuidV5 } from '../lib/manifest.mjs';
import { readPages } from '../lib/state.mjs';
import { planPages } from '../lib/plan/pages.mjs';
import { readPackage } from '../lib/spfx-package.mjs';

const SITE = 'https://t.sharepoint.com/sites/x';
const SOLUTION = '11111111-2222-3333-4444-555555555555';
const WP = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
const WEBPARTS = { AppWebPart: WP };
const RAW = {
  roles: { owner: {}, user: {} },
  lists: { Hlaseni: { class: 'operational', fields: [] } },
  pages: { App: { title: 'Hlášení', webparts: [
    { id: 'app', webpart: 'AppWebPart', properties: { seznam: '@list:Hlaseni', napoveda: '@env:napovedaUrl', pevna: 3 } },
    { id: 'druha', webpart: 'AppWebPart' },
  ] } },
};
const model = () => {
  const m = buildModel(RAW, 'CADK', { webparts: WEBPARTS, solutionId: SOLUTION });
  for (const p of m.pages) for (const w of p.webparts) w.properties = resolveProps(w.properties, { values: { napovedaUrl: 'https://n' }, envName: 'dev' });
  return m;
};
const ID1 = uuidV5(SOLUTION, 'App/app');
const ID2 = uuidV5(SOLUTION, 'App/druha');
const cmd = (a) => a.m365.slice(0, 4).join(' ');
// stav webu, který odpovídá manifestu (jako po úspěšném apply)
const matching = () => ({
  site: SITE, webparts: [WP],
  pages: { App: { title: 'Hlášení', layout: 'SingleWebPartAppPage', comments: false, version: '2.0', draft: false, sections: 1, controls: [
    { instanceId: ID1, webPartId: WP, properties: { seznam: 'Hlaseni', napoveda: 'https://n', pevna: 3, description: 'SP si přidal' } },
    { instanceId: ID2, webPartId: WP, properties: {} },
  ] } },
});

test('manifest stránek: soubor z prefixu a klíče, deterministické instanceId, @list zůstane klíčem, @env z hodnot prostředí', () => {
  const m = model();
  assert.equal(m.pages[0].file, 'CADK-App.aspx');
  assert.equal(m.pages[0].webparts[0].webPartId, WP);
  assert.equal(m.pages[0].webparts[0].instanceId, ID1);
  assert.notEqual(ID1, ID2);
  assert.match(ID1, /^[0-9a-f]{8}-[0-9a-f]{4}-5[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
  assert.deepEqual(m.pages[0].webparts[0].properties, { seznam: 'Hlaseni', napoveda: 'https://n', pevna: 3 });
  // RFC 4122 příklad: DNS jmenný prostor + www.example.com
  assert.equal(uuidV5('6ba7b810-9dad-11d1-80b4-00c04fd430c8', 'www.example.com'), '2ed6657d-e927-568b-95e1-2665a8aea6a2');
  assert.throws(() => resolveProps({ a: '@env:chybi' }, { values: {}, envName: 'dev' }), /environments\.dev\.values nemá chybi/);
});

test('manifest stránek: cizí web part, neznámý list, chybějící a zdvojené id instance = chyby', () => {
  const bad = structuredClone(RAW);
  bad.pages.App.webparts.push({ id: 'app', webpart: 'Cizi' }, { webpart: 'AppWebPart', properties: { s: '@list:Neni' } });
  bad.pages['Špatná'] = {};
  const { errors } = validateManifest(bad, { prefix: 'CADK', webparts: WEBPARTS });
  for (const re of [/App\.app: id instance je na stránce dvakrát/, /web part "Cizi" v balíčku není/, /"id" instance je povinné/, /@list:Neni — list "Neni" v manifestu není/, /stránka Špatná: klíč/]) assert.ok(errors.some((e) => re.test(e)), `chybí chyba ${re}`);
  const ok = structuredClone(RAW); ok.pages.App.layout = 'Article'; // dva web party jen na stránce Article (U08)
  assert.deepEqual(validateManifest(ok, { prefix: 'CADK', webparts: WEBPARTS }).errors.filter((e) => /stránka/.test(e)), []);
});

test('manifest stránek: Single Part App Page (i výchozí layout) musí mít právě jeden web part (U08)', () => {
  const errs = (raw) => validateManifest(raw, { prefix: 'CADK', webparts: WEBPARTS }).errors.filter((e) => /Single Part App Page/.test(e));
  assert.match(errs(RAW)[0], /stránka App: stránka typu Single Part App Page \(layout SingleWebPartAppPage, výchozí\) musí mít právě jeden web part, má 2/);
  const explicit = structuredClone(RAW); explicit.pages.App.layout = 'SingleWebPartAppPage'; explicit.pages.App.webparts = [];
  assert.match(errs(explicit)[0], /\(layout SingleWebPartAppPage\) musí mít právě jeden web part, má 0/);
  const one = structuredClone(RAW); one.pages.App.webparts.pop();
  assert.deepEqual(errs(one), []);
});

test('plán stránek: prázdný web — založit, sekce, web party s instanceId a vlastnostmi, jedno publikování na konci', () => {
  const p = planPages(model(), { site: SITE, webparts: [WP], pages: { App: null } });
  assert.deepEqual(p.actions.map(cmd), ['spo page add --name', 'spo page section add', 'spo page clientsidewebpart add', 'spo page clientsidewebpart add', 'spo page set --name']);
  const add = p.actions[2].m365;
  assert.deepEqual(JSON.parse(add[add.indexOf('--webPartData') + 1]), { instanceId: ID1, properties: { seznam: 'Hlaseni', napoveda: 'https://n', pevna: 3 } });
  assert.ok(!add.includes('--webPartProperties'), 'CLI 12 odmítne --webPartProperties spolu s --webPartData');
  assert.ok(p.actions.at(-1).m365.includes('--publish'));
  // nová stránka vzniká jako Article (ověřený postup se sekcí), aplikační layout a vypnuté komentáře až při publikování
  assert.equal(p.actions[0].m365[p.actions[0].m365.indexOf('--layoutType') + 1], 'Article');
  assert.deepEqual(p.actions.at(-1).m365.slice(-5), ['--layoutType', 'SingleWebPartAppPage', '--commentsEnabled', 'false', '--publish']);
  assert.deepEqual(p.findings, []);
});

test('plán stránek: stará stránka Article s komentáři → přepnout layout a vypnout komentáře; layout z manifestu má přednost', () => {
  const s = matching();
  s.pages.App.layout = 'Article'; s.pages.App.comments = true;
  let p = planPages(model(), s);
  assert.equal(p.actions.length, 1);
  assert.match(p.actions[0].desc, /layout Article → SingleWebPartAppPage, komentáře vypnout, publikovat/);
  const raw = structuredClone(RAW); raw.pages.App.layout = 'Article'; raw.pages.App.comments = true;
  const m = buildModel(raw, 'CADK', { webparts: WEBPARTS, solutionId: SOLUTION });
  for (const pg of m.pages) for (const w of pg.webparts) w.properties = resolveProps(w.properties, { values: { napovedaUrl: 'https://n' }, envName: 'dev' });
  p = planPages(m, s);
  assert.deepEqual(p.actions, []);
});

test('plán stránek: shodný web = nic (klíče, které si přidal SharePoint, se neporovnávají)', () => {
  assert.deepEqual(planPages(model(), matching()), { actions: [], findings: [] });
});

test('plán stránek: změněná vlastnost a titul → control set jen s rozdílem + publikování s titulem', () => {
  const s = matching();
  s.pages.App.title = 'Staré';
  s.pages.App.controls[0].properties.napoveda = 'https://stara';
  const p = planPages(model(), s);
  assert.equal(p.actions.length, 2);
  const set = p.actions[0].m365;
  assert.equal(cmd(p.actions[0]), 'spo page control set');
  assert.equal(set[set.indexOf('--id') + 1], ID1);
  assert.deepEqual(JSON.parse(set[set.indexOf('--webPartProperties') + 1]), { napoveda: 'https://n' });
  assert.match(p.actions[0].desc, /napoveda "https:\/\/stara" → "https:\/\/n"/);
  assert.deepEqual(p.actions[1].m365.slice(-3), ['--title', 'Hlášení', '--publish']);
});

test('plán stránek: web part nedostupný = nález nejdřív deploy; cizí instance z balíčku = navíc; jiný web part = migrace; koncept', () => {
  let s = { site: SITE, webparts: [], pages: { App: null } };
  let p = planPages(model(), s);
  assert.deepEqual(p.findings.map((f) => f.kind), ['nejdřív deploy', 'nejdřív deploy']);
  s = matching();
  s.pages.App.controls.push({ instanceId: 'ffffffff-0000-0000-0000-000000000000', webPartId: WP, properties: {} }, { instanceId: 'cizi', webPartId: 'vestaveny', properties: {} });
  s.pages.App.controls[1].webPartId = 'jiny';
  s.pages.App.draft = true; s.pages.App.version = '2.1';
  p = planPages(model(), s);
  assert.deepEqual(p.actions, []);
  assert.deepEqual(p.findings.map((f) => f.kind).sort(), ['koncept', 'migrace', 'navíc']);
});

test('state: readPages čte stránky přes sitepages GetByUrl, 404 = null, web party normalizuje (velká písmena, závorky)', () => {
  const m = model();
  const canvas = [
    { controlType: 3, id: ID1.toUpperCase(), webPartId: `{${WP.toUpperCase()}}`, position: { zoneIndex: 1 }, webPartData: { properties: { seznam: 'Hlaseni' } } },
    { position: { zoneIndex: 1 } },
  ];
  const api = {
    get(path) {
      assert.equal(path, "sitepages/pages/GetByUrl('sitepages/CADK-App.aspx')?$select=Title,Version,CanvasContent1,PageLayoutType,CommentsDisabled");
      return { Title: 'Hlášení', Version: '3.1', PageLayoutType: 'Article', CommentsDisabled: true, CanvasContent1: JSON.stringify(canvas) };
    },
    getAll(path) { assert.equal(path, 'web/getclientsidewebparts()'); return [{ Id: `{${WP.toUpperCase()}}` }]; },
  };
  const s = readPages({ api, model: m });
  assert.deepEqual(s.webparts, [WP]);
  assert.deepEqual(s.pages.App, { title: 'Hlášení', layout: 'Article', comments: false, version: '3.1', draft: true, sections: 1, controls: [{ instanceId: ID1, webPartId: WP, properties: { seznam: 'Hlaseni' } }] });
  assert.deepEqual(readPages({ api: { get: () => null, getAll: () => [] }, model: m }).pages, { App: null });
});

test('readPackage: id solution a alias → id web partu z manifestu s komentáři', () => {
  const d = mkdtempSync(join(tmpdir(), 'spfx-'));
  mkdirSync(join(d, 'config'));
  mkdirSync(join(d, 'src', 'webparts', 'app'), { recursive: true });
  writeFileSync(join(d, 'config', 'package-solution.json'), JSON.stringify({ solution: { id: SOLUTION, version: '1.0.0.0' }, paths: { zippedPackage: 'solution/x.sppkg' } }));
  writeFileSync(join(d, 'src', 'webparts', 'app', 'AppWebPart.manifest.json'), `{\n  // komentář\n  "id": "${WP.toUpperCase()}",\n  "alias": "AppWebPart"\n}`);
  const p = readPackage(d);
  assert.equal(p.solution.id, SOLUTION);
  assert.deepEqual(p.webparts, WEBPARTS);
  assert.match(p.zippedPackage, /sharepoint\/solution\/x\.sppkg$/);
});
