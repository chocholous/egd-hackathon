// Jedna appka, tři hostitelé — vývojové dva spouští tenhle soubor:
//   npm run dev [-- --port <číslo>]                    lokálně: harness (spfx/harness) nad MockSource
//   npm run dev -- --sp [--env dev] [--page <klíč>]    DEV: ladicí server heft + URL stránky z manifestu
// Třetí hostitel je nasazený balíček (npm run build, npm run deploy); appka je ve
// všech třech stejná, liší se jen DataSource (MockSource / SpSource) a kdo dodá vlastnosti web partu.
//
// Lokálně: esbuild s watch a vlastní http server:
//   /            harness
//   /assets/*    sp/assets/config (totéž, co jde do knihovny <prefix>-Assets)
// Port: --port, jinak PORT z prostředí, jinak volný port od OS (vypíše se).
// --interni: harness pro skript (kontrola vzhledu, test toku; lib/harness.mjs): adresu do .devkit/dev-server.json
// nezapíše. Ten soubor patří dev serveru, který pustil člověk nebo agent k prohlížení (čte ho export cockpitu).
// První build proběhne před startem serveru: první načtení stránky dostane hotový bundle, ne 404.
//
// --sp: spustí heft start ve spfx/ (http bez certifikátu, viz spfx/config/webpack-patch/dev-server-http.js)
// a vypíše adresu stránky na webu prostředí s ladicími parametry. Stránka musí existovat a mít web part
// (jednou npm run deploy); ladicí režim pak místo bundlu z katalogu načte kód
// z localhostu. Port a protokol se berou ze spfx/config/serve.json.
// Chyba (neznámé prostředí, stránka, chybějící heft) = výpis a exit 1; heft běží, dokud ho neukončíš.
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { readFileSync, existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { join, normalize, extname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { spawn, spawnSync } from 'node:child_process';
import { ROOT, loadConfig, loadManifest, envConfig } from './lib/config.mjs';
import { buildModel } from './lib/manifest.mjs';

const args = process.argv.slice(2);
const opt = (n) => (args.includes(n) ? args[args.indexOf(n) + 1] : undefined);

const gen = spawnSync(process.execPath, [join(ROOT, 'tools', 'gen.mjs')], { stdio: 'inherit' });
if (gen.status !== 0) process.exit(gen.status ?? 1);

if (args.includes('--sp')) spMode();
else await localMode();

/** Adresa stránky s ladicími parametry SPFx. */
function debugUrl(site, file, { https, port }) {
  const manifests = `${https ? 'https' : 'http'}://localhost:${port}/temp/build/manifests.js`;
  return `${site.replace(/\/$/, '')}/SitePages/${encodeURIComponent(file)}?loadSPFX=true&debugManifestsFile=${encodeURIComponent(manifests)}`;
}

function spMode() {
  const cfg = loadConfig();
  const envName = opt('--env') || 'dev';
  let env;
  try { env = envConfig(cfg, envName); } catch (e) { console.error(e.message); process.exit(1); }
  const model = buildModel(loadManifest(), cfg.app.prefix);
  if (!model.pages.length) { console.error('manifest nemá žádnou stránku (sp/app.manifest.json → "pages")'); process.exit(1); }
  const page = opt('--page') ? model.pages.find((p) => p.key === opt('--page')) : model.pages[0];
  if (!page) { console.error(`stránka "${opt('--page')}" v manifestu není (má: ${model.pages.map((p) => p.key).join(', ')})`); process.exit(1); }
  const serve = JSON.parse(readFileSync(join(ROOT, 'spfx', 'config', 'serve.json'), 'utf8'));
  const heft = join(ROOT, 'spfx', 'node_modules', '@rushstack', 'heft', 'bin', 'heft');
  if (!existsSync(heft)) { console.error('chybí spfx/node_modules — npm --prefix spfx install'); process.exit(1); }
  console.log(`\nladění na ${envName}: až heft napíše, že je build hotový, otevři\n  ${debugUrl(env.site, page.file, { https: serve.https === true, port: serve.port })}\na potvrď „Load debug scripts“ (Chrome/Edge se jednou zeptá na přístup k místní síti — povolit).\n`);
  const child = spawn(process.execPath, [heft, 'start', '--clean'], { cwd: join(ROOT, 'spfx'), stdio: 'inherit' });
  child.on('exit', (code) => process.exit(code ?? 1));
}

// SCSS jako v SPFx buildu: *.module.scss = CSS moduly (import styles from …), ostatní .scss globálně.
// Kompilátor je sass-embedded, který do projektu přináší rig SPFx (@rushstack/heft-sass-plugin),
// takže lokálně i v buildu překládá tentýž sass. CSS jde do .harness-dist/main.css.
function scss(require) {
  return {
    name: 'scss',
    setup(build) {
      build.onLoad({ filter: /\.scss$/ }, async (a) => {
        const sass = require('sass-embedded');
        const r = await sass.compileAsync(a.path, { loadPaths: [join(ROOT, 'spfx', 'node_modules')] });
        return { contents: r.css, loader: a.path.endsWith('.module.scss') ? 'local-css' : 'css', watchFiles: r.loadedUrls.filter((u) => u.protocol === 'file:').map((u) => fileURLToPath(u)) };
      });
    },
  };
}

async function localMode() {
  const require = createRequire(join(ROOT, 'spfx', 'package.json'));
  const esbuild = require('esbuild');
  const OUT = join(ROOT, '.harness-dist');
  const ASSETS = join(ROOT, 'sp', 'assets', 'config');
  const port = Number(opt('--port') || process.env.PORT || 0);
  const ctx = await esbuild.context({
    entryPoints: [join(ROOT, 'spfx', 'harness', 'main.tsx')],
    bundle: true, outfile: join(OUT, 'main.js'), format: 'iife', sourcemap: true,
    absWorkingDir: join(ROOT, 'spfx'), nodePaths: [join(ROOT, 'spfx', 'node_modules')],
    define: { 'process.env.NODE_ENV': '"development"' }, logLevel: 'info', plugins: [scss(require)],
  });
  if (args.includes('--build-only')) { await ctx.rebuild(); await ctx.dispose(); process.exit(0); }
  // první build hned; chybu kódu vypíše esbuild sám a hlídání změn (watch) běží dál, oprava se přeloží
  try { await ctx.rebuild(); } catch { /* vypsáno esbuildem (logLevel info) */ }
  await ctx.watch();

  const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.map': 'application/json', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png' };
  const HTML = '<!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' + loadConfig().app.name.replace(/</g, '&lt;') + ' — mock</title><link rel="stylesheet" href="/main.css"></head><body style="margin:0;background:#F6EFE2"><div id="root"></div><script src="/main.js"></script></body></html>';

  const server = createServer(async (req, res) => {
    const url = new URL(req.url, 'http://x');
    try {
      if (url.pathname === '/') { res.writeHead(200, { 'content-type': TYPES['.html'] }); return res.end(HTML); }
      const [base, rel] = url.pathname.startsWith('/assets/') ? [ASSETS, url.pathname.slice(8)] : [OUT, url.pathname.slice(1)];
      const file = normalize(join(base, decodeURIComponent(rel)));
      if (!file.startsWith(base)) throw new Error('mimo kořen');
      // main.css vzniká jen, když appka importuje (s)css; jinak prázdný styl místo 404
      const body = url.pathname === '/main.css' && !existsSync(file) ? '' : await readFile(file);
      res.writeHead(200, { 'content-type': TYPES[extname(file)] || 'application/octet-stream', 'cache-control': 'no-store' });
      res.end(body);
    } catch {
      res.writeHead(404); res.end('not found');
    }
  });
  server.listen(port, '127.0.0.1', () => {
    const url = `http://127.0.0.1:${server.address().port}/`;
    console.log(`harness: ${url}`);
    // Kde lokální instance běží → .devkit/dev-server.json; čte ho npm run cockpit (karta LOCAL v cockpitu).
    if (!args.includes('--interni')) try { mkdirSync(join(ROOT, '.devkit'), { recursive: true }); writeFileSync(join(ROOT, '.devkit', 'dev-server.json'), JSON.stringify({ url, pid: process.pid, kdy: new Date().toISOString() })); } catch (e) { console.error(`adresu dev serveru se nepodařilo zapsat: ${e.message}`); }
  });
}
