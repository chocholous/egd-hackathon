// npm test — plán nad JSON stavem webu (bez sítě): manifest → model, plan/*.mjs, state.mjs nad
// falešným REST, run.mjs se zachycenými argumenty m365. Žádný emulátor SharePointu: stav je prostý JSON.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildModel, validateManifest } from '../lib/manifest.mjs';
import { planStructure, fieldXml, spType, INDEX_LIMIT } from '../lib/plan/structure.mjs';
import { planPerms } from '../lib/plan/perms.mjs';
import { planConfig, pullConfig } from '../lib/plan/config.mjs';
import { readState, jeVestavenySloupec } from '../lib/state.mjs';
import { runAction } from '../lib/run.mjs';

const RAW = {
  roles: { owner: {}, editor: {}, user: {} },
  levels: { read: { builtin: 'Read' }, edit: { builtin: 'Contribute' } },
  lists: {
    Kategorie: { class: 'config', key: 'Kod', fields: [
      { name: 'Kod', type: 'text', required: true, unique: true, maxLength: 20 },
      { name: 'Nadrazena', type: 'lookup', list: '@list:Kategorie' },
      { name: 'Garant', type: 'user' },
    ], access: { user: 'read', editor: 'edit' } },
    Hlaseni: { class: 'operational', itemScope: 'own', title: 'Hlášení OpRisk', versioning: { majorVersionLimit: 50 }, attachments: false, fields: [
      { name: 'Kategorie', type: 'lookup', list: 'Kategorie', deleteBehavior: 'restrict', indexed: true },
      { name: 'Popis', type: 'note', display: 'Popis události' },
      { name: 'Stav', type: 'choice', choices: ['Nové', 'Uzavřeno'], default: 'Nové' },
    ], access: { user: 'edit', editor: 'edit' } },
  },
  libraries: { Assets: { class: 'config', source: 'sp/assets', access: { user: 'read', editor: 'read' } } },
};
const DATA = { Kategorie: [
  { Title: 'Podkategorie', Kod: 'IT-SW', Nadrazena: '@key:Kategorie/IT', Garant: 'Anna@Contoso.cz' },
  { Title: 'IT', Kod: 'IT' },
] };
const model = buildModel(RAW, 'CADK');
const SITE = 'https://t.sharepoint.com/sites/x';
const IDS = { Kategorie: 'aaaa-1', Hlaseni: 'bbbb-2', Assets: 'cccc-3' };
const RD = { read: { Id: 1073741826, Name: 'Read', RoleTypeKind: 2, Hidden: false }, contribute: { Id: 1073741827, Name: 'Contribute', RoleTypeKind: 3, Hidden: false }, full: { Id: 1073741829, Name: 'Full Control', RoleTypeKind: 5, Hidden: false }, limited: { Id: 1073741825, Name: 'Limited Access', RoleTypeKind: 1, Hidden: true } };
const OWNERS = { PrincipalId: 3, Member: { Title: 'x Owners' }, RoleDefinitionBindings: [RD.full] };

const emptyState = () => ({
  site: SITE, web: { path: '/sites/x', owners: 'x Owners', members: 'x Members', visitors: 'x Visitors' },
  roledefs: Object.values(RD), groups: { 'x Owners': { Id: 3 }, 'x Members': { Id: 4 }, 'x Visitors': { Id: 5 } }, groupMembers: {}, webRA: [OWNERS], orphans: [],
  me: { Id: 10, Title: 'Nasazující' },
  lists: Object.fromEntries(model.containers.map((c) => [c.key, null])), record: null,
});
// stav webu, který přesně odpovídá manifestu (jako po úspěšném apply)
function matchingState() {
  const s = emptyState();
  for (const c of model.containers) {
    s.lists[c.key] = {
      Id: IDS[c.key], Title: c.title, ItemCount: 0, ReadSecurity: c.security[0], WriteSecurity: c.security[1],
      EnableVersioning: !!c.versioning, MajorVersionLimit: c.versioning?.majorVersionLimit ?? 0, EnableAttachments: c.attachments ?? true,
      HasUniqueRoleAssignments: true, path: `/sites/x/${c.url}`, choiceUse: {},
      ra: [OWNERS], // práva tu netestujeme (perms má vlastní test)
      fields: Object.fromEntries(c.fields.map((f) => [f.name, {
        Title: f.display, TypeAsString: spType(f), Required: f.required, Indexed: f.indexed, EnforceUniqueValues: f.unique,
        SchemaXml: fieldXml(f, f.list ? IDS[f.list] : undefined).replace('<Field ', '<Field ID="{f1}" SourceID="{s1}" '),
      }])),
    };
  }
  s.lists.Kategorie.items = [];
  s.lists.Assets.files = [];
  return s;
}
const cmds = (p) => p.actions.map((a) => a.m365 && a.m365.slice(0, 3).join(' '));

test('manifest: URL z prefixu a klíče (pomlčka zmizí), výslovná url, titul zvlášť', () => {
  assert.equal(model.byKey.Hlaseni.url, 'Lists/CADKHlaseni');
  assert.equal(model.byKey.Hlaseni.createTitle, 'CADK-Hlaseni');
  assert.equal(model.byKey.Hlaseni.title, 'Hlášení OpRisk');
  assert.equal(model.byKey.Assets.url, 'CADKAssets');
  assert.equal(buildModel({ lists: { X: { class: 'operational', url: 'Lists/ChangelogX' } } }, 'P').byKey.X.createTitle, 'ChangelogX');
  assert.deepEqual(validateManifest(RAW, { prefix: 'CADK', configData: DATA }), { errors: [], warnings: [] });
});

test('manifest: chyby lookupu, názvů a dat konfigurace', () => {
  const bad = structuredClone(RAW);
  bad.lists.Hlaseni.fields.push({ name: 'Řešitel', type: 'user' }, { name: 'Jinam', type: 'lookup', list: 'CiziList' }, { name: 'Bez', type: 'lookup', list: 'Kategorie', deleteBehavior: 'cascade' }, { name: 'Uniq', type: 'lookup', list: 'Kategorie', unique: true });
  const { errors } = validateManifest(bad, { prefix: 'CA-DK' });
  for (const re of [/prefix/, /Řešitel: name je interní/, /Jinam: lookup "list" musí být list z tohoto manifestu/, /Bez: deleteBehavior vyžaduje indexed/, /Uniq: lookup nemůže být unique/]) assert.ok(errors.some((e) => re.test(e)), `chybí chyba ${re}`);
  const cyc = { Kategorie: [{ Title: 'a', Kod: 'A', Nadrazena: '@key:Kategorie/B' }, { Title: 'b', Kod: 'B', Nadrazena: '@key:Kategorie/A' }] };
  assert.match(validateManifest(RAW, { prefix: 'CADK', configData: cyc }).errors.join(), /cyklus odkazů Kategorie\/A → Kategorie\/B → Kategorie\/A/);
  assert.match(validateManifest(RAW, { prefix: 'CADK', configData: { Kategorie: [{ Title: 'a', Kod: 'A', Nadrazena: '@key:Kategorie/X' }] } }).errors.join(), /@key:Kategorie\/X v datech Kategorie není/);
  const many = structuredClone(RAW);
  for (let i = 0; i < 13; i++) many.lists.Hlaseni.fields.push({ name: `U${i}`, type: 'user' });
  assert.match(validateManifest(many, { prefix: 'CADK' }).warnings.join(), /nejvýš 12/);
});

test('struktura: prázdný web — nejdřív všechny listy, pak sloupce; lookup přes @listid; titul až po založení', () => {
  const p = planStructure(model, emptyState());
  const kinds = cmds(p);
  const firstField = kinds.indexOf('spo field add');
  assert.ok(kinds.lastIndexOf('spo list add') < firstField, 'list add musí předcházet všem field add');
  const add = p.actions.find((a) => a.m365[2] === 'add' && a.m365.includes('CADK-Hlaseni')).m365;
  assert.deepEqual(add.slice(add.indexOf('--readSecurity'), add.indexOf('--readSecurity') + 4), ['--readSecurity', '2', '--writeSecurity', '2']);
  assert.ok(add.includes('--majorVersionLimit') && add.includes('--enableAttachments'));
  const rename = p.actions.find((a) => a.m365.includes('--newTitle')).m365;
  assert.deepEqual(rename.slice(rename.indexOf('--url'), rename.indexOf('--url') + 4), ['--url', '/sites/x/Lists/CADKHlaseni', '--newTitle', 'Hlášení OpRisk']);
  const lk = p.actions.find((a) => a.desc.includes('přidat sloupec Kategorie')).m365;
  assert.match(lk[lk.indexOf('--xml') + 1], /List="\{@listid:\/sites\/x\/Lists\/CADKKategorie\}".*RelationshipDeleteBehavior="Restrict"/);
  assert.equal(lk[lk.indexOf('--listUrl') + 1], '/sites/x/Lists/CADKHlaseni');
  assert.deepEqual(p.findings, []);
});

test('struktura: web shodný s manifestem = žádné akce ani nálezy', () => {
  assert.deepEqual(planStructure(model, matchingState()), { actions: [], findings: [] });
});

test('struktura: přejmenování listu a popisku sloupce se zapíše, SchemaXml si ponechá ID', () => {
  const s = matchingState();
  s.lists.Hlaseni.Title = 'CADK-Hlaseni';
  s.lists.Hlaseni.fields.Popis.Title = 'Popis';
  const p = planStructure(model, s);
  assert.equal(p.actions.length, 2);
  assert.match(p.actions[0].desc, /titul „CADK-Hlaseni“ → „Hlášení OpRisk“/);
  const xml = p.actions[1].m365[p.actions[1].m365.indexOf('--SchemaXml') + 1];
  assert.match(xml, /ID="\{f1\}"/);
  assert.match(xml, /DisplayName="Popis události"/);
});

test('struktura: odebraná volba — používaná = nález, nepoužívaná = zápis', () => {
  const s = matchingState();
  const f = s.lists.Hlaseni.fields.Stav;
  f.SchemaXml = f.SchemaXml.replace('<CHOICE>Uzavřeno</CHOICE>', '<CHOICE>Uzavřeno</CHOICE><CHOICE>Staré</CHOICE>');
  s.lists.Hlaseni.choiceUse = { Stav: { Staré: true } };
  let p = planStructure(model, s);
  assert.equal(p.actions.length, 0);
  assert.match(p.findings[0].desc, /„Staré“ chce manifest odebrat, ale používají je položky/);
  s.lists.Hlaseni.choiceUse = { Stav: { Staré: false } };
  p = planStructure(model, s);
  assert.match(p.actions[0].m365.at(-1), /<CHOICES><CHOICE>Nové<\/CHOICE><CHOICE>Uzavřeno<\/CHOICE><\/CHOICES>/);
});

test('struktura: změna typu, index nad limitem, sloupec a list navíc = nálezy; povinný sloupec na neprázdném listu s upozorněním', () => {
  const s = matchingState();
  s.lists.Hlaseni.fields.Popis.TypeAsString = 'Text';
  s.lists.Hlaseni.ItemCount = INDEX_LIMIT + 1;
  s.lists.Hlaseni.fields.Kategorie.Indexed = false;
  s.lists.Hlaseni.fields.Stary = { Title: 'Starý', TypeAsString: 'Text', SchemaXml: '<Field/>' };
  s.orphans = [{ title: 'CADK-Pokus', url: '/sites/x/Lists/CADKPokus', items: 3 }];
  delete s.lists.Kategorie.fields.Garant;
  s.lists.Kategorie.ItemCount = 4;
  const m = buildModel({ ...RAW, lists: { ...RAW.lists, Kategorie: { ...RAW.lists.Kategorie, fields: [...RAW.lists.Kategorie.fields.slice(0, 2), { name: 'Garant', type: 'user', required: true }] } } }, 'CADK');
  const p = planStructure(m, s);
  const kinds = p.findings.map((f) => f.kind).sort();
  assert.deepEqual(kinds, ['limit', 'migrace', 'navíc', 'navíc']);
  assert.equal(p.actions.length, 1);
  assert.match(p.actions[0].desc, /přidat sloupec Garant .* existující položky \(4\) zůstanou prázdné/);
});

test('práva: nový list vychází ze sady webu ze stavu (plán nic nečte)', () => {
  const env = { roles: { user: { bindTo: '@members' }, editor: { members: { emails: ['a@b.cz'] } } } };
  const p = planPerms(model, emptyState(), { env, appName: 'T' });
  const hl = p.actions.filter((a) => a.desc.startsWith('„Hlášení OpRisk“'));
  assert.match(hl[0].rest.path, /breakroleinheritance\(copyRoleAssignments=true,clearSubscopes=false\)$/);
  assert.ok(hl.some((a) => a.desc.includes('x Members → Contribute')));
  assert.ok(p.actions.some((a) => a.desc === 'založit skupinu „CADK – editor“'));
});

test('konfigurace: zápis v pořadí odkazů, @key a osoba jako zástupci; shodný cíl = nic; pull vrátí tvar gitu', () => {
  const s = matchingState();
  let p = planConfig(model, s, { configData: DATA, assets: { Assets: [] }, envName: 'dev' });
  assert.deepEqual(p.actions.map((a) => a.desc), ['CADK-Kategorie: přidat IT', 'CADK-Kategorie: přidat IT-SW']);
  assert.deepEqual(p.actions[1].rest.body, { Title: 'Podkategorie', Kod: 'IT-SW', NadrazenaId: { $key: { list: '/sites/x/Lists/CADKKategorie', field: 'Kod', value: 'IT' } }, GarantId: { $user: 'anna@contoso.cz' } });
  s.lists.Kategorie.items = [
    { Id: 7, Title: 'IT', Kod: 'IT', NadrazenaId: null, Garant: null },
    { Id: 8, Title: 'Podkategorie', Kod: 'IT-SW', NadrazenaId: 7, Garant: 'anna@contoso.cz' },
  ];
  p = planConfig(model, s, { configData: DATA, assets: { Assets: [] }, envName: 'dev' });
  assert.deepEqual([p.actions, p.findings], [[], []]);
  assert.equal(pullConfig(model, s).Kategorie[1].Nadrazena, '@key:Kategorie/IT');
});

test('konfigurace: nový sloupec v manifestu = zápis, ne falešný konflikt; skutečný konflikt zůstává', () => {
  // minulé nasazení: Kategorie ještě bez sloupce Garant
  const oldModel = buildModel({ ...RAW, lists: { ...RAW.lists, Kategorie: { ...RAW.lists.Kategorie, fields: RAW.lists.Kategorie.fields.slice(0, 2) } } }, 'CADK');
  const oldData = { Kategorie: DATA.Kategorie.map(({ Garant, ...r }) => (void Garant, r)) };
  const s = matchingState();
  delete s.lists.Kategorie.fields.Garant; // na cíli sloupec ještě není
  s.lists.Kategorie.items = [
    { Id: 7, Title: 'IT', Kod: 'IT', NadrazenaId: null },
    { Id: 8, Title: 'Podkategorie', Kod: 'IT-SW', NadrazenaId: 7 },
  ];
  s.record = planConfig(oldModel, s, { configData: oldData, assets: { Assets: [] }, envName: 'dev' }).newRecord;
  let p = planConfig(model, s, { configData: DATA, assets: { Assets: [] }, envName: 'dev' });
  assert.deepEqual(p.findings, []);
  assert.deepEqual(p.actions.map((a) => a.desc), ['CADK-Kategorie: upravit IT', 'CADK-Kategorie: upravit IT-SW']); // obě dostanou nový sloupec
  // někdo mezitím na cíli změnil název: to je skutečný konflikt i se sloupcem navíc
  s.lists.Kategorie.items[1].Title = 'Přejmenováno na webu';
  p = planConfig(model, s, { configData: DATA, assets: { Assets: [] }, envName: 'dev' });
  assert.deepEqual(p.findings.map((f) => f.desc), ['CADK-Kategorie[IT-SW]: změněno v gitu i na cíli']);
});

test('state: listy podle URL, jen přidané sloupce, nepoužívané volby, osoba jako UPN, list navíc s prefixem', () => {
  const lists = [
    { Id: 'k', Title: 'Kategorie', BaseTemplate: 100, ItemCount: 1, Hidden: false, HasUniqueRoleAssignments: false, RootFolder: { ServerRelativeUrl: '/sites/x/Lists/CADKKategorie' } },
    { Id: 'h', Title: 'Hlášení OpRisk', BaseTemplate: 100, ItemCount: 0, Hidden: false, HasUniqueRoleAssignments: true, RootFolder: { ServerRelativeUrl: '/sites/x/Lists/CADKHlaseni' } },
    { Id: 'o', Title: 'CADK-Pokus', BaseTemplate: 100, ItemCount: 2, Hidden: false, RootFolder: { ServerRelativeUrl: '/sites/x/Lists/CADKPokus' } },
    { Id: 'z', Title: 'Dokumenty', BaseTemplate: 101, ItemCount: 9, Hidden: false, RootFolder: { ServerRelativeUrl: '/sites/x/Shared Documents' } },
  ];
  const K = "web/GetList('%2Fsites%2Fx%2FLists%2FCADKKategorie')";
  const H = "web/GetList('%2Fsites%2Fx%2FLists%2FCADKHlaseni')";
  const stav = { Title: 'Stav', TypeAsString: 'Choice', FromBaseType: false, ReadOnlyField: false, SchemaXml: '<Field><CHOICES><CHOICE>Nové</CHOICE><CHOICE>Staré</CHOICE></CHOICES></Field>' };
  const seen = [];
  const api = {
    site: SITE,
    get(path) {
      seen.push(path);
      if (path.startsWith('web/Associated')) return { Title: path.slice(14, -19) };
      if (path.startsWith('web/currentuser')) return { Id: 10, Title: 'Já' };
      if (path.startsWith(`${H}/items?$select=Id&$top=1`)) return { value: [] };
      throw new Error(`neočekávané GET ${path}`);
    },
    getAll(path) {
      seen.push(path);
      if (path.startsWith('web/roledefinitions')) return [RD.read];
      if (path.startsWith('web/sitegroups') || path.startsWith('web/roleassignments') || path.startsWith(`${H}/roleassignments`)) return [];
      if (path.startsWith('web/lists?')) return lists;
      if (path.startsWith(`${K}/fields`)) return [{ InternalName: 'Title', FromBaseType: true }, { InternalName: 'Kod', Title: 'Kod', TypeAsString: 'Text', FromBaseType: false, ReadOnlyField: false }, { InternalName: 'Garant', Title: 'Garant', TypeAsString: 'User', FromBaseType: false, ReadOnlyField: false }];
      if (path.startsWith(`${H}/fields`)) return [{ InternalName: 'Stav', ...stav }, { InternalName: 'MediaServiceImageTags', Title: 'Image Tags', TypeAsString: 'TaxonomyFieldTypeMulti', FromBaseType: false, ReadOnlyField: false, SchemaXml: '<Field Name="MediaServiceImageTags" Group="_Hidden" />' }];
      if (path.startsWith(`${K}/items`)) { assert.match(path, /\$select=Id,Title,Kod,Garant\/Name&\$expand=Garant/); return [{ Id: 1, Title: 'IT', Kod: 'IT', Garant: { Name: 'i:0#.f|membership|Anna@CONTOSO.cz' } }]; }
      throw new Error(`neočekávané GET ${path}`);
    },
    file() { return null; },
  };
  const s = readState({ model, api, envRoles: {}, groupOf: (r) => r, recordPath: '_deploy/dev.json' });
  assert.equal(s.lists.Assets, null);
  assert.deepEqual(Object.keys(s.lists.Kategorie.fields), ['Kod', 'Garant']);
  assert.equal(s.lists.Kategorie.items[0].Garant, 'anna@contoso.cz');
  assert.deepEqual(s.lists.Hlaseni.choiceUse, { Stav: { Staré: false } });
  assert.equal(s.lists.Kategorie.ra, null);
  assert.deepEqual(s.orphans, [{ title: 'CADK-Pokus', url: '/sites/x/Lists/CADKPokus', items: 2 }]);
  assert.ok(!seen.some((p) => /getByTitle/i.test(p)));
  assert.deepEqual(Object.keys(s.lists.Hlaseni.fields), ['Stav'], 'sloupec SharePointu ve skupině _Hidden se do stavu nedostane (D09)');
  assert.ok(seen.some((p) => p.startsWith('web/lists?') && /[,=]NoCrawl[,&]/.test(p)), 'stav čte NoCrawl (D08)');
});

test('run: dosadí @listid, $key a $user; chyba m365 = výjimka s popisem akce', () => {
  const calls = [];
  const api = { get(path) {
    if (path === "web/GetList('%2Fsites%2Fx%2FLists%2FCADKKategorie')?$select=Id") return { Id: 'guid-k' };
    if (path.startsWith("web/GetList('%2Fsites%2Fx%2FLists%2FCADKKategorie')/items?$select=Id&$top=1&$filter=Kod%20eq%20'IT'")) return { value: [{ Id: 7 }] };
    return null;
  } };
  const m365 = (args) => { calls.push(args); return { status: 0, out: '{}', json: {} }; };
  const rest = (url, o) => { calls.push([url, o]); return { status: 0, json: url.endsWith('ensureuser') ? { Id: 42 } : { Id: 9 } }; };
  runAction({ desc: 'sloupec', m365: ['spo', 'field', 'add', '--xml', '<Field List="{@listid:/sites/x/Lists/CADKKategorie}"/>'] }, { site: SITE, api, m365, rest });
  assert.equal(calls[0][4], '<Field List="{guid-k}"/>');
  runAction({ desc: 'položka', rest: { method: 'post', path: 'web/x/items', body: { Title: 'a', NadrazenaId: { $key: { list: '/sites/x/Lists/CADKKategorie', field: 'Kod', value: 'IT' } }, GarantId: { $user: 'anna@contoso.cz' } } } }, { site: SITE, api, m365, rest });
  assert.deepEqual(calls[1], [`${SITE}/_api/web/ensureuser`, { method: 'post', body: { logonName: 'i:0#.f|membership|anna@contoso.cz' } }]);
  assert.deepEqual(calls[2][1].body, { Title: 'a', NadrazenaId: 7, GarantId: 42 });
  assert.throws(() => runAction({ desc: 'pád', m365: ['x'] }, { site: SITE, api, m365: () => ({ status: 1, err: 'Access denied' }), rest }), /pád: Access denied/);
  assert.throws(() => runAction({ desc: 'chybí', m365: ['--xml', '{@listid:/sites/x/Lists/Nic}'] }, { site: SITE, api, m365, rest }), /chybí: list \/sites\/x\/Lists\/Nic neexistuje/);
});

test('sloupec, který SharePoint založil ve skupině _Hidden (MediaServiceImageTags), není „navíc“; vlastní sloupec ano (D09)', () => {
  const xml = (g) => `<Field Type="TaxonomyFieldTypeMulti" DisplayName="Image Tags" Name="MediaServiceImageTags" SourceID="{6740882b-99fe-4811-8e04-535861478c9a}" Group="${g}" Description="Field created by MediaTA" />`;
  assert.equal(jeVestavenySloupec({ FromBaseType: false, ReadOnlyField: false, SchemaXml: xml('_Hidden') }), true);
  assert.equal(jeVestavenySloupec({ FromBaseType: false, ReadOnlyField: false, SchemaXml: xml('Vlastní') }), false);
  assert.equal(jeVestavenySloupec({ FromBaseType: false, ReadOnlyField: false, SchemaXml: '<Field Type="Note" Name="Popis" SourceID="{abc}" />' }), false);
  assert.equal(jeVestavenySloupec({ FromBaseType: false, ReadOnlyField: false, SchemaXml: '<Field Name="Title" SourceID="http://schemas.microsoft.com/sharepoint/v3" />' }), true);
  assert.equal(jeVestavenySloupec({ FromBaseType: true, SchemaXml: '' }), true);
});

test('noCrawl (D08): validace, založení s --noCrawl, změna existujícího listu, shoda = nic, nevyplněné = kit neřeší', () => {
  const raw = structuredClone(RAW);
  raw.lists.Hlaseni.noCrawl = true;
  assert.deepEqual(validateManifest(raw, { prefix: 'CADK', configData: DATA }).errors, []);
  const bad = structuredClone(RAW);
  bad.lists.Hlaseni.noCrawl = 'ano';
  assert.ok(validateManifest(bad, { prefix: 'CADK', configData: DATA }).errors.some((e) => /Hlaseni: noCrawl musí být true\|false/.test(e)));
  const m = buildModel(raw, 'CADK');
  const p0 = planStructure(m, { ...emptyState(), lists: Object.fromEntries(m.containers.map((c) => [c.key, null])) });
  const add = p0.actions.find((a) => a.m365[2] === 'add' && a.m365.includes('CADK-Hlaseni'));
  assert.equal(add.m365[add.m365.indexOf('--noCrawl') + 1], 'true');
  assert.match(add.desc, /mimo vyhledávání/);
  assert.ok(!p0.actions.find((a) => a.m365.includes('CADK-Kategorie')).m365.includes('--noCrawl'), 'list bez noCrawl ho nedostane');
  const s = matchingState();
  s.lists.Hlaseni.NoCrawl = false;
  s.lists.Kategorie.NoCrawl = false; // bez noCrawl v manifestu kit stav neřeší
  const p = planStructure(m, s);
  assert.equal(p.actions.length, 1);
  assert.deepEqual(p.actions[0].m365.slice(0, 3), ['spo', 'list', 'set']);
  assert.equal(p.actions[0].m365[p.actions[0].m365.indexOf('--noCrawl') + 1], 'true');
  assert.match(p.actions[0].desc, /NoCrawl false → true/);
  s.lists.Hlaseni.NoCrawl = true;
  assert.deepEqual(planStructure(m, s), { actions: [], findings: [] });
});
