// npm run deploy -- --env dev|test                     plán nasazení (jen čte)
// npm run deploy -- --env dev|test --confirm <hash>    zápis přesně toho plánu
//   [--same-version]  nahrát a upgradovat i stejnou solution.version (SP pak může servírovat starý bundle)
//   [--prefer-git]    konfigurace: přepsat i změny na webu od posledního nasazení (jinak konflikt)
//
// Jediná cesta zápisu na SharePoint (pro člověka i agenta), v pořadí plánu:
//   balíček     .sppkg do site app catalogu webu → nasadit → nainstalovat / upgradovat
//   struktura   listy, knihovny, sloupce            ┐ z manifestu (sp/app.manifest.json)
//   práva       úrovně, skupiny, přiřazení          │ a gitu (sp/data/config, assety)
//   konfigurace obsah konfiguračních listů, assety  │
//   stránky     stránky appky a web party           ┘
// Pak záznam o nasazení na webu (_deploy/<env>.json a řádek historie, lib/records.mjs; do gitu se nic nezapisuje,
// po nasazení se necommituje; selže-li zápis záznamu, deploy to řekne a skončí 1), kontrolní plán (musí
// vyjít prázdný) a příkaz sondy (npm run probe -- --env <env>). Selže-li akce uprostřed, zápis skončí,
// záznam se nezapíše a deploy vypíše, kolik akcí proběhlo a co dál (nový plán; lib/apply.mjs). Jen DEV a TEST — produkci kit odmítne (lib/config.mjs).
// Nálezy se nezapisují nikdy; blokující nález zápis zastaví: balíček chybí, neodpovídá dnešnímu kódu (lib/otisk.mjs),
// stejná verze je na webu z jiného kódu, mimo DEV chybí úplná kontrola vzhledu dnešního kódu, chybí cockpit,
// nebo stav není commitnutý a pushnutý (nález `git`: záznam nasazení musí odpovídat dohledatelnému commitu).
// Podmínky zjistitelné bez webu jsou sepsané jednou v lib/podminky.mjs; stejné čte doctor --pred-nasazenim.
// Poslední řádek výstupu je vždy STAV: prázdný | akce | nálezy | chyba (lib/apply.mjs).
// Exit (lib/kody.mjs): 0 prázdný plán nebo zápis s prázdným kontrolním plánem; 10 plán má akce nebo nálezy a nic
//       se nezapsalo; 11 zapsáno, ale v kontrolním plánu něco zbylo; 1 odmítnutý zápis nebo selhání; 2 špatné použití.
import { assertDeployEnv } from './lib/config.mjs';
import { m365, rest, assertTenant, setFatalTail } from './lib/m365.mjs';
import { runAction } from './lib/run.mjs';
import { applyActions, failureReport, outcome, STAV } from './lib/apply.mjs';
import { KOD } from './lib/kody.mjs';
import { loadProject } from './lib/project.mjs';
import { prevzatoText } from './lib/records.mjs';
import { appUrl } from './lib/probe.mjs';

setFatalTail(STAV.chyba);
const argv = process.argv.slice(2);
const opt = (n) => (argv.includes(n) ? argv[argv.indexOf(n) + 1] : undefined);
const flag = (n) => argv.includes(n);
const ENV = opt('--env');

function main() {
  const USAGE = 'použití: npm run deploy -- --env dev|test [--confirm <hash>] [--same-version] [--prefer-git]\n  bez --confirm jen čte a vypíše plán; výstup je text, volbu --json tento příkaz nemá';
  if (flag('--help') || flag('-h')) { console.log(USAGE); return { stav: STAV.prazdny, code: KOD.hotovo }; }
  if (!ENV) { console.error(USAGE); return { stav: STAV.chyba, code: KOD.pouziti }; }
  try { assertDeployEnv(ENV); } catch (e) { console.error(e.message); return { stav: STAV.chyba, code: KOD.chyba }; }

  let P;
  try { P = loadProject(ENV, { preferGit: flag('--prefer-git'), sameVersion: flag('--same-version') }); } catch (e) { console.error(e.message); return { stav: STAV.chyba, code: KOD.chyba }; }
  const { cfg, env } = P;
  assertTenant(cfg.m365.tenantId);
  const extra = [flag('--same-version') && '--same-version', flag('--prefer-git') && '--prefer-git'].filter(Boolean).join(' ');
  const show = (p) => P.printPlan(p, { withPackage: true, next: (h) => `potvrzení: npm run deploy -- --env ${ENV} --confirm ${h}${extra ? ` ${extra}` : ''}` });
  const plan = () => P.buildPlan(P.read({ withPackage: true }), { withPackage: true });

  console.log('čtu stav webu …');
  const p = plan();
  if (!flag('--confirm')) { show(p); return outcome(p); }
  if (opt('--confirm') !== p.hash) { show(p); console.error(`\nhash plánu je ${p.hash}, potvrzení ${opt('--confirm') || 'chybí'} — nic nezapsáno`); return { stav: STAV.chyba, code: KOD.chyba }; }
  const git = p.findings.filter((f) => f.kind === 'git');
  if (git.length) { show(p); console.error('\nZÁPIS ODMÍTNUT: nasazuje se jen z commitnutého a pushnutého stavu (nálezy git výše) — nic nezapsáno.\n  co dál: commitni, pushni, spusť znovu plán (hash zůstane stejný, pokud se akce nezměnily)'); return { stav: STAV.chyba, code: KOD.chyba }; }
  const blocking = p.findings.filter((f) => f.block);
  if (blocking.length) { show(p); console.error(`\nblokující nález zápis zastavil — nic nezapsáno:\n${blocking.map((f) => `  ! ${f.kind}: ${f.desc}`).join('\n')}`); return { stav: STAV.chyba, code: KOD.chyba }; }
  if (!p.actions.length) { show(p); return outcome(p); }

  // selhání uprostřed: co proběhlo, co selhalo, záznam se nezapíše, další krok = nový plán (lib/apply.mjs)
  console.log(`\nzápis: ${p.actions.length} ${p.actions.length >= 1 && p.actions.length <= 4 ? 'akce' : 'akcí'}`);
  const applied = applyActions(p.actions, (a) => runAction(a, { site: env.site, api: P.api, m365, rest }), { before: () => assertTenant(cfg.m365.tenantId) });
  if (applied.failed) { console.error(failureReport(applied, ENV)); return { stav: STAV.chyba, code: KOD.chyba }; }
  const rec = P.writeRecord(p);
  console.log(`záznam o nasazení: ${rec.web === true ? `na webu zapsán (_deploy/${ENV}.json a řádek historie; do gitu se nic nezapisuje)${rec.prevzato ? `; do historie na webu ${prevzatoText(rec.prevzato)} z releases/${ENV}.jsonl (soubor v gitu už nástroje nečtou)` : ''}` : rec.web === null ? 'není kam zapsat (appka nemá konfigurační knihovnu — tříbodové porovnání konfigurace ani kontrola otisku kódu nefungují)' : 'NEZAPSÁN'}`);
  if (rec.web === false) console.error(`\nZÁZNAM O NASAZENÍ SELHAL: ${rec.webChyba}\n  akce nasazení proběhly, ale na webu chybí _deploy/${ENV}.json s novým stavem (a řádek historie).\n  co dál: web teď odpovídá gitu, ale záznam na webu je starý. Příští změnu konfigurace z gitu proto plán může ukázat jako konflikt „změněno v gitu i na cíli“; potvrď ji pak s --prefer-git, to nasazení záznam zapíše znovu.`);

  console.log('\nkontrolní plán: čtu stav webu znovu …');
  const t0 = Date.now();
  const after = plan();
  console.log(`(čtení ${Math.round((Date.now() - t0) / 1000)} s)`);
  show(after);
  const pages = P.model.pages.map((x) => appUrl(env.site, x.file));
  if (pages.length) console.log(`\nstránky appky: ${pages.join(' ; ')}\nsonda (důkaz, že appka běží): npm run probe -- --env ${ENV}`);
  const o = rec.web === false ? { stav: STAV.chyba, code: KOD.chyba } : outcome(after, { written: true });
  if (o.code === KOD.upozorneni) console.log(`\nzápis proběhl, ale kontrolní plán není prázdný (návratový kód ${KOD.upozorneni}): ${after.actions.length ? 'zbyly akce — spusť nový plán' : after.findings.every((f) => f.kind === 'navíc') ? 'zbyly jen nálezy „navíc“ (na webu je něco, co manifest nezná); nic k zápisu' : 'zbyly nálezy výše, rozhodni o nich'}`);
  return o;
}

const r = main();
console.log(r.stav);
process.exitCode = r.code;
