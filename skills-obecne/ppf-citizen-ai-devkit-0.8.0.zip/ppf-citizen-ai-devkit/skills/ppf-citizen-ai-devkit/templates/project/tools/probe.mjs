// npm run probe -- --env dev|test [--page <klíč>] [--url <adresa>] [--shot <soubor.png>]
//
// Sonda: důkaz, že nasazená appka na webu opravdu běží. Projde stránky appky (sp/app.manifest.json → pages;
// adresa environments.<env>.site + /SitePages/<PREFIX>-<Klíč>.aspx?env=WebView, stejná jako vypisuje nasazení)
// nebo jednu stránku (--page / --url; --url se otevře přesně tak, jak je zadaná)
// v prohlížeči (Playwright, headless) pod uloženou SharePoint session. Jen čte — na web nic nezapisuje
// a session (storage state) nikdy nepřepisuje.
// Hotovo = HTTP 200, přihlášeno, web party appky vykreslené, žádná chyba web partu (rámeček SP ani konzole).
// Font ikon (Material Symbols z Google Fonts): vypíše, zda je na stránce načtený; nenačtený = varování, ne selhání.
// Screenshot a text stránky: .devkit/probe-<klíč>.png / .txt (nebo --shot).
//
// Přihlášení sonda NEDĚLÁ: session zapisuje jen skill ppf-browsermagic (jeho auth-refresh.mjs, člověk a MFA);
// sonda vypíše přesný příkaz (lib/probe.mjs → loginHint).
// Store session: ~/.config/spo-auth/state-<tenant>.json, když adresář existuje (sdílí ho všechny projekty),
// jinak .auth/ v projektu (stejně jako ppf-browsermagic); SPO_AUTH_DIR přebije obojí (lib/auth-state.mjs).
// Prohlížeč: přibalené Chromium (npx playwright install chromium; npm run prereq to hlídá), a když nejde
// spustit, záloha Microsoft Edge (channel msedge; lib/probe.mjs launchProbeBrowser).
// Exit: 0 vše OK, 1 nějaká stránka neprošla / chybí session, 2 špatné použití.
// Poslední řádky: „co dál: …“ a STAV: hotovo | chyba (lib/stav.mjs).
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { dirname, join, relative } from 'node:path';
import { ROOT, loadConfig, loadManifest, envConfig } from './lib/config.mjs';
import { readPackage } from './lib/spfx-package.mjs';
import { probeTargets, classifyConsole, verdict, ICON_FONT, iconFontState, iconFontWarning, launchProbeBrowser, loginHint } from './lib/probe.mjs';
import { resolveAuthPaths, shouldReuse, spoSessionValidUntil } from './lib/auth-state.mjs';
import { stavNaKonci } from './lib/stav.mjs';

// Převzato ze scripts/browser/probe.mjs (ověřeno na DEV web):
const VIEWPORT = { width: 1600, height: 1200 }; // velikost okna pro screenshot
const GOTO_TIMEOUT_MS = 90_000; // první načtení SP stránky (studený start webu bývá pomalý)
const NETWORKIDLE_TIMEOUT_MS = 60_000; // čekání na utichnutí sítě; po vypršení se pokračuje
const SETTLE_MS = Number(process.env.PROBE_SETTLE || 5000); // dodatečné čekání po networkidle, ať web party doběhnou
// Telemetrie a Office prefetch (substrate 429 je běžný a stránku neovlivní)
const NOISE = ['OneCollector', 'events.data.microsoft.com', 'browser.events.data.msn.com', 'substrate.office.com'];
const TEXT_PREVIEW = 4000; // kolik znaků textu stránky vypsat
const LIST_LIMIT = 40; // kolik chybných požadavků / zpráv konzole vypsat
// Nové v sondě kitu (dřív nebylo potřeba): kontejner web partu na moderní stránce nese id instance
// porovnání bez ohledu na velikost písmen (příznak i): instanceId z plánu je malými, SharePoint by ho mohl vrátit jinak
// Aplikační stránka (SingleWebPartAppPage, ověřeno DEV web 2026-11-11) instanci nemá: kontejner nese jen
// data-sp-web-part-id = id web partu (komponenty). Sonda proto přijme obojí.
const WEBPART_SELECTOR = (w) => [
  w.instanceId && `[data-sp-feature-instance-id="${w.instanceId}" i]`,
  w.webPartId && `[data-sp-web-part-id="${w.webPartId}" i]`,
].filter(Boolean).join(', ');

const argv = process.argv.slice(2);
const opt = (n) => (argv.includes(n) ? argv[argv.indexOf(n) + 1] : undefined);
const USAGE = 'použití: npm run probe -- --env dev|test [--page <klíč>] [--url <adresa>] [--shot <soubor.png>]';
if (argv.includes('--help')) { console.log(USAGE); process.exit(0); }
const ENV = opt('--env');
stavNaKonci((kod) => (kod === 0 ? `ukaž člověku výsledek a screenshot (.devkit/probe-*.png); připomínky testerů: npm run feedback -- --env ${ENV}`
  : kod === 2 ? 'oprav volby podle hlášky výše a spusť sondu znovu'
    : 'přečti důvody (✗) a hlášky výše; po opravě spusť sondu znovu'));
if (!ENV) { console.error(USAGE); process.exit(2); }

let cfg, env;
try { cfg = loadConfig(); env = envConfig(cfg, ENV); } catch (e) { console.error(e.message); process.exit(2); }
if (ENV === 'local') { console.error('prostředí local nemá web — sonda je pro dev/test'); process.exit(2); }

let chromium;
try { ({ chromium } = await import('playwright')); }
catch { console.error('chybí balíček playwright — npm install (je v devDependencies)'); process.exit(1); }

const { tenant, authFile } = resolveAuthPaths(env.site, join(ROOT, '.auth')); // záložní složka jako u ppf-browsermagic (<projekt>/.auth)

if (argv[0] === 'login') { console.error(`sonda se nepřihlašuje — ${loginHint(env.site)}`); process.exit(2); }

// ---------- sonda ----------
let pkg = { webparts: {}, solution: {} };
try { pkg = readPackage(join(ROOT, 'spfx')); } catch (e) { console.warn(`pozor: balíček (spfx/) nejde přečíst — web party appky se nehlídají: ${e.message}`); }
let targets;
try {
  targets = probeTargets({ cfg, manifest: loadManifest(), envName: ENV, page: opt('--page'), url: opt('--url'), shot: opt('--shot'), webparts: pkg.webparts, solutionId: pkg.solution?.id, root: ROOT });
} catch (e) { console.error(e.message); process.exit(2); }

if (!spoSessionValidUntil(authFile)) {
  console.error(`SONDA: SELHALO — chybí uložená session pro ${tenant} (${authFile})\n  ${loginHint(env.site)}`);
  process.exit(1);
}
const reuse = shouldReuse(authFile);
if (!reuse.reuse) console.warn(`pozor: session — ${reuse.reason}; když sonda skončí na loginu: ${loginHint(env.site)}`);

let browser;
try { browser = await launchProbeBrowser(chromium); }
catch (e) { console.error(`SONDA: SELHALO — prohlížeč nejde spustit: ${e.message.split('\n')[0]}\n  nainstaluj: npx playwright install chromium (nebo na firemním Windows nainstaluj Microsoft Edge)`); process.exit(1); }

const results = [];
for (const t of targets) {
  // storage state jen čte — sonda nikdy nezapisuje session zpět (guard skillu ppf-browsermagic)
  const ctx = await browser.newContext({ storageState: authFile, viewport: VIEWPORT, serviceWorkers: 'block', reducedMotion: 'reduce' });
  const page = await ctx.newPage();
  const msgs = [];
  const failed = [];
  page.on('console', (m) => msgs.push({ type: m.type(), text: m.text().slice(0, 400), url: m.location()?.url || '' }));
  page.on('pageerror', (e) => msgs.push({ type: 'pageerror', text: String(e.stack || e).slice(0, 400), url: '' }));
  page.on('requestfailed', (r) => {
    const u = r.url();
    if (NOISE.some((n) => u.includes(n)) || r.failure()?.errorText === 'net::ERR_ABORTED') return;
    failed.push(`${r.failure()?.errorText} ${u.slice(0, 160)}`);
  });
  let worst = 0; // nejhorší status hlavního dokumentu
  page.on('response', (r) => {
    const u = r.url();
    if (r.status() >= 400 && !NOISE.some((n) => u.includes(n))) failed.push(`HTTP ${r.status()} ${u.slice(0, 160)}`);
    if (r.request().resourceType() === 'document' && r.request().frame() === page.mainFrame()) worst = Math.max(worst, r.status());
  });

  let status = 0;
  let gotoError = null;
  try { status = (await page.goto(t.url, { waitUntil: 'domcontentloaded', timeout: GOTO_TIMEOUT_MS }))?.status() || 0; }
  catch (e) { gotoError = e.message.split('\n')[0]; }
  const loggedIn = !gotoError && new URL(page.url()).hostname === new URL(t.url).hostname;
  if (loggedIn) {
    await page.waitForLoadState('networkidle', { timeout: NETWORKIDLE_TIMEOUT_MS }).catch(() => console.log('(networkidle timeout — pokračuju)'));
    await page.waitForTimeout(SETTLE_MS);
  }
  const wpErrors = await page.locator('[class*="webpartError"]').count();
  const missing = [];
  for (const w of t.expect) {
    const el = page.locator(WEBPART_SELECTOR(w));
    const rendered = (await el.count()) > 0 && ((await el.first().innerText().catch(() => '')).trim().length > 0 || (await el.first().locator('*').count()) > 1);
    if (!rendered) missing.push(w);
  }
  const found = await page.$$eval('[data-sp-feature-instance-id], [data-sp-web-part-id]', (els) => els.map((e) => e.getAttribute('data-sp-feature-tag') || e.getAttribute('data-sp-feature-instance-id') || `web part ${e.getAttribute('data-sp-web-part-id')}`)).catch(() => []);
  mkdirSync(dirname(t.shot), { recursive: true });
  await page.screenshot({ path: t.shot, fullPage: true }).catch((e) => console.warn(`screenshot nevznikl: ${e.message.split('\n')[0]}`));
  const text = (await page.evaluate(() => document.body?.innerText || '').catch(() => '')) || '';
  const iconFont = loggedIn ? await page.evaluate(iconFontState, ICON_FONT).catch(() => null) : null;
  const iconWarn = loggedIn ? iconFontWarning(iconFont) : null;
  writeFileSync(t.shot.replace(/\.png$/i, '') + '.txt', text);
  const { app, other, znamy } = classifyConsole(msgs, { solutionId: pkg.solution?.id, webparts: pkg.webparts });
  const v = verdict({ status, worst, loggedIn, notFound: /^\s*404 NOT FOUND/i.test(text), wpErrors, missing, appErrors: app });
  if (gotoError) v.reasons.unshift(`stránka se nenačetla: ${gotoError}`);
  await ctx.close();

  const rel = (p) => relative(ROOT, p) || p;
  console.log(`\n=== ${t.key}  ${t.url}`);
  console.log(`výsledek: ${v.ok ? 'OK' : 'SELHALO'}  (HTTP ${status}${worst > status ? `, nejhorší ${worst}` : ''}, konečná adresa ${page.url()})`);
  for (const r of v.reasons) console.log(`  ✗ ${r.replace('<env>', ENV)}`);
  if (loggedIn) console.log(iconWarn ? `  ? varování: ${iconWarn}` : `font ikon ${ICON_FONT}: načtený`);
  console.log(`web party na stránce: ${found.length ? found.join(', ') : '(žádné)'}${t.expect.length ? ` · appky očekávané: ${t.expect.map((w) => w.alias).join(', ')}` : ''}`);
  console.log(`screenshot: ${rel(t.shot)} · text: ${rel(t.shot.replace(/\.png$/i, '') + '.txt')}`);
  if (app.length) console.log('--- CHYBY WEB PARTU APPKY (konzole) ---\n' + app.slice(0, LIST_LIMIT).map((m) => `[${m.type}] ${m.text}${m.url ? ` @ ${m.url.slice(0, 160)}` : ''}`).join('\n'));
  if (failed.length) console.log('--- CHYBNÉ POŽADAVKY ---\n' + [...new Set(failed)].slice(0, LIST_LIMIT).join('\n'));
  if (other.length) console.log(`--- OSTATNÍ CHYBY KONZOLE (šum SharePointu, sondu neshazují): ${other.length} ---\n` + other.slice(0, LIST_LIMIT).map((m) => `[${m.type}] ${m.text}`).join('\n'));
  if (znamy.length) console.log(`(známé hlášky SharePointu v konzoli, s appkou nesouvisí: ${znamy.length}× — nevypisuju)`);
  console.log(`--- TEXT STRÁNKY (prvních ${TEXT_PREVIEW} znaků) ---\n${text.slice(0, TEXT_PREVIEW)}`);
  results.push({ key: t.key, ok: v.ok, iconFont: iconFont ? iconFont.loaded : null });
}
await browser.close();

const bad = results.filter((r) => !r.ok);
console.log(`\nSONDA ${ENV}: ${bad.length ? `SELHALO ${bad.length}/${results.length} (${bad.map((r) => r.key).join(', ')})` : `OK ${results.length}/${results.length}`}`);
const fonts = results.filter((r) => r.iconFont !== null);
if (fonts.length) console.log(`font ikon ${ICON_FONT}: načtený na ${fonts.filter((r) => r.iconFont).length}/${fonts.length} stránkách${fonts.every((r) => r.iconFont) ? '' : ' (varování, sondu neshazuje)'}`);
process.exitCode = bad.length ? 1 : 0;
