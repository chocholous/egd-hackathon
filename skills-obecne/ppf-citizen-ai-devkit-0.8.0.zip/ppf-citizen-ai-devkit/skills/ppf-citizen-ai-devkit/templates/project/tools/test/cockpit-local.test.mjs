// npm test — místní cockpit (lib/cockpit-local.mjs): JSON soubory místo databáze artefaktu a server, který stránce
// dovolí zapsat jen rozhodnutí a nové zadání. Server poslouchá na 127.0.0.1 na portu od systému; bez sítě ven.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { basename, join } from 'node:path';
import { LOCAL_URL, isLocalCockpit, docFile, readDb, writeDoc, pageWrite, startCockpitServer } from '../lib/cockpit-local.mjs';

const novyKoren = () => mkdtempSync(join(tmpdir(), 'cockpit-local-'));

test('místní cockpit se pozná z project_config.json → cockpit.url', () => {
  assert.equal(isLocalCockpit({ cockpit: { url: LOCAL_URL } }), true);
  assert.equal(isLocalCockpit({ cockpit: { url: 'https://claude.ai/artifact/x' } }), false);
  assert.equal(isLocalCockpit({}), false);
});

test('dokument = soubor; dvojtečka v id se do jména souboru zakóduje (Windows ji ve jménu nedovolí)', () => {
  const root = novyKoren();
  writeDoc(root, 'rozhodnuti', 'otazka:o1', { vysledek: 'zvoleno', moznost: 'web', kolo: 1 });
  writeDoc(root, 'otazky', 'o1', { nazev: 'Konflikt', kolo: 1 });
  assert.equal(basename(docFile(root, 'rozhodnuti', 'otazka:o1')), 'otazka%3Ao1.json');
  const { db, vadne } = readDb(root);
  assert.deepEqual(db.rozhodnuti, { 'otazka:o1': { vysledek: 'zvoleno', moznost: 'web', kolo: 1 } });
  assert.deepEqual(db.otazky, { o1: { nazev: 'Konflikt', kolo: 1 } });
  assert.deepEqual(db.ukoly, {});
  assert.deepEqual(vadne, []);
  assert.throws(() => writeDoc(root, 'jina', 'x', {}), /neplatný dokument/);
  assert.throws(() => writeDoc(root, 'otazky', '../x', {}), /neplatný dokument/);
});

test('nečitelný soubor databázi neshodí: přeskočí se a je vypsaný', () => {
  const root = novyKoren();
  writeDoc(root, 'otazky', 'o1', { nazev: 'A' });
  writeFileSync(join(root, '.devkit', 'cockpit', 'db', 'otazky', 'rozbity.json'), '{');
  const { db, vadne } = readDb(root);
  assert.deepEqual(Object.keys(db.otazky), ['o1']);
  assert.deepEqual(vadne, ['otazky/rozbity.json']);
});

test('stránka smí zapsat jen rozhodnutí a nové zadání', () => {
  assert.deepEqual(pageWrite('PUT', ['db', 'rozhodnuti', 'otazka:o1']), { kolekce: 'rozhodnuti', id: 'otazka:o1' });
  assert.deepEqual(pageWrite('POST', ['db', 'zadani']), { kolekce: 'zadani', id: null });
  for (const [m, c] of [['PUT', ['db', 'otazky', 'o1']], ['PUT', ['db', 'ukoly', 'p-dev-1']], ['PUT', ['db', 'zadani', 'z1']], ['POST', ['db', 'rozhodnuti']], ['DELETE', ['db', 'rozhodnuti', 'x']], ['PUT', ['db', 'rozhodnuti', '..']]]) {
    assert.equal(pageWrite(m, c), null, `${m} /${c.join('/')}`);
  }
});

test('server: vydá stránku a data, přijme rozhodnutí z vlastní stránky, odmítne zápis odjinud', async () => {
  const root = novyKoren();
  mkdirSync(join(root, '.devkit'), { recursive: true });
  const html = join(root, '.devkit', 'cockpit.html');
  writeFileSync(html, '<title>Cockpit appky</title><p>obsah</p>');
  writeDoc(root, 'otazky', 'o1', { nazev: 'Konflikt', kolo: 1 });
  const { url, server } = await startCockpitServer({ root, html });
  try {
    const origin = url.slice(0, -1);
    const stranka = await (await fetch(url)).text();
    assert.match(stranka, /^<!doctype html>/);
    assert.match(stranka, /<p>obsah<\/p>/);
    assert.deepEqual((await (await fetch(`${url}db`)).json()).otazky, { o1: { nazev: 'Konflikt', kolo: 1 } });

    const json = { 'content-type': 'application/json', origin };
    const put = (cesta, headers, telo = { vysledek: 'zvoleno', moznost: 'web', kolo: 1 }) => fetch(`${url}${cesta}`, { method: 'PUT', headers, body: JSON.stringify(telo) });
    assert.equal((await put('db/rozhodnuti/otazka%3Ao1', json)).status, 200);
    assert.equal(JSON.parse(readFileSync(docFile(root, 'rozhodnuti', 'otazka:o1'), 'utf8')).moznost, 'web');

    assert.equal((await put('db/otazky/o1', json)).status, 403, 'otázky zapisuje agent, ne stránka');
    assert.equal((await put('db/rozhodnuti/otazka%3Ao2', { 'content-type': 'application/json', origin: 'https://cizi.example' })).status, 403, 'cizí Origin');
    assert.equal((await put('db/rozhodnuti/otazka%3Ao2', { 'content-type': 'text/plain', origin })).status, 403, 'jen JSON');
    assert.equal(existsSync(docFile(root, 'rozhodnuti', 'otazka:o2')), false);
    assert.equal((await fetch(`${url}db/rozhodnuti/x`, { method: 'PUT', headers: json, body: '[1]' })).status, 400, 'tělo musí být objekt');

    const nove = await fetch(`${url}db/zadani`, { method: 'POST', headers: json, body: JSON.stringify({ faze: 'nove', verbatim: 'evidence' }) });
    assert.equal(nove.status, 200);
    const { id } = await nove.json();
    assert.equal(readDb(root).db.zadani[id].verbatim, 'evidence');
    assert.equal((await fetch(`${url}soubory/neni.png`)).status, 404);
    assert.equal((await fetch(`${url}jinam`)).status, 404);
  } finally { server.close(); }
});
