// npm test — výchozí sada (class initial): kontrola manifestu a plan/initial.mjs nad JSON stavem webu, bez sítě.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildModel, validateManifest } from '../lib/manifest.mjs';
import { planInitial } from '../lib/plan/initial.mjs';
import { readState } from '../lib/state.mjs';
import { runAction } from '../lib/run.mjs';

const RAW = {
  roles: { owner: {}, editor: {}, user: {} },
  levels: { read: { builtin: 'Read' }, edit: { builtin: 'Contribute' } },
  lists: {
    Skupiny: { class: 'config', key: 'Kod', fields: [{ name: 'Kod', type: 'text', required: true, unique: true }], access: { user: 'read', editor: 'read' } },
    Druhy: { class: 'initial', key: 'Kod', fields: [
      { name: 'Kod', type: 'text', required: true, unique: true },
      { name: 'Popis', type: 'text' },
      { name: 'Skupina', type: 'lookup', list: 'Skupiny' },
    ], access: { user: 'read', editor: 'edit' } },
  },
  libraries: { Assets: { class: 'config', source: 'sp/assets/config', access: { user: 'read', editor: 'read' } } },
};
const CONFIG = { Skupiny: [{ Title: 'Technika', Kod: 'T' }] };
const DATA = { Druhy: [
  { Title: 'Firewall', Kod: 'FW', Popis: 'síť', Skupina: '@key:Skupiny/T' },
  { Title: 'Hardware', Kod: 'HW' },
  { Title: 'Software', Kod: 'SW' },
] };
const model = buildModel(RAW, 'CADK');
const state = ({ keys, count = keys?.length ?? 0, record = null } = {}) => ({
  site: 'https://t.sharepoint.com/sites/x', web: { path: '/sites/x' }, record,
  lists: { Skupiny: { items: [] }, Assets: { files: [] }, Druhy: keys === undefined ? null : { ItemCount: count, keys, fields: { Kod: {}, Popis: {}, Skupina: {} } } },
});
const plan = (s) => planInitial(model, s, { initialData: DATA });
const descs = (p) => p.actions.map((a) => a.desc);

test('manifest: class initial projde; chce key (required+unique), list a konfigurační knihovnu; data se kontrolují jako konfigurace', () => {
  assert.deepEqual(validateManifest(RAW, { prefix: 'CADK', configData: CONFIG, initialData: DATA }).errors, []);
  const bezKlice = structuredClone(RAW); delete bezKlice.lists.Druhy.key;
  assert.match(validateManifest(bezKlice, { prefix: 'CADK' }).errors.join('\n'), /Druhy: list s výchozí sadou \(class initial\) musí mít "key"/);
  const bezKnihovny = structuredClone(RAW); delete bezKnihovny.libraries;
  assert.match(validateManifest(bezKnihovny, { prefix: 'CADK' }).errors.join('\n'), /class initial potřebuje v manifestu konfigurační knihovnu/);
  const knihovna = structuredClone(RAW); knihovna.libraries.Vychozi = { class: 'initial', access: 'inherit' };
  assert.match(validateManifest(knihovna, { prefix: 'CADK' }).errors.join('\n'), /Vychozi: class initial je jen pro list/);
  assert.match(validateManifest({ ...RAW, lists: { X: { class: 'seed', access: 'inherit' } } }, { prefix: 'CADK' }).errors.join('\n'), /class musí být config\|initial\|operational/);
  const dup = validateManifest(RAW, { prefix: 'CADK', configData: CONFIG, initialData: { Druhy: [{ Kod: 'FW' }, { Kod: 'FW' }, { Kod: '' }] } }).errors.join('\n');
  assert.match(dup, /data Druhy: duplicitní klíč FW/);
  assert.match(dup, /data Druhy\[2\]: prázdný klíč Kod/);
  // lookup výchozího řádku smí mířit jen na konfigurační list s daty v gitu
  assert.match(validateManifest(RAW, { prefix: 'CADK', configData: {}, initialData: DATA }).errors.join('\n'), /Skupiny není konfigurační list s daty v gitu/);
});

test('první nasazení: list ještě není nebo je prázdný → vloží celou výchozí sadu a zapíše klíče do záznamu', () => {
  for (const s of [state(), state({ keys: [] })]) {
    const p = plan(s);
    assert.deepEqual(descs(p), ['CADK-Druhy: vložit výchozí FW', 'CADK-Druhy: vložit výchozí HW', 'CADK-Druhy: vložit výchozí SW']);
    assert.ok(p.actions.every((a) => a.area === 'konfigurace' && a.rest.method === 'post' && !a.rest.merge));
    assert.equal(p.actions[0].rest.path, "web/GetList('%2Fsites%2Fx%2FLists%2FCADKDruhy')/items");
    assert.deepEqual(p.actions[0].rest.body, { Title: 'Firewall', Kod: 'FW', Popis: 'síť', SkupinaId: { $key: { list: '/sites/x/Lists/CADKSkupiny', field: 'Kod', value: 'T' } } });
    assert.deepEqual(p.newRecord, { initial: { Druhy: ['FW', 'HW', 'SW'] } });
    assert.deepEqual(p.poznamky, []);
    assert.deepEqual(p.findings, []);
  }
});

test('po nasazení: existující řádek se neupraví, smazaný byznysem se nevrátí, řádek byznysu zůstane, nový klíč z gitu se vloží', () => {
  // FW na webu je (obsah se neporovnává), HW byznys smazal, XX byznys přidal, SW je v gitu nový
  const p = plan(state({ keys: ['FW', 'XX'], record: { initial: { Druhy: ['FW', 'HW'] } } }));
  assert.deepEqual(descs(p), ['CADK-Druhy: vložit výchozí SW']);
  assert.deepEqual(p.newRecord.initial.Druhy, ['FW', 'HW', 'SW']);
  // všechno vyřízeno → prázdný plán; klíč odebraný z gitu v záznamu zůstane a na webu se nic nemaže
  const hotovo = planInitial(model, state({ keys: ['FW', 'XX', 'SW'], record: { initial: { Druhy: ['FW', 'HW', 'SW', 'STARY'] } } }), { initialData: DATA });
  assert.deepEqual(hotovo.actions, []);
  assert.deepEqual(hotovo.newRecord.initial.Druhy, ['FW', 'HW', 'STARY', 'SW']);
  // byznys smazal všechno: nic se nevrátí
  assert.deepEqual(plan(state({ keys: [], record: { initial: { Druhy: ['FW', 'HW', 'SW'] } } })).actions, []);
});

test('list už má řádky a záznam o něm neví: nevloží nic, chybějící klíče vypíše, naplánuje převzetí bez zápisu na web', () => {
  for (const record of [null, { items: {}, assets: {} }]) {
    const p = plan(state({ keys: ['FW', 'XX'], record }));
    assert.equal(p.actions.length, 1);
    assert.equal(p.actions[0].noop, true);
    assert.equal(p.actions[0].rest, undefined);
    assert.match(p.actions[0].desc, /CADK-Druhy: převzít list s výchozí sadou bez vkládání \(list už má 2 řádky/);
    assert.match(p.poznamky.join('\n'), /klíče, které na webu nejsou \(HW, SW\)/);
    assert.deepEqual(p.newRecord.initial.Druhy, ['FW', 'HW', 'SW']);
  }
  // po převzetí (záznam zapsán) je plán prázdný a klíč přidaný do gitu později se vloží
  const record = { initial: { Druhy: ['FW', 'HW', 'SW'] } };
  assert.deepEqual(plan(state({ keys: ['FW', 'XX'], record })).actions, []);
  const novy = planInitial(model, state({ keys: ['FW', 'XX'], record }), { initialData: { Druhy: [...DATA.Druhy, { Title: 'Cloud', Kod: 'CL' }] } });
  assert.deepEqual(descs(novy), ['CADK-Druhy: vložit výchozí CL']);
  // list má řádky, ale klíčový sloupec na webu ještě není (klíče nejdou přečíst): pořád jen převzetí
  assert.equal(plan(state({ keys: [], count: 4 })).actions[0].noop, true);
});

test('appka bez listu class initial: plán nic nepřidá ani do záznamu', () => {
  const m = buildModel({ ...RAW, lists: { Skupiny: RAW.lists.Skupiny } }, 'CADK');
  assert.deepEqual(planInitial(m, state(), { initialData: {} }), { actions: [], findings: [], poznamky: [], newRecord: {} });
});

test('run: akce noop na web nic nepošle', () => {
  const zavolano = [];
  const spy = (...a) => { zavolano.push(a); return { status: 0 }; };
  assert.equal(runAction({ area: 'konfigurace', noop: true, desc: 'převzít' }, { site: 'https://t', api: { get: spy }, m365: spy, rest: spy }), null);
  assert.deepEqual(zavolano, []);
});

test('state: u listu class initial čte jen klíčový sloupec', () => {
  const dotazy = [];
  const api = {
    site: 'https://t.sharepoint.com/sites/x',
    get: () => ({ Title: 'x' }),
    getAll: (path) => {
      dotazy.push(path);
      if (path.startsWith('web/lists?')) return model.containers.map((c, i) => ({ Id: `id-${i}`, Title: c.title, ItemCount: 2, Hidden: false, HasUniqueRoleAssignments: false, RootFolder: { ServerRelativeUrl: `/sites/x/${c.url}` } }));
      if (path.includes('/fields?')) return path.includes('CADKDruhy') ? [{ InternalName: 'Kod', TypeAsString: 'Text' }] : [];
      if (path.includes('CADKDruhy') && path.includes('/items?')) return [{ Id: 1, Kod: 'FW' }, { Id: 2, Kod: 'HW' }];
      return [];
    },
    file: () => null,
  };
  const s = readState({ model, api, envRoles: {}, groupOf: (r) => r, recordPath: '_deploy/dev.json' });
  assert.deepEqual(s.lists.Druhy.keys, ['FW', 'HW']);
  assert.equal(s.lists.Druhy.ItemCount, 2);
  const naDruhy = dotazy.filter((d) => d.includes('CADKDruhy') && d.includes('/items?'));
  assert.deepEqual(naDruhy, ["web/GetList('%2Fsites%2Fx%2FLists%2FCADKDruhy')/items?$select=Id,Kod"]);
});
