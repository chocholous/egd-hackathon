// npm run lockfix [-- --check]   (spouští se samo jako postinstall)
// Vyhodí z package-lock.json položky "extraneous", které tam npm zanese ze shrinkwrapu m365 CLI
// a kvůli kterým padá `npm ci` na EBADPLATFORM — proč viz tools/lib/lockfile.mjs.
// --check: nic nepíše, exit 1, když lockfile čištění potřebuje (pro prereq a CI).
// Bez lockfile (npm install --no-package-lock) nic nedělá.
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { ROOT } from './lib/config.mjs';
import { stripExtraneous } from './lib/lockfile.mjs';

const file = join(ROOT, 'package-lock.json');
if (!existsSync(file)) process.exit(0);
const text = readFileSync(file, 'utf8');
const { lock, removed } = stripExtraneous(JSON.parse(text));
if (!removed.length) process.exit(0);
if (process.argv.includes('--check')) {
  console.error(`package-lock.json má ${removed.length} položek "extraneous" (npm ci na nich padá) — npm run lockfix`);
  process.exit(1);
}
writeFileSync(file, JSON.stringify(lock, null, 2) + (text.endsWith('\n') ? '\n' : ''));
console.log(`lockfix: z package-lock.json vyhozeno ${removed.length} položek "extraneous" (shrinkwrap m365 CLI)`);
