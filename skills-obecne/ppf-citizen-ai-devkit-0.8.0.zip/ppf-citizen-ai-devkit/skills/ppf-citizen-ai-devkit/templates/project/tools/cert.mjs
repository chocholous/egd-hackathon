// npm run cert — připraví vývojový certifikát pro `heft start` přes https (viz tools/lib/devcert.mjs).
// Výchozí ladicí server běží přes http a certifikát nepotřebuje; tohle je jen pro "https": true v serve.json.
// Nikdy nespouští sudo. Na macOS vypíše jeden příkaz pro správce; po něm `npm run prereq` ukáže OK.
// `heft trust-dev-cert` nepoužívej: certifikát přegeneruje a důvěra se ztratí.
import { platform } from 'node:os';
import { certStatus, generateCert, adminCommand } from './lib/devcert.mjs';

let s = certStatus();
if (!s.exists) { await generateCert(); s = certStatus(); }
if (s.trusted === false) {
  console.log(`Certifikát existuje (SHA1 ${s.sha1}), ale systém mu nevěří. Spusť jako správce (v Terminálu, ne přes agenta):\n\n  ${adminCommand()}\n`);
  console.log('Bez práv správce: požádej IT o přidání této autority, nebo spusť přes účet správce: su <admin> -c \'<příkaz výše>\'');
  process.exitCode = 1;
} else {
  console.log(`Certifikát je připravený${s.trusted === null ? ` (důvěru na ${platform()} řeší heft sám)` : ' a důvěryhodný'}.`);
}
