// npm run feedback -- --env dev|test [--all] [--json]
//
// Přečte připomínky testerů (list Pripominky, fáze P6) z webu prostředí a vypíše je jako markdown
// pro vývojáře a agenta (výchozí jen otevřená vlákna, --all i vyřešená; --json = strojový výstup).
// Jen čte (REST GET přes m365 request). Logika vláken, čtení a výpisu je v lib/feedback.mjs.
// Exit: 0 OK (i když manifest připomínky nemá — není co číst), 1 list na webu chybí nebo čtení selhalo
// (připomínky jsou zapnuté, ale kit ještě nenasadil list — to je stav k řešení: npm run deploy), 2 použití.
import { assertTenant } from './lib/m365.mjs';
import { loadProject } from './lib/project.mjs';
import { FEEDBACK_KEY, threads, readFeedbackItems, formatMarkdown, toJson } from './lib/feedback.mjs';

const argv = process.argv.slice(2);
const opt = (n) => (argv.includes(n) ? argv[argv.indexOf(n) + 1] : undefined);
const flag = (n) => argv.includes(n);
const USAGE = 'použití: npm run feedback -- --env dev|test [--all] [--json]\n  výchozí: jen otevřená vlákna; --all i vyřešená; --json strojový výstup';
if (flag('--help') || flag('-h')) { console.log(USAGE); process.exit(0); }
const ENV = opt('--env');
if (!ENV || ENV.startsWith('--')) { console.error(USAGE); process.exit(2); }

let P;
try { P = loadProject(ENV); } catch (e) { console.error(e.message); process.exit(1); }
if (!P.model.byKey[FEEDBACK_KEY]) {
  console.log(`Manifest (sp/app.manifest.json) nemá "feedback": true — appka nemá vrstvu připomínek, není co číst.`);
  process.exit(0);
}
assertTenant(P.cfg.m365.tenantId);

let items;
try { items = readFeedbackItems(P); } catch (e) { console.error(e.message); process.exit(1); }

const ths = threads(items);
const opts = { all: flag('--all'), env: ENV };
console.log(flag('--json') ? JSON.stringify(toJson(ths, opts), null, 2) : formatMarkdown(ths, opts));
