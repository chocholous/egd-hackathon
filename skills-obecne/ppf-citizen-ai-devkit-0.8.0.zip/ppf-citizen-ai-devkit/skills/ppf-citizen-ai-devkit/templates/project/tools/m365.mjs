// Průchozí spuštění lokálního m365 CLI s izolovaným přihlášením (npm run m365 -- <args>).
// Přihlášení: npm run m365 -- login --authType browser --appId <m365.appId> --tenant <m365.tenantId>
import { m365 } from './lib/m365.mjs';
const r = m365(process.argv.slice(2), { inherit: true });
process.exitCode = r.status ?? 1;
