// npm test — lockfile.mjs: vyhození "extraneous" ze shrinkwrapu m365 CLI (bez sítě).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { stripExtraneous } from '../lib/lockfile.mjs';

const CLI = 'node_modules/@pnp/cli-microsoft365';
const lock = () => ({
  lockfileVersion: 3,
  packages: {
    '': { devDependencies: { '@pnp/cli-microsoft365': '12.0.0' } },
    [CLI]: { version: '12.0.0', hasShrinkwrap: true },
    [`${CLI}/node_modules/retry`]: { version: '0.12.0' },
    [`${CLI}/node_modules/typescript-native`]: { version: '7.0.2', extraneous: true },
    [`${CLI}/node_modules/@typescript/typescript-aix-ppc64`]: { version: '7.0.2', os: ['aix'], cpu: ['ppc64'], extraneous: true },
  },
});

test('stripExtraneous: vyhodí jen extraneous, ostatní nechá beze změny', () => {
  const { lock: out, removed } = stripExtraneous(lock());
  assert.deepEqual(removed.sort(), [`${CLI}/node_modules/@typescript/typescript-aix-ppc64`, `${CLI}/node_modules/typescript-native`]);
  assert.deepEqual(Object.keys(out.packages), ['', CLI, `${CLI}/node_modules/retry`]);
  assert.equal(out.lockfileVersion, 3);
});

test('stripExtraneous: čistý lockfile = tentýž objekt; bez packages = výjimka', () => {
  const clean = stripExtraneous(lock()).lock;
  const again = stripExtraneous(clean);
  assert.equal(again.lock, clean);
  assert.deepEqual(again.removed, []);
  assert.throws(() => stripExtraneous({ lockfileVersion: 1, dependencies: {} }), /lockfileVersion/);
});
