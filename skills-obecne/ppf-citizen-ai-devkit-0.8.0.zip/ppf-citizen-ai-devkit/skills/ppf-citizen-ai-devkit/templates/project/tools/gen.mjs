// Vygeneruje spfx/src/app/generated/appManifest.ts z sp/app.manifest.json + prefixu z project_config.json
// a generated/localProps.ts: vlastnosti web partů pro lokální harness (první instance každého web partu ze
// stránek manifestu, @env: z environments.local.values). localProps importuje jen harness, do bundlu nejde.
// A generated/mockData.ts: data mocku ze sp/data/config, sp/data/initial a sp/data/seed (lib/mockgen.mjs), také jen pro harness.
// Spouští se před buildem appky i harnessu (npm run gen). Soubor je generovaný — needitovat.
// Zapisuje jen soubor, jehož obsah se změnil (lib/otisk.mjs zapisKdyzJiny): opakovaný běh nic nepřepíše.
// Titul a URL každého listu/knihovny počítá tools/lib/manifest.mjs (buildModel) — appka je
// sama neodvozuje, takže web, plán i appka používají tutéž URL.
import { existsSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { ROOT, loadConfig, loadManifest } from './lib/config.mjs';
import { buildModel, validateManifest, resolveProps } from './lib/manifest.mjs';
import { readPackage } from './lib/spfx-package.mjs';
import { withFeedback, feedbackProps, FEEDBACK_KEY } from './lib/feedback.mjs';
import { levelRights, mockDataSource } from './lib/mockgen.mjs';
import { zapisKdyzJiny } from './lib/otisk.mjs';
import { stavNaKonci } from './lib/stav.mjs';

// Závěrečné řádky (lib/stav.mjs): po chybě vždy; po úspěchu jen při samostatném `npm run gen` — uvnitř build
// a typecheck by řádky uprostřed výstupu mátly (npm_lifecycle_event je jméno spuštěného skriptu).
const SAMOSTATNE = (process.env.npm_lifecycle_event || 'gen') === 'gen';
stavNaKonci((kod) => (kod !== 0 ? 'oprav chyby výše (sp/app.manifest.json, project_config.json) a spusť znovu npm run gen'
  : SAMOSTATNE ? 'npm run dev (lokální náhled); před commitem npm run check-all' : false));

const raw = withFeedback(loadManifest());
const cfg = loadConfig();
const prefix = cfg.app.prefix;
const pkg = readPackage(join(ROOT, 'spfx'));
const { errors, warnings } = validateManifest(raw, { prefix, webparts: pkg.webparts });
for (const w of [...warnings, ...pkg.warnings]) console.warn(`pozor: ${w}`);
if (errors.length) { console.error('manifest neprošel kontrolou:\n- ' + errors.join('\n- ')); process.exit(1); }
const model = buildModel(raw, prefix, { webparts: pkg.webparts });
const withSp = (group) => Object.fromEntries(Object.entries(raw[group] || {}).map(([k, d]) => [k, { ...d, title: model.byKey[k].title, url: model.byKey[k].url }]));
const out = { prefix, roles: raw.roles, levels: levelRights(raw.levels), lists: withSp('lists'), libraries: withSp('libraries') };
// MockSource počítá práva z úrovní (levels → rights); úroveň připomínek je Contribute = edit
if (out.lists[FEEDBACK_KEY]) out.lists[FEEDBACK_KEY].access = Object.fromEntries(Object.keys(out.lists[FEEDBACK_KEY].access).map((r) => [r, 'edit']));
const dir = join(ROOT, 'spfx', 'src', 'app', 'generated');
mkdirSync(dir, { recursive: true });
const zmeneno = [];
const zapis = (jmeno, text) => { if (zapisKdyzJiny(join(dir, jmeno), text)) zmeneno.push(jmeno); };
zapis('appManifest.ts',
  `// GENEROVÁNO tools/gen.mjs z sp/app.manifest.json — needitovat ručně\nimport { AppManifest } from '../manifest';\n\nexport const appManifest: AppManifest = ${JSON.stringify(out, null, 2)} as AppManifest;\n`);
const localProps = {};
try {
  for (const w of model.pages.flatMap((p) => p.webparts)) {
    localProps[w.alias] ??= resolveProps(w.properties, { values: cfg.environments?.local?.values, envName: 'local' });
    if (raw.feedback === true) localProps[w.alias].pripominky = feedbackProps({ envName: 'local', version: pkg.solution.version });
  }
} catch (e) { console.error(e.message); process.exit(1); }
zapis('localProps.ts',
  `// GENEROVÁNO tools/gen.mjs ze stránek v sp/app.manifest.json pro prostředí local — needitovat ručně\nexport const localProps: Record<string, Record<string, unknown>> = ${JSON.stringify(localProps, null, 2)};\n`);
zapis('mockData.ts', mockDataSource(Object.keys(raw.lists || {}), (druh, key) => existsSync(join(ROOT, 'sp', 'data', druh, `${key}.json`))));
console.log(zmeneno.length ? `spfx/src/app/generated: změněno ${zmeneno.join(', ')}` : 'spfx/src/app/generated: beze změny');
