// npm test — připomínky (P6): schéma listu z kódu kitu (lib/feedback.mjs) a čisté funkce vrstvy
// (spfx/src/feedback/model.ts: kotvy a vlákna). model.ts se přeloží esbuildem ze spfx/node_modules jako
// v spsource.test.mjs; bez `npm --prefix spfx install` test selže s návodem.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { ROOT } from '../lib/config.mjs';
import { withFeedback, feedbackProps, FEEDBACK_KEY, FEEDBACK_LEVEL, threads as jsThreads, normalizeItem, itemsQuery, summarize, formatMarkdown, toJson } from '../lib/feedback.mjs';
import { buildModel, validateManifest } from '../lib/manifest.mjs';

const SPFX = join(ROOT, 'spfx');
async function load() {
  if (!existsSync(join(SPFX, 'node_modules', 'esbuild'))) throw new Error('chybí spfx/node_modules/esbuild — npm --prefix spfx install');
  const esbuild = createRequire(join(SPFX, 'package.json'))('esbuild');
  const out = await esbuild.build({ entryPoints: [join(SPFX, 'src', 'feedback', 'model.ts')], bundle: true, format: 'esm', platform: 'neutral', write: false, logLevel: 'silent' });
  return import(`data:text/javascript;base64,${Buffer.from(out.outputFiles[0].text).toString('base64')}`);
}
const { pick, threads } = await load();

const RAW = { roles: { owner: {}, editor: {}, user: {} }, levels: { read: { builtin: 'Read' } }, lists: {}, libraries: {}, feedback: true };

test('feedback: list připomínek z kódu kitu, všechny role kromě owner Contribute, own-write', () => {
  const raw = withFeedback(RAW);
  assert.deepEqual(raw.lists[FEEDBACK_KEY].access, { editor: FEEDBACK_LEVEL, user: FEEDBACK_LEVEL });
  assert.equal(raw.levels[FEEDBACK_LEVEL].builtin, 'Contribute');
  assert.deepEqual(validateManifest(raw, { prefix: 'CADK' }).errors, []);
  const c = buildModel(raw, 'CADK').byKey[FEEDBACK_KEY];
  assert.equal(c.url, 'Lists/CADKPripominky');
  assert.equal(c.title, 'CADK-Pripominky'); // titul s prefixem: titul listu je na webu unikátní, víc appek na jednom DEV webu
  assert.deepEqual(c.security, [1, 2]); // vidí vše, upravuje svoje
  assert.ok(['Text', 'Kotva', 'KotvaKlic', 'Stav', 'NadrazenaId', 'Zdroj'].every((f) => c.fields.some((x) => x.name === f)));
});

test('feedback: bez "feedback": true se manifest nemění; kolize s vlastním listem = chyba', () => {
  const off = { ...RAW, feedback: undefined };
  assert.equal(withFeedback(off), off);
  assert.throws(() => withFeedback({ ...RAW, lists: { [FEEDBACK_KEY]: {} } }), /zakládá kit/);
  assert.deepEqual(feedbackProps({ envName: 'dev', version: '1.0.0.2' }), { list: FEEDBACK_KEY, env: 'dev', verze: '1.0.0.2' });
});

const CANDS = [{ id: 'hlavicka' }, { id: 'hlaseni' }, { id: 'hlaseni', key: '7' }, { id: 'hlaseni', key: '9' }];

test('kotva: id+klíč přesně, při přidaném řádku a jiném řazení stále stejný řádek', () => {
  assert.deepEqual(pick(CANDS, { id: 'hlaseni', key: '9' }), { index: 3, exact: true });
  const after = [{ id: 'hlaseni', key: '12' }, { id: 'hlaseni', key: '9' }, { id: 'hlaseni' }, { id: 'hlavicka' }, { id: 'hlaseni', key: '7' }];
  assert.deepEqual(pick(after, { id: 'hlaseni', key: '9' }), { index: 1, exact: true });
});

test('kotva: zmizelý řádek → kontejner (ne přesně); neznámé id → nepřipnutá', () => {
  assert.deepEqual(pick(CANDS, { id: 'hlaseni', key: '5' }), { index: 1, exact: false });
  assert.deepEqual(pick(CANDS, { id: 'hlavicka' }), { index: 0, exact: true });
  assert.equal(pick(CANDS, { id: 'smazany-prvek' }), undefined);
  assert.equal(pick(CANDS, { id: '' }), undefined);
});

test('vlákna: odpovědi podle NadrazenaId, stav = poslední Stav ve vlákně (vyřešit = odpověď)', () => {
  const t = threads([
    { Id: 1, Title: 'a', Text: 'a', Stav: 'Otevřeno' },
    { Id: 2, Title: 'b', Text: 'b', NadrazenaId: 1 },
    { Id: 3, Title: 'c', Text: 'c', Stav: 'Otevřeno' },
    { Id: 4, Title: 'x', Text: 'Vyřešeno.', NadrazenaId: 1, Stav: 'Vyřešeno' },
  ]);
  assert.equal(t.length, 2);
  assert.deepEqual(t[0].replies.map((r) => r.Id), [2, 4]);
  assert.equal(t[0].status, 'Vyřešeno');
  assert.equal(t[1].status, 'Otevřeno');
});

// ---------- čtení připomínek (npm run feedback): čisté funkce lib/feedback.mjs ----------
const ITEMS = [
  { Id: 1, Text: 'Tlačítko je špatně', Stav: 'Otevřeno', Stranka: 'Přehled', Verze: '1.0.0.2', Kotva: 'hlaseni', KotvaKlic: '7', KotvaText: 'Uložit\n změny', Created: '2026-11-10T09:30:15Z', Author: { Title: 'Jan Tester', EMail: 'jan@x.cz' } },
  { Id: 2, Text: 'Opraveno v 1.0.0.3', NadrazenaId: 1, Zdroj: 'agent', Created: '2026-11-10T10:00:00Z', Author: { Title: 'Agent', EMail: null } },
  { Id: 3, Text: 'Vyřešeno.', NadrazenaId: 1, Stav: 'Vyřešeno', Created: '2026-11-10T11:00:00Z', Author: { Title: 'Jan Tester', EMail: 'jan@x.cz' } },
  { Id: 4, Text: 'Chybí filtr', Stav: 'Otevřeno', Stranka: 'Přehled', Created: '2026-11-11T08:00:00Z', Author: { Title: 'Eva', EMail: 'eva@x.cz' } },
  { Id: 5, Text: 'Znovu otevřeno', NadrazenaId: 3 + 1, Stav: 'Vyřešeno', Created: '2026-11-11T09:00:00Z', Author: { Title: 'Eva', EMail: null } },
].map(normalizeItem);

test('feedback čtení: JS vlákna dávají stejný výsledek jako TS threads z model.ts', () => {
  const shapes = [
    ITEMS, [], [{ Id: 9, Text: 'x' }],
    [{ Id: 2, NadrazenaId: 1, Text: 'o', Stav: 'Vyřešeno' }, { Id: 1, Text: 'r', Stav: 'Otevřeno' }, { Id: 3, NadrazenaId: 1, Text: 'p', Stav: 'Otevřeno' }, { Id: 4, NadrazenaId: 1, Text: 'q' }], // neseřazené, znovuotevření
    [{ Id: 1, Text: 'a' }, { Id: 2, NadrazenaId: '1', Text: 'b' }], // NadrazenaId jako řetězec
  ];
  for (const items of shapes) assert.deepEqual(jsThreads(items), threads(items));
});

test('feedback čtení: stav vlákna, souhrn a filtr otevřených/--all', () => {
  const t = jsThreads(ITEMS);
  assert.deepEqual(t.map((x) => [x.root.Id, x.status]), [[1, 'Vyřešeno'], [4, 'Vyřešeno']]);
  assert.deepEqual(summarize(t), { open: 0, resolved: 2, total: 2 });
  const open = jsThreads([...ITEMS.slice(0, 3), ITEMS[3]]);
  assert.deepEqual(summarize(open), { open: 1, resolved: 1, total: 2 });
  assert.deepEqual(toJson(open, { env: 'dev' }).threads.map((x) => x.id), [4]);
  assert.deepEqual(toJson(open, { env: 'dev', all: true }).threads.map((x) => x.id), [1, 4]);
  assert.deepEqual(toJson(open, { env: 'dev' }).summary, { open: 1, resolved: 1, total: 2 });
});

test('feedback čtení: markdown — kotva, úryvek, autor, odsazené odpovědi, souhrn a návod', () => {
  const t = jsThreads(ITEMS.slice(0, 4));
  const md = formatMarkdown(t, { all: true, env: 'test' });
  assert.match(md, /^# Připomínky — test \(všechna vlákna\)/);
  assert.match(md, /## #1 \[Vyřešeno\] Přehled · verze 1\.0\.0\.2/);
  assert.match(md, /- kotva: `hlaseni` \(klíč řádku `7`\) — „Uložit změny“/);
  assert.match(md, /- autor: Jan Tester, 2026-11-10 09:30/);
  assert.doesNotMatch(md, /jan@x\.cz/, 'e-mail autora do textu pro agenta nepatří');
  assert.match(md, /^ {2}- \*\*Agent \[agent\]\*\*/m);
  assert.match(md, /^ {2}- \*\*Jan Tester\*\*.*\(→ Vyřešeno\)/m);
  assert.match(md, /## #4 \[Otevřeno\] Přehled\n- kotva: — \(nepřipnuto k prvku\)/);
  assert.match(md, /Souhrn: 1 otevřených, 1 vyřešených \(celkem 2 vláken\)\./);
  assert.ok(md.includes("rg 'data-cadk-id=\"<Kotva>\"' spfx/src"));
  const onlyOpen = formatMarkdown(t, { env: 'test' });
  assert.ok(!onlyOpen.includes('## #1') && onlyOpen.includes('## #4'));
  assert.match(formatMarkdown([], { env: 'dev' }), /Žádná otevřená vlákna/);
});

test('feedback čtení: dotaz na položky vybírá sloupce schématu, autora a stránkuje', () => {
  const q = itemsQuery({ pageSize: 123 });
  assert.match(q, /\$select=Id,Created,Text,.*Zdroj,Author\/Title,Author\/EMail/);
  assert.ok(q.includes('$expand=Author') && q.includes('$top=123'));
  assert.deepEqual(normalizeItem({ Id: 1, Author: { Title: 'A', EMail: 'a@x' } }), { Id: 1, Autor: 'A', AutorEmail: 'a@x' });
});
