// npm test — jména pluginu kitu (tools/lib/kit-plugin.mjs): prereq i doctor kitu uznají přechodně
// současné jméno ppf-citizen-ai-devkit i staré ppf-spfx-devkit. Bez sítě, bez přihlášení.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdirSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { KIT_PLUGIN_NAMES, copilotPlugins, findKitPlugin, findPlugin, installedPlugins, isKitPluginId, materialSkillDir } from '../lib/kit-plugin.mjs';

const TOOLS = join(dirname(fileURLToPath(import.meta.url)), '..');

test('seznam jmen: současné jméno první, staré přechodně druhé', () => {
  assert.deepEqual([...KIT_PLUGIN_NAMES], ['ppf-citizen-ai-devkit', 'ppf-spfx-devkit']);
  assert.ok(Object.isFrozen(KIT_PLUGIN_NAMES));
});

test('isKitPluginId: obě jména s marketplace i bez, nic jiného', () => {
  assert.equal(isKitPluginId('ppf-citizen-ai-devkit@ppf-skills'), true);
  assert.equal(isKitPluginId('ppf-spfx-devkit@inline'), true);
  assert.equal(isKitPluginId('ppf-citizen-ai-devkit'), true);
  assert.equal(isKitPluginId('ppf-sharepoint@ppf-skills'), false);
  assert.equal(isKitPluginId('ppf-spfx-devkit-fork@x'), false);   // jen přesná shoda jména, ne prefix
  assert.equal(isKitPluginId(undefined), false);
});

test('findKitPlugin: registr installed_plugins.json se starým, novým i oběma jmény', () => {
  const zaznam = (v) => [{ installPath: `/cache/${v}` }];
  const stary = { 'ppf-material@ppf-skills': zaznam('m'), 'ppf-spfx-devkit@local': zaznam('0.4.2') };
  const novy = { 'ppf-citizen-ai-devkit@local': zaznam('0.5.0') };
  const oba = { ...stary, ...novy };
  const najdi = (reg) => findKitPlugin(Object.entries(reg), ([k]) => k)?.[1]?.[0]?.installPath;
  assert.equal(najdi(stary), '/cache/0.4.2');
  assert.equal(najdi(novy), '/cache/0.5.0');
  assert.equal(najdi(oba), '/cache/0.5.0', 'jsou-li obě, vyhraje současné jméno');
  assert.equal(najdi({ 'ppf-material@ppf-skills': zaznam('m') }), undefined);
  assert.equal(findKitPlugin(undefined), undefined);
});

test('findKitPlugin: výpis claude plugin list --json (pole objektů s id)', () => {
  const list = [{ id: 'ppf-material@ppf-skills' }, { id: 'ppf-spfx-devkit@ppf-skills', version: '0.4.2' }];
  assert.equal(findKitPlugin(list, (p) => p.id)?.version, '0.4.2');
});

test('prereq.mjs nemá vlastní literál jména pluginu: bere ho jen z lib/kit-plugin.mjs', () => {
  const src = readFileSync(join(TOOLS, 'prereq.mjs'), 'utf8').split('\n').filter((l) => !/^\s*\/\//.test(l)).join('\n');
  assert.match(src, /from '\.\/lib\/kit-plugin\.mjs'/);
  for (const jmeno of KIT_PLUGIN_NAMES) assert.equal(src.includes(`'${jmeno}`), false, `prereq.mjs obsahuje literál ${jmeno}`);
});

test('pluginy GitHub Copilot CLI: čtou se ze složky installed-plugins a řadí se za pluginy Claude Code', () => {
  const home = mkdtempSync(join(tmpdir(), 'kit-copilot-'));
  const plugin = (jmeno, verze) => {
    const d = join(home, 'installed-plugins', 'ppf-skills', jmeno);
    mkdirSync(join(d, '.claude-plugin'), { recursive: true });
    writeFileSync(join(d, '.claude-plugin', 'plugin.json'), JSON.stringify({ name: jmeno, version: verze }));
    return d;
  };
  plugin('ppf-citizen-ai-devkit', '0.7.1');
  const material = plugin('ppf-material', '1.1.0');
  mkdirSync(join(material, 'skills', 'ppf-material', 'tokens'), { recursive: true });
  writeFileSync(join(material, 'skills', 'ppf-material', 'tokens', 'tokens.json'), '{}');
  const env = { COPILOT_HOME: home, CLAUDE_CONFIG_DIR: join(home, 'zadny-claude') };

  const list = copilotPlugins({ env });
  assert.deepEqual(list.map((p) => [p.id, p.version, p.scope]).sort(), [['ppf-citizen-ai-devkit@ppf-skills', '0.7.1', 'copilot'], ['ppf-material@ppf-skills', '1.1.0', 'copilot']]);
  assert.deepEqual(copilotPlugins({ env: { COPILOT_HOME: join(home, 'neni') } }), []);

  // Claude Code nic nemá (CLI selže, registr chybí): seznam je z Copilotu a ppf-material se najde
  const bezClaude = installedPlugins({ env, run: () => ({ error: new Error('ENOENT') }) });
  assert.equal(bezClaude.zdroj, 'copilot');
  assert.equal(findKitPlugin(bezClaude.list, (p) => p.id)?.version, '0.7.1');
  assert.equal(materialSkillDir({ plugins: bezClaude }), join(material, 'skills', 'ppf-material'));

  // plugin v Claude Code i v Copilotu: vyhraje ten z Claude Code
  const oba = installedPlugins({ env, run: () => ({ status: 0, stdout: JSON.stringify([{ id: 'ppf-material@ppf-skills', version: '1.0.0', scope: 'user', installPath: '/x' }]) }) });
  assert.equal(oba.zdroj, 'claude');
  assert.equal(findPlugin(oba.list, 'ppf-material').scope, 'user');
});
