// npm test — testy pomocných modulů v tools/lib (node:test, bez sítě, bez m365 přihlášení).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { writeFileSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

// Falešné m365: tabulka zaznamenaných odpovědí, viz hlavička tools/lib/m365.mjs.
function withFake(table) {
  const f = join(mkdtempSync(join(tmpdir(), 'm365fake-')), 'fake.json');
  writeFileSync(f, JSON.stringify(table));
  process.env.M365_FAKE = f;
}

test('m365 fake: zaznamenané volání vrátí JSON, nezaznamenané vyhodí výjimku', async () => {
  withFake({ 'status --output json': { out: '{"connectedAs":"a@b.cz","appTenant":"t"}' } });
  const { m365, status } = await import('../lib/m365.mjs');
  assert.equal(status().connectedAs, 'a@b.cz');
  assert.throws(() => m365(['spo', 'web', 'get']), /nezaznamenané volání/);
});

test('dev-server-http: http přepne server, manifest přepíše na http; https nechá být', async () => {
  const { createRequire } = await import('node:module');
  const { devServerHttp } = createRequire(import.meta.url)('../../spfx/config/webpack-patch/dev-server-http.js');
  const dir = mkdtempSync(join(tmpdir(), 'devsrv-'));
  const manifestsFile = join(dir, 'manifests.js');
  writeFileSync(manifestsFile, '{"internalModuleBaseUrls":["https://localhost:4321/dist/"]}');
  const mk = () => ({ devServer: { client: { webSocketURL: { protocol: 'wss' } }, setupMiddlewares: (m) => m } });

  assert.equal(devServerHttp(mk(), { https: true, manifestsFile }).devServer.server, undefined);

  const ds = devServerHttp(mk(), { https: false, manifestsFile }).devServer;
  assert.deepEqual(ds.server, { type: 'http' });
  assert.equal(ds.client.webSocketURL.protocol, 'ws');
  const [mw] = ds.setupMiddlewares([], {});
  assert.equal(mw.path, '/temp/build/manifests.js');
  let body = '';
  mw.middleware({}, { setHeader() {}, end(b) { body = b; } });
  assert.equal(body, '{"internalModuleBaseUrls":["http://localhost:4321/dist/"]}');
});

test('m365 fail-loud: {"error"} s exit 0 je selhání a expectShape ho nahlas odmítne', async () => {
  withFake({
    'spo list get --title X --output json': { status: 0, out: '{"error":"List does not exist"}' },
    'spo list list --output json': { status: 0, out: '[]' },
  });
  const { m365, expectShape } = await import('../lib/m365.mjs');
  const r = m365(['spo', 'list', 'get', '--title', 'X']);
  assert.equal(r.status, 1);
  assert.throws(() => expectShape(r, 'object', 'čtení listu X'), /čtení listu X: m365 nevrátilo objekt \(rc 1\)/);
  assert.deepEqual(expectShape(m365(['spo', 'list', 'list']), 'array', 'listy'), []);
});
