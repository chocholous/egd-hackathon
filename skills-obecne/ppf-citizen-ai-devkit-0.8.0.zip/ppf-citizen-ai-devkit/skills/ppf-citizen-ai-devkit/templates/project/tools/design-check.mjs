// Kontrola vzhledu podle ppf-material nad lokálním harnessem (mock data, lokální uživatelé). Dva režimy:
//   npm run design-check                       ÚPLNÁ (před nasazením do dalšího prostředí): spustí harness na volném
//                                              portu a projde uživatele × sekce × záložky × detail prvního řádku
//   npm run design-check -- --rychle [--sekce <id>] [--user <jméno>]
//                                              RYCHLÁ (v průběhu vývoje): jedna sekce (výchozí = ta, na které appka
//                                              otevře), jeden uživatel (výchozí první), jen otevřený pohled a jeho detail
//   --url <adresa>                             použije už běžící harness (npm run dev) — v obou režimech
//   --user <jméno>                             jen jeden lokální uživatel (úplná pak není úplná: nasazení ji neuzná)
// Sekce = prvky lišty appky s data-cadk-id="sekce-<id>" (aktivní má aria-current="page"); appka bez sekcí
// = jeden průchod záložkami. Záložky se hledají podle popisku, ne pořadí (sekce mají každá jiné).
// DALŠÍ OBRAZOVKY KONTROLA NEOTEVÍRÁ: formulář, panel úprav, okno ani krok průvodce se nezměří a report je nezná.
// Posuzují se ručně (references/app-design.md §Co kontrola projde). Platí pro úplnou i rychlou kontrolu.
// Pro každý pohled: pravidla z tools/lib/design-rules.mjs + screenshot do .devkit/design/.
// Hodnoty pravidel (barvy, písma, zaoblení) jsou z ppf-material: spfx/src/app/ppf/ppfDesign.json, generuje ho
// `devkit theme` spolu s ppfMuiTheme.ts. Platí pro rychlou i úplnou kontrolu; bez souboru kontrola skončí (exit 2).
// Výsledek úplné: .devkit/design/report.json (čte ho plán nasazení, lib/design-report.mjs). Report nese otisk
// kódu, nad kterým kontrola běžela (lib/otisk.mjs), a `uplna: true`, když nebyla zúžená na jednoho uživatele;
// nasazení ho uzná, dokud se kód nezmění (commit ani čas souborů nerozhodují). Rychlá píše jen
// .devkit/design/rychla.json, report úplné nepřepisuje. Exit 1 = aspoň jedna chyba.
// Vypnutá pravidla: project_config.json → vzhled.vypnutaPravidla [{ pravidlo, vyjimka }] (lib/design-vypnuto.mjs).
// Vypnuté pravidlo se dál měří, jeho nálezy se vypíší jako „vypnuto“ s ID výjimky a nepočítají se mezi chyby;
// seznam vypnutých pravidel s ID vypíše každý běh (na začátku i na konci). Neplatný seznam = exit 2.
// Co změřit nejde (přehlednost, hierarchie), posuď na screenshotech — references/app-design.md §2.
// Klik, který nejde provést (prvek překrývá jiný, zmizel, nejde na něj dosáhnout), kontrolu neshodí: zapíše se jako
// chyba pravidla „běh“ u pohledu, kde k němu došlo, a průchod pokračuje dalším pohledem.
// Start harnessu a načtení appky: tools/lib/harness.mjs (sdílí ho i vlastní testy toků projektu).
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { ROOT, loadConfig } from './lib/config.mjs';
import { designRules } from './lib/design-rules.mjs';
import { otiskKodu } from './lib/otisk.mjs';
import { vypnutaPravidla, oznacVypnute, popisVypnutych } from './lib/design-vypnuto.mjs';
import { ROOT_SEL, loadChromium, startHarness, openApp } from './lib/harness.mjs';
import { launchProbeBrowser } from './lib/probe.mjs';

const args = process.argv.slice(2);
if (args.includes('--help') || args.includes('-h')) {
  console.log(`npm run design-check [-- volby] — kontrola vzhledu podle ppf-material nad lokálním harnessem (mock data)
  (bez voleb)        ÚPLNÁ: všichni lokální uživatelé × sekce × záložky × detail prvního řádku;
                     jen ji uzná plán nasazení
  --rychle           RYCHLÁ: jedna sekce, jeden uživatel, otevřený pohled a jeho detail
  --sekce <id>       jen s --rychle: sekce podle data-cadk-id="sekce-<id>"
  --user <jméno>     jen jeden lokální uživatel (úplná pak není úplná: nasazení ji neuzná)
  --url <adresa>     použije běžící harness (npm run dev) místo vlastního
  --help, -h         tato nápověda
Výstup: .devkit/design/ (screenshoty, report.json; rychlá rychla.json). Kód 0 bez chyb, 1 aspoň jedna chyba, 2 špatné použití.`);
  process.exit(0);
}
const opt = (n) => (args.includes(n) ? args[args.indexOf(n) + 1] : undefined);
const RYCHLE = args.includes('--rychle');
const OUT = join(ROOT, '.devkit', 'design');
const VIEWPORT = { width: 1440, height: 900 }; // okno podle vzorových obrazovek ppf-material ($preview 1440×900)
const SETTLE_MS = 400;                          // po přepnutí pohledu (React render, přechody 200–280 ms)
const t0 = Date.now();
const HODNOTY = join(ROOT, 'spfx', 'src', 'app', 'ppf', 'ppfDesign.json');
if (!existsSync(HODNOTY)) { console.error('chybí spfx/src/app/ppf/ppfDesign.json (hodnoty ppf-material pro kontrolu vzhledu) — vygeneruj: devkit theme spfx/src/app/ppf --material <složka skillu ppf-material>'); process.exit(2); }
const hodnoty = JSON.parse(readFileSync(HODNOTY, 'utf8'));
const V = vypnutaPravidla();
if (V.chyby.length) { console.error(`project_config.json: neplatný seznam vypnutých pravidel vzhledu — kontrola se nespustila\n- ${V.chyby.join('\n- ')}`); process.exit(2); }
const VYPNUTO = V.vypnuto.length ? `VYPNUTÁ PRAVIDLA VZHLEDU (project_config.json, schválené výjimky v DEVKIT-VYJIMKY.md): ${popisVypnutych(V.vypnuto)}` : '';
if (VYPNUTO) console.log(VYPNUTO);

if (opt('--sekce') && !RYCHLE) { console.error('--sekce jde jen s --rychle (úplná kontrola prochází všechny sekce)'); process.exit(2); }

let chromium;
try { chromium = await loadChromium(); }
catch (e) { console.error(e.message); process.exit(1); }

let server;
try { server = await startHarness({ url: opt('--url') }); }
catch (e) { console.error(e.message); process.exit(1); }
const url = server.url;
const otisk = otiskKodu(ROOT); // kód, nad kterým kontrola běží: až po startu harnessu, ten nejdřív spustí npm run gen

const users = Object.keys(loadConfig().environments?.local?.users || {});
const only = opt('--user');
const list = only ? [only] : users.length ? (RYCHLE ? [users[0]] : users) : [''];
mkdirSync(OUT, { recursive: true });

const browser = await launchProbeBrowser(chromium).catch((e) => { console.error(`prohlížeč nejde spustit: ${e.message.split('\n')[0]}\n  npx playwright install chromium, nebo nainstaluj Microsoft Edge`); server.stop(); process.exit(1); });
const views = [];
try {
  const page = await browser.newPage({ viewport: VIEWPORT, reducedMotion: 'reduce' });
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  for (const user of list) {
    await openApp(page, url, { reset: true, user }, { settleMs: SETTLE_MS * 2 });
    // sekce v liště appky (data-cadk-id="sekce-…"); appka bez sekcí = jeden průchod záložkami
    let sekce = await page.$$eval(`${ROOT_SEL} [data-cadk-id^="sekce-"]`, (els) => els.map((e) => ({ id: e.getAttribute('data-cadk-id'), label: (e.textContent || '').trim() || e.getAttribute('data-cadk-id').slice(6), on: e.getAttribute('aria-current') === 'page' })));
    if (RYCHLE) {
      const want = opt('--sekce');
      const hit = want ? sekce.find((s) => s.id === `sekce-${want}` || s.id === want) : sekce.find((s) => s.on);
      if (want && !hit) { console.error(`sekce "${want}" v appce není (má: ${sekce.map((s) => s.id.slice(6)).join(', ') || 'žádné sekce'})`); process.exitCode = 2; break; }
      sekce = hit ? [hit] : [];
    }
    for (const s of sekce.length ? sekce : [{ id: '', label: '' }]) {
      if (s.id) { if (!(await klik(page.locator(`${ROOT_SEL} [data-cadk-id="${s.id}"]`), user, s.label, `sekce „${s.label}“`))) continue; await page.waitForLoadState('networkidle'); await page.waitForTimeout(SETTLE_MS * 2); }
      const pre = s.label ? `${s.label} · ` : '';
      const tabs = await page.$$eval(`${ROOT_SEL} [role="tab"]`, (els) => els.map((e, i) => ({ i, label: (Array.from(e.childNodes).find((n) => n.nodeType === 3 && n.textContent.trim())?.textContent || e.textContent || '').trim(), on: e.getAttribute('aria-selected') === 'true' })));
      // rychlá: jen otevřená záložka (bez klikání), úplná: všechny podle popisku
      const projit = RYCHLE ? [{ i: -1, label: tabs.find((t) => t.on)?.label || s.label || 'appka' }] : tabs.length ? tabs : [{ i: -1, label: s.label || 'appka' }];
      for (const t of projit) {
        if (s.id) { const sb = page.locator(`${ROOT_SEL} [data-cadk-id="${s.id}"]`); if ((await sb.getAttribute('aria-current')) !== 'page') { if (!(await klik(sb, user, s.label, `sekce „${s.label}“`))) continue; await page.waitForTimeout(SETTLE_MS * 2); } } // proklik z řádku mohl odvést do jiné sekce
        if (t.i >= 0) { const tb = page.locator(`${ROOT_SEL} [role="tab"]`, { hasText: t.label }).first(); if (!(await tb.count())) continue; if (!(await klik(tb, user, `${pre}${t.label}`, `záložka „${t.label}“`))) continue; await page.waitForTimeout(SETTLE_MS); }
        const v = s.label && t.label !== s.label ? `${pre}${t.label}` : t.label;
        await check(page, user, v);
        const row = page.locator(`${ROOT_SEL} [data-ppf="row"]`).first();
        if (await row.count() && await klik(row, user, v, 'první řádek tabulky')) {
          await page.waitForTimeout(SETTLE_MS);
          // tabulka bez onOpen detail neotevře: neměřit pohled, který neexistuje
          if (await page.locator(`${ROOT_SEL} [data-ppf="detail"]`).count()) await check(page, user, `${v} · detail`);
          const close = page.locator(`${ROOT_SEL} [data-ppf="detail"] [aria-label="Zavřít detail"]`);
          if (await close.count()) { await klik(close, user, `${v} · detail`, 'křížek „Zavřít detail“'); await page.waitForTimeout(SETTLE_MS); }
        }
      }
    }
  }
  if (errors.length) views.push({ user: '', view: 'chyby stránky', shot: '', findings: errors.map((e) => ({ rule: 'běh', level: 'chyba', text: e, where: '' })) });
} finally {
  await browser.close();
  server.stop();
}
if (process.exitCode === 2) process.exit(2);

/** Klik průchodu. Nejde-li provést, vrátí false a zapíše chybu „běh“ k pohledu (řádek „… intercepts pointer events“ říká, co prvek překrývá). */
async function klik(locator, user, view, co) {
  try { await locator.click(); return true; }
  catch (e) {
    const radky = e.message.split('\n').map((l) => l.trim()).filter(Boolean);
    const prekryv = radky.find((l) => /intercepts pointer events/.test(l));
    views.push({ user, view: `${view || 'appka'} · klik`, shot: '', findings: [{ rule: 'běh', level: 'chyba', text: `na ${co} nejde kliknout${prekryv ? ': překrývá ho jiný prvek' : ''} — stejně na něj nedosáhne člověk; oprav rozvržení`, where: prekryv || radky[0] || '' }] });
    return false;
  }
}

async function check(page, user, view) {
  const findings = oznacVypnute(await page.evaluate(designRules, { root: ROOT_SEL, v: hodnoty }), V.vypnuto);
  const name = `${RYCHLE ? 'rychla-' : ''}${user || 'appka'}-${view}`.replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-|-$/g, '').toLowerCase();
  const shot = join(OUT, `${name}.png`);
  await page.screenshot({ path: shot });
  views.push({ user, view, shot, findings });
}

const errs = views.reduce((n, v) => n + v.findings.filter((f) => f.level === 'chyba').length, 0);
const warns = views.reduce((n, v) => n + v.findings.filter((f) => f.level === 'varování').length, 0);
const vyp = views.reduce((n, v) => n + v.findings.filter((f) => f.level === 'vypnuto').length, 0);
const report = { at: new Date().toISOString(), rezim: RYCHLE ? 'rychlá' : 'úplná', uplna: !RYCHLE && !only, source: otisk, material: hodnoty.$zdroj, errors: errs, warnings: warns, vypnuto: V.vypnuto, views };
writeFileSync(join(OUT, RYCHLE ? 'rychla.json' : 'report.json'), JSON.stringify(report, null, 2));
for (const v of views) {
  console.log(`\n${v.user ? `${v.user} · ` : ''}${v.view}${v.findings.length ? '' : ' — OK'}`);
  for (const f of v.findings) console.log(`  ${f.level === 'chyba' ? '!' : f.level === 'vypnuto' ? '–' : '?'} ${f.rule}${f.level === 'vypnuto' ? ` [vypnuto, výjimka ${f.vyjimka}]` : ''}: ${f.text}${f.where ? `\n      ${f.where}` : ''}`);
}
const sec = ((Date.now() - t0) / 1000).toFixed(0);
console.log(`\nhodnoty pravidel: ${hodnoty.$zdroj}`);
console.log(`vzhled (${RYCHLE ? 'rychlá' : 'úplná'} kontrola, ${sec} s): ${errs} chyb, ${warns} varování${V.vypnuto.length ? `, ${vyp} nálezů vypnutých pravidel` : ''} v ${views.length} pohledech; screenshoty ${OUT.replace(ROOT + '/', '')}/ — projdi je, přehlednost se změřit nedá`);
console.log('další obrazovky (formulář, okno, krok průvodce) kontrola neotevírá a NEZMĚŘILA je: posuď je ručně (references/app-design.md §Co kontrola projde)');
if (VYPNUTO) console.log(VYPNUTO);
if (!RYCHLE && !only && !errs) console.log(`úplná kontrola prošla pro kód s otiskem ${otisk}: nasazení ji uzná, dokud se kód ve spfx/ nezmění`);
else if (!RYCHLE && only) console.log('kontrola jen pro jednoho uživatele není úplná — nasazení na TEST ji neuzná');
else if (RYCHLE) console.log('rychlá kontrola nasazení neodemyká — před nasazením na TEST npm run design-check (úplná)');
process.exitCode = errs ? 1 : 0;
