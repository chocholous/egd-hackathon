// npm test — závěrečné řádky „co dál“ a STAV nástrojů bez plánu (lib/stav.mjs) a skript check-all.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, join } from 'node:path';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const STAV_URL = pathToFileURL(join(ROOT, 'tools', 'lib', 'stav.mjs')).href;
// spustí v podprocesu kód, který zaregistruje stavNaKonci a skončí daným způsobem
const beh = (telo, env = {}) => spawnSync(process.execPath, ['--input-type=module', '-e', `import { stavNaKonci } from ${JSON.stringify(STAV_URL)};\n${telo}`], { encoding: 'utf8', env: { ...process.env, ...env } });

test('stav: úspěch končí řádky „co dál“ a STAV: hotovo; jsou poslední i za vlastním výstupem nástroje', () => {
  const r = beh(`stavNaKonci((k) => (k === 0 ? 'další příkaz' : 'oprav'));\nconsole.log('výstup nástroje');`);
  assert.equal(r.status, 0);
  assert.deepEqual(r.stdout.trimEnd().split('\n'), ['výstup nástroje', 'co dál: další příkaz', 'STAV: hotovo']);
});

test('stav: nenulový kód (process.exit i exitCode) končí STAV: chyba a kód se nemění', () => {
  for (const konec of ['process.exit(1);', 'process.exitCode = 2;']) {
    const r = beh(`stavNaKonci((k) => (k === 0 ? 'dál' : 'oprav ' + k));\n${konec}`);
    assert.notEqual(r.status, 0);
    assert.deepEqual(r.stdout.trimEnd().split('\n'), [`co dál: oprav ${r.status}`, 'STAV: chyba']);
  }
});

test('stav: null vynechá „co dál“, false vynechá oba řádky, naStderr nechá stdout čistý', () => {
  assert.equal(beh('stavNaKonci(() => null);').stdout, 'STAV: hotovo\n');
  assert.equal(beh('stavNaKonci(() => false);').stdout, '');
  const r = beh(`stavNaKonci(() => 'dál', { naStderr: true });\nconsole.log('{}');`);
  assert.equal(r.stdout, '{}\n');
  assert.equal(r.stderr, 'co dál: dál\nSTAV: hotovo\n');
});

test('check-all: jeden příkaz před commitem = test, typecheck a lint; npm test zůstává bez typecheck a lint', () => {
  const { scripts } = JSON.parse(readFileSync(join(ROOT, 'package.json'), 'utf8'));
  assert.equal(scripts['check-all'], 'npm test && npm run typecheck && npm run lint');
  assert.doesNotMatch(scripts.test, /tsc|eslint|typecheck|lint/);
  assert.ok(scripts.typecheck && scripts.lint);
});
