// npm test — kontrola vzhledu bez prohlížeče: platnost reportu podle otisku kódu (lib/design-report.mjs,
// lib/otisk.mjs), kterou čte nasazení, a adresy harnessu (lib/harness.mjs). Bez sítě, jen dočasné složky.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, utimesSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { designFindings, designPoznamky, posledniKontrola } from '../lib/design-report.mjs';
import { otiskKodu, zapisBalicek, stavBalicku, zapisKdyzJiny } from '../lib/otisk.mjs';
import { harnessUrl } from '../lib/harness.mjs';
import { VYPINATELNA, idVyjimek, vypnutaPravidla, oznacVypnute, stejnaSada } from '../lib/design-vypnuto.mjs';

const tmp = () => mkdtempSync(join(tmpdir(), 'devkit-design-'));
function projekt() {
  const root = tmp();
  for (const d of ['spfx/src/app/generated', 'spfx/config', 'spfx/harness', 'spfx/sharepoint/solution', 'releases']) mkdirSync(join(root, d), { recursive: true });
  writeFileSync(join(root, 'spfx/src/app/App.tsx'), 'export const a = 1;\n');
  writeFileSync(join(root, 'spfx/src/app/generated/appManifest.ts'), 'export const m = {};\n');
  writeFileSync(join(root, 'spfx/config/package-solution.json'), '{"solution":{"version":"1.0.0.0"}}\n');
  writeFileSync(join(root, 'spfx/sharepoint/solution/app.sppkg'), 'zip');
  return root;
}
const report = (root, r) => { mkdirSync(join(root, '.devkit', 'design'), { recursive: true }); writeFileSync(join(root, '.devkit', 'design', 'report.json'), typeof r === 'string' ? r : JSON.stringify(r)); };
const ok = (root, o = {}) => ({ at: '2026-11-14T10:00:00.000Z', uplna: true, source: otiskKodu(root), errors: 0, views: [], ...o });

test('otisk: závisí na obsahu, ne na čase souboru; mění ho kód, konfigurace i generated; ne soubory mimo spfx', () => {
  const root = projekt();
  const o = otiskKodu(root);
  assert.match(o, /^[0-9a-f]{16}$/);
  const f = join(root, 'spfx/src/app/App.tsx');
  utimesSync(f, new Date(), new Date(statSync(f).mtimeMs + 60_000)); // novější čas, stejný obsah
  assert.equal(otiskKodu(root), o);
  writeFileSync(join(root, 'releases/dev.jsonl'), '{}\n'); // commit záznamu o nasazení
  writeFileSync(join(root, 'spfx/src/.DS_Store'), 'x');
  assert.equal(otiskKodu(root), o);
  writeFileSync(f, 'export const a = 1;\r\n'); // jen konce řádků (Windows s autocrlf)
  assert.equal(otiskKodu(root), o);
  writeFileSync(f, 'export const a = 2;\n');
  const o2 = otiskKodu(root);
  assert.notEqual(o2, o);
  writeFileSync(join(root, 'spfx/src/app/generated/appManifest.ts'), 'export const m = { x: 1 };\n');
  assert.notEqual(otiskKodu(root), o2);
});

test('zapisKdyzJiny: stejný obsah se nepřepíše (čas souboru zůstane), jiný ano', () => {
  const root = tmp();
  const f = join(root, 'a.ts');
  assert.equal(zapisKdyzJiny(f, 'x'), true);
  const starý = new Date(Date.now() - 3_600_000);
  utimesSync(f, starý, starý);
  assert.equal(zapisKdyzJiny(f, 'x'), false);
  assert.equal(Math.round(statSync(f).mtimeMs), Math.round(starý.getTime()));
  assert.equal(zapisKdyzJiny(f, 'y'), true);
});

test('balíček: bez záznamu o buildu, po buildu v pořádku, po změně kódu nebo souboru .sppkg neodpovídá', () => {
  const root = projekt();
  const sppkg = join(root, 'spfx/sharepoint/solution/app.sppkg');
  assert.match(stavBalicku(root, sppkg), /není záznam o buildu/);
  zapisBalicek(root, sppkg);
  assert.equal(stavBalicku(root, sppkg), null);
  // gen, dev, typecheck, design-check: přepíší čas, ne obsah → balíček dál odpovídá
  const g = join(root, 'spfx/src/app/generated/appManifest.ts');
  utimesSync(g, new Date(), new Date(Date.now() + 60_000));
  assert.equal(stavBalicku(root, sppkg), null);
  writeFileSync(join(root, 'spfx/src/app/App.tsx'), 'export const a = 2;\n');
  assert.match(stavBalicku(root, sppkg), /kód ve spfx\/ se od buildu změnil/);
  zapisBalicek(root, sppkg);
  writeFileSync(sppkg, 'jiný zip');
  assert.match(stavBalicku(root, sppkg), /není ten, který vyrobil poslední npm run build/);
  writeFileSync(join(root, '.devkit', 'balicek.json'), '{nejde');
  assert.match(stavBalicku(root, sppkg), /nejde přečíst/);
});

test('nasazení: TEST bez úplné kontroly dnešního kódu blokuje, DEV jen upozorní, shoda = žádný nález', () => {
  const root = projekt();
  const none = designFindings('test', { root });
  assert.equal(none.length, 1);
  assert.equal(none[0].kind, 'vzhled');
  assert.equal(none[0].block, true);
  assert.match(none[0].desc, /neproběhla.*bez ní se na test nenasazuje/);
  const dev = designFindings('dev', { root });
  assert.equal(dev.length, 1);
  assert.equal(dev[0].block, undefined);

  report(root, '{nejde');
  assert.equal(posledniKontrola(root), null);
  assert.match(designFindings('test', { root })[0].desc, /neproběhla/);
  report(root, ok(root, { source: 'b'.repeat(16) }));
  assert.match(designFindings('test', { root })[0].desc, /k jinému kódu \(otisk bbbbbbbbbbbbbbbb/);
  report(root, ok(root, { uplna: false }));
  assert.match(designFindings('test', { root })[0].desc, /nebyla úplná/);
  report(root, ok(root, { errors: 2, views: [{ findings: [{ level: 'chyba' }] }] }));
  assert.match(designFindings('test', { root })[0].desc, /2 porušení ppf-material v 1 pohledech/);
  report(root, ok(root));
  assert.deepEqual(designFindings('test', { root }), []);
  assert.deepEqual(designFindings('dev', { root }), []);
});

test('kontrolu vzhledu nezneplatní commit záznamu o nasazení ani nový čas souborů, změna kódu ano', () => {
  const root = projekt();
  report(root, ok(root));
  writeFileSync(join(root, 'releases/dev.jsonl'), '{"version":"1.0.0.0"}\n');
  const f = join(root, 'spfx/src/app/App.tsx');
  utimesSync(f, new Date(), new Date(Date.now() + 60_000));
  assert.deepEqual(designFindings('test', { root }), []);
  writeFileSync(f, 'export const a = 3;\n');
  assert.equal(designFindings('test', { root })[0].block, true);
});

const VYJIMKY = `# Výjimky
| ID | pravidlo | rozsah |
|---|---|---|
| V09 | 06 čísla | tabulka |

## V02 — nadpisem
<!--
| V01 | vzor řádku v komentáři | x |
-->
`;

test('vypínatelná pravidla = všechna jména z design-rules.mjs kromě „kořen“ (a „běh“ z design-check)', () => {
  const zdroj = readFileSync(new URL('../lib/design-rules.mjs', import.meta.url), 'utf8');
  const jmena = [...new Set([...zdroj.matchAll(/add\('([^']+)'/g)].map((m) => m[1]))].sort();
  assert.deepEqual([...VYPINATELNA].sort(), jmena);
  assert.equal(VYPINATELNA.includes('kořen'), false);
});

test('ID výjimek: řádek tabulky nebo nadpis; hlavička, oddělovač a komentář se nepočítají', () => {
  assert.deepEqual([...idVyjimek(VYJIMKY)].sort(), ['V02', 'V09']);
});

test('vypnutá pravidla: platí jen známé pravidlo s ID, které je v DEVKIT-VYJIMKY.md; jinak chyba a nic se nevypne', () => {
  const v = (seznam) => vypnutaPravidla({ cfg: { vzhled: { vypnutaPravidla: seznam } }, vyjimky: VYJIMKY });
  assert.deepEqual(vypnutaPravidla({ cfg: {}, vyjimky: VYJIMKY }), { vypnuto: [], chyby: [] });
  assert.deepEqual(v([{ pravidlo: '06 čísla', vyjimka: 'V09' }, { pravidlo: '04 radius', vyjimka: 'V02' }]), { vypnuto: [{ pravidlo: '06 čísla', vyjimka: 'V09' }, { pravidlo: '04 radius', vyjimka: 'V02' }], chyby: [] });
  assert.match(v([{ pravidlo: '06 čísla' }]).chyby[0], /chybí "vyjimka"/);
  assert.match(v([{ pravidlo: '06 čísla', vyjimka: 'V01' }]).chyby[0], /výjimka V01 není v DEVKIT-VYJIMKY\.md/); // V01 je jen v komentáři
  assert.match(v([{ pravidlo: 'kořen', vyjimka: 'V09' }]).chyby[0], /neexistuje nebo vypnout nejde/);
  assert.match(v([{ pravidlo: '99 nic', vyjimka: 'V09' }]).chyby[0], /neexistuje/);
  assert.match(v([{ pravidlo: '06 čísla', vyjimka: 'V09' }, { pravidlo: '06 čísla', vyjimka: 'V02' }]).chyby[0], /dvakrát/);
  assert.match(v('06 čísla').chyby[0], /musí být seznam/);
  assert.deepEqual(v([{ pravidlo: '06 čísla', vyjimka: 'V01' }]).vypnuto, []);
});

test('vypnuté pravidlo se dál měří: nález zůstane, jen s úrovní „vypnuto“ a ID výjimky', () => {
  const nalezy = [{ rule: '06 čísla', level: 'chyba', text: 'a' }, { rule: '04 radius', level: 'chyba', text: 'b' }];
  assert.deepEqual(oznacVypnute(nalezy, [{ pravidlo: '06 čísla', vyjimka: 'V09' }]), [{ rule: '06 čísla', level: 'vypnuto', text: 'a', vyjimka: 'V09' }, { rule: '04 radius', level: 'chyba', text: 'b' }]);
  assert.equal(stejnaSada([{ pravidlo: 'a', vyjimka: '1' }, { pravidlo: 'b', vyjimka: '2' }], [{ pravidlo: 'b', vyjimka: '2' }, { pravidlo: 'a', vyjimka: '1' }]), true);
  assert.equal(stejnaSada(undefined, []), true);
  assert.equal(stejnaSada([{ pravidlo: 'a', vyjimka: '1' }], [{ pravidlo: 'a', vyjimka: '2' }]), false);
});

test('nasazení: report platí jen pro dnešní seznam vypnutých pravidel; neplatný seznam blokuje', () => {
  const root = projekt();
  const cfg = (seznam) => writeFileSync(join(root, 'project_config.json'), JSON.stringify({ vzhled: { vypnutaPravidla: seznam } }));
  writeFileSync(join(root, 'DEVKIT-VYJIMKY.md'), VYJIMKY);
  cfg([{ pravidlo: '06 čísla', vyjimka: 'V09' }]);
  report(root, ok(root, { vypnuto: [{ pravidlo: '06 čísla', vyjimka: 'V09' }] }));
  assert.deepEqual(designFindings('test', { root }), []);
  cfg([]); // výjimka z konfigurace zmizela → kontrola s vypnutým pravidlem už neplatí
  assert.match(designFindings('test', { root })[0].desc, /běžela s jiným seznamem vypnutých pravidel \(tehdy: 06 čísla \(výjimka V09\); teď: žádné\)/);
  cfg([{ pravidlo: '06 čísla', vyjimka: 'V77' }]);
  const neplatny = designFindings('test', { root })[0];
  assert.equal(neplatny.block, true);
  assert.match(neplatny.desc, /seznam vypnutých pravidel vzhledu v project_config\.json je neplatný.*V77 není v DEVKIT-VYJIMKY/);
});

test('vypnutá pravidla: poznámka plánu s ID výjimky, ne nález', () => {
  const root = projekt();
  writeFileSync(join(root, 'DEVKIT-VYJIMKY.md'), VYJIMKY);
  writeFileSync(join(root, 'project_config.json'), JSON.stringify({ vzhled: { vypnutaPravidla: [{ pravidlo: '06 čísla', vyjimka: 'V09' }] } }));
  report(root, ok(root, { vypnuto: [{ pravidlo: '06 čísla', vyjimka: 'V09' }] }));
  assert.deepEqual(designFindings('test', { root }), []);
  assert.deepEqual(designPoznamky({ root }), ['kontrola vzhledu běžela s vypnutými pravidly: 06 čísla (výjimka V09)']);
  report(root, ok(root));
  assert.deepEqual(designPoznamky({ root }), []);
  assert.equal(designFindings('test', { root }).length, 1); // report bez vypnutých pravidel, konfigurace je má
});

test('kontrola vzhledu nezná značky otevření; harness pro skript nepřepisuje adresu dev serveru', () => {
  const tento = new URL('..', import.meta.url).pathname;
  assert.doesNotMatch(readFileSync(join(tento, 'design-check.mjs'), 'utf8'), /data-ppf-otevira|data-ppf-zavira/);
  assert.match(readFileSync(join(tento, 'lib', 'harness.mjs'), 'utf8'), /'--interni'/);
  assert.match(readFileSync(join(tento, 'dev.mjs'), 'utf8'), /if \(!args\.includes\('--interni'\)\) try/);
});

test('harnessUrl: ?reset, ?user=, ?now= v pořadí, jaké čekají skripty; bez parametrů holá adresa', () => {
  const base = 'http://127.0.0.1:5000/';
  assert.equal(harnessUrl(base), base);
  assert.equal(harnessUrl(base, { reset: true, user: '' }), `${base}?reset`);
  assert.equal(harnessUrl(base, { reset: true, user: 'anna' }), `${base}?reset&user=anna`);
  assert.equal(harnessUrl(base, { user: 'jan novák', now: '2026-11-11T08:30' }), `${base}?user=jan%20nov%C3%A1k&now=2026-11-11T08%3A30`);
});
