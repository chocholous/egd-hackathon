// npm run prereq [-- --json] [--env dev] [--pred-nasazenim]
// Ověří, že projekt má vše, co potřebuje: ladicí server, prohlížeč pro sondu,
// úplný project_config.json, přihlášení m365 do správného tenantu a na každém webu
// práva vlastníka + site app catalog. Jen čte. Exit: 0 vše OK, 1 nějaký FAIL, 2 špatné použití.
// Poslední řádky: „co dál: …“ a STAV: hotovo | chyba (lib/stav.mjs; s --json na stderr).
// Dvě fáze, stejné jako u doctoru kitu: bez volby se ptá „jde vyvíjet?“ a co je potřeba až k nasazení (cockpit.url,
// "site" prostředí, žádné prostředí s webem), je jen WARN. S --pred-nasazenim je to FAIL: cockpit.url vždy, "site"
// u prostředí z --env (bez --env u dev, stejný výchozí jako doctor). Přihlášení m365 je FAIL v obou fázích: lokální
// vývoj neblokuje (SKILL.md krok 4), ale bez něj nejde nic na SharePointu.
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { ROOT, loadConfig } from './lib/config.mjs';
import { status, rest, notLoggedIn, M365_HOME } from './lib/m365.mjs';
import { kontrolaNastroju } from './lib/nastroje.mjs';
import { spApi, readSiteCatalog } from './lib/state.mjs';
import { KATALOG_CHYBI } from './lib/plan/package.mjs';
import { memberLogin } from './lib/plan/perms.mjs';
import { launchProbeBrowser } from './lib/probe.mjs';
import { findKitPlugin, installedPlugins, pluginVersion } from './lib/kit-plugin.mjs';
import { stavNaKonci } from './lib/stav.mjs';
import { stejneRepo } from './lib/gitcheck.mjs';

const args = process.argv.slice(2);
if (args.includes('--help')) { console.log('npm run prereq [-- --json] [--env <prostředí>] [--pred-nasazenim]\n  --pred-nasazenim   prázdné cockpit.url a nevyplněný "site" prostředí (z --env, jinak dev) jsou FAIL; bez volby jen WARN'); process.exit(0); }
const asJson = args.includes('--json');
const onlyEnv = args.includes('--env') ? args[args.indexOf('--env') + 1] : null;
const PRED = args.includes('--pred-nasazenim');
// závěrečné řádky (lib/stav.mjs); s --json jdou na stderr, stdout zůstává čistý JSON
stavNaKonci((kod) => (kod !== 0 ? 'oprav řádky FAIL výše (každý říká jak) a spusť prereq znovu'
  : PRED ? `plán nasazení: npm run deploy -- --env ${onlyEnv || 'dev'}`
    : 'npm run dev (lokální vývoj); před nasazením npm run prereq -- --pred-nasazenim'), { naStderr: asJson });

const results = [];
const add = (area, name, ok, detail, level = ok ? 'OK' : 'FAIL') => results.push({ area, name, level, detail });
const warn = (area, name, detail) => results.push({ area, name, level: 'WARN', detail });

// 1) + 2) ladicí server: lib/nastroje.mjs (stejné řádky čte plán nasazení jako blokující nálezy).
// Verze Node a nástrojů tu od 0.7 nejsou: hlídá je npm při instalaci (.npmrc engine-strict, npm ci z lockfile)
for (const r of kontrolaNastroju(ROOT)) results.push({ area: 'nástroje', ...r });
// prohlížeč pro sondu (npm run probe) — jen WARN: lokální vývoj (npm run dev) ho nepotřebuje
if (existsSync(join(ROOT, 'node_modules', 'playwright', 'package.json'))) {
  try {
    const { chromium } = await import('playwright');
    const b = await launchProbeBrowser(chromium); // headless = totéž, co spouští sonda: přibalené Chromium, záloha Edge
    add('nástroje', 'prohlížeč pro sondu', true, `chromium ${b.version()}`);
    await b.close();
  } catch (e) {
    warn('nástroje', 'prohlížeč pro sondu', `nejde spustit (${e.message.split('\n')[0]}) — npx playwright install chromium, nebo nainstaluj Microsoft Edge`);
  }
}

// 3) project_config.json
let cfg;
try { cfg = loadConfig(); add('config', 'project_config.json', true, 'načteno'); }
catch (e) { add('config', 'project_config.json', false, e.message); }
if (cfg) {
  add('config', 'app.prefix', /^[A-Za-z][A-Za-z0-9]{1,15}$/.test(cfg.app?.prefix || ''), cfg.app?.prefix || 'chybí');
  add('config', 'm365.tenantId', /^[0-9a-f-]{36}$/.test(cfg.m365?.tenantId || ''), cfg.m365?.tenantId || 'chybí');
  add('config', 'm365.appId', /^[0-9a-f-]{36}$/.test(cfg.m365?.appId || ''), cfg.m365?.appId || 'chybí');
  const envs = Object.entries(cfg.environments || {}).filter(([n]) => n !== 'local');
  const withSite = envs.filter(([, e]) => e.site);
  if (withSite.length || PRED) add('config', 'environments', withSite.length > 0, withSite.map(([n]) => n).join(', ') || 'žádné SP prostředí s vyplněným "site"');
  else warn('config', 'environments', 'žádné SP prostředí s vyplněným "site" — lokálnímu vývoji nevadí; před prvním nasazením doplň adresu webu');
  for (const [n] of envs.filter(([, e]) => !e.site)) {
    if (PRED && n === (onlyEnv || 'dev')) add('config', `environments.${n}.site`, false, 'nevyplněno — bez adresy webu nejde nasadit');
    else warn('config', `environments.${n}.site`, 'nevyplněno — prostředí se přeskočí');
  }
  if (!cfg.environments?.local?.users) warn('config', 'environments.local.users', 'bez lokálních uživatelů mock neumí přepínat role');
  // cockpit stránku Node nečte; prereq jen připomene agentovi, že má cockpit přečíst (ArtifactData), references/cockpit.md
  if (cfg.cockpit?.url) add('config', 'cockpit.url', true, `${cfg.cockpit.url} — agent: přečti cockpit (zadání, rozhodnutí) před další prací`);
  else if (PRED) add('config', 'cockpit.url', false, 'prázdné — cockpit je podmínka každého nasazení, i na DEV (references/cockpit.md): nasazení zápis odmítne. Založ ho a adresu zapiš do project_config.json');
  else warn('config', 'cockpit.url', 'prázdné — lokálnímu vývoji nevadí; před prvním nasazením nutné, i na DEV (references/cockpit.md): založ cockpit a adresu zapiš do project_config.json');
  // git remote
  const r = spawnSync('git', ['remote', 'get-url', 'origin'], { cwd: ROOT, encoding: 'utf8' });
  const actual = r.status === 0 ? r.stdout.trim() : '';
  if (!cfg.git?.remote) warn('config', 'git.remote', actual ? `prázdné, ale origin = ${actual}` : 'prázdné, repo nemá origin');
  else add('config', 'git.remote', stejneRepo(actual, cfg.git.remote), actual === cfg.git.remote ? actual : `config ${cfg.git.remote} · origin ${actual || 'není'}${stejneRepo(actual, cfg.git.remote) ? ' (totéž repo)' : ' — jiné repo'}`);
}

// 4) m365 přihlášení a tenant
const homeExisted = existsSync(M365_HOME); // první volání m365 složku založí; hláška má říct, jestli tu byla (U09)
const maCli = existsSync(join(ROOT, 'node_modules', '@pnp', 'cli-microsoft365', 'package.json'));
const st = maCli ? status() : null;
// CLI chybí (typicky nový worktree, kde kopie node_modules ještě běží): přihlášení ověřit nejde. Neříkat „není
// přihlášené“ — člověk by šel zbytečně znovu na MFA, a npm install by se popral s běžící kopií.
if (!maCli) add('m365', 'přihlášení', false, 'nejde ověřit: CLI m365 není nainstalované (viz nástroje výše). Přihlášení tím dotčené není, znovu se nepřihlašuj. V novém worktree počkej, až doběhne kopie node_modules (wt config state logs → háček copy-ignored), a spusť prereq znovu; jinde npm ci');
// bez m365.appId a tenantId hláška místo příkazu přihlášení řekne, co doplnit
else if (!st) add('m365', 'přihlášení', false, notLoggedIn({ homeExisted, m365cfg: cfg?.m365 || {} }));
else {
  add('m365', 'přihlášení', true, `${st.connectedAs} (${st.authType})`);
  add('m365', 'tenant', st.appTenant === cfg?.m365?.tenantId, `${st.appTenant}${st.appTenant === cfg?.m365?.tenantId ? '' : ` ≠ config ${cfg?.m365?.tenantId}`}`);
}

// 5) weby: dostupnost, vlastník, site app catalog
if (st && cfg) {
  for (const [name, env] of Object.entries(cfg.environments)) {
    if (name === 'local' || !env.site || (onlyEnv && name !== onlyEnv)) continue;
    const web = rest(`${env.site}/_api/web?$select=Title,Url`);
    if (!web.json?.Url) { add(name, 'web', false, `${env.site}: ${(web.err || web.out).trim().slice(0, 200)}`); continue; }
    add(name, 'web', true, `${web.json.Title} — ${web.json.Url}`);
    const me = rest(`${env.site}/_api/web/currentuser?$select=IsSiteAdmin`);
    // člen se páruje podle Email → UPN → přihlašovací jméno (Email bývá u části účtů prázdný; U01)
    const isOwnerMember = rest(`${env.site}/_api/web/AssociatedOwnerGroup/users?$select=Email,UserPrincipalName,LoginName`);
    const inOwners = (isOwnerMember.json?.value || []).some((u) => memberLogin(u) === (st.connectedAs || '').toLowerCase());
    const admin = me.json?.IsSiteAdmin === true;
    add(name, 'vlastník webu', admin || inOwners, admin ? 'správce kolekce webů' : inOwners ? 'člen skupiny Owners' : 'ani správce, ani přímý člen Owners (člen přes Entra skupinu se tu nepozná)', admin || inOwners ? 'OK' : 'WARN');
    // stejné čtení a stejná věta jako blokující nález `katalog` v plánu nasazení
    let cat = null, catErr = '';
    try { cat = readSiteCatalog({ api: spApi(env.site) }); } catch (e) { catErr = e.message; }
    add(name, 'site app catalog', !!cat, cat || (catErr ? `nejde zjistit: ${catErr.slice(0, 200)}` : KATALOG_CHYBI));
  }
}

// 6) verze kitu: project_config.json → kit.verze proti nainstalovanému pluginu (jen WARN; nezjistí-li se, nic se nehlásí)
if (cfg) {
  // obě jména pluginu (staré ppf-spfx-devkit přechodně) i hledání pluginů: tools/lib/kit-plugin.mjs.
  // Plugin není nainstalovaný nebo se seznam nedá zjistit: nic nehlásit.
  const kit = findKitPlugin(installedPlugins({ cwd: ROOT }).list.filter((p) => p.enabled), (p) => p.id);
  const nainstalovana = kit ? pluginVersion(kit) : null;
  if (nainstalovana) {
    if (!cfg.kit?.verze) warn('kit', 'kit.verze', `project_config.json nemá kit.verze (projekt vznikl před zápisem verze); nainstalovaný plugin je ${nainstalovana} — devkit diff <projekt> ukáže rozdíly proti šabloně`);
    else if (cfg.kit.verze !== nainstalovana) warn('kit', 'kit.verze', `projekt vznikl z kitu ${cfg.kit.verze}, nainstalovaný plugin je ${nainstalovana} — devkit diff <projekt> ukáže rozdíly proti šabloně`);
  }
}

const fails = results.filter((r) => r.level === 'FAIL').length;
if (asJson) console.log(JSON.stringify({ ok: fails === 0, results }, null, 2));
else {
  for (const r of results) console.log(`${r.level.padEnd(4)}  ${r.area.padEnd(9)} ${r.name.padEnd(26)} ${r.detail}`);
  console.log(fails ? `\n${fails}× FAIL` : '\nvše potřebné je k dispozici');
}
process.exitCode = fails ? 1 : 0;
