// npm test — plán práv (plan/perms.mjs) a kontrola rolí (manifest.mjs) nad JSON stavem, bez sítě.
// simulate() provede akce plánu nad stavem tak, jak by je provedl SharePoint (přerušení s kopií, reset,
// přidání a odebrání vazby), aby šlo ověřit, že kontrolní plán po apply je prázdný.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildModel, validateManifest, validateEnv } from '../lib/manifest.mjs';
import { planPerms, maskOf, memberLogin } from '../lib/plan/perms.mjs';

const RD = {
  read: { Id: 2, Name: 'Read', RoleTypeKind: 2, Hidden: false },
  contribute: { Id: 3, Name: 'Contribute', RoleTypeKind: 3, Hidden: false },
  full: { Id: 5, Name: 'Full Control', RoleTypeKind: 5, Hidden: false },
  limited: { Id: 1, Name: 'Limited Access', RoleTypeKind: 1, Hidden: true },
};
const RAW = {
  roles: { owner: {}, editor: {}, user: {} },
  levels: { read: { builtin: 'Read' }, edit: { builtin: 'Contribute' }, add: { custom: 'Přidávání', rights: ['ViewListItems', 'AddListItems', 'Open'] } },
  lists: {
    Hlaseni: { class: 'operational', access: { user: 'add', editor: 'edit' } },
    Poznamky: { class: 'operational', access: 'inherit' },
  },
  libraries: { Assets: { class: 'config', access: { user: 'read', editor: 'read' } } },
};
const ENV = { roles: { user: { bindTo: '@members' }, editor: { members: { emails: [] } } } };
const model = buildModel(RAW, 'CADKP3');
const SITE = 'https://t.sharepoint.com/sites/x';
const ra = (id, title, ...rds) => ({ PrincipalId: id, Member: { Title: title }, RoleDefinitionBindings: rds });
const WEB_RA = [ra(3, 'x Owners', RD.full), ra(4, 'x Members', RD.contribute), ra(5, 'x Visitors', RD.read)];

function state() {
  return {
    site: SITE, web: { path: '/sites/x', owners: 'x Owners', members: 'x Members', visitors: 'x Visitors' },
    roledefs: [...structuredClone(Object.values(RD)), { Id: 100, Name: 'CADKP3 – Přidávání', RoleTypeKind: 0, Hidden: false, BasePermissions: { High: '0', Low: String(maskOf(RAW.levels.add.rights)) } }],
    groups: { 'x Owners': { Id: 3 }, 'x Members': { Id: 4 }, 'x Visitors': { Id: 5 }, 'CADKP3 – editor': { Id: 20 } },
    groupMembers: { editor: [] }, webRA: structuredClone(WEB_RA), me: { Id: 10, Title: 'Nasazující' },
    lists: { Hlaseni: { HasUniqueRoleAssignments: false, ra: null }, Poznamky: { HasUniqueRoleAssignments: false, ra: null }, Assets: { HasUniqueRoleAssignments: false, ra: null } },
  };
}
test('členové skupiny: účet s prázdným Email se pozná podle UPN nebo přihlašovacího jména (nepřidává se znovu, není „navíc“; U01)', () => {
  const env = { roles: { user: { bindTo: '@members' }, editor: { members: { emails: ['Pavel@Firma.cz', 'jana@firma.cz'] } } } };
  const s = state();
  s.groupMembers.editor = [
    { Title: 'Pavel', Email: '', UserPrincipalName: 'pavel@firma.cz', LoginName: 'i:0#.f|membership|pavel@firma.cz' },
    { Title: 'Jana', Email: null, LoginName: 'i:0#.f|membership|jana@firma.cz' },
    { Title: 'Cizí', Email: '', UserPrincipalName: 'cizi@firma.cz' },
  ];
  const p = plan(s, env);
  assert.deepEqual(p.actions.filter((a) => /přidat/.test(a.desc) && /editor/.test(a.desc)).map((a) => a.desc), []);
  assert.deepEqual(p.findings.filter((f) => /navíc/.test(f.desc)).map((f) => f.desc), ['ve skupině „CADKP3 – editor“ je navíc Cizí <cizi@firma.cz> (odebrat jen ručně)']);
  assert.equal(memberLogin({ Email: 'A@B.cz', UserPrincipalName: 'x@y' }), 'a@b.cz', 'Email má přednost');
});

const plan = (s, env = ENV) => planPerms(model, s, { env, appName: 'T' });
const keyOf = (path) => Object.keys(model.byKey).find((k) => path.includes(encodeURIComponent(`/sites/x/${model.byKey[k].url}`)) || path === `/sites/x/${model.byKey[k].url}`);

// provede akce plánu nad stavem jako SharePoint
function simulate(s, actions) {
  const rdBy = (pred) => s.roledefs.find(pred);
  for (const a of actions) {
    if (a.rest) {
      const st = s.lists[keyOf(a.rest.path)];
      let m;
      if (/breakroleinheritance/.test(a.rest.path)) { st.HasUniqueRoleAssignments = true; st.ra = structuredClone(s.webRA); }
      else if (/resetroleinheritance/.test(a.rest.path)) { st.HasUniqueRoleAssignments = false; st.ra = null; }
      else if ((m = /removeroleassignment\(principalid=(\d+),roledefid=(\d+)\)/.exec(a.rest.path))) {
        const x = st.ra.find((r) => r.PrincipalId === +m[1]);
        x.RoleDefinitionBindings = x.RoleDefinitionBindings.filter((r) => r.Id !== +m[2]);
        if (!x.RoleDefinitionBindings.length) st.ra = st.ra.filter((r) => r !== x);
      } else throw new Error(`neznámá REST akce ${a.rest.path}`);
      continue;
    }
    const [, , , verb] = a.m365;
    const opt = (n) => a.m365[a.m365.indexOf(n) + 1];
    if (a.m365[1] === 'roledefinition') { s.roledefs.push({ Id: 100 + s.roledefs.length, Name: opt('--name'), RoleTypeKind: 0, Hidden: false, BasePermissions: { High: '0', Low: String(maskOf(opt('--rights').split(','))) } }); continue; }
    if (a.m365[1] === 'group' && a.m365[2] === 'add') { s.groups[opt('--name')] = { Id: 50 + Object.keys(s.groups).length }; continue; }
    if (a.m365[1] === 'group') continue; // členové
    assert.equal(verb, 'add');
    const st = s.lists[keyOf(opt('--listUrl'))];
    const id = a.m365.includes('--principalId') ? +opt('--principalId') : s.groups[opt('--groupName')].Id;
    const title = Object.entries(s.groups).find(([, g]) => g.Id === id)?.[0];
    const rd = rdBy((r) => r.Name === opt('--roleDefinitionName'));
    const x = st.ra.find((r) => r.PrincipalId === id);
    if (x) x.RoleDefinitionBindings.push(rd); else st.ra.push(ra(id, title, rd));
  }
  return s;
}
const converges = (s, env = ENV) => {
  const p = plan(s, env);
  simulate(s, p.actions);
  assert.deepEqual(plan(s, env).actions.map((a) => a.desc), [], 'kontrolní plán po apply musí být prázdný');
  return p;
};

test('práva: access "inherit" nechá dědit, objekt přeruší s kopií a srovná; kontrolní plán je prázdný', () => {
  const s = state();
  const p = converges(s);
  assert.ok(!p.actions.some((a) => a.desc.startsWith('„CADKP3-Poznamky“')), 'list s inherit se nesmí přerušit');
  const hl = p.actions.filter((a) => a.desc.startsWith('„CADKP3-Hlaseni“')).map((a) => a.desc);
  assert.deepEqual(hl, [
    '„CADKP3-Hlaseni“: přerušit dědičnost (s kopií práv webu, práva položek zůstanou)',
    '„CADKP3-Hlaseni“: x Members → CADKP3 – Přidávání',
    '„CADKP3-Hlaseni“: CADKP3 – editor → Contribute',
    '„CADKP3-Hlaseni“: x Members — odebrat Contribute (git: CADKP3 – Přidávání)',
    '„CADKP3-Hlaseni“: x Visitors — odebrat Read (není v gitu)',
  ]);
  assert.equal(s.lists.Poznamky.ra, null);
});

test('práva: ruční přidání práv na list s vlastními právy → plán „odebrat“, po apply prázdný (hotovo P3)', () => {
  const s = state();
  converges(s);
  s.lists.Hlaseni.ra.push(ra(77, 'Petr Ručně', RD.contribute));
  s.lists.Hlaseni.ra.find((r) => r.PrincipalId === 20).RoleDefinitionBindings.push(RD.read);
  const p = converges(s);
  assert.deepEqual(p.actions.map((a) => a.desc), [
    '„CADKP3-Hlaseni“: CADKP3 – editor — odebrat Read (git: Contribute)',
    '„CADKP3-Hlaseni“: Petr Ručně — odebrat Contribute (není v gitu)',
  ]);
  assert.match(p.actions[1].rest.path, /removeroleassignment\(principalid=77,roledefid=3\)$/);
});

test('práva: vlastníci, nasazující účet a Limited Access se nikdy neodebírají', () => {
  const s = state();
  converges(s);
  const st = s.lists.Hlaseni;
  st.ra.find((r) => r.PrincipalId === 3).RoleDefinitionBindings.push(RD.read); // vlastníci s další úrovní
  st.ra.push(ra(10, 'Nasazující', RD.contribute)); // přímé přiřazení nasazujícího
  st.ra.push(ra(88, 'Sdíleno z appky', RD.limited)); // Limited Access ze sdílení položky
  assert.deepEqual(plan(s), { actions: [], findings: [], poznamky: [] });
  st.ra = st.ra.filter((r) => r.PrincipalId !== 3); // vlastníci zmizeli → vrátit Full Control
  assert.deepEqual(plan(s).actions.map((a) => a.desc), ['„CADKP3-Hlaseni“: x Owners → Full Control']);
});

test('práva: ručně přerušený list s "inherit" → obnovit dědičnost', () => {
  const s = state();
  s.lists.Poznamky = { HasUniqueRoleAssignments: true, ra: [ra(3, 'x Owners', RD.full), ra(77, 'Petr', RD.read)] };
  const p = converges(s);
  assert.ok(p.actions.some((a) => a.desc === '„CADKP3-Poznamky“: obnovit dědičnost z webu (vlastní práva listu se zahodí)' && /\/resetroleinheritance$/.test(a.rest.path)));
});

test('práva: lokalizované názvy úrovní — vestavěné podle typu, ne podle jména', () => {
  const s = state();
  for (const r of s.roledefs) r.Name = { 2: 'Čtení', 3: 'Přispívání', 5: 'Úplné řízení', 1: 'Omezený přístup' }[r.RoleTypeKind] || r.Name;
  for (const x of s.webRA) for (const b of x.RoleDefinitionBindings) b.Name = s.roledefs.find((r) => r.Id === b.Id).Name;
  const p = converges(s);
  assert.ok(p.actions.some((a) => a.desc === '„CADKP3-Hlaseni“: CADKP3 – editor → Přispívání'));
  assert.deepEqual(p.findings, []);
});

test('práva: vlastní úroveň chybí = založit; jiná oprávnění = nález (platí pro celou kolekci), ne zápis', () => {
  const s = state();
  s.roledefs = s.roledefs.filter((r) => r.Id !== 100);
  let p = converges(s);
  assert.equal(p.actions[0].desc, 'založit úroveň oprávnění „CADKP3 – Přidávání“ (ViewListItems, AddListItems, Open)');
  s.roledefs.find((r) => r.Name === 'CADKP3 – Přidávání').BasePermissions = { High: '0', Low: '1' };
  p = plan(s);
  assert.deepEqual(p.actions, []);
  assert.match(p.findings[0].desc, /úroveň „CADKP3 – Přidávání“ má jiná oprávnění .* celou kolekci webů/);
});

test('práva: skupina role, která ještě neexistuje, se přiřadí podle jména až po založení', () => {
  const s = state();
  delete s.groups['CADKP3 – editor'];
  const p = converges(s);
  const add = p.actions.find((a) => a.desc === '„CADKP3-Hlaseni“: CADKP3 – editor → Contribute').m365;
  assert.deepEqual(add.slice(add.indexOf('--groupName'), add.indexOf('--groupName') + 2), ['--groupName', 'CADKP3 – editor']);
  assert.ok(p.actions.findIndex((a) => a.desc === 'založit skupinu „CADKP3 – editor“') < p.actions.indexOf(p.actions.find((a) => a.m365 === add)));
});

test('manifest: access povinné ("inherit" nebo objekt), owner do access nepatří, runtime jen u listu, neznámé oprávnění', () => {
  const bad = structuredClone(RAW);
  delete bad.lists.Hlaseni.access;
  bad.lists.Poznamky.access = { owner: 'read' };
  bad.lists.Poznamky.itemPermissions = 'yes';
  bad.libraries.Assets.access = 'inherit';
  bad.levels.add.rights.push('Teleport');
  const { errors } = validateManifest(bad, { prefix: 'CADKP3' });
  for (const re of [/list Hlaseni: chybí "access"/, /list Poznamky: role owner se do access nepíše/, /itemPermissions smí být jen "runtime"/, /knihovna Assets: role user musí mít v access aspoň read/, /neznámé oprávnění "Teleport"/]) assert.ok(errors.some((e) => re.test(e)), `chybí chyba ${re}: ${errors.join(' | ')}`);
  const ok = structuredClone(RAW);
  ok.lists.Hlaseni.itemPermissions = 'runtime';
  assert.deepEqual(validateManifest(ok, { prefix: 'CADKP3' }).errors, []);
});

test('prostředí: neznámá role, owner, bindTo @owners, dvě role na jednu skupinu, nemapovaná role z access', () => {
  assert.deepEqual(validateEnv(RAW, 'dev', ENV), []);
  const e = validateEnv(RAW, 'dev', { roles: { owner: { bindTo: '@owners' }, user: { bindTo: '@owners' }, ghost: { members: {} } } });
  for (const re of [/role owner: owner se nemapuje/, /role user: bindTo smí být @members nebo @visitors/, /role ghost: manifest takovou roli nezná/, /role editor je v access, ale v prostředí není mapovaná/]) assert.ok(e.some((x) => re.test(x)), `chybí chyba ${re}: ${e.join(' | ')}`);
  assert.match(validateEnv(RAW, 'dev', { roles: { user: { bindTo: '@members' }, editor: { bindTo: '@members' } } }).join(), /stejnou skupinu jako role user/);
});
