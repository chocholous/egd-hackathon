// npm test — lib/mockgen.mjs: práva úrovní a seznam dat, které gen.mjs zapisuje pro lokální mock.
// Proč: když mock dostane jiná práva než SharePoint nebo mu chybí data listu, chyba se ukáže až na DEV.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { levelRights, mockDataSource } from '../lib/mockgen.mjs';

test('levelRights: vestavěná úroveň dostane čtení a práva s položkami, vlastní přesně svá rights', () => {
  const r = levelRights({
    read: { builtin: 'Read' }, edit: { builtin: 'Contribute' }, design: { builtin: 'Design' },
    'read-all': { custom: 'Čtení všeho', rights: ['ViewListItems', 'CancelCheckout'] },
  });
  assert.deepEqual(r.read.rights, ['ViewListItems']);
  assert.deepEqual(r.edit.rights, ['ViewListItems', 'AddListItems', 'EditListItems', 'DeleteListItems']);
  assert.ok(r.design.rights.includes('CancelCheckout'), 'Design obchází „jen své“');
  assert.deepEqual(r['read-all'].rights, ['ViewListItems', 'CancelCheckout']);
  assert.deepEqual(levelRights(undefined), {});
});

test('mockDataSource: každý list se souborem, config má přednost před seed, list bez souboru se vynechá', () => {
  const soubory = new Set(['config/Kategorie', 'seed/Kategorie', 'seed/Hlaseni']);
  const ts = mockDataSource(['Kategorie', 'Hlaseni', 'Pripominky'], (druh, k) => soubory.has(`${druh}/${k}`));
  assert.match(ts, /import d0 from '\.\.\/\.\.\/\.\.\/\.\.\/sp\/data\/config\/Kategorie\.json';/);
  assert.match(ts, /import d1 from '\.\.\/\.\.\/\.\.\/\.\.\/sp\/data\/seed\/Hlaseni\.json';/);
  assert.match(ts, /"Kategorie": d0 as Item\[\],\n  "Hlaseni": d1 as Item\[\],/);
  assert.doesNotMatch(ts, /Pripominky/);
  assert.match(mockDataSource([], () => false), /mockData: Record<string, Item\[\]> = \{\n\n\};/);
  // výchozí sada (class initial) má přednost před seed, config před ní
  const ini = mockDataSource(['Druhy', 'Kody'], (druh, k) => new Set(['initial/Druhy', 'seed/Druhy', 'config/Kody', 'initial/Kody']).has(`${druh}/${k}`));
  assert.match(ini, /import d0 from '\.\.\/\.\.\/\.\.\/\.\.\/sp\/data\/initial\/Druhy\.json';/);
  assert.match(ini, /import d1 from '\.\.\/\.\.\/\.\.\/\.\.\/sp\/data\/config\/Kody\.json';/);
});
