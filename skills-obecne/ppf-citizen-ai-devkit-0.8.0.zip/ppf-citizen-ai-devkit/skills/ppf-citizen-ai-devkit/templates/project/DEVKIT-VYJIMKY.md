# Povolené výjimky z pravidel ppf-citizen-ai-devkit

Kánon kitu je ve skillu `ppf-citizen-ai-devkit` (SKILL.md a `references/`). Tenhle soubor je jediné místo, kde se
projekt smí od jeho pravidel odchýlit. **Agent nesmí porušit pravidlo kitu bez položky v tomto souboru a položku
schvaluje člověk**: agent ji jen navrhne (vyplní všechna pole kromě „schválil“), člověk doplní „schválil“
(kdo, kdy, doslova) a commitne. Bez schválení se položka nepoužije.

Odchylka je dočasná: nejlepší výjimka je ta, která se vrátí do kitu jako oprava. Pole „nahlášeno do kitu“ proto
nese odkaz na požadavek nebo opravu v repu kitu, nebo `ne` (a proč).

| ID | pravidlo | rozsah | důvod | schválil | kdy se zruší | nahlášeno do kitu |
|---|---|---|---|---|---|---|

<!--
Vzor řádku (ID `Vnn`, nikdy se nepřečíslovává):
| V01 | které pravidlo kitu se porušuje (odkaz na skill nebo soubor) | cesty, knihovny, soubory | proč to jinak nejde | jméno, datum, doslovné ano | podmínka zrušení | odkaz na požadavek v kitu, nebo `ne` + důvod |
-->
