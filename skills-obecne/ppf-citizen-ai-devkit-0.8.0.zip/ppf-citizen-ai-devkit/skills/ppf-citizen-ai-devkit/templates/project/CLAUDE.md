# __APP_NAME__

**Povinné pro každou konverzaci v tomto repu:** načti skill `ppf-citizen-ai-devkit` (workflow, příkazy,
pravidla) a spusť `npm run prereq`. FAIL u Node nebo závislostí = nejdřív oprav. FAIL u webu
(`environments`) nebo přihlášení do m365 blokuje jen SharePoint (deploy, probe, feedback, `dev --sp`);
lokálně nad mocky (`gen`, `dev`, `build`, `test`) pracuj i tak.

## Co kde je
- `project_config.json` — tenant, weby DEV/TEST, mapování rolí na skupiny, hodnoty `@env:` pro web party; `kit` = verze a commit kitu, ze kterého projekt vznikl (rozdíl proti šabloně: `devkit diff`, viz skill).
- `sp/app.manifest.json` — listy a knihovny (`class: config|initial|operational`), sloupce, role, práva, stránky.
- `sp/data/config/*.json` — **kanón** obsahu konfiguračních listů; `sp/data/initial/*.json` — výchozí sada listů `class: initial` (deploy ji vloží jednou, pak ji spravuje byznys v appce); `sp/data/seed/*.json` — ukázková data jen pro mock.
- `sp/assets/config/` — **kanón** konfiguračních assetů (knihovna `<prefix>-Assets`).
- `spfx/src/app/` — appka nezávislá na SPFx (`App.tsx`, `data/MockSource.ts`, `data/SpSource.ts`).
- `spfx/src/webparts/` — tenký SPFx host; `spfx/harness/` — lokální spouštění nad mocky.
- `tools/` — nástroje projektu (`npm run <jméno>`), sdílené moduly `tools/lib/`, testy `tools/test/`.
- Záznam o nasazení je na webu (`_deploy/<env>.json` a historie v konfigurační knihovně appky); zapisuje ho nasazení
  samo, do gitu se po nasazení nic necommituje. `releases/` má jen projekt založený před kitem 0.6 (stará historie).
- `DEVKIT-VYJIMKY.md` — povolené výjimky z pravidel kitu (viz níže).

## Pravidla
Pravidla (nasazení a plán, git, m365, vzhled, výjimky, produkce, co je „hotovo“) jsou jen ve skillu
`ppf-citizen-ai-devkit`, §Pojistky a §Další pravidla; tady se neopakují, aby se kopie nerozešly. Odchylka od nich potřebuje položku
v `DEVKIT-VYJIMKY.md`, kterou schválí člověk.
