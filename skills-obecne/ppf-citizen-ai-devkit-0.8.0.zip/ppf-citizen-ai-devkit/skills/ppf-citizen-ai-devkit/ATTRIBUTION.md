# Původ kopie

Tenhle skill je **kopie** pluginu `ppf-citizen-ai-devkit` z interního repa kitu `ppf-spfx-devkit` (správce
kitu a tohoto katalogu je stejný). Zdroj pravdy je repo kitu; tady se nic needituje ručně kromě tohoto
souboru. Odkaz `external:` nejde: repo kitu je interní a `external:` vyžaduje veřejné repo.

| | |
|---|---|
| **Zdroj** | repo `ppf-spfx-devkit` (lokálně `~/Projects/ppf-spfx-devkit`), složka `plugin/ppf-citizen-ai-devkit/` |
| **Commit** | `8818e1b` (větev `main`); stejný commit je v `_plugin/BUILD.json` |
| **Verze** | 0.8.0 (`version:` v `SKILL.md`, řada kitu) |
| **Závislosti** | `ppf-material`, `ppf-browsermagic`, `m365-cli-12` (pole `dependencies` v `tools/skills.yaml`) |

## Mapování

| Ve zdroji (`plugin/ppf-citizen-ai-devkit/`) | Tady | V pluginu (`plugins/ppf-citizen-ai-devkit/`) |
|---|---|---|
| `skills/ppf-citizen-ai-devkit/**` | `**` | `skills/ppf-citizen-ai-devkit/**` |
| `hooks/hooks.json`, `README.md`, `SOURCES.json` | `_plugin/…` | kořen pluginu |
| `BUILD.json` (commit kitu; v repu kitu se neverzuje) | `_plugin/BUILD.json` | kořen pluginu (čte ho `scripts/devkit.mjs`) |
| `.claude-plugin/plugin.json` | — | generuje `tools/build_plugins.py` z `SKILL.md` a `tools/skills.yaml` |

Hook `hooks/hooks.json` plugin registruje (PreToolUse na `scripts/m365-hook.mjs`), na rozdíl od
neregistrovaného hooku uvnitř skillu `m365-cli-12`.

## Přebalení na novější commit kitu

1. V repu kitu: commit, čistý strom, `node tools/build-plugin.mjs --check`.
2. `PPF_SKILLS_DIR=<tento checkout> node tools/sync-to-skills.mjs` a pak `--check` (exit 0 = shoda).
   Skript zapíše skill i `_plugin/`, soubory, které ve zdroji zmizely, pošle do koše, tento soubor nechá.
3. Tady: commit v tabulce výše, bump `version:` jen ve zdroji kitu (kopie ho převezme),
   `.venv/bin/python tools/build_plugins.py`, `claude plugin validate plugins/ppf-citizen-ai-devkit`.
