#!/usr/bin/env node
// devkit — CLI pluginu ppf-citizen-ai-devkit: založí projekt ze šablony, vygeneruje PPF vzhled a ukáže,
// čím se projekt liší od šablony. Všechno ostatní (prereq, dev, build, deploy, probe, feedback, m365)
// jsou npm skripty projektu. Běží na macOS, Linuxu/WSL i Windows (PowerShell): jen Node, žádné závislosti.
//
//   node devkit.mjs help
//
// Verze kitu v projektu (D16): init zapíše do project_config.json klíč `kit` = { verze, commit }.
//   verze  = version z .claude-plugin/plugin.json pluginu;
//   commit = kit.commit z BUILD.json vedle pluginu (píše ho tools/build-plugin.mjs); jinak git rev-parse
//            repa kitu, běží-li plugin z checkoutu; jinak null. Projekt bez klíče = „neznámá verze“, ne chyba.
//   `diff <projekt>` jen čte a vypíše jeden řádek na soubor: `zmeneno|chybi|navic<TAB>cesta`
//   (řádky s `#` jsou informace). Exit 0 = bez rozdílů, 10 = rozdíly (jen čte, nic se nezapsalo), 2 = chyba použití.
//
// Aktualizace projektu (`update <projekt> [--zapsat]`): třícestné porovnání bez uložených starých šablon.
//   základ  = otisky šablony verze kit.verze projektu z templates/otisky.json (sha256 souborů po převodu na LF
//             a scripts/devDependencies package.json); otisky vydaných verzí doplňuje dev/sablona-otisky.mjs z git
//             tagů a tools/build-plugin.mjs --check hlídá, že poslední tag v nich je. Aktuální verze se nedrží,
//             počítá se živě ze šablony (jen když otisky.json pro kit.verze záznam nemá a kit.verze = verze kitu).
//   nová    = dnešní šablona; projekt = soubor v projektu. Rozsah: soubory šablony mimo obsah projektu (UPDATE_VYNECHAT)
//             a blocks.tsx; package.json po klíčích scripts/devDependencies; generovaný vzhled přes --check generátorů.
//   Bez --zapsat jen čte a vypíše plán `druh<TAB>cesta[<TAB>důvod]` (prevzit|pridat|konflikt|zruseno|vlastni|vzhled);
//   exit 0 = nic k převzetí ani konflikt, 10 = plán má akce/konflikty/zruseno a nic se nezapsalo, 2 = použití.
//   --zapsat jen v git repu s čistým stromem (změny jdou projít `git diff` a vrátit), jinak exit 1 bez zápisu; zapíše
//   prevzit/pridat, klíče package.json, vzhled a kit.verze/commit; nic nemaže a necommituje. Exit 0 = bez konfliktů,
//   11 = zapsáno, ale zůstaly konflikty nebo zruseno k ručnímu dořešení.
//   POZOR: konflikt se po --zapsat posouvá spolu s kit.verze: příští update ho ohlásí znovu jen tehdy, když šablona
//   ten soubor změní znovu. Proto se musí sloučit hned; devkit diff ho dál ukazuje jako zmeneno.
//
// Prázdný projekt (O02): `init --prazdny` založí tutéž šablonu bez ukázkové domény (listy Kategorie a Hlaseni,
// knihovna Prilohy, jejich data, texty.json, ukázkový App.tsx), s prázdnou appkou v AppShell. Řešení je nejmenší:
// žádná druhá šablona, jen tabulka PRAZDNY níže — soubory k odstranění, soubor k přepsání z
// templates/project-prazdny/ (jediný: App.tsx) a jedna úprava textu (manifest; data mocku generuje gen.mjs z manifestu). Šablona se změní
// → úprava, která nenajde svůj text, init zastaví hláškou (hlídá to test dev/devkit.test.mjs).
// Klíč `kit.varianta: "prazdny"` v project_config.json říká `diff`, že tyto soubory se s šablonou neporovnávají.
//
// .gitignore šablony: v šabloně se jmenuje `gitignore` (bez tečky) a init ho v novém projektu přejmenuje.
// Důvod: balení pluginu soubory `.gitignore` vynechává (generátor katalogu ppf-skills, stejně tak npm),
// projekt z nainstalovaného pluginu by je tedy neměl. Chybí-li po initu `.gitignore` v kořeni, init skončí chybou.
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { cpSync, existsSync, mkdirSync, readFileSync, readdirSync, realpathSync, renameSync, writeFileSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';
import { homedir } from 'node:os';
import { fileURLToPath } from 'node:url';

const SKILL = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const SCRIPTS = join(SKILL, 'scripts');
const WIN = process.platform === 'win32';
const fwd = (p) => p.replace(/\\/g, '/');

import { materialSkillDir } from '../templates/project/tools/lib/kit-plugin.mjs';

function die(msg, code = 1) { console.error(`devkit: ${msg}`); process.exit(code); }
function run(cmd, args, opts = {}) {
  const r = spawnSync(cmd, args, { stdio: 'inherit', shell: WIN && /^(npm|npx)$/.test(cmd), ...opts });
  return r.error ? { status: 127, error: r.error } : r;
}
function flag(args, name) { const i = args.indexOf(name); if (i < 0) return null; const v = args[i + 1]; args.splice(i, 2); return v; }
function has(args, name) { const i = args.indexOf(name); if (i < 0) return false; args.splice(i, 1); return true; }

/** Skill ppf-material zapnutého nainstalovaného pluginu (jediné hledání: templates/project/tools/lib/kit-plugin.mjs). */
const findMaterial = () => materialSkillDir();

/**
 * Proč kit není vydaná verze: commit bez tagu v<verze>, nebo necommitnuté změny ve složce pluginu. null = vydaný.
 * Číslo verze samo nic neříká: plugin.json nese „0.6.0“ po celou dobu vývoje 0.6.0, takže projekt založený nebo
 * aktualizovaný z rozpracované větve nese kit.verze vydané verze, ale jiný obsah (nález U10).
 */
export function nevydanyDuvod({ verze, head, tagy, zmen }) {
  const p = [];
  if (!tagy.includes(`v${verze}`)) p.push(`commit ${head} nemá tag v${verze}`);
  if (zmen) p.push(`${zmen} necommitnutých změn ve složce pluginu`);
  return p.length ? p.join(', ') : null;
}

/**
 * Verze a commit kitu, ze kterého tenhle devkit běží (zapisuje se do project_config.json → kit). Neznámé = null.
 * nevydany = důvod (viz nevydanyDuvod), null = vydaná verze nebo to nejde zjistit (plugin mimo git bez BUILD.json).
 */
export function kitInfo() {
  const plugin = resolve(SKILL, '..', '..');
  const readJson = (f) => { try { return JSON.parse(readFileSync(f, 'utf8')); } catch { return null; } };
  const verze = readJson(join(plugin, '.claude-plugin', 'plugin.json'))?.version ?? null;
  const build = readJson(join(plugin, 'BUILD.json'))?.kit;
  let commit = build?.commit ?? null;
  // zip z tools/build-plugin.mjs: tagy commitu zapsal build (starší build je nenese = nejde zjistit)
  let nevydany = commit && Array.isArray(build.tagy) ? nevydanyDuvod({ verze, head: String(commit).replace(/\+dirty$/, '').slice(0, 7), tagy: build.tagy, zmen: /\+dirty$/.test(commit) ? 1 : 0 }) : null;
  if (!commit) {
    // plugin z checkoutu kitu: toplevel gitu musí být repo, které plugin opravdu obsahuje (ne cizí repo nad cache)
    const git = (a) => spawnSync('git', a, { cwd: plugin, encoding: 'utf8' });
    const top = git(['rev-parse', '--show-toplevel']);
    if (top.status === 0 && existsSync(join(top.stdout.trim(), 'plugin', 'ppf-citizen-ai-devkit'))
      && realpathSync(join(top.stdout.trim(), 'plugin', 'ppf-citizen-ai-devkit')) === realpathSync(plugin)) {
      const h = git(['rev-parse', '--short', 'HEAD']);
      if (h.status === 0) {
        // změny jen ve složce pluginu, včetně nových nesledovaných souborů (nový modul šablony je taky jiný obsah)
        const zmen = git(['status', '--porcelain', '--', plugin]).stdout.split('\n').filter(Boolean).length;
        commit = `${h.stdout.trim()}${zmen ? '+dirty' : ''}`;
        const t = git(['tag', '--points-at', 'HEAD']);
        if (t.status === 0) nevydany = nevydanyDuvod({ verze, head: h.stdout.trim(), tagy: t.stdout.split('\n').filter(Boolean), zmen });
      }
    }
  }
  return { verze, commit, nevydany };
}

/** Upozornění na stderr, když devkit běží z nevydaného kitu; `zapis` = příkaz zapisuje kit.verze do projektu. */
function varujNevydany(now, zapis) {
  if (!now.nevydany) return;
  console.error(`POZOR: devkit běží z NEVYDANÉHO kitu ${now.verze} (${now.nevydany}).${zapis ? ` Projekt ponese kit.verze ${now.verze} (${now.commit}), ale obsah se s vydanou ${now.verze} nemusí shodovat: příští devkit update z vydané verze by rozdíly bral jako vlastní úpravy projektu. Po vydání projekt porovnej (devkit diff) a rozdíly převezmi ručně.` : ' Šablona, proti které se porovnává, není vydaná verze.'}`);
}

/** Prázdný projekt (init --prazdny): co se v šabloně považuje za ukázkovou doménu. Viz hlavička souboru. */
const PRAZDNY = {
  odstranit: ['sp/data/config/Kategorie.json', 'sp/data/seed/Hlaseni.json', 'sp/assets/config/texty.json'],
  prepsat: ['spfx/src/app/App.tsx'],               // z templates/project-prazdny/ (stejná cesta)
  upravit: ['sp/app.manifest.json', 'project_config.json'],
};
// role, kterou má jen ukázková doména (spravuje číselník a vidí všechna hlášení); prázdná appka ji nemá
const PRAZDNY_ROLE = 'editor';
const PRAZDNY_SOUBORY = [...PRAZDNY.odstranit, ...PRAZDNY.prepsat, ...PRAZDNY.upravit];

/** Manifest bez ukázkových listů a knihovny, web part bez vlastnosti seznam. Mění se jen to, co zná; jinak výjimka. */
export function prazdnyManifest(text) {
  const m = JSON.parse(text);
  for (const k of ['Kategorie', 'Hlaseni']) { if (!m.lists?.[k]) throw new Error(`manifest šablony nemá list ${k}`); delete m.lists[k]; }
  if (!m.libraries?.Prilohy) throw new Error('manifest šablony nemá knihovnu Prilohy');
  delete m.libraries.Prilohy;
  let seznam = 0;
  for (const p of Object.values(m.pages || {})) for (const w of p.webparts || []) if (w.properties && 'seznam' in w.properties) { delete w.properties.seznam; seznam++; }
  if (!seznam) throw new Error('manifest šablony nemá web part s vlastností seznam');
  // role ukázkové domény a její práva na zbylých objektech; vlastní úrovně oprávnění, které už nic nepoužívá
  if (!m.roles?.[PRAZDNY_ROLE]) throw new Error(`manifest šablony nemá roli ${PRAZDNY_ROLE}`);
  delete m.roles[PRAZDNY_ROLE];
  const objekty = [...Object.values(m.lists || {}), ...Object.values(m.libraries || {})];
  for (const o of objekty) if (o.access && typeof o.access === 'object') delete o.access[PRAZDNY_ROLE];
  const pouzite = new Set(objekty.flatMap((o) => (o.access && typeof o.access === 'object' ? Object.values(o.access) : [])));
  for (const [k, l] of Object.entries(m.levels || {})) if (l.custom && !pouzite.has(k)) delete m.levels[k];
  return JSON.stringify(m, null, 2) + '\n';
}

/** project_config.json bez mapování role ukázkové domény a bez lokálního uživatele, který ji měl jako jedinou. */
export function prazdnyConfig(text) {
  const c = JSON.parse(text);
  let mapovani = 0;
  for (const e of Object.values(c.environments || {})) {
    if (e.roles && PRAZDNY_ROLE in e.roles) { delete e.roles[PRAZDNY_ROLE]; mapovani++; }
    for (const [u, role] of Object.entries(e.users || {})) {
      const zbyle = role.filter((r) => r !== PRAZDNY_ROLE);
      if (zbyle.length === role.length) continue;
      mapovani++;
      if (zbyle.length) e.users[u] = zbyle; else delete e.users[u];
    }
  }
  if (!mapovani) throw new Error(`project_config.json šablony nemá mapování role ${PRAZDNY_ROLE}`);
  return JSON.stringify(c, null, 2) + '\n';
}

function uplatniPrazdny(dest) {
  for (const rel of PRAZDNY.prepsat) cpSync(join(SKILL, 'templates', 'project-prazdny', rel), join(dest, rel));
  const upravy = { 'sp/app.manifest.json': prazdnyManifest, 'project_config.json': prazdnyConfig };
  for (const rel of PRAZDNY.upravit) writeFileSync(join(dest, rel), upravy[rel](readFileSync(join(dest, rel), 'utf8')));
}

const KIT_POZN = 'verze a commit kitu, ze kterého projekt vznikl (devkit init); devkit diff <projekt> ukáže, čím se nástroje a datová vrstva od šablony liší';
/** Config s klíčem kit: existující kit doplní (pořadí jeho klíčů i souboru zůstává), chybějící vloží hned za app. */
export function configSKitem(cfg, kit) {
  if (cfg.kit) return { ...cfg, kit: { ...cfg.kit, ...kit } };
  const out = {};
  for (const [k, v] of Object.entries(cfg)) { out[k] = v; if (k === 'app') out.kit = kit; }
  if (!out.kit) out.kit = kit;
  return out;
}

/** Zapíše do project_config.json klíč kit (za app); zbytek souboru zůstává, jak je. */
function zapisKit(dest, prazdny) {
  const f = join(dest, 'project_config.json');
  const cfg = JSON.parse(readFileSync(f, 'utf8'));
  const info = kitInfo();
  const kit = { verze: info.verze, commit: info.commit, ...(prazdny ? { varianta: 'prazdny' } : {}), _pozn: KIT_POZN };
  writeFileSync(f, JSON.stringify(configSKitem(cfg, kit), null, 2) + '\n');
  return info;
}

// Projektové .claude/settings.json: pluginy, které init v projektu vypne. Šablona ten soubor nemá, protože
// se do existujícího nastavení slučuje (nic se nepřepisuje). Zápis je tentýž, jaký dělá
// `claude plugin disable <id> --scope project`: "enabledPlugins": { "<id>": false }.
//   ppf-sharepoint@ppf-skills: starý plugin s popisem „pro jakoukoli práci se SharePointem“; v projektu kitu
//   konkuruje skillu kitu a agent by se řídil jím.
const PROJEKT_VYPNUTE_PLUGINY = ['ppf-sharepoint@ppf-skills'];

/** Sloučí vypnuté pluginy do nastavení projektu. Klíč, který už v enabledPlugins je (i true), zůstane, jak je. */
export function nastaveniProjektu(stavajici = {}) {
  const enabledPlugins = { ...(stavajici.enabledPlugins || {}) };
  for (const id of PROJEKT_VYPNUTE_PLUGINY) if (!(id in enabledPlugins)) enabledPlugins[id] = false;
  return { ...stavajici, enabledPlugins };
}

/** Zapíše .claude/settings.json projektu; nečitelný existující soubor nechá být a ohlásí to. */
function zapisNastaveni(dest) {
  const f = join(dest, '.claude', 'settings.json');
  let stavajici = {};
  if (existsSync(f)) {
    try { stavajici = JSON.parse(readFileSync(f, 'utf8')); } catch (e) { console.error(`devkit: ${fwd(f)} není čitelný JSON (${e.message}), nechávám ho beze změny`); return; }
  }
  mkdirSync(dirname(f), { recursive: true });
  writeFileSync(f, JSON.stringify(nastaveniProjektu(stavajici), null, 2) + '\n');
}

// diff: rozsah porovnání s šablonou (složky celé, soubory jednotlivě)
const DIFF_SLOZKY = ['tools', 'spfx/src/app/data', 'spfx/src/feedback', 'spfx/harness', 'spfx/config'];
const DIFF_SOUBORY = ['spfx/eslint.config.js'];
// Soubory, kde projekt mění verzi řešení (solution.version a verze feature): řádky "version" se neporovnávají.
const BEZ_VERZE = new Set(['spfx/config/package-solution.json']);
const bezVerze = (s) => s.replace(/("version":\s*)"[^"\n]*"/g, '$1"*"');
/** Konce řádků se neporovnávají: checkout na Windows (autocrlf) není změna souboru. */
const lf = (s) => s.replace(/\r\n/g, '\n');
const TOKEN_RE = /__[A-Z]+(?:_[A-Z]+)*__/;
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
/** Soubor odpovídá šabloně, i když se liší jen dosazenými tokeny (__APP_NAME__, __PREFIX__, UUID…). */
export function odpovidaSablone(sablona, text, { verze = true } = {}) {
  sablona = lf(sablona); text = lf(text);
  if (!verze) { sablona = bezVerze(sablona); text = bezVerze(text); }
  if (sablona === text) return true;
  if (!TOKEN_RE.test(sablona)) return false;
  const re = new RegExp('^' + sablona.split(new RegExp(TOKEN_RE.source, 'g')).map(esc).join('[^\\n]*?') + '$');
  return re.test(text);
}
/** Jméno, pod kterým šablona nese .gitignore (viz hlavička). */
export const GITIGNORE_V_SABLONE = 'gitignore';
function soubory(root, sub) {
  const base = join(root, sub);
  if (!existsSync(base)) return [];
  return readdirSync(base, { recursive: true, withFileTypes: true })
    .filter((e) => e.isFile() && e.name !== '.DS_Store')
    .map((e) => fwd(relative(root, join(e.parentPath ?? e.path, e.name))))
    .filter((r) => !r.split('/').includes('node_modules'));
}

// ---------- generovaný vzhled: --check generátorů (diff i update) ----------
const VZHLED_GEN = [['ppfMuiTheme.ts', 'gen-mui-theme.mjs'], ['ppf-fonts.scss', 'gen-fonts-scss.mjs'], ['ppfDesign.json', 'gen-design-values.mjs']];
/** → [{ soub, rel, stav: 'chybi'|'zmeneno'|'hlavicka'|'ok' }] pro generované soubory vzhledu v projektu. */
function vzhledStav(proj, matDir) {
  const ppf = join(proj, 'spfx', 'src', 'app', 'ppf');
  return VZHLED_GEN.map(([soub, gen]) => {
    const rel = `spfx/src/app/ppf/${soub}`;
    if (!existsSync(join(ppf, soub))) return { soub, rel, gen, stav: 'chybi' };
    const r = spawnSync(process.execPath, [join(SCRIPTS, 'spfx', gen), matDir, '--out', join(ppf, soub), '--check'], { encoding: 'utf8' });
    return { soub, rel, gen, stav: r.status !== 0 ? 'zmeneno' : /^INFO/.test(r.stdout) ? 'hlavicka' : 'ok' };
  });
}

// ---------- update: třícestné porovnání s otisky šablony (viz hlavička) ----------
// Obsah, který patří projektu: update ho nečte ani nepíše (package.json se řeší po klíčích zvlášť).
const UPDATE_VYNECHAT = new Set(['project_config.json', 'DEVKIT-VYJIMKY.md', 'CLAUDE.md', 'spfx/src/app/App.tsx', 'spfx/src/app/App.module.scss',
  'package.json', 'package-lock.json', 'spfx/package-lock.json']);
const UPDATE_VYNECHAT_SLOZKY = ['sp/'];
const BLOCKS_V_PROJEKTU = 'spfx/src/app/ppf/blocks.tsx';
const PKG_SEKCE = ['scripts', 'devDependencies'];
const OTISKY = join(SKILL, 'templates', 'otisky.json');
/** sha256 textu po převodu konců řádků na LF (hex). */
export const otisk = (text) => createHash('sha256').update(lf(text)).digest('hex');
/** Cesta souboru šablony → cesta v projektu (gitignore → .gitignore, jako init). */
export const cestaVProjektu = (rel) => rel.split('/').map((c, i, a) => (i === a.length - 1 && c === GITIGNORE_V_SABLONE ? '.gitignore' : c)).join('/');
/**
 * Otisky jedné verze šablony: soubory = [[cesta v templates/project, text]], blocks = text scripts/spfx/ppf-blocks.tsx,
 * pkg = text templates/project/package.json. Stejná funkce počítá živou šablonu i tagy (dev/sablona-otisky.mjs).
 */
export function otiskyVerze(soubory, blocks, pkg) {
  const out = {};
  for (const [rel, text] of soubory) out[cestaVProjektu(rel)] = otisk(text);
  if (blocks != null) out[BLOCKS_V_PROJEKTU] = otisk(blocks);
  const p = JSON.parse(pkg);
  const sorted = Object.fromEntries(Object.keys(out).sort().map((k) => [k, out[k]]));
  return { soubory: sorted, package: Object.fromEntries(PKG_SEKCE.map((s) => [s, p[s] || {}])) };
}
/** Patří cesta (v projektu) do rozsahu update? */
export function vRozsahuUpdate(rel, { prazdny = false } = {}) {
  if (UPDATE_VYNECHAT.has(rel) || UPDATE_VYNECHAT_SLOZKY.some((s) => rel.startsWith(s))) return false;
  return !(prazdny && PRAZDNY_SOUBORY.includes(rel));
}

/**
 * Jádro třícestného rozhodnutí nad porovnatelnými hodnotami (otisk souboru nebo hodnota klíče package.json).
 * zaklad/novy/projekt: hodnota, nebo undefined = v té straně není; znamy = false → základ neznámý.
 * → { druh, duvod? } nebo null (nic k hlášení: mimo šablonu, zrušené a v projektu už smazané).
 */
export function rozhodni({ zaklad, novy, projekt, znamy = true }) {
  const neznamy = 'základ neznámý: slouč ručně';
  if (novy === undefined) {
    if (!znamy || zaklad === undefined || projekt === undefined) return null;
    if (projekt === zaklad) return { druh: 'zruseno', duvod: 'šablona ho zrušila, projekt ho nezměnil: nepotřebuje-li ho projekt, smaž ho přes koš' };
    return { druh: 'vlastni', duvod: 'šablona ho zrušila, projekt ho upravil' };
  }
  if (projekt === undefined) {
    if (!znamy) return { druh: 'konflikt', duvod: `chybí v projektu, ${neznamy}` };
    return zaklad === undefined ? { druh: 'pridat' } : { druh: 'konflikt', duvod: 'v projektu chybí (smazaný, nebo ho projekt nikdy neměl), šablona ho má dál' };
  }
  if (projekt === novy) return { druh: 'stejne' };
  if (!znamy) return { druh: 'konflikt', duvod: neznamy };
  if (zaklad === novy) return { druh: 'vlastni' };
  if (projekt === zaklad) return { druh: 'prevzit' };
  return { druh: 'konflikt', duvod: zaklad === undefined ? 'šablona soubor přidala, projekt má vlastní: slouč ručně' : 'změnil ho projekt i šablona: slouč ručně' };
}

/**
 * Rozhodnutí pro soubor. zaklad = otisk ze základu (undefined = v základu nebyl), novy/projekt = text nebo undefined.
 * Soubor šablony s tokeny (__APP_NAME__…) má v projektu dosazené hodnoty: s projektem se porovná přes odpovidaSablone.
 */
export function rozhodniSoubor({ rel, zaklad, novy, projekt, znamy = true }) {
  if (novy !== undefined && TOKEN_RE.test(lf(novy))) {
    if (projekt === undefined) return { druh: 'konflikt', duvod: 'soubor s tokeny šablony v projektu chybí: doplň ho ručně s hodnotami projektu' };
    if (odpovidaSablone(novy, projekt, { verze: !BEZ_VERZE.has(rel) })) return { druh: 'stejne' };
    if (znamy && zaklad === otisk(novy)) return { druh: 'vlastni' };
    return { druh: 'konflikt', duvod: znamy ? 'soubor s dosazenými hodnotami projektu, šablona ho změnila: slouč ručně' : 'soubor s dosazenými hodnotami projektu, základ neznámý: slouč ručně' };
  }
  return rozhodni({ zaklad, novy: novy === undefined ? undefined : otisk(novy), projekt: projekt === undefined ? undefined : otisk(projekt), znamy });
}

/** Rozhodnutí pro scripts/devDependencies package.json: → [{ sek, klic, druh, duvod?, hodnota }] (bez stejne). */
export function rozhodniPackage({ zaklad, novy, projekt, znamy = true }) {
  const out = [];
  for (const sek of PKG_SEKCE) {
    const z = zaklad?.[sek] || {}, n = novy?.[sek] || {}, p = projekt?.[sek] || {};
    const klice = [...new Set([...Object.keys(z), ...Object.keys(n), ...Object.keys(p)])].sort();
    for (const klic of klice) {
      const r = rozhodni({ zaklad: z[klic], novy: n[klic], projekt: p[klic], znamy });
      if (r && r.druh !== 'stejne') out.push({ sek, klic, ...r, hodnota: n[klic] });
    }
  }
  return out;
}

/** Text package.json s převzatými klíči: existující klíč drží místo, nový jde na konec sekce, zbytek souboru beze změny. */
export function upravPackage(text, zmeny) {
  const p = JSON.parse(text);
  for (const { sek, klic, hodnota } of zmeny) { if (!p[sek]) p[sek] = {}; p[sek][klic] = hodnota; }
  return JSON.stringify(p, null, 2) + '\n';
}

/**
 * Plán update (čistá funkce). zaklad = otisky verze ({ soubory, package }) nebo null (neznámý), nova = { soubory:
 * Map cesta v projektu → text, package }, projekt = { cti(rel) → text|undefined, package }, prazdny.
 * → { soubory: [{ rel, druh, duvod? }], package: [...], stejne: počet }
 */
export function planUpdate({ zaklad, nova, projekt, prazdny = false }) {
  const znamy = !!zaklad;
  const rels = new Set([...nova.soubory.keys(), ...Object.keys(zaklad?.soubory || {})]);
  const soubory = [];
  let stejne = 0;
  for (const rel of [...rels].sort()) {
    if (!vRozsahuUpdate(rel, { prazdny })) continue;
    const r = rozhodniSoubor({ rel, zaklad: zaklad?.soubory?.[rel], novy: nova.soubory.get(rel), projekt: projekt.cti(rel), znamy });
    if (!r) continue;
    if (r.druh === 'stejne') stejne++;
    else soubory.push({ rel, ...r });
  }
  const pkg = rozhodniPackage({ zaklad: zaklad?.package, novy: nova.package, projekt: projekt.package, znamy });
  return { soubory, package: pkg, stejne };
}

/** Dnešní šablona kitu: Map cesta v projektu → text a sekce package.json. */
function zivaSablona() {
  const tpl = join(SKILL, 'templates', 'project');
  const mapa = new Map(soubory(tpl, '').map((rel) => [cestaVProjektu(rel), readFileSync(join(tpl, rel), 'utf8')]));
  mapa.set(BLOCKS_V_PROJEKTU, readFileSync(join(SCRIPTS, 'spfx', 'ppf-blocks.tsx'), 'utf8'));
  const pkg = readFileSync(join(tpl, 'package.json'), 'utf8');
  return { soubory: mapa, package: otiskyVerze([], null, pkg).package };
}

/**
 * Základ pro projekt verze kitVerze: záznam otisky.json; bez něj, je-li kitVerze verze kitu, živá šablona (otiskyZive());
 * jinak null = neznámý. → { zaklad, popis }
 */
export function vyberZaklad(otisky, kitVerze, verzeKitu, otiskyZive) {
  if (!kitVerze) return { zaklad: null, popis: 'základ neznámý (project_config.json nemá kit.verze)' };
  if (otisky?.[kitVerze]) return { zaklad: otisky[kitVerze], popis: `základ: otisky šablony ${kitVerze} (templates/otisky.json)` };
  if (kitVerze === verzeKitu) return { zaklad: otiskyZive(), popis: `základ: dnešní šablona (projekt je na verzi kitu ${kitVerze})` };
  return { zaklad: null, popis: `základ neznámý (templates/otisky.json nemá záznam pro verzi ${kitVerze})` };
}

const commands = {
  help() {
    console.log(`devkit — CLI pluginu ppf-citizen-ai-devkit.
Spouštěj:  node "${fwd(join(SCRIPTS, 'devkit.mjs'))}" <příkaz>

 init <složka> --name "<Název>" --prefix <PREFIX> [--prazdny] [--install] [--material <složka skillu ppf-material>]
        NOVÝ projekt ze šablony s prvním commitem; --install = i npm ci; --prazdny = bez ukázkové domény (prázdná appka v AppShell).
        Zapíše project_config.json → kit { verze, commit } kitu a do .claude/settings.json vypne plugin ppf-sharepoint.
        Všechno další se dělá v projektu: npm run prereq|dev|gen|build|deploy|sp|probe|feedback|m365|test|check-all
 diff <složka projektu> [--material <složka skillu ppf-material>]
        JEN ČTE: čím se tools/, spfx/src/app/data, spfx/src/feedback, spfx/harness, spfx/config, spfx/eslint.config.js, scripts a devDependencies
        v package.json a generovaný vzhled liší od šablony kitu (konce řádků a verze řešení se neporovnávají). Řádek na soubor: zmeneno|chybi|navic<TAB>cesta; exit 0 bez rozdílů, 10 rozdíly, 2 chyba použití.
 update <složka projektu> [--material <složka skillu ppf-material>] [--zapsat]
        Převezme změny šablony od verze kit.verze projektu (třícestně přes templates/otisky.json); sp/, App.tsx, App.module.scss,
        project_config.json, CLAUDE.md, DEVKIT-VYJIMKY.md a zámky nechá být, package.json jen scripts/devDependencies.
        Bez --zapsat JEN ČTE a vypíše plán: druh<TAB>cesta[<TAB>důvod], druh = prevzit|pridat|konflikt|zruseno|vlastni|vzhled;
        exit 0 nic k převzetí, 10 plán má akce nebo konflikty (nic nezapsáno), 2 chyba použití.
        --zapsat (jen čistý git strom): zapíše prevzit, pridat, klíče package.json, vzhled a kit.verze/commit; nic nemaže,
        necommituje; exit 0 hotovo, 11 zapsáno a zůstaly konflikty/zruseno. Konflikt slouč hned: příští update ho znovu
        ohlásí, jen když šablona soubor změní znovu.
 theme <ppf-dir> --material <složka skillu ppf-material> [--check]   ppfMuiTheme.ts, ppf-fonts.scss, ppfDesign.json, blocks.tsx
        vygeneruje ppfMuiTheme.ts + ppf-fonts.scss (PPF vzhled pro MUI) z aktuálního skillu ppf-material`);
  },

  init(args) {
    // Nový projekt ze šablony templates/project (ověřeno na DEV web 2026-11-09 a 2026-11-11).
    const name = flag(args, '--name');
    const prefix = flag(args, '--prefix');
    const install = has(args, '--install');
    const prazdny = has(args, '--prazdny');
    const target = args[0];
    if (!target || !name || !prefix) die('init <složka> --name "<Název appky>" --prefix <PREFIX> [--prazdny] [--install]', 2);
    if (!/^[A-Za-z][A-Za-z0-9]{1,15}$/.test(prefix)) die('--prefix: 2–16 znaků, písmena a číslice, začíná písmenem (dává se před názvy SP objektů appky)', 2);
    const dest = resolve(target);
    if (existsSync(dest) && readdirSync(dest).length) die(`${fwd(dest)} existuje a není prázdná — init nic nepřepisuje`, 2);
    // vzhled: theme a stavební bloky (spfx/src/app/ppf) se generují ze skillu ppf-material — šablona appky je importuje
    const matArg = flag(args, '--material');   // flag() hodnotu z args odebere, čte se jednou
    const matDir = matArg ? resolve(matArg) : findMaterial();
    if (!matDir || !existsSync(join(matDir, 'tokens', 'tokens.json'))) die('nenalezen skill ppf-material (tokens/tokens.json): nainstaluj plugin ppf-material z marketplace ppf-skills, nebo předej --material <složka skillu>', 2);
    const pkgName = name.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'spfx-app';
    const uuid = () => globalThis.crypto.randomUUID();
    const tokens = { __APP_NAME__: name.replace(/["\\]/g, ''), __PACKAGE_NAME__: pkgName, __PREFIX__: prefix, __SOLUTION_ID__: uuid(), __FEATURE_ID__: uuid(), __WEBPART_ID__: uuid() };
    const sub = (s) => Object.entries(tokens).reduce((a, [k, v]) => a.split(k).join(v), s);
    // --prazdny: ukázková data a texty se nekopírují vůbec (nic se nemaže)
    const bezUkazky = (src) => !prazdny || !PRAZDNY.odstranit.includes(fwd(relative(join(SKILL, 'templates', 'project'), src)));
    cpSync(join(SKILL, 'templates', 'project'), dest, { recursive: true, filter: bezUkazky });
    if (prazdny) uplatniPrazdny(dest);   // před dosazením tokenů: přepsaný App.tsx má __APP_NAME__ taky
    const walkDir = (d) => {
      for (const e of readdirSync(d, { withFileTypes: true })) {
        let p = join(d, e.name);
        if (e.isFile() && e.name === GITIGNORE_V_SABLONE) { const np = join(d, '.gitignore'); renameSync(p, np); p = np; }
        if (e.name.includes('__')) { const np = join(d, sub(e.name)); renameSync(p, np); p = np; }
        if (e.isDirectory()) { walkDir(p); continue; }
        if (/\.(png|jpe?g|ico|woff2?)$/i.test(p)) continue;
        const s = readFileSync(p, 'utf8');
        const o = sub(s);
        if (o !== s) writeFileSync(p, o);
      }
    };
    walkDir(dest);
    if (!existsSync(join(dest, '.gitignore'))) die(`šablona nemá ${GITIGNORE_V_SABLONE} v kořeni: projekt by commitoval node_modules a přihlášení (poškozená instalace pluginu?)`, 2);
    const kit = zapisKit(dest, prazdny);
    zapisNastaveni(dest);   // .claude/settings.json: vypnutý ppf-sharepoint (viz PROJEKT_VYPNUTE_PLUGINY)
    commands.theme([join(dest, 'spfx', 'src', 'app', 'ppf'), '--material', matDir]);
    if (process.exitCode) die('devkit theme selhalo — projekt je založený, ale bez spfx/src/app/ppf');
    spawnSync('git', ['init', '-q', '-b', 'main'], { cwd: dest, stdio: 'inherit' });
    console.log(`projekt „${tokens.__APP_NAME__}“ (prefix ${prefix}, balík ${pkgName}${prazdny ? ', prázdný' : ''}) založen v ${fwd(dest)}; kit ${kit.verze ?? '?'} (${kit.commit ?? 'commit neznámý'})`);
    varujNevydany(kitInfo(), true);
    if (install) {
      for (const a of [['ci'], ['--prefix', 'spfx', 'ci']]) {
        console.log(`\n> npm ${a.join(' ')}`);
        if (run('npm', a, { cwd: dest }).status !== 0) die(`npm ${a.join(' ')} selhalo. Projekt v ${fwd(dest)} je založený, ale bez úplných závislostí a BEZ prvního commitu; init znovu nepouštěj (do neprázdné složky nezapisuje). Odstraň příčinu (časté: plný disk, závislosti zaberou přes 1,5 GB; síť) a navaž v té složce:\n  npm ci && npm --prefix spfx ci\n  git add . && git commit -m "Nový projekt ${tokens.__APP_NAME__} ze šablony ppf-citizen-ai-devkit"`);
      }
    }
    // první commit: záznam prvního nasazení pak nese commit (ne null/dirty); bez identity gitu jen hláška
    const g = (a) => spawnSync('git', a, { cwd: dest, encoding: 'utf8' });
    const ga = g(['add', '.']);
    const gc = ga.status === 0 ? g(['commit', '-q', '-m', `Nový projekt ${tokens.__APP_NAME__} ze šablony ppf-citizen-ai-devkit`]) : ga;
    console.log(gc.status === 0 ? 'první commit hotový' : `první commit se nepovedl (${(gc.stderr || '').trim()}) — nastav git user.name/user.email a commitni ručně`);
    console.log(`
Dál (v ${fwd(dest)}):
${install ? '' : '  npm ci && npm --prefix spfx ci\n'}  project_config.json: environments.dev.site (+ mapování rolí); m365 je předvyplněné pro PPF tenant
  npm run prereq                         vypíše přihlášení do m365 (otevře prohlížeč — člověk) a vše, co chybí
  npm run dev -- --port <port>           lokální appka nad mocky
  cockpit                                publikuj ho a adresu zapiš do project_config.json → cockpit.url (references/cockpit.md);
                                         je podmínka každého nasazení, i na DEV
  node ${fwd(join(SCRIPTS, 'doctor.mjs'))} --project ${fwd(dest)} --pred-nasazenim
                                         před prvním nasazením: co ještě chybí (git, web, katalog aplikací, cockpit, vzhled)
  npm run deploy -- --env dev            plán nasazení na DEV; zápis až --confirm <hash> po ano člověka`);
  },

  diff(args) {
    const mat = flag(args, '--material');
    const dir = args[0];
    if (!dir) die('diff <složka projektu> [--material <složka skillu ppf-material>]', 2);
    const proj = resolve(dir);
    if (!existsSync(join(proj, 'project_config.json'))) die(`${fwd(proj)} není projekt kitu (chybí project_config.json)`, 2);
    const tpl = join(SKILL, 'templates', 'project');
    let cfg;
    try { cfg = JSON.parse(readFileSync(join(proj, 'project_config.json'), 'utf8')); } catch (e) { die(`project_config.json: ${e.message}`, 2); }
    const now = kitInfo();
    const kit = cfg.kit;
    const prazdny = kit?.varianta === 'prazdny';
    const radky = [];
    const info = (s) => console.log(`# ${s}`);
    info(kit ? `projekt: kit ${kit.verze ?? '?'} (${kit.commit ?? 'commit neznámý'})${prazdny ? ', varianta prázdný' : ''}` : 'projekt: neznámá verze kitu (project_config.json nemá klíč kit — vznikl před devkit diff)');
    info(`šablona: kit ${now.verze ?? '?'} (${now.commit ?? 'commit neznámý'})`);
    varujNevydany(now, false);
    const preskocit = new Set(prazdny ? PRAZDNY_SOUBORY : []);
    const vRozsahu = [...preskocit].filter((r) => DIFF_SLOZKY.some((s) => r.startsWith(s + '/')));
    if (vRozsahu.length) info(`varianta prázdný: neporovnává se ${vRozsahu.join(', ')}`);

    // soubory nástrojů, datové vrstvy a harnessu
    const rels = new Set([...DIFF_SLOZKY.flatMap((s) => [...soubory(tpl, s), ...soubory(proj, s)]), ...DIFF_SOUBORY]);
    for (const rel of [...rels].sort()) {
      if (preskocit.has(rel)) continue;
      const t = existsSync(join(tpl, rel)), p = existsSync(join(proj, rel));
      if (t && !p) radky.push(['chybi', rel]);
      else if (!t && p) radky.push(['navic', rel]);
      else if (!t && !p) continue;
      else if (!odpovidaSablone(readFileSync(join(tpl, rel), 'utf8'), readFileSync(join(proj, rel), 'utf8'), { verze: !BEZ_VERZE.has(rel) })) radky.push(['zmeneno', rel]);
    }

    // package.json: jen scripts a devDependencies
    let pt, pp;
    try { pt = JSON.parse(readFileSync(join(tpl, 'package.json'), 'utf8')); pp = JSON.parse(readFileSync(join(proj, 'package.json'), 'utf8')); } catch (e) { die(`package.json: ${e.message}`, 2); }
    for (const sek of ['scripts', 'devDependencies']) {
      const a = pt[sek] || {}, b = pp[sek] || {};
      for (const k of [...new Set([...Object.keys(a), ...Object.keys(b)])].sort()) {
        if (!(k in b)) radky.push(['chybi', `package.json#${sek}.${k}`]);
        else if (!(k in a)) radky.push(['navic', `package.json#${sek}.${k}`]);
        else if (a[k] !== b[k]) radky.push(['zmeneno', `package.json#${sek}.${k}`]);
      }
    }

    // generovaný vzhled: theme --check (hodnoty z nainstalovaného ppf-material; jen hlavička = INFO, ne rozdíl)
    const matDir = mat ? resolve(mat) : findMaterial();
    const ppf = join(proj, 'spfx', 'src', 'app', 'ppf');
    if (!matDir || !existsSync(join(matDir, 'tokens', 'tokens.json'))) info('vzhled: neporovnáno, nenalezen skill ppf-material (předej --material <složka skillu>)');
    else {
      for (const { soub, rel, stav } of vzhledStav(proj, matDir)) {
        if (stav === 'chybi' || stav === 'zmeneno') radky.push([stav, rel]);
        else if (stav === 'hlavicka') info(`vzhled: ${soub} liší se jen hlavička (verze/zdroj tokenů)`);
      }
      const blocks = join(ppf, 'blocks.tsx');
      if (!existsSync(blocks)) radky.push(['chybi', 'spfx/src/app/ppf/blocks.tsx']);
      else if (lf(readFileSync(blocks, 'utf8')) !== lf(readFileSync(join(SCRIPTS, 'spfx', 'ppf-blocks.tsx'), 'utf8'))) radky.push(['zmeneno', 'spfx/src/app/ppf/blocks.tsx']);
    }
    for (const [druh, rel] of radky) console.log(`${druh}\t${rel}`);
    info(radky.length ? `${radky.length} rozdílů` : 'bez rozdílů');
    process.exitCode = radky.length ? 10 : 0;
  },

  update(args) {
    const mat = flag(args, '--material');
    const zapsat = has(args, '--zapsat');
    const dir = args[0];
    if (!dir || args.length > 1) die('update <složka projektu> [--material <složka skillu ppf-material>] [--zapsat]', 2);
    const proj = resolve(dir);
    if (!existsSync(join(proj, 'project_config.json'))) die(`${fwd(proj)} není projekt kitu (chybí project_config.json)`, 2);
    let cfg, pkgText, otisky;
    try { cfg = JSON.parse(readFileSync(join(proj, 'project_config.json'), 'utf8')); } catch (e) { die(`project_config.json: ${e.message}`, 2); }
    try { pkgText = readFileSync(join(proj, 'package.json'), 'utf8'); JSON.parse(pkgText); } catch (e) { die(`package.json projektu: ${e.message}`, 2); }
    try { otisky = JSON.parse(readFileSync(OTISKY, 'utf8')); } catch (e) { die(`${fwd(OTISKY)}: ${e.message} (poškozená instalace pluginu?)`); }
    const now = kitInfo();
    const kit = cfg.kit;
    const prazdny = kit?.varianta === 'prazdny';
    const nova = zivaSablona();
    const { zaklad, popis } = vyberZaklad(otisky, kit?.verze, now.verze, () => otiskyVerze([...nova.soubory].filter(([r]) => r !== BLOCKS_V_PROJEKTU), nova.soubory.get(BLOCKS_V_PROJEKTU), readFileSync(join(SKILL, 'templates', 'project', 'package.json'), 'utf8')));
    const info = (s) => console.log(`# ${s}`);
    info(`projekt: kit ${kit?.verze ?? '?'} (${kit?.commit ?? 'commit neznámý'})${prazdny ? ', varianta prázdný' : ''} → kit ${now.verze ?? '?'} (${now.commit ?? 'commit neznámý'})`);
    info(zaklad ? popis : `${popis}: co se liší od dnešní šablony, je konflikt`);
    varujNevydany(now, zapsat);
    const cti = (rel) => { const f = join(proj, rel); try { return readFileSync(f, 'utf8'); } catch { return undefined; } };
    const plan = planUpdate({ zaklad, nova, projekt: { cti, package: JSON.parse(pkgText) }, prazdny });
    const radky = [
      ...plan.soubory.map((r) => [r.druh, r.rel, r.duvod]),
      ...plan.package.map((r) => [r.druh, `package.json#${r.sek}.${r.klic}`, r.duvod]),
    ];

    // generovaný vzhled: přegenerování podle --check generátorů (bez ppf-material jen ohlas, update kvůli tomu neselže)
    const matDir = mat ? resolve(mat) : findMaterial();
    let vzhled = [];
    if (!matDir || !existsSync(join(matDir, 'tokens', 'tokens.json'))) info('vzhled: neporovnáno, nenalezen skill ppf-material (předej --material <složka skillu>)');
    else {
      vzhled = vzhledStav(proj, matDir).filter((v) => v.stav === 'chybi' || v.stav === 'zmeneno');
      for (const v of vzhled) radky.push(['vzhled', v.rel, v.stav === 'chybi' ? 'chybí: vygeneruje se' : 'neodpovídá nainstalovanému ppf-material: přegeneruje se']);
    }
    radky.sort((a, b) => (a[0] + '\t' + a[1]).localeCompare(b[0] + '\t' + b[1]));
    const pocty = {};
    for (const [druh] of radky) pocty[druh] = (pocty[druh] || 0) + 1;
    for (const r of radky) console.log(r.filter((x) => x !== undefined).join('\t'));
    info(`stejne ${plan.stejne}; ${Object.entries(pocty).map(([k, v]) => `${k} ${v}`).join(', ') || 'nic k převzetí'}`);
    const akce = radky.filter(([d]) => d === 'prevzit' || d === 'pridat' || d === 'vzhled');
    const kRuce = radky.filter(([d]) => d === 'konflikt' || d === 'zruseno');
    if (!zapsat) {
      if (akce.length || kRuce.length) info('nic nezapsáno; převzetí: znovu s --zapsat (jen v čistém git stromu)');
      process.exitCode = akce.length || kRuce.length ? 10 : 0;
      return;
    }

    // --zapsat: jen v čistém git stromu, aby šly změny projít git diff a vrátit
    const st = spawnSync('git', ['status', '--porcelain'], { cwd: proj, encoding: 'utf8' });
    if (st.error || st.status !== 0) die(`${fwd(proj)} není git repo (${(st.stderr || st.error?.message || '').trim()}): update zapisuje jen do repa, kde jdou změny projít git diff a vrátit`);
    if (st.stdout.trim()) die(`${fwd(proj)} má necommitnuté změny: commitni je nebo odlož (git stash) a spusť update znovu\n${st.stdout.trimEnd()}`);
    for (const r of plan.soubory.filter((x) => x.druh === 'prevzit' || x.druh === 'pridat')) {
      mkdirSync(dirname(join(proj, r.rel)), { recursive: true });
      writeFileSync(join(proj, r.rel), nova.soubory.get(r.rel));
    }
    const pkgZmeny = plan.package.filter((x) => x.druh === 'prevzit' || x.druh === 'pridat');
    if (pkgZmeny.length) writeFileSync(join(proj, 'package.json'), upravPackage(pkgText, pkgZmeny));
    let chyba = false;
    if (vzhled.length) mkdirSync(join(proj, 'spfx', 'src', 'app', 'ppf'), { recursive: true });
    for (const v of vzhled) {
      const r = run(process.execPath, [join(SCRIPTS, 'spfx', v.gen), matDir, '--out', join(proj, v.rel)]);
      if (r.status !== 0) { console.error(`devkit: ${v.gen} selhal (rc ${r.status}): ${v.rel} nepřegenerován`); chyba = true; }
    }
    writeFileSync(join(proj, 'project_config.json'), JSON.stringify(configSKitem(cfg, { verze: now.verze, commit: now.commit }), null, 2) + '\n');
    const zavislosti = pkgZmeny.some((x) => x.sek === 'devDependencies') || plan.soubory.some((x) => x.rel === 'spfx/package.json' && (x.druh === 'prevzit' || x.druh === 'pridat'));
    const konflikty = radky.filter(([d]) => d === 'konflikt').map(([, rel]) => rel);
    const zruseno = radky.filter(([d]) => d === 'zruseno').map(([, rel]) => rel);
    console.log(`\nzapsáno: ${akce.length} převzato/přidáno/přegenerováno; project_config.json → kit ${now.verze ?? '?'} (${now.commit ?? 'commit neznámý'}); nic necommitnuto
Dál (v ${fwd(proj)}):
${zavislosti ? '  npm install && npm --prefix spfx install     změnily se závislosti\n' : ''}  npm run check-all
${[...akce.map(([, rel]) => rel), ...konflikty].some((rel) => rel.startsWith('spfx/')) ? '  zvedni solution.version (spfx/config/package-solution.json)   update změnil kód appky (nebo ho změní sloučení konfliktu ve spfx/): stejná verze s jiným kódem se nenasadí (nález balíček)\n  npm run build && npm run design-check                          až po zvednutí verze: změna verze i kódu úplnou kontrolu vzhledu zneplatní\n' : ''}${konflikty.length ? `  sloučit ručně HNED (příští update je znovu neohlásí, devkit diff ano):\n${konflikty.map((r) => `    ${r}`).join('\n')}\n` : ''}${zruseno.length ? `  šablona zrušila (smaž přes koš, nepotřebuje-li je projekt):\n${zruseno.map((r) => `    ${r}`).join('\n')}\n` : ''}  každou vlastní odchylku od šablony zapsat do DEVKIT-VYJIMKY.md
  git diff, pak commit`);
    process.exitCode = chyba ? 1 : konflikty.length || zruseno.length ? 11 : 0;
  },

  theme(args) {
    // Zdroj vzhledu je skill ppf-material (plugin z marketplace ppf-skills), ne kopie v kitu:
    // agent načte skill ppf-material a předá jeho složku, takže se bere vždy nainstalovaná verze.
    const check = has(args, '--check');
    const mat = flag(args, '--material');
    const out = resolve(args[0] || die('theme <adresář pro ppfMuiTheme.ts a ppf-fonts.scss> --material <složka skillu ppf-material>', 2));
    if (!mat) die('chybí --material <složka skillu ppf-material>: načti skill ppf-material a předej jeho základní složku (obsahuje tokens/tokens.json)', 2);
    const matDir = resolve(mat);
    if (!existsSync(join(matDir, 'tokens', 'tokens.json'))) die(`${fwd(matDir)} není skill ppf-material (chybí tokens/tokens.json)`, 2);
    if (!check) mkdirSync(out, { recursive: true });   // cílová složka (např. spfx/src/app/ppf) v šabloně není
    let st = 0;
    st ||= run(process.execPath, [join(SCRIPTS, 'spfx', 'gen-mui-theme.mjs'), matDir, '--out', join(out, 'ppfMuiTheme.ts'), ...(check ? ['--check'] : [])]).status;
    st ||= run(process.execPath, [join(SCRIPTS, 'spfx', 'gen-fonts-scss.mjs'), matDir, '--out', join(out, 'ppf-fonts.scss'), ...(check ? ['--check'] : [])]).status;
    // hodnoty pro kontrolu vzhledu (tools/design-check.mjs) — ze stejných tokenů jako theme
    st ||= run(process.execPath, [join(SCRIPTS, 'spfx', 'gen-design-values.mjs'), matDir, '--out', join(out, 'ppfDesign.json'), ...(check ? ['--check'] : [])]).status;
    // --check: rozdíl jen v hlavičce generovaného souboru (verze a zdroj tokenů) generátor vypíše jako INFO a vrátí 0
    // stavební bloky obrazovky (AppShell, DataTable, DetailPanel, ConfirmDialog, StatusBadge…) — kopie z kitu, v projektu se neupravují
    const blocks = readFileSync(join(SCRIPTS, 'spfx', 'ppf-blocks.tsx'), 'utf8');
    const dest = join(out, 'blocks.tsx');
    if (check) {
      if (!existsSync(dest) || readFileSync(dest, 'utf8') !== blocks) { console.error(`${fwd(dest)} neodpovídá kitu — devkit theme ${fwd(out)} --material …`); st ||= 1; }
    } else writeFileSync(dest, blocks);
    process.exitCode = st;
  },
};

// CLI se spustí jen při přímém spuštění; import (dev/devkit.test.mjs) zpřístupní jen exportované funkce
if (process.argv[1] && realpathSync(process.argv[1]) === realpathSync(fileURLToPath(import.meta.url))) {
  let [cmd = 'help', ...rest] = process.argv.slice(2);
  if (cmd === '--help' || cmd === '-h') cmd = 'help';
  (Object.hasOwn(commands, cmd) && commands[cmd] || (() => { commands.help(); die(`neznámý příkaz: ${cmd}`, 2); }))(rest);
}
