#!/usr/bin/env node
// PreToolUse(Bash|PowerShell) hook pluginu: v projektu ze šablony (kořen s project_config.json
// a tools/m365.mjs) odmítne m365 mimo projektový wrapper a pošle agenta na `npm run m365 -- …`.
//
// Holé `m365`, `npx @pnp/cli-microsoft365` apod. sahají na globální přihlášení a jinou verzi CLI
// než pinnutou v projektu; projektový wrapper má vlastní přihlášení projektu (tenant neověřuje, je průchozí).
// Rozpoznání příkazu dělá vendorovaný prefer-lookup.mjs (z pluginu m365-cli-12 v ppf-skills, licence MIT vedle).
// `npm run m365 …` jako m365 nepozná, takže projde i s --help (nápověda CLI je v projektu v pořádku).
// Mimo projekt ze šablony hook nic nerozhoduje. Jen odmítá, nikdy neupravuje.
import { spawnSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const input = readFileSync(0);

function projectRoot(start) {
  for (let d = resolve(start); ; d = dirname(d)) {
    if (existsSync(join(d, 'project_config.json')) && existsSync(join(d, 'tools', 'm365.mjs'))) return d;
    if (dirname(d) === d) return null;
  }
}

let payload = {};
try { payload = JSON.parse(input.toString('utf8')); } catch { process.exit(0); }
const root = projectRoot(typeof payload.cwd === 'string' ? payload.cwd : process.env.CLAUDE_PROJECT_DIR || process.cwd());
if (!root) process.exit(0);

const r = spawnSync(process.execPath, [join(HERE, 'prefer-lookup.mjs')], { input, encoding: 'utf8' });
if (r.stderr) process.stderr.write(r.stderr);
let decision;
try { decision = JSON.parse((r.stdout || '').trim()); } catch { process.exit(0); }
if (!decision?.hookSpecificOutput) process.exit(0);
decision.hookSpecificOutput.permissionDecisionReason =
  `Projekt ${root}: m365 spouštěj z kořene projektu jako  npm run m365 -- <příkaz>  ` +
  '(pinnutá verze z package.json projektu, vlastní přihlášení projektu). ' +
  'Nápověda: npm run m365 -- <příkaz> --help. Holé m365 ani npx tady nepoužívej. ' +
  'Nasazení jen přes npm run deploy; jiný zápis ručním m365 jen po ano člověka.';
process.stdout.write(`${JSON.stringify(decision)}\n`);
