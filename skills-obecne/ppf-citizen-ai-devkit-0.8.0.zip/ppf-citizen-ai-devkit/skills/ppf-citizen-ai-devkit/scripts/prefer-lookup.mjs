#!/usr/bin/env node
// PreToolUse(Bash|PowerShell) guard. Two habits it enforces, both observed failing in practice:
//
//  1. `m365 <cmd> --help` / `-h` costs ~2.4 s and its docs are wrong in places the
//     lookup already corrects. Agents that never read SKILL.md reach for it by reflex --
//     one test agent made ~14 such calls and never found ./lookup.
//     Denied however m365 is invoked, matching SKILL.md: the lookup IS the help here.
//  2. Any m365 other than the pinned wrapper -- a bare `m365` through PATH, another install
//     by path, `npx @pnp/cli-microsoft365`, the package's dist/index.js run without the
//     wrapper -- is usually NOT the version pinned and verified here, or not on the fast path.
//
//   node prefer-lookup.mjs [--lookup <cmd>] [--run <cmd>] [--env <cmd>]
//                          [--ps-lookup <cmd>] [--ps-run <cmd>] [--ps-env <cmd>]
//
// The options are how the deny messages name the right invocation where the hook runs.
// Bash defaults: ./lookup, ./m365, `source scripts/env.sh`. PowerShell (tool_name
// "PowerShell") defaults: node scripts/m365-lookup.mjs, node scripts/m365-run.mjs and the
// env.mjs | Invoke-Expression line -- on native Windows the root symlinks are text files.
// --run/--lookup also apply to PowerShell unless --ps-run/--ps-lookup are given; a plugin
// passes e.g. --run 'node "<plugin>/scripts/m365-run.mjs"', valid in both shells.
// The --run invocation is recognised as the pinned wrapper, so running it is allowed.
//
// Reads the hook payload (JSON) on stdin, writes a decision as JSON on stdout. Node only, no
// dependencies. Only ever denies; never edits, never calls out. Anything it cannot parse
// gets no decision.
//
// It reads a command line, it does not run one. Out of reach, by design rather than a shell
// in here: anything decided at run time -- "$M", $(which m365), aliases, functions, eval of
// a variable, a script file that calls m365, Start-Process -FilePath m365 -- and commands
// that are not a recognised wrapper around another command.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { parseArgs } from 'node:util';

const { values: opt } = parseArgs({
  options: Object.fromEntries(['lookup', 'run', 'env', 'ps-lookup', 'ps-run', 'ps-env'].map((k) => [k, { type: 'string' }])),
  strict: false,
});
const PROFILE = {
  bash: {
    lookup: opt.lookup || './lookup',
    run: opt.run || './m365',
    env: `${opt.env || 'source scripts/env.sh'} &&`,
  },
  pwsh: {
    lookup: opt['ps-lookup'] || opt.lookup || 'node scripts/m365-lookup.mjs',
    run: opt['ps-run'] || opt.run || 'node scripts/m365-run.mjs',
    env: `${opt['ps-env'] || 'node scripts/env.mjs pwsh | Out-String | Invoke-Expression'};`,
  },
};

// --- words ---------------------------------------------------------------------------
// Enough of each shell's quoting to find command words: quotes, escapes, operators that
// start a new command, and (bash) here-document bodies, which are text, not commands.
// No expansion. What it cannot read it reads towards "no decision".
const SEP = {
  bash: new Set([';', '&', '|', '(', ')', '`', '\n']),
  pwsh: new Set([';', '&', '|', '(', ')', '{', '}', '\n']),
};
const DQ_ESCAPABLE = new Set(['$', '`', '"', '\\', '\n']);
const PS_SQ = new Set(["'", '\u2018', '\u2019', '\u201A', '\u201B']);
const PS_DQ = new Set(['"', '\u201C', '\u201D', '\u201E']);

/** Index of the ')' closing the '$(' at i, or -1. Quotes inside are skipped. */
function closeParen(line, i) {
  let depth = 0, q = null;
  for (let j = i + 1; j < line.length; j++) {
    const c = line[j];
    if (q) { if (c === q) { q = null; } else if (c === '\\' && q === '"') { j++; } continue; }
    if (c === "'" || c === '"') { q = c; continue; }
    if (c === '\\') { j++; continue; }
    if (c === '(') { depth++; }
    else if (c === ')' && --depth === 0) { return j; }
  }
  return -1;
}

export function commands(line, dialect = 'bash') {
  const out = [];
  let words = [], word = null, quote = null;
  const heredocs = [];   // [{ delim, tabs }] waiting for the end of the current line
  const endWord = () => { if (word !== null) { words.push(word); word = null; } };
  const endCommand = () => { endWord(); if (words.length) { out.push(words); } words = []; };
  const add = (c) => { word = (word ?? '') + c; };
  const ps = dialect === 'pwsh';
  // $(...) -- bash command substitution, PowerShell subexpression: its inside is a command
  // line of its own; in the word it stands in for, it is a placeholder (so a path built on
  // it, like $(npm root -g)/@pnp/..., still ends the way it ends).
  const substitution = (i) => {
    if (line[i] !== '$' || line[i + 1] !== '(') { return -1; }
    const end = closeParen(line, i);
    if (end === -1) { return -1; }
    out.push(...commands(line.slice(i + 2, end), dialect));
    add('$(\u2026)');
    return end;
  };

  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (quote && (quote === '"' || PS_DQ.has(quote))) {
      const end = substitution(i);
      if (end !== -1) { i = end; continue; }
    }
    if (quote) {
      if (ps && PS_SQ.has(quote)) {
        if (PS_SQ.has(c)) { if (PS_SQ.has(line[i + 1])) { add(c); i++; } else { quote = null; } }
        else { add(c); }
      }
      else if (ps) {
        if (c === '`' && i + 1 < line.length) { add(line[++i]); }
        else if (PS_DQ.has(c)) { if (PS_DQ.has(line[i + 1])) { add(c); i++; } else { quote = null; } }
        else { add(c); }
      }
      else if (quote === "'") { if (c === "'") { quote = null; } else { add(c); } }
      else if (c === '"') { quote = null; }
      else if (c === '\\' && DQ_ESCAPABLE.has(line[i + 1])) { add(line[++i]); }
      else { add(c); }
      continue;
    }
    if (ps ? PS_SQ.has(c) || PS_DQ.has(c) : c === "'" || c === '"') { quote = c; word ??= ''; continue; }
    if (!ps && c === '$' && line[i + 1] === "'") { quote = "'"; word ??= ''; i++; continue; }   // $'...'
    if (ps && c === '<' && line[i + 1] === '#') {                                             // <# ... #>
      const end = line.indexOf('#>', i + 2);
      endWord();
      i = end === -1 ? line.length : end + 1;
      continue;
    }
    const sub = substitution(i);
    if (sub !== -1) { i = sub; continue; }
    // 2>&1, >&2, &>file: the & belongs to a redirection, not a background/and operator
    if (c === '&' && line[i + 1] !== '&' && (word?.endsWith('>') || word?.endsWith('<') || line[i + 1] === '>')) { add(c); continue; }
    if (ps && c === '`' && i + 1 < line.length) { if (line[i + 1] !== '\n') { add(line[i + 1]); } i++; continue; }
    if (!ps && c === '\\' && i + 1 < line.length) { if (line[i + 1] !== '\n') { add(line[i + 1]); } i++; continue; }
    if (!ps && c === '<' && line[i + 1] === '<' && line[i + 2] !== '<') {
      // here-document: remember the delimiter, skip the body when this line ends
      let j = i + 2;
      const tabs = line[j] === '-';
      if (tabs) { j++; }
      while (line[j] === ' ' || line[j] === '\t') { j++; }
      let delim = '';
      while (j < line.length && !/[\s;&|<>()]/.test(line[j])) { if (!`'"\\`.includes(line[j])) { delim += line[j]; } j++; }
      if (delim) { heredocs.push({ delim, tabs }); }
      endWord();
      i = j - 1;
      continue;
    }
    if (c === '\n' && heredocs.length) {
      endCommand();
      let j = i + 1;
      for (const { delim, tabs } of heredocs.splice(0)) {
        for (;;) {
          const nl = line.indexOf('\n', j);
          const body = line.slice(j, nl === -1 ? line.length : nl);
          j = nl === -1 ? line.length : nl + 1;
          if ((tabs ? body.replace(/^\t+/, '') : body) === delim || nl === -1) { break; }
        }
      }
      i = j - 1;
      continue;
    }
    if (SEP[dialect].has(c)) { endCommand(); continue; }
    if (/\s/.test(c)) { endWord(); continue; }
    add(c);
  }
  endCommand();
  return out;
}

// --- what counts as running m365 ------------------------------------------------------
const base = (w) => w.split(/[\\/]/).pop();
const hasDir = (w) => /[\\/]/.test(w) || w.startsWith('~');
// compared lower-cased in both shells: Windows (Git Bash included) and default macOS
// filesystems do not care about case, so M365.CMD runs m365.cmd
const BARE = new Set(['m365', 'm365.cmd', 'm365.ps1', 'm365.exe']);
const isBareName = (file) => BARE.has(file.toLowerCase());
const PACKAGES = new Set(['m365', '@pnp/cli-microsoft365']);
const RUNTIMES = new Set(['node', 'node.exe', 'bun', 'bun.exe']);
const SHELLS = new Set(['sh', 'bash', 'zsh', 'dash', 'ksh']);
const POWERSHELLS = new Set(['pwsh', 'pwsh.exe', 'powershell', 'powershell.exe']);
const WRAPPER_FILE = 'm365-run.mjs';
const DIST_SUFFIX = 'cli-microsoft365/dist/index.js';
const KEYWORDS = new Set(['if', 'then', 'else', 'elif', 'do', 'while', 'until', '!', '{', '}', 'coproc']);
// redirections before the command: `2>/dev/null m365`, `> out m365`, `</dev/null m365`
const REDIRECT_OP = /^\d*(?:<>|<|>>|>|>\||&>>|&>|>&|<&)$/;   // the target is the next word
const REDIRECT_WORD = /^\d*(?:<|>|&>)/;                       // operator and target in one word
// PowerShell: `$x = m365 ...`, `[string]$x = ...`, `$script:x += ...`
const PS_VAR = /^(?:\[[^\]]+\])*\$[\w:]+$/;
const PS_ASSIGN_OP = /^(?:[-+*/%]|\?\?)?=$/;
const PS_VAR_ASSIGN = /^(?:\[[^\]]+\])*\$[\w:]+(?:[-+*/%]|\?\?)?=(?!=)(.*)$/;
// How many command lines inside command lines (sh -c, eval, iex, cmd /c, ...) are unpacked.
// Real commands nest one or two deep; deeper than this is not read but REFUSED, so nesting
// cannot be used to walk m365 past the hook.
const MAX_NESTING = 8;
// commands that run the rest of their arguments as a command: options taking a value, and
// how many plain arguments come before the command
const RUNS_COMMAND = {
  env: { valued: ['-u', '--unset', '-C', '--chdir'], assigns: true },
  command: {}, exec: { valued: ['-a'] }, nohup: {}, time: {}, builtin: {},
  nice: { valued: ['-n', '--adjustment'] },
  timeout: { valued: ['-s', '--signal', '-k', '--kill-after'], positional: 1 },
  stdbuf: { valued: ['-i', '-o', '-e'] },
  xargs: { valued: ['-I', '-n', '-P', '-L', '-d', '-E', '-s', '-a', '--max-args', '--max-procs', '--max-lines', '--delimiter', '--arg-file', '--replace'] },
  sudo: { valued: ['-u', '-g', '-C', '-D', '-h', '-p', '-r', '-t', '-U', '-T', '--user', '--group'] },
  watch: { valued: ['-n', '--interval', '-q', '--equexit'] },
  caffeinate: { valued: ['-t', '-w'] },
  script: { valued: ['-F', '-t', '-T', '-c', '--command'], positional: 1 },   // macOS: script [-q] file cmd
};
const NODE_VALUED = new Set(['-r', '--require', '--import', '--loader', '--experimental-loader', '--preload', '--env-file', '-C', '--conditions']);
const CMD_EXE = new Set(['cmd', 'cmd.exe']);
const PACKAGE_RUNNERS = { npx: 0, bunx: 0, pnpx: 0, npm: 1, pnpm: 1, yarn: 1 };   // npm exec, pnpm dlx, yarn dlx

const same = (a, b, dialect) => {
  const n = (w) => w.replace(/\\/g, '/');
  return dialect === 'pwsh' ? n(a).toLowerCase() === n(b).toLowerCase() : n(a) === n(b);
};

function skipOptions(w, i, spec) {
  const valued = new Set(spec.valued ?? []);
  while (i < w.length && w[i].startsWith('-')) {
    if (w[i] === '--') { return i + 1; }
    i += valued.has(w[i]) ? 2 : 1;
  }
  return i;
}

/** Is this path the wrapper? Resolved against the tool call's cwd, through symlinks. */
function isWrapperPath(word, cwd, dialect) {
  if (base(word) === WRAPPER_FILE) { return true; }
  let p = dialect === 'pwsh' && process.platform !== 'win32' ? word.replace(/\\/g, '/') : word;
  if (p === '~' || p.startsWith('~/') || p.startsWith('~\\')) { p = path.join(os.homedir(), p.slice(1)); }
  try { return path.basename(fs.realpathSync(path.resolve(cwd, p))) === WRAPPER_FILE; }
  catch { return false; }
}

/**
 * One command's words -> null (not m365), or { kind: 'wrapper'|'bare'|'other', args }.
 * Recurses into the commands that run a command: env, xargs, sudo, sh -c, iex, ...
 */
function invocation(words, ctx, depth = 0) {
  const { dialect, cwd } = ctx;
  let w = words;
  if (depth > MAX_NESTING) { return { verdict: 'nesting' }; }
  for (;;) {
    if (!w.length) { return null; }
    const head = base(dialect === 'pwsh' ? w[0].toLowerCase() : w[0]);
    if (dialect === 'bash') {
      if (/^[A-Za-z_][A-Za-z0-9_]*=/.test(w[0]) || KEYWORDS.has(w[0])) { w = w.slice(1); continue; }
      if (w[0] === 'function') { w = w.slice(2); continue; }   // function f { ... }
    }
    if (REDIRECT_OP.test(w[0])) { w = w.slice(2); continue; }
    if (REDIRECT_WORD.test(w[0])) { w = w.slice(1); continue; }
    if (dialect === 'pwsh') {
      if (w[0] === '.') { w = w.slice(1); continue; }           // dot-sourcing runs it too
      if (PS_VAR.test(w[0]) && w[1] !== undefined && PS_ASSIGN_OP.test(w[1])) { w = w.slice(2); continue; }
      const glued = PS_VAR_ASSIGN.exec(w[0]);                  // $x=m365
      if (glued) { w = glued[1] ? [glued[1], ...w.slice(1)] : w.slice(1); continue; }
    }
    // `command -v m365` / `command -V m365` only ask whether it exists
    if (head === 'command' && /^-[pvV]*[vV][pvV]*$/.test(w[1] ?? '')) { return null; }
    if (head === 'env') {
      const k = w.findIndex((x, n) => n > 0 && (x === '-S' || x === '--split-string'));
      if (k > 0 && w[k + 1] !== undefined) { return decideLine([w[k + 1], ...w.slice(k + 2)].join(' '), { ...ctx, dialect: 'bash' }, depth + 1); }
    }
    if (dialect === 'pwsh' && ['start-process', 'saps', 'start'].includes(head)) {
      // Start-Process [-FilePath] X [-ArgumentList] a,b: reads as the command line X a b
      const rest = w.slice(1).filter((x) => !/^-(FilePath|ArgumentList|Wait|NoNewWindow|PassThru|Verb|WindowStyle)$/i.test(x));
      return rest.length ? decideLine(rest.join(' ').replace(/,/g, ' '), { ...ctx, dialect: 'pwsh' }, depth + 1) : null;
    }
    if (Object.hasOwn(RUNS_COMMAND, head)) {
      const spec = RUNS_COMMAND[head];
      let i = skipOptions(w, 1, spec);
      if (spec.assigns) { while (i < w.length && /^[A-Za-z_][A-Za-z0-9_]*=/.test(w[i])) { i++; } }
      i += spec.positional ?? 0;
      w = w.slice(i);
      continue;
    }
    break;
  }
  const head = dialect === 'pwsh' ? w[0].toLowerCase() : w[0];
  const name = base(head);

  // sh -c '...', pwsh -Command '...', Invoke-Expression '...': the string is a command line
  const inner = (line, d) => decideLine(line, { ...ctx, dialect: d }, depth + 1);
  if (SHELLS.has(name)) {
    const i = w.findIndex((x, k) => k > 0 && /^-[a-z]*c[a-z]*$/.test(x));
    const j = w[i + 1] === '--' ? i + 2 : i + 1;
    return i > 0 && w[j] !== undefined ? inner(w[j], 'bash') : null;
  }
  if (dialect === 'bash' && name === 'eval') {
    return w.length > 1 ? inner(w.slice(1).join(' '), 'bash') : null;
  }
  if (CMD_EXE.has(name)) {                    // cmd /c "...", also //c as Git Bash spells it
    const i = w.findIndex((x, k) => k > 0 && /^\/{1,2}[ck]$/i.test(x));
    return i > 0 && w[i + 1] !== undefined ? inner(w.slice(i + 1).join(' '), 'pwsh') : null;
  }
  if (POWERSHELLS.has(name)) {
    const i = w.findIndex((x, k) => k > 0 && /^-(c|command)$/i.test(x));
    return i > 0 && w[i + 1] !== undefined ? inner(w.slice(i + 1).join(' '), 'pwsh') : null;
  }
  if (dialect === 'pwsh' && (head === 'invoke-expression' || head === 'iex')) {
    const rest = w.slice(1).filter((x) => !/^-command$/i.test(x));
    return rest.length ? inner(rest.join(' '), 'pwsh') : null;
  }

  // the configured wrapper invocation, in either profile
  for (const p of Object.values(PROFILE)) {
    const runWords = commands(p.run, dialect)[0] ?? [];
    if (runWords.length && w.length >= runWords.length && runWords.every((r, k) => same(r, w[k], dialect))) {
      return { kind: 'wrapper', args: w.slice(runWords.length) };
    }
  }

  if (RUNTIMES.has(name)) {
    let i = 1;
    if (name.startsWith('bun') && ['run', 'x'].includes(w[1])) {
      i = 2;
      if (PACKAGES.has(w[2]?.replace(/^(@[^/]+\/[^@]+|[^@]+)@.*$/, '$1'))) { return { kind: 'other', args: w.slice(3) }; }
    }
    while (i < w.length && w[i].startsWith('-')) { i += NODE_VALUED.has(w[i]) ? 2 : 1; }
    const script = w[i];
    if (script === undefined) { return null; }
    const args = w.slice(i + 1);
    if (base(script) === WRAPPER_FILE) { return { kind: 'wrapper', args }; }
    if (script.replace(/\\/g, '/').endsWith(DIST_SUFFIX)) { return { kind: 'other', args }; }
    if (isBareName(base(script))) { return { kind: isWrapperPath(script, cwd, dialect) ? 'wrapper' : 'other', args }; }
    return null;
  }

  if (Object.hasOwn(PACKAGE_RUNNERS, name)) {
    let i = 1 + PACKAGE_RUNNERS[name];   // npm exec / pnpm dlx / yarn dlx: skip the subcommand
    if (PACKAGE_RUNNERS[name] && !['exec', 'dlx', 'x'].includes(w[1])) { return null; }
    i = skipOptions(w, i, { valued: ['-p', '--package', '-c', '--call'] });
    const pkg = w[i];
    if (pkg === undefined) { return null; }
    const bareName = pkg.startsWith('@') ? pkg.replace(/^(@[^/]+\/[^@]+)@.*$/, '$1') : pkg.replace(/@.*$/, '');
    return PACKAGES.has(bareName) ? { kind: 'other', args: w.slice(i + 1) } : null;
  }

  const file = base(w[0]);
  const isM365 = isBareName(file);
  if (!isM365 && file !== WRAPPER_FILE) { return null; }
  if (!hasDir(w[0])) { return isM365 ? { kind: 'bare', args: w.slice(1) } : null; }
  return { kind: isWrapperPath(w[0], cwd, dialect) ? 'wrapper' : 'other', args: w.slice(1) };
}

const isHelp = (a) => a === '-h' || a === '--help' || a.startsWith('--help=');

/** A command line -> null, or { verdict: 'help'|'bare'|'other'|'nesting', word } */
function decideLine(line, ctx, depth = 0) {
  let found = null;
  for (const words of commands(line, ctx.dialect)) {
    const inv = invocation(words, ctx, depth);
    if (!inv) { continue; }
    if (inv.verdict) {                      // from a nested command line
      if (inv.verdict === 'help') { return inv; }
      found ??= inv;
      continue;
    }
    if (inv.args.some(isHelp)) { return { verdict: 'help' }; }
    if (inv.kind !== 'wrapper') { found ??= { verdict: inv.kind, word: words.join(' ') }; }
  }
  return found;
}

export function decide(command, { dialect = 'bash', cwd = process.cwd() } = {}) {
  return decideLine(command, { dialect, cwd })?.verdict ?? null;
}

function reason(verdict, p) {
  if (verdict === 'nesting') {
    return `This command line nests command lines (sh -c, eval, Invoke-Expression, cmd /c) more than ${MAX_NESTING} deep, which this hook does not unpack -- so it is refused rather than let through unread. Run the m365 part directly: ${p.run} <command>, looked up with ${p.lookup} <command>.`;
  }
  if (verdict === 'unreadable') {
    return `This hook could not read this command line, so it is refused rather than let through unread. Simplify it, and run m365 as ${p.run} <command>, looked up with ${p.lookup} <command>.`;
  }
  if (verdict === 'help') {
    return `${p.lookup} is the help here: run  ${p.lookup} <command>  (e.g. ${p.lookup} spo page add), plus --examples / --remarks / --permissions / --response. It is an order of magnitude faster than m365 --help and it corrects the places where the CLI help is wrong -- option casing, restricted --output values, and options the docs list that the CLI rejects.`;
  }
  const why = verdict === 'bare'
    ? 'a bare m365 resolves through PATH to whatever is installed globally, which is a different version than the one pinned and verified here.'
    : 'that is not the pinned wrapper: another m365 install, a package runner fetching whatever version it resolves, or the CLI run without the wrapper -- not the version pinned and verified here, or not with its fixes.';
  return `Run it as ${p.run} <command>  -- ${why} ${p.run} runs the pinned dist/index.js in a home directory of its own, so it cannot sign a v11 install out or overwrite its connection, and writes the connection files under a lock; the reasons are in the README. Values from .env come from prefixing the SAME command line with: ${p.env}  ... And look the command up first: ${p.lookup} <command>.`;
}

function main() {
  let payload;
  try { payload = JSON.parse(fs.readFileSync(0, 'utf8')); }
  catch { return; }
  const command = payload?.tool_input?.command;
  if (typeof command !== 'string') { return; }
  const dialect = payload.tool_name === 'PowerShell' ? 'pwsh' : 'bash';
  const cwd = typeof payload.cwd === 'string' ? payload.cwd : process.cwd();
  let verdict;
  // A valid payload the reader chokes on (e.g. $( nested thousands deep overflows the stack)
  // is refused: a crashed hook counts as no decision, which would let the command through.
  try { verdict = decide(command, { dialect, cwd }); }
  catch { verdict = 'unreadable'; }
  if (!verdict) { return; }
  fs.writeSync(1, JSON.stringify({
    hookSpecificOutput: { hookEventName: 'PreToolUse', permissionDecision: 'deny', permissionDecisionReason: reason(verdict, PROFILE[dialect]) },
  }) + '\n');
}

main();
