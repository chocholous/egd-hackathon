// Kontrola verze Node proti package.json#engines.node pro doctor kitu (krok s-node průvodce).
// Projekt ji od 0.7 nemá: tam verzi hlídá npm při instalaci (.npmrc engine-strict).
// Umí jen tvar, který píše generátor SPFx: ">=A.B.C <X.0.0 || >=… <…". Jiný tvar = výjimka, ne tiché OK.

const ge = (a, b) => {
  const x = a.split('.').map(Number), y = b.split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
  return true;
};

export function nodeSatisfies(version, range) {
  return range.split('||').some((part) => {
    const m = /^\s*>=(\d+\.\d+\.\d+)\s*<(\d+)\./.exec(part);
    if (!m) throw new Error(`nepodporovaný tvar rozsahu Node: "${part.trim()}"`);
    return ge(version, m[1]) && Number(version.split('.')[0]) < Number(m[2]);
  });
}
