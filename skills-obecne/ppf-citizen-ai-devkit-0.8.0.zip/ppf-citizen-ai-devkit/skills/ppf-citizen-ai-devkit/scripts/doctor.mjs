#!/usr/bin/env node
// doctor — strojová kontrola prerekvizit projektu pro průvodce založením a migrací (references/onboarding.md).
//
// Co dělá: projde stroj, projekt, git, tenant a stav nasazení a ke každému kroku průvodce vrátí
//   ok | chyba | pozor | neznamo + jednu větu, co našel. Jen čte. S --write uloží výsledek do
//   <projekt>/.devkit/onboarding.json (tělo dokumentu meta/doctor pro artefakt průvodce).
// Proč je v kitu a ne v šabloně projektu: migrovaný projekt nové nástroje ještě nemá, a přesto ho
//   musí jít zkontrolovat. Kontroly tenantu a webů nepíše znovu: volá `npm run prereq -- --json` projektu.
// Dvě fáze: bez volby se ptá „jde lokálně vyvíjet?“ a `chyba` je jen to, bez čeho nejede gen, dev a testy
//   (Node, git, projekt a jeho nástroje, závislosti, prefix, manifest) a cockpit (povinný vždy). Co je potřeba až
//   k nasazení (vzdálený repozitář a pushnutý stav, web a přihlášení, role, balíček, kontrola vzhledu, výjimky, tag),
//   je v té fázi `pozor` s poznámkou. S --pred-nasazenim jsou i tyto kroky `chyba`: spouští se před nasazením.
// Podmínky nasazení zjistitelné bez webu (git, cockpit, balíček, vzhled) doctor nezná sám: ptá se projektu
//   (tools/lib/podminky.mjs, stejný modul čte plán nasazení). Co tady projde, nasazení neodmítne, a naopak.
//   Projekt se staršími nástroji (bez podminky.mjs) se kontroluje postaru a krok to řekne.
// Záznam o nasazení čte z webu přes nástroje projektu (od 0.6 žije jen tam); u starších nástrojů z releases/.
// Při chybě: každá kontrola je samostatná; co nejde zjistit, je `neznamo` s důvodem, skript pokračuje.
//   Exit 0 = žádná `chyba`, 1 = aspoň jedna `chyba`, 2 = špatné použití.
//
//   node doctor.mjs [--project <složka>] [--env <prostředí>] [--pred-nasazenim] [--json] [--write]
import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { nodeSatisfies } from './node-version.mjs';
import { stejneRepo } from '../templates/project/tools/lib/gitcheck.mjs';
import { findKitPlugin, findPlugin, installedPlugins, materialSkillDir } from '../templates/project/tools/lib/kit-plugin.mjs';
import { kitInfo } from './devkit.mjs';

const SKILL = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const TEMPLATE = join(SKILL, 'templates', 'project');
const WIN = process.platform === 'win32';
const USAGE = 'použití: node doctor.mjs [--project <složka>] [--env <prostředí>] [--pred-nasazenim] [--json] [--write]';

const argv = process.argv.slice(2);
if (argv.includes('--help') || argv.includes('-h')) { console.log(USAGE); process.exit(0); }
const opt = (n) => { const i = argv.indexOf(n); return i < 0 ? null : argv[i + 1]; };
const known = new Set(['--project', '--env', '--pred-nasazenim', '--json', '--write']);
for (let i = 0; i < argv.length; i++) {
  if (!known.has(argv[i])) { console.error(`doctor: neznámá volba ${argv[i]}\n${USAGE}`); process.exit(2); }
  if (argv[i] === '--project' || argv[i] === '--env') { if (!argv[i + 1] || argv[i + 1].startsWith('--')) { console.error(USAGE); process.exit(2); } i++; }
}
const ROOT = resolve(opt('--project') || process.cwd());
// Složka projektu při prvním běhu ještě nemusí existovat (doctor je první krok nováčka): příkazy pak běží z domovské
// složky. Spuštění v neexistující složce selže dřív, než se program spustí, a kontrola by hlásila chybu, která není.
const CWD = existsSync(ROOT) ? ROOT : homedir();
const ENV = opt('--env') || 'dev';
const asJson = argv.includes('--json');
const write = argv.includes('--write');

const PRED = argv.includes('--pred-nasazenim');

const kroky = {};
const set = (id, stav, detail) => { kroky[id] = { stav, detail }; };
// krok potřebný až k nasazení: při kontrole pro lokální vývoj z něj chyba není, jen upozornění s důvodem
const setN = (id, stav, detail) => set(id, stav === 'chyba' && !PRED ? 'pozor' : stav, stav === 'chyba' && !PRED ? `${detail} (lokálnímu vývoji nevadí; před prvním nasazením nutné)` : detail);
const sh = (cmd, args, cwd = CWD) => {
  const r = spawnSync(cmd, args, { cwd, encoding: 'utf8', shell: WIN && /^(npm|npx|claude)$/.test(cmd) });
  return { rc: r.error ? 127 : r.status, out: (r.stdout || '').trim(), err: (r.stderr || '').trim() };
};
const git = (...a) => sh('git', a);
const json = (p) => { try { return JSON.parse(readFileSync(p, 'utf8')); } catch { return null; } };
const lastLine = (p) => { try { const l = readFileSync(p, 'utf8').trim().split('\n').filter(Boolean); return l.length ? JSON.parse(l[l.length - 1]) : null; } catch { return null; } };

// ---------- stroj ----------
const tplPkg = json(join(TEMPLATE, 'package.json'));
const pkg = json(join(ROOT, 'package.json'));
const range = pkg?.engines?.node || tplPkg?.engines?.node;
if (!range) set('s-node', 'neznamo', `Node ${process.versions.node}; rozsah engines se nepodařilo přečíst`);
else set('s-node', nodeSatisfies(process.versions.node, range) ? 'ok' : 'chyba', `Node ${process.versions.node}, projekt chce ${range}`);

{
  const v = sh('git', ['--version'], homedir());
  const name = git('config', 'user.name').out, mail = git('config', 'user.email').out;
  if (v.rc !== 0) set('s-git', 'chyba', 'git není v PATH');
  else set('s-git', name && mail ? 'ok' : 'chyba', name && mail ? `${v.out}, identita nastavená` : `${v.out}, chybí git user.name nebo user.email`);
}

// pluginy Claude Code: jeden dotaz, tři kroky (kit, ppf-material, ppf-browsermagic)
const kitVersion = (readFileSync(join(SKILL, 'SKILL.md'), 'utf8').match(/^version:\s*(\S+)/m) || [])[1] || null;
// kit z rozpracované větve nese číslo vydané verze, ale jiný obsah: řekni to u s-kit i p-kit (nález U10)
const NEVYDANY = kitInfo().nevydany;
const nevydanyText = NEVYDANY ? ` — NEVYDANÝ kit (${NEVYDANY}): číslo verze nezaručuje obsah vydané ${kitVersion}` : '';
{
  const plugins = installedPlugins({ cwd: CWD });   // v projektu: uvidí i pluginy v rozsahu projektu
  const list = plugins.zdroj ? plugins.list : null;
  const find = (n) => [findPlugin(list, n)].filter(Boolean);
  if (!list) {
    for (const id of ['s-kit', 's-material']) set(id, 'neznamo', `seznam pluginů nejde zjistit (${plugins.duvod})`);
  } else {
    // obě jména pluginu (staré ppf-spfx-devkit přechodně): seznam je v templates/project/tools/lib/kit-plugin.mjs
    const kit = findKitPlugin((list || []).filter((p) => p.enabled !== false), (p) => p.id || p.name);
    // dvě různé věci: kit, ze kterého tenhle doctor běží (jeho šablonu a pravidla kontrola používá), a plugin
    // nainstalovaný v Claude Code (z něj bere postup agent). Když se liší, kontrola to řekne.
    const bezi = `doctor běží z kitu ${kitVersion} (${SKILL})${nevydanyText}`;
    if (!kit) set('s-kit', 'pozor', `${bezi}; plugin kitu nainstalovaný není (Claude Code ani GitHub Copilot CLI)`);
    else if (kit.version === kitVersion) set('s-kit', NEVYDANY ? 'pozor' : 'ok', `${bezi}; nainstalovaný plugin ${kit.id} ${kit.version} (${kit.scope}) je stejné verze`);
    else set('s-kit', 'pozor', `${bezi}; nainstalovaný plugin ${kit.id} je ${kit.version} (${kit.scope}) — verze se liší: agent bere postup z pluginu ${kit.version}, kontrola a šablona jsou z ${kitVersion}`);
    const mat = find('ppf-material')[0];
    const tokens = !!materialSkillDir({ plugins });
    (existsSync(join(ROOT, 'spfx', 'src', 'app', 'ppf', 'ppfDesign.json')) ? setN : set)('s-material', mat && tokens ? 'ok' : 'chyba', mat ? `${mat.id} ${mat.version} (${mat.scope})${tokens ? '' : ', ale chybí tokens/tokens.json'}` : 'plugin ppf-material není nainstalovaný (marketplace ppf-skills)');
  }
  // sdílená session pro sondu: zapisuje ji jen skill ppf-browsermagic (auth-refresh.mjs), sonda ji jen čte
  const store = join(homedir(), '.config', 'spo-auth');
  const states = existsSync(store) ? readdirSync(store).filter((f) => /^state-.+\.json$/.test(f)) : [];
  const bm = list ? find('ppf-browsermagic')[0] : null;
  const bmTxt = !list ? '' : bm ? `; ppf-browsermagic ${bm.version} (${bm.scope})` : '; ppf-browsermagic není nainstalovaný — bez něj se sonda nemá jak přihlásit (marketplace ppf-skills)';
  set('s-auth', states.length ? 'ok' : 'pozor', (states.length ? `~/.config/spo-auth: ${states.join(', ')}` : '~/.config/spo-auth nemá uloženou session; vznikne přihlášením přes skill ppf-browsermagic (krok t-sonda)') + bmTxt);
}

// ---------- projekt ----------
const cfg = json(join(ROOT, 'project_config.json'));
const isProject = !!cfg;
set('p-projekt', isProject ? 'ok' : 'chyba', isProject ? `${cfg.app?.name || '?'} (prefix ${cfg.app?.prefix || '?'}) v ${ROOT}` : `${ROOT} nemá čitelný project_config.json: nový projekt založ přes devkit init, starší převeď podle cesty Migrace`);

if (isProject) {
  // verze kitu, ze které projekt vznikl (klíč kit {verze, commit} zapisuje devkit init)
  if (cfg.kit?.verze) set('p-kit', cfg.kit.verze === kitVersion && !NEVYDANY ? 'ok' : 'pozor', `projekt je z kitu ${cfg.kit.verze}${cfg.kit.commit ? ` (${String(cfg.kit.commit).slice(0, 7)})` : ''}, tento kit je ${kitVersion}${nevydanyText}`);
  else set('p-kit', 'pozor', `project_config.json nemá klíč kit {verze, commit}: neznámá verze šablony (tento kit je ${kitVersion})`);

  // nástroje projektu proti šabloně: porovnání vlastní devkit diff (řádky zmeneno|chybi|navic<TAB>cesta), doctor ho jen čte
  {
    const r = sh(process.execPath, [join(SKILL, 'scripts', 'devkit.mjs'), 'diff', ROOT], homedir());
    const rows = r.out.split('\n').map((l) => l.split('\t')).filter((x) => x.length === 2 && !x[0].startsWith('#'));
    const of = (k) => rows.filter(([kind]) => kind === k).map(([, p]) => p);
    const chybi = of('chybi'), zmeneno = of('zmeneno'), navic = of('navic');
    const head = (l) => l.slice(0, 4).join(', ') + (l.length > 4 ? ` a ${l.length - 4} dalších` : '');
    const lisi = chybi.length + zmeneno.length;
    if (!pkg) set('p-nastroje', 'chyba', 'chybí package.json');
    else if (r.rc !== 0 && r.rc !== 10) set('p-nastroje', 'neznamo', `devkit diff selhal (${(r.err || r.out).split('\n')[0] || `exit ${r.rc}`})`);
    else if (chybi.length) set('p-nastroje', 'chyba', `proti šabloně chybí ${chybi.length}: ${head(chybi)}${zmeneno.length ? `; změněno ${zmeneno.length}` : ''} (devkit diff)`);
    else if (zmeneno.length) set('p-nastroje', 'pozor', `změněno ${zmeneno.length}: ${head(zmeneno)}; každá odchylka patří do DEVKIT-VYJIMKY.md (devkit diff)`);
    else set('p-nastroje', 'ok', navic.length ? `shodné se šablonou; navíc ${navic.length} vlastních souborů` : 'shodné se šablonou');
    // sepsané výjimky schvaluje člověk: doctor krok nikdy neoznačí jako splněný, jen řekne, co vidí
    const vyj = existsSync(join(ROOT, 'DEVKIT-VYJIMKY.md'));
    if (!vyj) setN('m-vyjimky', lisi ? 'chyba' : 'pozor', `DEVKIT-VYJIMKY.md chybí${lisi ? ` a projekt se od šablony liší v ${lisi} souborech` : ''}`);
    else set('m-vyjimky', 'pozor', `DEVKIT-VYJIMKY.md existuje; jestli pokrývá ${lisi} odlišných souborů a kdo výjimky schválil, posoudí člověk`);
  }

  const nm = existsSync(join(ROOT, 'node_modules')), nmSpfx = existsSync(join(ROOT, 'spfx', 'node_modules'));
  set('p-zavislosti', nm && nmSpfx ? 'ok' : 'chyba', nm && nmSpfx ? 'node_modules i spfx/node_modules existují (verze ověřuje prereq)' : `chybí ${[!nm && 'node_modules (npm ci)', !nmSpfx && 'spfx/node_modules (npm --prefix spfx ci)'].filter(Boolean).join(' a ')}`);

  // project_config.json: prostředí a mapování rolí
  const env = cfg.environments?.[ENV];
  const cfgProblems = [];
  if (!cfg.m365?.tenantId || !cfg.m365?.appId) cfgProblems.push('m365.tenantId / m365.appId');
  if (!env?.site) cfgProblems.push(`environments.${ENV}.site`);
  if (!cfg.app?.name || !cfg.app?.prefix) set('p-config', 'chyba', `nevyplněno: ${['app.name / app.prefix', ...cfgProblems].join(', ')}`);
  else setN('p-config', cfgProblems.length ? 'chyba' : 'ok', cfgProblems.length ? `nevyplněno: ${cfgProblems.join(', ')}` : `${ENV}: ${env.site}`);

  const manifest = json(join(ROOT, 'sp', 'app.manifest.json'));
  if (!manifest) { set('p-manifest', 'chyba', 'sp/app.manifest.json chybí nebo není platný JSON'); set('t-role', 'neznamo', 'bez manifestu nejde zjistit role'); }
  else {
    const roles = Object.keys(manifest.roles || {}).filter((r) => r !== 'owner');
    set('p-manifest', 'ok', `${Object.keys(manifest.lists || {}).length} listů, ${Object.keys(manifest.libraries || {}).length} knihoven, role: ${['owner', ...roles].join(', ')}`);
    const local = Object.keys(cfg.environments?.local?.users || {}).length;
    set('l-mock', local ? 'ok' : 'pozor', local ? `environments.local.users: ${local} uživatelů pro přepínání rolí v mocku` : 'environments.local.users je prázdné, mock neumí přepínat role');
    const unmapped = roles.filter((r) => !env?.roles?.[r]);
    const empty = roles.filter((r) => { const m = env?.roles?.[r]?.members; return m && !(m.emails || []).length && !(m.entraGroups || []).length; });
    if (!env?.site) set('t-role', 'neznamo', `prostředí ${ENV} nemá site`);
    else if (unmapped.length) setN('t-role', 'chyba', `${ENV}: role bez mapování na skupinu: ${unmapped.join(', ')}`);
    else set('t-role', empty.length ? 'pozor' : 'ok', empty.length ? `${ENV}: všechny role namapované; bez členů: ${empty.join(', ')} (členy dodá člověk)` : `${ENV}: ${roles.length} rolí namapováno`);
  }

  // podmínky nasazení z projektu (tools/lib/podminky.mjs): { git, cockpit, balicek, vzhled } = pole nálezů; null = starší nástroje
  const libUrl = (f) => JSON.stringify(pathToFileURL(join(ROOT, 'tools', 'lib', f)).href);
  const zProjektu = (kod) => { const r = sh(process.execPath, ['--input-type=module', '-e', kod]); try { return JSON.parse(r.out.split('\n').pop()); } catch { return { chyba: (r.err || r.out || `exit ${r.rc}`).trim().split('\n')[0] }; } };
  const pod = existsSync(join(ROOT, 'tools', 'lib', 'podminky.mjs')) ? zProjektu(`import { podminkyNasazeni } from ${libUrl('podminky.mjs')}; console.log(JSON.stringify(podminkyNasazeni(${JSON.stringify(ENV)})));`) : null;
  const popis = (f) => f.map((x) => x.desc).join('; ');

  // git: repo, remote, čistý strom, pushnuto
  if (git('rev-parse', '--is-inside-work-tree').out !== 'true') set('p-git', 'chyba', 'složka není git repozitář');
  else if (pod?.git?.length) setN('p-git', 'chyba', popis(pod.git));
  else {
    const origin = git('remote', 'get-url', 'origin').out;
    const dirty = git('status', '--porcelain').out.split('\n').filter(Boolean).length;
    const branch = git('branch', '--show-current').out;
    const up = git('rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}');
    const ahead = up.rc === 0 ? Number(git('rev-list', '--count', '@{u}..HEAD').out) : null;
    const p = [];
    if (!origin) p.push('repo nemá origin');
    else if (cfg.git?.remote && !stejneRepo(cfg.git.remote, origin)) p.push(`git.remote v configu (${cfg.git.remote}) ≠ origin (${origin})`);
    else if (!cfg.git?.remote) p.push('git.remote v project_config.json je prázdné');
    if (dirty) p.push(`${dirty} necommitnutých změn`);
    if (up.rc !== 0) p.push(`větev ${branch} nemá vzdálený protějšek (git push -u origin ${branch})`);
    else if (ahead) p.push(`${ahead} commitů není pushnuto`);
    // s podminky.mjs o chybě rozhodl projekt výše (nasazení by ho pustilo): zbylé poznámky jsou jen upozornění
    setN('p-git', p.length ? (origin || pod?.git ? 'pozor' : 'chyba') : 'ok', p.length ? p.join('; ') : `origin ${origin}, větev ${branch} čistá a pushnutá`);
  }

  // tenant a weby: přebírá výsledky prereq projektu (jediný vlastník těchto kontrol)
  const tenantIds = ['t-login', 't-web', 't-vlastnik', 't-katalog'];
  if (!pkg?.scripts?.prereq || !existsSync(join(ROOT, 'node_modules'))) {
    for (const id of [...tenantIds, 'p-prereq']) set(id, 'neznamo', 'projekt nemá skript prereq nebo nainstalované závislosti');
  } else {
    const r = sh('npm', ['run', '-s', 'prereq', '--', '--json', '--env', ENV]);
    let res = null;
    try { res = JSON.parse(r.out).results; } catch { res = null; }
    if (!res) for (const id of [...tenantIds, 'p-prereq']) set(id, 'neznamo', `npm run prereq -- --json nevrátil JSON (${(r.err || r.out).split('\n')[0]})`);
    else {
      const lvl = { OK: 'ok', WARN: 'pozor', FAIL: 'chyba' };
      const one = (id, area, name, missing) => { const x = res.find((y) => y.area === area && y.name === name); setN(id, x ? lvl[x.level] : 'neznamo', x ? x.detail : missing); };
      const tools = res.filter((x) => x.area === 'nástroje');
      const bad = tools.filter((x) => x.level !== 'OK');
      set('p-prereq', bad.some((x) => x.level === 'FAIL') ? 'chyba' : bad.length ? 'pozor' : 'ok', bad.length ? bad.map((x) => `${x.name}: ${x.detail}`).join('; ') : tools.map((x) => `${x.name}: ${x.detail}`).join('; ') || 'prereq nevrátil žádný řádek oblasti nástroje');
      const login = res.find((x) => x.area === 'm365' && x.name === 'přihlášení'), tenant = res.find((x) => x.area === 'm365' && x.name === 'tenant');
      setN('t-login', !login ? 'neznamo' : login.level !== 'OK' ? 'chyba' : tenant && tenant.level !== 'OK' ? 'chyba' : 'ok', !login ? 'prereq přihlášení nevrátil' : login.level !== 'OK' ? login.detail : tenant && tenant.level !== 'OK' ? `jiný tenant: ${tenant.detail}` : `${login.detail}, tenant sedí`);
      const noEnv = `prereq prostředí ${ENV} nekontroloval (chybí přihlášení nebo site)`;
      one('t-web', ENV, 'web', noEnv); one('t-vlastnik', ENV, 'vlastník webu', noEnv); one('t-katalog', ENV, 'site app catalog', noEnv);
    }
  }

  // balíček, cockpit, nasazení, předání
  const sol = json(join(ROOT, 'spfx', 'config', 'package-solution.json'))?.solution;
  const pkgDir = join(ROOT, 'spfx', 'sharepoint', 'solution');
  const sppkg = existsSync(pkgDir) ? readdirSync(pkgDir).filter((f) => f.endsWith('.sppkg')) : [];
  if (pod?.balicek) (pod.balicek.length ? setN : set)('l-build', pod.balicek.length ? 'chyba' : 'ok', pod.balicek.length ? popis(pod.balicek) : `${sppkg.join(', ')} je z dnešního kódu (solution.version ${sol?.version || '?'})`);
  else set('l-build', sppkg.length ? 'ok' : 'pozor', sppkg.length ? `${sppkg.join(', ')} existuje (solution.version ${sol?.version || '?'}; čerstvost ověří plán nasazení)` : 'balíček .sppkg zatím není: npm run build');

  // úplná kontrola vzhledu: jestli report platí pro dnešní kód, rozhodují nástroje projektu (lib/design-report.mjs,
  // otisk kódu); doctor je jen zavolá, sám otisk nepočítá
  {
    const lib = join(ROOT, 'tools', 'lib', 'design-report.mjs');
    const maOtisk = existsSync(join(ROOT, 'tools', 'lib', 'otisk.mjs'));
    if (!pkg?.scripts?.['design-check']) set('l-design', 'chyba', 'projekt nemá skript design-check (převzít nástroje ze šablony)');
    else if (pod?.vzhled) {
      // stejný nález jako v plánu nasazení pro prostředí ENV: mimo DEV blokuje, na DEV jen upozorní
      const f = pod.vzhled;
      if (!f.length) set('l-design', 'ok', 'úplná kontrola vzhledu prošla pro dnešní kód');
      else if (f[0].block) setN('l-design', 'chyba', popis(f));
      else set('l-design', 'pozor', `${popis(f)} (na ${ENV} nasazení neblokuje)`);
    }
    else if (!maOtisk) set('l-design', 'pozor', 'projekt má nástroje starší než 0.5.1 (bez tools/lib/otisk.mjs): platnost kontroly vzhledu odtud ověřit nejde, řekne ji plán nasazení');
    else {
      const r = sh(process.execPath, ['--input-type=module', '-e', `import { designFindings } from ${JSON.stringify(pathToFileURL(lib).href)}; console.log(JSON.stringify(designFindings('test')));`]);
      let f = null;
      try { f = JSON.parse(r.out); } catch { /* níže */ }
      if (!f) set('l-design', 'pozor', `stav kontroly vzhledu se nepodařilo zjistit: ${(r.err || r.out || '').trim().split('\n')[0]}`);
      else set('l-design', f.length ? 'pozor' : 'ok', f.length ? `${f[0].desc.split(' — ')[0]}; TEST bez ní nasazení odmítne` : 'úplná kontrola vzhledu prošla pro dnešní kód');
    }
  }

  // cockpit je podmínka každého nasazení, i na DEV (stejně ho hlásí prereq a plán nasazení); lokálnímu vývoji nevadí
  setN('c-url', cfg.cockpit?.url ? 'ok' : 'chyba', cfg.cockpit?.url || (pod?.cockpit?.length ? popis(pod.cockpit) : 'cockpit.url v project_config.json je prázdné: cockpit je povinný, založ ho a adresu zapiš'));

  // Záznam o nasazení: od 0.6 jen na webu (_deploy/<env>.json); čtou ho nástroje projektu a potřebují přihlášení.
  // Starší nástroje (bez readRecord): poslední řádek releases/<env>.jsonl v gitu, jako dřív.
  const zWebu = (() => { try { return /readRecord/.test(readFileSync(join(ROOT, 'tools', 'lib', 'project.mjs'), 'utf8')); } catch { return false; } })();
  const prihlaseno = kroky['t-login']?.stav === 'ok';
  const zaznam = (env) => {
    if (!zWebu) { const r = lastLine(join(ROOT, 'releases', `${env}.jsonl`)); return { zdroj: `releases/${env}.jsonl`, rec: r ? { ...r, appliedAt: r.at } : null }; }
    if (!cfg.environments?.[env]?.site) return { zdroj: 'web', rec: null, proc: `prostředí ${env} nemá site` };
    if (!prihlaseno) return { zdroj: 'web', neznamo: 'záznam o nasazení je na webu a bez přihlášení m365 ho nejde přečíst' };
    const r = zProjektu(`import { loadProject } from ${libUrl('project.mjs')}; console.log(JSON.stringify({ rec: loadProject(${JSON.stringify(env)}).readRecord() }));`);
    return r.chyba ? { zdroj: 'web', neznamo: `záznam o nasazení se z webu nepodařilo přečíst: ${r.chyba}` } : { zdroj: 'web', rec: r.rec };
  };
  const z = zaznam(ENV);
  if (z.neznamo) set('d-zaznam', 'neznamo', z.neznamo);
  else if (!z.rec) set('d-zaznam', 'pozor', `${z.proc || `${z.zdroj === 'web' ? `_deploy/${ENV}.json na webu` : z.zdroj} nemá žádný záznam`}: na ${ENV} se ještě nenasazovalo`);
  else {
    const rel = z.rec;
    const p = [];
    if (rel.dirty) p.push('poslední nasazení proběhlo s necommitnutými změnami (dirty: true)');
    if (sol?.version && rel.version !== sol.version) p.push(`nasazeno ${rel.version}, v gitu je solution.version ${sol.version}`);
    if (!zWebu && git('status', '--porcelain', '--', `releases/${ENV}.jsonl`).out) p.push(`releases/${ENV}.jsonl není commitnutý`);
    set('d-zaznam', p.length ? 'pozor' : 'ok', `${ENV}: ${rel.version} z ${String(rel.commit).slice(0, 7)} (${rel.appliedAt}; záznam ${z.zdroj === 'web' ? 'na webu' : `v ${z.zdroj}`})${p.length ? '; ' + p.join('; ') : ''}`);
  }

  const zt = ENV === 'test' ? z : zaznam('test');
  const relTest = zt.rec || null;
  if (zt.neznamo) set('x-tag', 'neznamo', zt.neznamo);
  else if (!relTest) set('x-tag', 'neznamo', 'TEST nemá záznam o nasazení: předání na PROD přichází až po nasazení na TEST');
  else {
    const tag = `v${relTest.version}`;
    const at = git('rev-list', '-n', '1', tag);
    if (at.rc !== 0) set('x-tag', 'pozor', `tag ${tag} neexistuje (TEST má ${relTest.version} z ${String(relTest.commit).slice(0, 7)})`);
    else setN('x-tag', at.out === relTest.commit && !relTest.dirty ? 'ok' : 'chyba', at.out === relTest.commit ? (relTest.dirty ? `tag ${tag} je na commitu nasazeném s dirty: true` : `tag ${tag} je na commitu nasazeném na TEST`) : `tag ${tag} míří na ${at.out.slice(0, 7)}, na TEST je nasazen ${String(relTest.commit).slice(0, 7)}`);
  }
}

const doc = {
  kdy: new Date().toISOString(),
  prostredi: ENV,
  faze: PRED ? 'pred-nasazenim' : 'lokalni',
  projekt: isProject ? { nazev: cfg.app?.name || null, prefix: cfg.app?.prefix || null, cesta: ROOT, cockpit: cfg.cockpit?.url || null } : { cesta: ROOT },
  kit: { verze: kitVersion },
  kroky,
};
const chyb = Object.values(kroky).filter((k) => k.stav === 'chyba').length;

if (write) {
  // zapisuje jen do gitignored .devkit/ (stejné místo jako export cockpitu); jinde by výstup skončil v commitu
  const ignored = git('check-ignore', '-q', '.devkit/onboarding.json').rc === 0;
  if (!isProject || !ignored) console.error('doctor: --write přeskočeno, .devkit/ v této složce není v .gitignore (nebo to není projekt); výsledek je jen na výstupu');
  else { mkdirSync(join(ROOT, '.devkit'), { recursive: true }); writeFileSync(join(ROOT, '.devkit', 'onboarding.json'), JSON.stringify(doc, null, 2) + '\n'); }
}
if (asJson) console.log(JSON.stringify(doc, null, 2));
else {
  const lab = { ok: 'OK', chyba: 'CHYBA', pozor: 'POZOR', neznamo: '?' };
  for (const [id, k] of Object.entries(kroky)) console.log(`${lab[k.stav].padEnd(5)}  ${id.padEnd(12)} ${k.detail}`);
  console.log(`\nkontrola pro ${PRED ? 'nasazení' : 'lokální vývoj (před nasazením spusť s --pred-nasazenim)'}: ${chyb ? `${chyb}× CHYBA` : 'žádná chyba (POZOR a ? si přečti)'}`);
  if (write && existsSync(join(ROOT, '.devkit', 'onboarding.json'))) console.log('zapsáno: .devkit/onboarding.json → ArtifactData set meta/doctor (file_path)');
}
process.exitCode = chyb ? 1 : 0;
