#!/usr/bin/env node
// Generátor MUI theme z ppf-material tokens/tokens.json.
//
// Proč generátor a ne ručně opsaný soubor: ppf-material vendoruje brand hodnoty z brandového zdroje
// a při re-syncu je mění. Ručně opsaný theme by driftoval stejně, jako driftovaly ručně opsané kopie
// mezi projekty. Výstup má hlavičku s verzí tokenů a `--check` porovná
// vygenerovaný text s tím, co leží v repu (drift = rc 1) — stejný princip jako `ppf-tokens.scss`
// v thoru a `gen_docs.py --check` ve VIP.
//
// Použití:
//   node gen-mui-theme.mjs <ppf-material-dir> --out spfx/src/webparts/<wp>/components/ppf/ppfMuiTheme.ts
//   node gen-mui-theme.mjs <ppf-material-dir> --out <cesta> --check
// <ppf-material-dir> = kořen skillu ppf-material (obsahuje tokens/tokens.json). Kde je nainstalovaný,
// je u pluginu z marketplace ~/.claude/plugins/cache/<marketplace>/ppf-material/<verze>/skills/ppf-material
// (verzi vypíše `claude plugin list`); cesta se záměrně nehádá.

import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { join, resolve } from 'node:path';

const args = process.argv.slice(2);
const dir = args.find((a) => !a.startsWith('--'));
const out = args.includes('--out') ? args[args.indexOf('--out') + 1] : null;
const check = args.includes('--check');
if (!dir || !out) {
  console.error('Použití: gen-mui-theme.mjs <ppf-material-dir> --out <ppfMuiTheme.ts> [--check]');
  process.exit(2);
}
const tokensPath = join(resolve(dir), 'tokens', 'tokens.json');
if (!existsSync(tokensPath)) {
  console.error(`tokens.json nenalezen: ${tokensPath}`);
  process.exit(2);
}
const t = JSON.parse(readFileSync(tokensPath, 'utf8'));
const role = t.color.role;
const status = t.color.status;
const aa = t.color.aa;
const px = (v) => parseInt(String(v), 10);
const ms = (v) => parseInt(String(v), 10);
// Přepínač: rozměry a doba přechodu jsou tokeny od ppf-material 1.1.0; starší skill je nemá → skončit s návodem, nehádat.
const sw = { w: px(t.size.switch_track_width), h: px(t.size.switch_track_height), thumb: px(t.size.switch_thumb), ms: ms(t.motion.duration.switch) };
if (Object.values(sw).some((v) => !Number.isFinite(v))) {
  console.error(`ppf-material ${t.$meta?.version ?? '?'} nemá tokeny přepínače (size.switch_track_width, size.switch_track_height, size.switch_thumb, motion.duration.switch) — aktualizuj plugin ppf-material na 1.1.0 nebo novější`);
  process.exit(2);
}
const swPad = (sw.h - sw.thumb) / 2; // knoflík svisle uprostřed dráhy
const shadows = Array.from({ length: 25 }, (_, i) => (t.elevation[String(i)] && t.elevation[String(i)] !== 'none' ? t.elevation[String(i)] : 'none'));
// MUI má 25 úrovní; ppf-material definuje 0–4 a úrovně 4–5 vyhrazuje dialogům a menu.
// Vyšší úrovně, které MUI komponenty používají (Dialog = 24, Menu = 8, Drawer = 16), mapujeme na level 4.
[5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24].forEach((i) => { shadows[i] = t.elevation['4']; });
const opacity = (rgba) => Number(String(rgba).match(/,\s*(\.?\d*\.?\d+)\)$/)[1]);
const scale = t.type.scale;
const font = (name) => t.type.font[name].value;
const typo = (s) => `{ fontFamily: FONT.${s.font}, fontSize: ${px(s.size)}, lineHeight: ${s.line ?? 1.2}, fontWeight: ${s.weight ?? 400}${s.letterSpacing ? `, letterSpacing: '${s.letterSpacing}'` : ''}${s.transform ? `, textTransform: '${s.transform}'` : ''} }`;

const ts = `// PPF × Material 3 → MUI theme.
// Generated from ppf-material tokens/tokens.json v${t.$meta.version} (brand synced ${t.$meta.brand_source.synced} from ${t.$meta.brand_source.repo}) — do NOT edit manually.
// Přegenerovat: devkit theme <adresář tohoto souboru> --material <složka skillu ppf-material> (skill ppf-citizen-ai-devkit)
// Pravidla, která theme nevynutí (rozložení, copper < 10 % plochy, status = tečka + slovo): ppf-material references/principles.md.
import { createTheme } from '@mui/material/styles';
import type { Shadows } from '@mui/material/styles';

export const FONT = {
  display: "${font('display')}",
  body: "${font('body')}",
  mono: "${font('mono')}",
  icon: "${font('icon')}"
};

export const PPF = {
  navy: '${role.primary}',
  navyDark: '${aa.navy_dark.value}',
  copper: '${role.accent}',
  copperText: '${role['accent-text']}',
  copperWash: '${role['surface-container-warm']}',
  cream: '${role.surface}',
  white: '${role['surface-container']}',
  inkSecondary: '${role['on-surface-variant']}',
  outline: '${role.outline}',
  outlineVariant: '${role['outline-variant']}',
  inverse: '${role['inverse-surface']}',
  muted: '${role.muted}',
  chart: [${t.color.chart_web.map((c) => `'${c}'`).join(', ')}],
  status: {
    positive: { dot: '${status.positive}', text: '${status.positive_text}', bg: '${status.positive_bg}' },
    negative: { dot: '${status.negative}', text: '${status.negative_text}', bg: '${status.negative_bg}' },
    caution: { dot: '${status.caution}', text: '${status.caution_text}', bg: '${status.caution_bg}' },
    neutral: { dot: '${status.neutral}', text: '${role['on-surface-variant']}', bg: '${status.neutral_bg}' }
  },
  selected: { layer: '${t.state_layer.selected}', marker: '${t.state_layer.selected_marker}' },
  radius: { small: ${px(t.shape.small)}, medium: ${px(t.shape.medium)}, full: ${px(t.shape.full)} },
  size: { button: ${px(t.size.button)}, input: ${px(t.size.input)}, chip: ${px(t.size.chip)}, tab: ${px(t.size.tab)}, appBar: ${px(t.size.app_bar)}, rowCompact: ${px(t.size.row_compact)} }
};

const shadows = [
${shadows.map((s) => `  '${s}'`).join(',\n')}
] as Shadows;

export const ppfMuiTheme = createTheme({
  palette: {
    mode: 'light',
    primary: { main: PPF.navy, dark: PPF.navyDark, contrastText: '${role['on-primary']}' },
    secondary: { main: PPF.copper, contrastText: PPF.white },
    background: { default: PPF.cream, paper: PPF.white },
    text: { primary: '${role['on-surface']}', secondary: PPF.inkSecondary, disabled: PPF.muted },
    divider: PPF.outline,
    // state layers ppf-material: hover ${t.state_layer.hover}, focus ${t.state_layer.focus}, pressed ${t.state_layer.pressed}
    action: {
      hoverOpacity: ${opacity(t.state_layer.hover)},
      focusOpacity: ${opacity(t.state_layer.focus)},
      activatedOpacity: ${opacity(t.state_layer.pressed)},
      selectedOpacity: ${opacity(t.state_layer.selected)},
      disabledOpacity: ${t.state_layer.disabled_opacity}
    },
    success: { main: PPF.status.positive.dot, contrastText: PPF.status.positive.text },
    error: { main: PPF.status.negative.dot, contrastText: PPF.status.negative.text },
    warning: { main: PPF.status.caution.dot, contrastText: PPF.status.caution.text }
  },
  shape: { borderRadius: PPF.radius.small },
  shadows,
  typography: {
    fontFamily: FONT.body,
    h1: ${typo(scale['page-title'])},
    h2: ${typo(scale['section-title'])},
    subtitle1: ${typo(scale['card-title'])},
    body1: ${typo(scale.body)},
    body2: ${typo(scale.secondary)},
    button: ${typo({ ...scale.label, transform: 'none' })}, // PPF Material: verzálky jen eyebrow
    overline: ${typo(scale.eyebrow)}
  },
  transitions: {
    duration: { shortest: ${ms(t.motion.duration.short)}, shorter: ${ms(t.motion.duration.short)}, short: ${ms(t.motion.duration.medium)}, standard: ${ms(t.motion.duration.medium)}, complex: ${ms(t.motion.duration.long)}, enteringScreen: ${ms(t.motion.duration.long)}, leavingScreen: ${ms(t.motion.duration.medium)} },
    easing: { easeInOut: '${t.motion.easing.standard}', easeOut: '${t.motion.easing.standard}', easeIn: '${t.motion.easing.standard}', sharp: '${t.motion.easing.standard}' }
  },
  components: {
    // ppf-material adoption.md: ripple se nepřejímá, nahrazuje ho statický state layer
    MuiButtonBase: { defaultProps: { disableRipple: true } },
    // disabled = opacity .38 bez vrstvy (tokens.md state layers); prvek si nechá svou barvu
    MuiButton: { styleOverrides: {
      root: { height: PPF.size.button, borderRadius: PPF.radius.small, '&.Mui-disabled': { opacity: 0.38 } },
      contained: { '&.Mui-disabled': { backgroundColor: PPF.navy, color: '${role['on-primary']}' } },
      outlined: { '&.Mui-disabled': { borderColor: PPF.outline, color: PPF.navy } }
    } },
    // přepínač s popiskem zarovnaný s ostatními poli (MUI dává -11 px)
    MuiFormControlLabel: { styleOverrides: { root: { marginLeft: 0 } } },
    // components.md Switch: rozměry a doba přechodu z tokenů (size.switch_*, motion.duration.switch); vypnuto = obrys a šedý knoflík, zapnuto = navy výplň a krémový knoflík
    MuiSwitch: { styleOverrides: {
      root: { width: ${sw.w}, height: ${sw.h}, padding: 0, margin: '0 10px 0 0' },
      switchBase: { padding: ${swPad}, color: PPF.outline, transitionDuration: '${sw.ms}ms',
        '&.Mui-checked': { transform: 'translateX(${sw.w - sw.thumb - 2 * swPad}px)', color: '${role['on-primary']}', '& + .MuiSwitch-track': { backgroundColor: PPF.navy, borderColor: PPF.navy, opacity: 1 } },
        '&.Mui-disabled': { opacity: 0.38 } },
      thumb: { width: ${sw.thumb}, height: ${sw.thumb}, boxShadow: 'none' },
      track: { borderRadius: PPF.radius.full, boxSizing: 'border-box', border: '2px solid ' + PPF.outline, backgroundColor: 'transparent', opacity: 1 }
    } },
    MuiOutlinedInput: { styleOverrides: { root: { borderRadius: PPF.radius.small } } },
    MuiPaper: { styleOverrides: { rounded: { borderRadius: PPF.radius.medium } } },
    MuiDialog: { styleOverrides: { paper: { borderRadius: PPF.radius.medium } } },
    MuiCard: { styleOverrides: { root: { borderRadius: PPF.radius.medium } } },
    MuiChip: { styleOverrides: { root: { borderRadius: PPF.radius.full, height: PPF.size.chip } } },
    MuiTab: { styleOverrides: { root: { minHeight: PPF.size.tab, textTransform: 'none' } } },
    MuiTabs: { styleOverrides: { indicator: { backgroundColor: PPF.copper } } },
    MuiAppBar: { styleOverrides: { root: { borderRadius: 0, minHeight: PPF.size.appBar } } },
    MuiTableHead: { styleOverrides: { root: { backgroundColor: PPF.navy, '& .MuiTableCell-root': { color: '${role['on-primary']}' } } } },
    MuiTableCell: { styleOverrides: { root: { borderBottomColor: PPF.outlineVariant } } },
    MuiListItemButton: { styleOverrides: { root: { '&.Mui-selected, &.Mui-selected:hover': { backgroundColor: PPF.selected.layer, boxShadow: PPF.selected.marker } } } },
    MuiMenuItem: { styleOverrides: { root: { '&.Mui-selected, &.Mui-selected:hover': { backgroundColor: PPF.selected.layer, boxShadow: PPF.selected.marker } } } },
    MuiSnackbarContent: { styleOverrides: { root: { backgroundColor: PPF.inverse, color: '${role['on-inverse-surface']}' } } },
    MuiTooltip: { styleOverrides: { tooltip: { backgroundColor: PPF.inverse, borderRadius: PPF.radius.small } } },
    MuiLink: { styleOverrides: { root: { color: PPF.copperText } } },
    // Material Symbols Outlined; font načti přes @font-face / <link> v rootu webpartu
    MuiIcon: { defaultProps: { baseClassName: 'material-symbols-outlined' } }
  }
});
`;


// --check porovnává HODNOTY, ne hlavičku: hlavička (komentáře na začátku souboru) nese verzi tokenů a zdroj
// (brand_source.repo), které se po povýšení ppf-material změní, i když se hodnoty nezměnily. Rozdíl jen v hlavičce
// se vypíše jako INFO a vrací 0; rozdíl v hodnotách je drift (rc 1).
const hlavicka = (s) => (s.match(/^(\/\/[^\n]*\n)+/) || [''])[0];
const telo = (s) => s.slice(hlavicka(s).length);

if (check) {
  const current = existsSync(out) ? readFileSync(out, 'utf8') : '';
  if (current === ts) { console.log(`OK: ${out} odpovídá tokens v${t.$meta.version}`); process.exit(0); }
  if (current && telo(current) === telo(ts)) {
    console.log(`INFO: ${out}: hodnoty odpovídají tokens v${t.$meta.version}, liší se jen hlavička se zdrojem (přegenerováním bez --check se aktualizuje)`);
    process.exit(0);
  }
  console.error(`DRIFT: ${out} neodpovídá vygenerovanému výstupu z tokens v${t.$meta.version} — přegeneruj bez --check`);
  process.exit(1);
}
writeFileSync(out, ts);
console.log(`${out} ← tokens v${t.$meta.version} (synced ${t.$meta.brand_source.synced})`);
