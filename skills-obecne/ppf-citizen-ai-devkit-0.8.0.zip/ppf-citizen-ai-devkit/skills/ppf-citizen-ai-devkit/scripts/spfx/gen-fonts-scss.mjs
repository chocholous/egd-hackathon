#!/usr/bin/env node
// Vygeneruje SCSS s @font-face pro brand fonty z ppf-material assets/fonts (woff2 jako data-URI).
//
// Proč data-URI a ne URL: SPFx bundle se servíruje z CDN/app catalogu a relativní cesty k fontům
// v .sppkg nefungují spolehlivě; thor tenhle postup používá od začátku (ppf-fonts.scss ~176 kB).
// Cena je velikost bundle, výhoda je nulová závislost na Site Assets a na tom, kdo je tam nahrál.
//
// Použití: node gen-fonts-scss.mjs <ppf-material-dir> --out spfx/src/webparts/<wp>/components/ppf/ppf-fonts.scss [--check]

import { readFileSync, readdirSync, writeFileSync, existsSync } from 'node:fs';
import { join, resolve } from 'node:path';

const args = process.argv.slice(2);
const dir = args.find((a) => !a.startsWith('--'));
const out = args.includes('--out') ? args[args.indexOf('--out') + 1] : null;
const check = args.includes('--check');
if (!dir || !out) {
  console.error('Použití: gen-fonts-scss.mjs <ppf-material-dir> --out <ppf-fonts.scss> [--check]');
  process.exit(2);
}
const fontsDir = join(resolve(dir), 'assets', 'fonts');
if (!existsSync(fontsDir)) { console.error(`assets/fonts nenalezen: ${fontsDir}`); process.exit(2); }

// Váha z názvu souboru (NeueHaasUnicaW1G-Medium.woff2 → 500). Neznámý název = chyba, ne tichý default.
const WEIGHTS = { Light: 300, Regular: 400, Medium: 500, Bold: 700 };
const FAMILY = { NeueHaasUnicaW1G: 'Neue Haas Unica W1G', PPFDisplay: 'PPFDisplay' };
const files = readdirSync(fontsDir).filter((f) => f.endsWith('.woff2')).sort();
if (files.length === 0) { console.error(`žádný .woff2 v ${fontsDir}`); process.exit(2); }

const faces = files.map((f) => {
  const m = f.match(/^([A-Za-z0-9]+)-([A-Za-z]+)\.woff2$/);
  if (!m || !(m[1] in FAMILY) || !(m[2] in WEIGHTS)) { console.error(`nerozpoznaný název fontu: ${f}`); process.exit(2); }
  const b64 = readFileSync(join(fontsDir, f)).toString('base64');
  return `@font-face {
  font-family: "${FAMILY[m[1]]}";
  font-weight: ${WEIGHTS[m[2]]};
  font-style: normal;
  font-display: swap;
  src: url("data:font/woff2;base64,${b64}") format("woff2");
}`;
});
const meta = JSON.parse(readFileSync(join(resolve(dir), 'tokens', 'tokens.json'), 'utf8')).$meta;
const scss = `// PPF brand fonts as data-URI, generated from ppf-material v${meta.version} assets/fonts — do NOT edit manually.
// Přegenerovat: devkit theme <adresář tohoto souboru> --material <složka skillu ppf-material> (skill ppf-citizen-ai-devkit)
// Material Symbols Outlined (ikony) tady nejsou: načítají se z fonts.googleapis.com v onInit webpartu.

${faces.join('\n\n')}
`;

// --check porovnává HODNOTY, ne hlavičku: hlavička (komentáře na začátku souboru) nese verzi tokenů a zdroj
// (brand_source.repo), které se po povýšení ppf-material změní, i když se hodnoty nezměnily. Rozdíl jen v hlavičce
// se vypíše jako INFO a vrací 0; rozdíl v hodnotách je drift (rc 1).
const hlavicka = (s) => (s.match(/^(\/\/[^\n]*\n)+/) || [''])[0];
const telo = (s) => s.slice(hlavicka(s).length);

if (check) {
  const current = existsSync(out) ? readFileSync(out, 'utf8') : '';
  if (current === scss) { console.log(`OK: ${out} odpovídá fontům ppf-material v${meta.version}`); process.exit(0); }
  if (current && telo(current) === telo(scss)) {
    console.log(`INFO: ${out}: fonty odpovídají ppf-material v${meta.version}, liší se jen hlavička se zdrojem (přegenerováním bez --check se aktualizuje)`);
    process.exit(0);
  }
  console.error(`DRIFT: ${out} — přegeneruj bez --check`); process.exit(1);
}
writeFileSync(out, scss);
console.log(`${out} ← ${files.length} fontů z ppf-material v${meta.version} (${Math.round(scss.length / 1024)} kB)`);
