#!/usr/bin/env node
// Hodnoty pro kontrolu vzhledu (npm run design-check) z ppf-material tokens/tokens.json.
//
// Proč existuje: pravidla v tools/lib/design-rules.mjs měří vykreslenou appku proti barvám, písmům, zaoblení
// a velikosti verzálek. Dokud byly ty hodnoty opsané v pravidlech, kontrola po změně tokenů měřila proti
// staré verzi a nikdo se to nedozvěděl. Teď je bere z tohoto souboru, který vzniká ze stejných tokenů a stejným
// příkazem (devkit theme) jako ppfMuiTheme.ts; `--check` hlásí drift stejně.
//
// Použití: node gen-design-values.mjs <ppf-material-dir> --out spfx/src/app/ppf/ppfDesign.json [--check]
// Chyba: chybějící tokens.json nebo token, ze kterého se hodnota bere = rc 2 se jménem tokenu (nehádá se).
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { join, resolve } from 'node:path';

const args = process.argv.slice(2);
const dir = args.find((a) => !a.startsWith('--'));
const out = args.includes('--out') ? args[args.indexOf('--out') + 1] : null;
const check = args.includes('--check');
if (!dir || !out) { console.error('Použití: gen-design-values.mjs <ppf-material-dir> --out <ppfDesign.json> [--check]'); process.exit(2); }
const tokensPath = join(resolve(dir), 'tokens', 'tokens.json');
if (!existsSync(tokensPath)) { console.error(`tokens.json nenalezen: ${tokensPath}`); process.exit(2); }
const t = JSON.parse(readFileSync(tokensPath, 'utf8'));

const chybi = [];
const get = (cesta) => {
  const v = cesta.split('.').reduce((o, k) => (o == null ? o : o[k]), t);
  if (v == null) chybi.push(cesta);
  return v;
};
const rgb = (hex) => { const m = /^#([0-9a-f]{6})$/i.exec(String(hex)); if (!m) return null; const n = parseInt(m[1], 16); return `${n >> 16}, ${(n >> 8) & 255}, ${n & 255}`; };
const barva = (cesta) => { const c = rgb(get(cesta)); if (!c) chybi.push(`${cesta} (není #rrggbb)`); return c; };
const rodina = (cesta) => String(get(cesta) ?? '').split(',')[0].trim().replace(/^['"]|['"]$/g, '');
const px = (cesta) => parseInt(String(get(cesta)), 10);

const navy = barva('color.role.primary');
const scale = get('type.scale') || {};
const verzalky = Object.values(scale).filter((s) => s && s.transform === 'uppercase').map((s) => parseInt(String(s.size), 10));
if (!verzalky.length) chybi.push('type.scale.*.transform = uppercase');
const hodnoty = {
  $zdroj: `ppf-material tokens/tokens.json v${t.$meta?.version ?? '?'} — generováno (devkit theme), needituj`,
  plne: [`rgb(${navy})`, `rgb(${barva('color.aa.navy_dark.value')})`],            // pozadí plného tlačítka (a jeho hover)
  copper: [`rgb(${barva('color.role.accent')})`, `rgb(${barva('color.role.accent-text')})`], // plná copper plocha
  stinRgb: navy,                                                                       // stíny se míchají z primární barvy
  pisma: ['display', 'body', 'mono', 'icon'].map((f) => rodina(`type.font.${f}.value`)),
  mono: rodina('type.font.mono.value'),
  radiusPx: [px('shape.small'), px('shape.medium')],
  verzalkyMaxPx: Math.max(...verzalky),
};
if (chybi.length) { console.error(`ppf-material ${t.$meta?.version ?? '?'}: chybí tokeny pro kontrolu vzhledu: ${[...new Set(chybi)].join(', ')}`); process.exit(2); }

const json = JSON.stringify(hodnoty, null, 2) + '\n';
// --check porovnává hodnoty; rozdíl jen v řádku $zdroj (verze tokenů) je INFO, ne drift — stejně jako u theme
const telo = (s) => { try { const o = JSON.parse(s); delete o.$zdroj; return JSON.stringify(o); } catch { return null; } };
if (check) {
  const current = existsSync(out) ? readFileSync(out, 'utf8') : '';
  if (current === json) { console.log(`OK: ${out} odpovídá tokens v${t.$meta.version}`); process.exit(0); }
  if (current && telo(current) === telo(json)) { console.log(`INFO: ${out}: hodnoty odpovídají tokens v${t.$meta.version}, liší se jen řádek se zdrojem (přegenerováním bez --check se aktualizuje)`); process.exit(0); }
  console.error(`DRIFT: ${out} neodpovídá vygenerovanému výstupu z tokens v${t.$meta.version} — přegeneruj bez --check`);
  process.exit(1);
}
writeFileSync(out, json);
console.log(`${out} ← tokens v${t.$meta.version}`);
