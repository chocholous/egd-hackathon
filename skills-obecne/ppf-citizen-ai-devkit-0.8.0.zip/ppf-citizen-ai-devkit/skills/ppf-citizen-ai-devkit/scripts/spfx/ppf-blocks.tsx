// Stavební bloky obrazovky PPF × Material pro appky z ppf-citizen-ai-devkit.
// sources: ppf-material 1.1.0 (z této verze vycházejí principy a vzorové obrazovky, na které se odkazuje; platnost odkazů hlídá dev/ppf-material-links.test.mjs)
// Kopíruje ho `devkit theme` vedle ppfMuiTheme.ts — NEUPRAVUJ v projektu, změna patří do kitu
// (scripts/spfx/ppf-blocks.tsx); `devkit theme … --check` hlásí rozdíl.
//
// Rozvržení podle ppf-material (references/principles.md 08–10, examples/App - Schvalovaci fronta):
//   AppShell   lišta appky (navy 64 px; vpravo akce, místo pro tlačítko Připomínky a uživatel) + záložky s počty
//              + filtry vpravo v liště záložek
//              + sloupce: [rail vlevo] | obsah | [panel detailu vpravo, 420 px]
//   DataTable  jedna tabulka, řádek otevírá detail (žádná tlačítka ani pole v řádku), vybraný řádek
//              copper 10 % + 3px marker, sloupce s čísly a daty neproporcionálním písmem vpravo
//   DetailPanel  detail vedle seznamu (nikdy přes něj), oddíly Section, akce v liště dole
//   ConfirmDialog  jediné povolené okno: potvrzení a mazání, volitelně s povinným komentářem
//   StatusBadge  stav = tečka + slovo
//   BulkBar    hromadné akce v jedné tmavé liště
// Atributy data-ppf=… čte `npm run design-check` (kontrola vzhledu nad lokálním harnessem).
import * as React from 'react';
import { ThemeProvider } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import IconButton from '@mui/material/IconButton';
import TextField from '@mui/material/TextField';
import { ppfMuiTheme, PPF, FONT } from './ppfMuiTheme';

/** Material Symbols Outlined + JetBrains Mono (osy podle ppf-material tokens.icon.axes; stejný odkaz
 *  používají examples/ ppf-material a references/kod.md §UI). Vloží se jednou na stránku. */
export const PPF_FONT_CSS = 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,400,0,0&family=JetBrains+Mono:wght@400;500&display=block';
// display=block: dokud font ikon nedorazí, je ikona neviditelná (se swap by se ukázal její název, např. „support_agent“).
const FONT_LINK_ID = 'ppf-material-fonts';

export function usePpfFonts(): void {
  React.useEffect(() => {
    if (typeof document === 'undefined' || document.getElementById(FONT_LINK_ID)) return;
    const l = document.createElement('link');
    l.id = FONT_LINK_ID; l.rel = 'stylesheet'; l.href = PPF_FONT_CSS;
    document.head.appendChild(l);
  }, []);
}

const EYEBROW: React.CSSProperties = { fontSize: 11, letterSpacing: '.08em', textTransform: 'uppercase', color: PPF.muted, fontWeight: 500 };
const BORDER = `1px solid ${PPF.outline}`;
const DIVIDER = `1px solid ${PPF.outlineVariant}`;

/** Ikona Material Symbols Outlined (nikdy SVG ani emoji). */
export function Icon({ name, size = 20, color, fill }: { name: string; size?: number; color?: string; fill?: boolean }): React.ReactElement {
  return (
    <span aria-hidden="true" style={{
      fontFamily: FONT.icon, fontSize: size, lineHeight: 1, color, display: 'inline-block', userSelect: 'none',
      width: size, height: size, overflow: 'hidden', flex: 'none', whiteSpace: 'nowrap', // bez fontu se název ikony neroztáhne do textu
      fontVariationSettings: `'FILL' ${fill ? 1 : 0}, 'wght' 400, 'GRAD' 0, 'opsz' ${Math.max(20, Math.min(48, size))}`,
    }}>{name}</span>
  );
}

/** Popisek nad skupinou (jediné povolené verzálky). */
export function Eyebrow({ children }: { children: React.ReactNode }): React.ReactElement {
  return <span style={EYEBROW} data-ppf="eyebrow">{children}</span>;
}

/** Čísla, data, ID: neproporcionální písmo. */
export function Mono({ children, muted }: { children: React.ReactNode; muted?: boolean }): React.ReactElement {
  return <span style={{ fontFamily: FONT.mono, fontSize: '0.92em', color: muted ? PPF.muted : undefined }} data-ppf="mono">{children}</span>;
}

export type Tone = 'positive' | 'negative' | 'caution' | 'neutral' | 'accent';
const TONES: Record<Tone, { dot: string; text: string; bg: string }> = {
  ...PPF.status,
  accent: { dot: PPF.copper, text: PPF.copperText, bg: PPF.selected.layer },
};

/** Stav = tečka + slovo (barva nikdy nenese význam sama). */
export function StatusBadge({ tone = 'neutral', children }: { tone?: Tone; children: React.ReactNode }): React.ReactElement {
  const t = TONES[tone];
  return (
    <span data-ppf="status" style={{
      display: 'inline-flex', alignItems: 'center', gap: 6, height: 26, padding: '0 10px', borderRadius: PPF.radius.full,
      background: t.bg, color: t.text, fontSize: 12, whiteSpace: 'nowrap',
    }}>
      <span style={{ width: 6, height: 6, borderRadius: PPF.radius.full, background: t.text, flex: 'none' }} />{children}
    </span>
  );
}

/** Věcné sdělení v toku stránky (místo barevných Alertů): tečka + text, bílá plocha s obrysem. */
export function Notice({ tone = 'neutral', children, action }: { tone?: Tone; children: React.ReactNode; action?: React.ReactNode }): React.ReactElement {
  return (
    <div role={tone === 'negative' ? 'alert' : 'status'} data-ppf="notice" style={{
      display: 'flex', alignItems: 'center', gap: 10, padding: '10px 14px', border: BORDER, borderRadius: PPF.radius.small,
      background: PPF.white, fontSize: 14, color: tone === 'negative' ? PPF.status.negative.text : PPF.navy,
    }}>
      <span style={{ width: 8, height: 8, borderRadius: PPF.radius.full, background: TONES[tone].text, flex: 'none' }} />
      <span style={{ flex: 1 }}>{children}</span>{action}
    </div>
  );
}

export interface ShellTab { id: string; label: string; count?: number }

/** Výška od horního okraje kostry do spodku okna — na SharePointu je nad appkou rámec webu. */
function useFillHeight(ref: React.RefObject<HTMLDivElement>): number | undefined {
  const [h, setH] = React.useState<number | undefined>();
  React.useLayoutEffect(() => {
    const upd = (): void => { const el = ref.current; if (el) setH(Math.max(480, window.innerHeight - el.getBoundingClientRect().top - 8)); };
    upd();
    window.addEventListener('resize', upd);
    return () => window.removeEventListener('resize', upd);
  }, []);
  return h;
}
function useWidth(ref: React.RefObject<HTMLDivElement>): number {
  const [w, setW] = React.useState(1280);
  React.useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return undefined;
    const upd = (): void => setW(el.clientWidth);
    upd();
    if (typeof ResizeObserver === 'undefined') { window.addEventListener('resize', upd); return () => window.removeEventListener('resize', upd); }
    const ro = new ResizeObserver(upd); ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return w;
}

/** Pod touto šířkou kostry se panel detailu zobrazuje místo seznamu (ne přes něj) a rail se skryje. */
export const NARROW = 960;

/** AppShell ukazuje panel detailu nebo je užší než NARROW: DataTable pak schová sloupce označené secondary. */
const DetailOpen = React.createContext(false);

/**
 * Kostra appky: lišta, záložky s počty, filtry v liště záložek, sloupce.
 * Obsahuje ThemeProvider a načtení fontů, takže App ji jen obalí.
 */
export function AppShell(props: {
  title: string; icon?: string; actions?: React.ReactNode; user?: string;
  tabs?: ShellTab[]; tab?: string; onTab?: (id: string) => void;
  /** filtry jako čipy vpravo v liště záložek (vzor fronta); delší sadu filtrů dej do rail */
  toolbar?: React.ReactNode;
  rail?: React.ReactNode;
  /** panel detailu (DetailPanel) nebo null; při úzké šířce nahradí obsah */
  detail?: React.ReactNode;
  /** plovoucí prvky nad obsahem: BulkBar */
  overlay?: React.ReactNode;
  children: React.ReactNode;
}): React.ReactElement {
  usePpfFonts();
  const ref = React.useRef<HTMLDivElement>(null);
  const height = useFillHeight(ref);
  const width = useWidth(ref);
  const narrow = width < NARROW;
  const { title, icon, actions, user, tabs, tab, onTab, toolbar, rail, detail, overlay, children } = props;
  const cols = [!narrow && rail ? '260px' : '', narrow && detail ? '' : 'minmax(0,1fr)', detail ? (narrow ? 'minmax(0,1fr)' : '420px') : ''].filter(Boolean).join(' ');
  return (
    <ThemeProvider theme={ppfMuiTheme}>
      <div ref={ref} data-ppf="shell" style={{
        fontFamily: FONT.body, color: PPF.navy, background: PPF.cream, height, minHeight: 480,
        display: 'flex', flexDirection: 'column', position: 'relative', overflow: 'hidden',
      }}>
        <header data-ppf="appbar" style={{ height: PPF.size.appBar, flex: 'none', padding: '0 24px', background: PPF.navy, color: PPF.cream, display: 'flex', alignItems: 'center', gap: 16 }}>
          {icon && <Icon name={icon} size={22} />}
          <span style={{ fontSize: 18, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} data-cadk-id="nazev">{title}</span>
          <span style={{ flex: 1 }} />
          {actions}
          {/* pevné místo pro tlačítko Připomínky: na DEV a TEST ho sem vloží vrstva připomínek (src/feedback), jinde zůstává prázdné */}
          <span data-ppf="pripominky" style={{ display: 'contents' }} />
          {user && <span title={user} style={{ width: 32, height: 32, flex: 'none', borderRadius: PPF.radius.full, background: PPF.copper, color: PPF.white, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 500 }}>{initials(user)}</span>}
        </header>
        {(tabs?.length || toolbar) && (
          <div style={{ flex: 'none', display: 'flex', alignItems: 'center', gap: 4, padding: '0 16px', background: PPF.white, borderBottom: BORDER, overflowX: 'auto' }}>
            <div role="tablist" style={{ display: 'flex' }}>
              {(tabs || []).map((t) => {
                const on = t.id === tab;
                return (
                  <button key={t.id} type="button" role="tab" aria-selected={on} data-cadk-id={`zalozka-${t.id}`} onClick={() => onTab?.(t.id)}
                    style={{
                      height: PPF.size.tab, padding: '0 18px', display: 'flex', alignItems: 'center', gap: 8, border: 'none', background: 'transparent',
                      fontFamily: 'inherit', fontSize: 14, fontWeight: 500, color: on ? PPF.navy : PPF.inkSecondary, cursor: 'pointer', whiteSpace: 'nowrap',
                      boxShadow: on ? `inset 0 -2px 0 ${PPF.copper}` : 'none', transition: 'box-shadow 200ms cubic-bezier(.2,0,0,1)',
                    }}>
                    {t.label}
                    {t.count !== undefined && <span style={{
                      height: 20, minWidth: 20, padding: '0 6px', boxSizing: 'border-box', borderRadius: PPF.radius.full, fontFamily: FONT.mono, fontSize: 11,
                      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                      background: on ? 'rgba(176,111,65,.14)' : 'rgba(0,44,90,.06)', color: on ? PPF.copperText : PPF.inkSecondary,
                    }}>{t.count}</span>}
                  </button>
                );
              })}
            </div>
            <span style={{ flex: 1 }} />
            {toolbar && <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 8px 6px 0' }}>{toolbar}</div>}
          </div>
        )}
        <DetailOpen.Provider value={!!detail || narrow}>
        <div style={{ flex: 1, minHeight: 0, display: 'grid', gridTemplateColumns: cols }}>
          {!narrow && rail && <aside data-ppf="rail" style={{ minHeight: 0, overflow: 'auto', background: PPF.white, borderRight: BORDER, padding: '20px 16px', display: 'flex', flexDirection: 'column', gap: 20 }}>{rail}</aside>}
          {!(narrow && detail) && <main data-ppf="main" style={{ minHeight: 0, overflow: 'auto', padding: '24px 24px 96px' }}>{children}</main>}
          {detail}
        </div>
        </DetailOpen.Provider>
        {overlay}
        <style>{'[data-ppf=shell] button:focus-visible,[data-ppf=shell] [role=tab]:focus-visible{outline:2px solid #002C5A;outline-offset:2px}'}</style>
      </div>
    </ThemeProvider>
  );
}

function initials(name: string): string {
  const p = name.replace(/[,()]/g, ' ').split(/\s+/).filter(Boolean);
  return ((p[0]?.[0] || '') + (p[1]?.[0] || '')).toUpperCase();
}

/** Skupina filtrů v railu. */
export function FilterGroup({ label, children }: { label: string; children: React.ReactNode }): React.ReactElement {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }} data-ppf="filters">
      <Eyebrow>{label}</Eyebrow>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>{children}</div>
    </div>
  );
}

/** Filtrační čip (vyp: obrys, zap: copper 12 %). */
export function FilterChip({ selected, onClick, children, count }: { selected?: boolean; onClick: () => void; children: React.ReactNode; count?: number }): React.ReactElement {
  return (
    <button type="button" aria-pressed={!!selected} onClick={onClick} data-ppf="chip" style={{
      height: 32, padding: '0 14px', border: `1px solid ${selected ? PPF.copper : PPF.outline}`, borderRadius: PPF.radius.full,
      background: selected ? 'rgba(176,111,65,.12)' : 'transparent', color: selected ? PPF.copperText : PPF.navy,
      fontFamily: 'inherit', fontSize: 13, whiteSpace: 'nowrap', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 6,
    }}>
      {children}{count !== undefined && <span style={{ fontFamily: FONT.mono, fontSize: 11, color: PPF.muted }}>{count}</span>}
    </button>
  );
}

/** Hledání (filled varianta pro datové obrazovky). */
export function SearchField({ value, onChange, placeholder = 'Hledat' }: { value: string; onChange: (v: string) => void; placeholder?: string }): React.ReactElement {
  return (
    <label style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
      <span style={{ position: 'absolute', left: 10, color: PPF.inkSecondary, display: 'flex' }}><Icon name="search" size={18} /></span>
      <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} aria-label={placeholder} data-cadk-id="hledat"
        style={{
          width: '100%', minWidth: 200, height: 36, padding: '0 12px 0 36px', boxSizing: 'border-box', border: 'none',
          borderBottom: `2px solid ${PPF.outline}`, borderRadius: `${PPF.radius.small}px ${PPF.radius.small}px 0 0`,
          background: 'rgba(0,44,90,.04)', fontFamily: 'inherit', fontSize: 14, color: PPF.navy, outline: 'none',
        }} />
    </label>
  );
}

export interface Column<T> {
  key: string; label: string;
  /** šířka sloupce v CSS gridu (např. '2fr', '120px'); výchozí 1fr */
  width?: string;
  align?: 'left' | 'right' | 'center';
  /** čísla, data, ID: neproporcionální písmo (a typicky align right) */
  mono?: boolean;
  /** vedlejší sloupec: schová se, když je otevřený panel detailu (nebo při compact) */
  secondary?: boolean;
  render?: (row: T) => React.ReactNode;
}

/**
 * Jedna tabulka seznamu. Klik na řádek = onOpen (detail v panelu). Žádná tlačítka ani pole v řádku;
 * výběr pro hromadné akce přes checked/onCheck (BulkBar).
 */
export function DataTable<T>(props: {
  columns: Column<T>[]; rows: T[]; rowKey: (row: T) => string;
  selectedKey?: string; onOpen?: (row: T) => void;
  checked?: string[]; onCheck?: (keys: string[]) => void;
  empty?: React.ReactNode; label?: string;
  /** jen hlavní sloupce (bez secondary); výchozí: když AppShell ukazuje panel detailu */
  compact?: boolean;
}): React.ReactElement {
  const { rows, rowKey, selectedKey, onOpen, checked, onCheck, empty, label } = props;
  const detailOpen = React.useContext(DetailOpen);
  const compact = props.compact ?? detailOpen;
  const columns = compact ? props.columns.filter((c) => !c.secondary) : props.columns;
  const sel = !!onCheck;
  const tpl = [sel ? '44px' : '', ...columns.map((c) => c.width || '1fr')].filter(Boolean).join(' ');
  const all = sel && rows.length > 0 && rows.every((r) => (checked || []).includes(rowKey(r)));
  const toggle = (k: string): void => onCheck?.((checked || []).includes(k) ? (checked || []).filter((x) => x !== k) : [...(checked || []), k]);
  if (!rows.length && empty) return <>{empty}</>;
  return (
    <div role="table" aria-label={label} data-ppf="table" style={{ background: PPF.white, borderRadius: PPF.radius.medium, overflow: 'clip', boxShadow: ppfMuiTheme.shadows[1] }}>
      <div role="row" style={{
        display: 'grid', gridTemplateColumns: tpl, alignItems: 'center', padding: '12px 20px', background: PPF.navy, color: PPF.cream,
        fontSize: 12, letterSpacing: '.06em', textTransform: 'uppercase', position: 'sticky', top: 0, zIndex: 1, borderRadius: 0,
      }}>
        {sel && <CheckBox on={all} label="Vybrat vše" onClick={() => onCheck?.(all ? [] : rows.map(rowKey))} dark />}
        {columns.map((c) => <span role="columnheader" key={c.key} style={{ textAlign: c.align || (c.mono ? 'right' : 'left'), paddingRight: 12 }}>{c.label}</span>)}
      </div>
      {rows.map((r) => {
        const k = rowKey(r);
        const on = k === selectedKey;
        return (
          <div role="row" key={k} data-ppf="row" data-cadk-key={k} aria-selected={on} tabIndex={onOpen ? 0 : undefined}
            onClick={() => onOpen?.(r)} onKeyDown={(e) => { if (e.key === 'Enter' && onOpen) onOpen(r); }}
            className="ppf-row"
            style={{
              display: 'grid', gridTemplateColumns: tpl, alignItems: 'center', padding: '14px 20px', borderTop: DIVIDER,
              background: on ? PPF.selected.layer : undefined, boxShadow: on ? PPF.selected.marker : 'none', cursor: onOpen ? 'pointer' : 'default',
            }}>
            {sel && <CheckBox on={(checked || []).includes(k)} label="Vybrat" onClick={(e) => { e.stopPropagation(); toggle(k); }} />}
            {columns.map((c) => (
              <span role="cell" key={c.key} style={{
                textAlign: c.align || (c.mono ? 'right' : 'left'), paddingRight: 12, minWidth: 0, fontSize: 14,
                fontFamily: c.mono ? FONT.mono : undefined, overflowWrap: 'break-word', whiteSpace: c.mono ? 'nowrap' : undefined,
              }}>{c.render ? c.render(r) : String((r as unknown as Record<string, unknown>)[c.key] ?? '')}</span>
            ))}
          </div>
        );
      })}
      <style>{'.ppf-row:hover{background-color:rgba(0,44,90,.04)}.ppf-row[aria-selected=true]:hover{background-color:rgba(176,111,65,.10)}.ppf-row:focus-visible{outline:2px solid #002C5A;outline-offset:-2px;background-color:rgba(0,44,90,.08)}'}</style>
    </div>
  );
}

/** Hlavní text buňky + druhý řádek (ID, typ) menším neproporcionálním písmem. */
export function CellTitle({ title, sub }: { title: React.ReactNode; sub?: React.ReactNode }): React.ReactElement {
  return (
    <span style={{ display: 'flex', flexDirection: 'column', gap: 3, minWidth: 0 }}>
      <span style={{ fontSize: 14, fontWeight: 500 }}>{title}</span>
      {sub && <span style={{ fontFamily: FONT.mono, fontSize: 11, color: PPF.muted }}>{sub}</span>}
    </span>
  );
}

function CheckBox({ on, label, onClick, dark }: { on: boolean; label: string; onClick: (e: React.MouseEvent) => void; dark?: boolean }): React.ReactElement {
  return (
    <button type="button" role="checkbox" aria-checked={on} aria-label={label} onClick={onClick} data-ppf="check" style={{
      width: 20, height: 20, padding: 0, borderRadius: 4, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
      border: `1.5px solid ${on ? (dark ? PPF.cream : PPF.navy) : (dark ? 'rgba(246,239,226,.6)' : PPF.outline)}`,
      background: on ? (dark ? PPF.cream : PPF.navy) : 'transparent', color: dark ? PPF.navy : PPF.cream,
    }}>{on && <Icon name="check" size={16} />}</button>
  );
}

/**
 * Panel detailu vpravo vedle seznamu. Hlavička (ID, název, stav), oddíly, lišta akcí dole.
 * Úpravy probíhají v panelu (přepnutím do režimu úprav), ne v okně.
 */
export function DetailPanel(props: {
  eyebrow?: React.ReactNode; title: React.ReactNode; status?: React.ReactNode; meta?: React.ReactNode;
  onClose: () => void; actions?: React.ReactNode; children?: React.ReactNode;
}): React.ReactElement {
  const { eyebrow, title, status, meta, onClose, actions, children } = props;
  return (
    <aside data-ppf="detail" data-cadk-id="detail" aria-label="Detail" style={{ background: PPF.white, borderLeft: BORDER, minHeight: 0, overflow: 'auto', display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '22px 24px 20px', display: 'flex', flexDirection: 'column', gap: 10, borderBottom: DIVIDER }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontFamily: FONT.mono, fontSize: 12, color: PPF.muted, flex: 1 }}>{eyebrow}</span>
          <IconButton aria-label="Zavřít detail" onClick={onClose} size="small" sx={{ width: 36, height: 36 }}><Icon name="close" size={20} /></IconButton>
        </div>
        <h2 style={{ margin: 0, fontFamily: FONT.display, fontSize: 23, fontWeight: 400, lineHeight: 1.25 }}>{title}</h2>
        {(status || meta) && <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap', fontSize: 13, color: PPF.inkSecondary }}>{status}{meta}</div>}
      </div>
      <div style={{ flex: 1 }}>{children}</div>
      {actions && (
        <div data-ppf="actions" style={{ position: 'sticky', bottom: 0, zIndex: 2, padding: '16px 24px 20px', borderTop: DIVIDER, background: PPF.white, display: 'flex', flexWrap: 'wrap', gap: 8 }}>{actions}</div>
      )}
    </aside>
  );
}

/** Oddíl panelu detailu (nebo railu). */
export function Section({ label, action, children }: { label: string; action?: React.ReactNode; children: React.ReactNode }): React.ReactElement {
  return (
    <section style={{ padding: '20px 24px', display: 'flex', flexDirection: 'column', gap: 12, borderBottom: DIVIDER }} data-ppf="section">
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, minHeight: 20 }}><span style={{ flex: 1 }}><Eyebrow>{label}</Eyebrow></span>{action}</div>
      {children}
    </section>
  );
}

export interface Field { label: string; value: React.ReactNode; mono?: boolean; wide?: boolean }

/** Mřížka údajů: popisek nad hodnotou, dva sloupce. */
export function Fields({ items }: { items: Field[] }): React.ReactElement {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px 18px' }}>
      {items.map((f) => (
        <div key={f.label} style={{ display: 'flex', flexDirection: 'column', gap: 4, gridColumn: f.wide ? '1 / -1' : undefined, minWidth: 0 }}>
          <Eyebrow>{f.label}</Eyebrow>
          <span style={{ fontSize: 14, fontFamily: f.mono ? FONT.mono : undefined, overflowWrap: 'anywhere', whiteSpace: 'pre-wrap' }}>{f.value === '' || f.value === undefined || f.value === null ? '—' : f.value}</span>
        </div>
      ))}
    </div>
  );
}

/**
 * Jediné povolené okno: potvrzení a nevratné akce. Esc zavře, Enter potvrdí (mimo víceřádkový komentář).
 * comment.required = auditní komentář je povinný (zrušení, zamítnutí, smazání).
 */
export function ConfirmDialog(props: {
  open: boolean; title: string; body?: React.ReactNode; confirmLabel: string; cancelLabel?: string;
  comment?: { label: string; required?: boolean; maxLength?: number };
  onConfirm: (comment: string) => void | Promise<void>; onCancel: () => void;
}): React.ReactElement {
  const { open, title, body, confirmLabel, cancelLabel = 'Zrušit', comment, onConfirm, onCancel } = props;
  const [text, setText] = React.useState('');
  const [busy, setBusy] = React.useState(false);
  React.useEffect(() => { if (open) setText(''); }, [open]);
  const ok = !comment?.required || text.trim().length > 0;
  const go = async (): Promise<void> => {
    if (!ok || busy) return;
    setBusy(true);
    try { await onConfirm(text.trim()); } finally { setBusy(false); }
  };
  return (
    <Dialog open={open} onClose={onCancel} data-ppf="confirm" slotProps={{ paper: { sx: { width: 460, maxWidth: 'calc(100% - 32px)', p: '28px', borderRadius: `${PPF.radius.medium}px`, fontFamily: FONT.body, color: PPF.navy } }, backdrop: { sx: { backgroundColor: 'rgba(0,44,90,.42)' } } }}
      onKeyDown={(e) => { if (e.key === 'Enter' && (e.target as HTMLElement).tagName !== 'TEXTAREA') { e.preventDefault(); go().catch(() => undefined); } }}>
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: '14px' }} data-ppf="confirm">
        <h3 style={{ margin: 0, fontFamily: FONT.display, fontSize: 22, fontWeight: 400, color: PPF.navy }}>{title}</h3>
        {body && <div style={{ margin: 0, fontSize: 14, lineHeight: 1.6, color: PPF.inkSecondary }}>{body}</div>}
        {comment && (
          <TextField label={comment.label} value={text} onChange={(e) => setText(e.target.value)} multiline minRows={3} required={comment.required} autoFocus
            slotProps={{ htmlInput: { maxLength: comment.maxLength } }} />
        )}
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, paddingTop: 4 }}>
          <Button variant="text" onClick={onCancel} sx={{ color: PPF.copperText }}>{cancelLabel}</Button>
          <Button variant="contained" disableElevation disabled={!ok || busy} onClick={() => { go().catch(() => undefined); }}>{confirmLabel}</Button>
        </div>
      </Box>
    </Dialog>
  );
}

/** Prázdný stav: věcně, prázdná fronta je hotová práce, ne chyba. */
export function EmptyState({ icon = 'inbox', title, text, action }: { icon?: string; title: string; text?: string; action?: React.ReactNode }): React.ReactElement {
  return (
    <div data-ppf="empty" style={{ padding: '64px 24px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, textAlign: 'center' }}>
      <Icon name={icon} size={40} color={PPF.outline} />
      <span style={{ fontSize: 16, fontWeight: 500 }}>{title}</span>
      {text && <span style={{ fontSize: 14, color: PPF.inkSecondary, maxWidth: '44ch' }}>{text}</span>}
      {action}
    </div>
  );
}

/** Hromadné akce: jedna tmavá lišta nad spodním okrajem obsahu. Primární (světlá) akce vpravo, zavřít na konci. */
export function BulkBar({ count, summary, children, onClear }: { count: number; summary?: React.ReactNode; children: React.ReactNode; onClear: () => void }): React.ReactElement {
  if (!count) return <></>;
  return (
    <div data-ppf="bulkbar" style={{
      position: 'absolute', left: 24, right: 24, bottom: 24, height: 64, padding: '0 12px 0 20px', borderRadius: PPF.radius.medium,
      background: PPF.inverse, color: PPF.cream, display: 'flex', alignItems: 'center', gap: 16, boxShadow: ppfMuiTheme.shadows[3], zIndex: 3,
    }}>
      <span style={{ fontFamily: FONT.mono, fontSize: 14 }}>{count}</span>
      <span style={{ fontSize: 14 }}>vybráno{summary ? <> · {summary}</> : null}</span>
      <span style={{ flex: 1 }} />
      {children}
      <IconButton aria-label="Zrušit výběr" onClick={onClear} sx={{ color: PPF.cream }}><Icon name="close" size={20} /></IconButton>
    </div>
  );
}

/** Tlačítka podle priority ppf-material: jedno plné (Primary) na pohled, ostatní obrys / text. */
export function Primary(props: { onClick: () => void; disabled?: boolean; children: React.ReactNode; icon?: string; testId?: string }): React.ReactElement {
  return <Button variant="contained" disableElevation onClick={props.onClick} disabled={props.disabled} data-testid={props.testId} startIcon={props.icon ? <Icon name={props.icon} size={18} /> : undefined}>{props.children}</Button>;
}
export function Secondary(props: { onClick: () => void; disabled?: boolean; children: React.ReactNode; icon?: string; testId?: string }): React.ReactElement {
  return <Button variant="outlined" onClick={props.onClick} disabled={props.disabled} data-testid={props.testId} sx={{ borderColor: PPF.outline }} startIcon={props.icon ? <Icon name={props.icon} size={18} /> : undefined}>{props.children}</Button>;
}
export function Quiet(props: { onClick: () => void; disabled?: boolean; children: React.ReactNode; icon?: string; testId?: string }): React.ReactElement {
  return <Button variant="text" onClick={props.onClick} disabled={props.disabled} data-testid={props.testId} sx={{ color: PPF.copperText }} startIcon={props.icon ? <Icon name={props.icon} size={18} /> : undefined}>{props.children}</Button>;
}
/** Tlačítko v liště appky (navy pozadí): obrysové světlé. Plné tlačítko patří do obsahu nebo panelu. */
export function BarButton(props: { onClick: () => void; children: React.ReactNode; icon?: string; testId?: string }): React.ReactElement {
  return <Button variant="outlined" onClick={props.onClick} data-testid={props.testId} sx={{ color: PPF.cream, borderColor: 'rgba(246,239,226,.35)', height: 36, '&:hover': { borderColor: PPF.cream, backgroundColor: 'rgba(246,239,226,.08)' } }} startIcon={props.icon ? <Icon name={props.icon} size={18} /> : undefined}>{props.children}</Button>;
}
